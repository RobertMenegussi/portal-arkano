extends Control

@export var mage_type: String = "orbit"
var t: float = 0.0
var aim_direction: Vector2 = Vector2(0.35, 0.10).normalized()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	var c: Vector2 = Vector2(size.x * 0.5, size.y * 0.66)
	var scale_v: float = 1.56
	draw_set_transform(c, 0.0, Vector2(scale_v, scale_v))
	var bob: float = sin(t * 2.0) * 0.35
	var ink: Color = Color("#111111")
	var paper: Color = Color("#faf7ef")
	var accent: Color = Color("#ece5d8")
	match mage_type:
		"storm": accent = Color(0.84, 0.93, 1.0, 0.92)
		"rift": accent = Color(0.86, 0.96, 1.0, 0.88)
		"samurai": accent = Color(1.0, 0.90, 0.90, 0.88)
	_draw_oval(Vector2(0, 23), Vector2(22, 5.0), Color(0.02, 0.02, 0.02, 0.12))
	draw_arc(Vector2(0, 16), 18.0 + sin(t * 1.8) * 1.0, 0.0, TAU, 26, Color(accent.r, accent.g, accent.b, 0.10), 1.0)
	match mage_type:
		"storm": _draw_storm_mage(bob, ink, paper)
		"rift": _draw_rift_mage(bob, ink, paper)
		"samurai": _draw_samurai_mage(bob, ink, paper)
		_: _draw_orbit_mage(bob, ink, paper)
	match mage_type:
		"storm": _draw_storm_magic()
		"rift": _draw_rift_magic()
		"samurai": _draw_samurai_magic()
		_: _draw_magic_stones()
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_orbit_mage(bob: float, ink: Color, paper: Color) -> void:
	var sway: float = sin(t * 2.8) * 0.8
	var torso_shift: Vector2 = Vector2(sin(t * 1.2) * 0.3, 0.0)
	_draw_legs(bob, ink)
	var rear_drape: PackedVector2Array = PackedVector2Array([
		Vector2(-12.0, -9.5 + bob), Vector2(12.0, -9.5 + bob), Vector2(16.0, 3.0 + bob + sway * 0.3),
		Vector2(14.0, 17.0 + bob), Vector2(7.0, 24.0 + bob), Vector2(0.0, 26.0 + bob), Vector2(-7.0, 24.0 + bob), Vector2(-14.0, 17.0 + bob), Vector2(-16.0, 3.0 + bob - sway * 0.3)
	])
	for i in range(rear_drape.size()):
		rear_drape[i] += torso_shift
	draw_colored_polygon(rear_drape, Color(0.05, 0.05, 0.05, 0.42))
	var robe: PackedVector2Array = PackedVector2Array([
		Vector2(-11.2, -9.0 + bob), Vector2(11.2, -9.0 + bob), Vector2(10.2, 3.6 + bob), Vector2(16.0, 19.7 + bob),
		Vector2(8.0, 21.0 + bob), Vector2(0.0, 24.0 + bob), Vector2(-8.0, 21.0 + bob), Vector2(-16.0, 19.7 + bob), Vector2(-10.2, 3.6 + bob)
	])
	for i in range(robe.size()):
		robe[i] += torso_shift
	draw_colored_polygon(robe, ink)
	var inner_panel: PackedVector2Array = PackedVector2Array([
		Vector2(-4.0, -5.0 + bob), Vector2(4.0, -5.0 + bob), Vector2(5.0, 16.0 + bob), Vector2(0.0, 22.0 + bob), Vector2(-5.0, 16.0 + bob)
	])
	for i in range(inner_panel.size()):
		inner_panel[i] += torso_shift
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var mantle: PackedVector2Array = PackedVector2Array([
		Vector2(-13.0, -10.2 + bob), Vector2(13.0, -10.2 + bob), Vector2(10.0, -1.2 + bob), Vector2(4.0, 1.2 + bob), Vector2(0.0, 2.0 + bob), Vector2(-4.0, 1.2 + bob), Vector2(-10.0, -1.2 + bob)
	])
	for i in range(mantle.size()):
		mantle[i] += torso_shift
	draw_colored_polygon(mantle, Color(0.06, 0.06, 0.06, 0.94))
	draw_line(Vector2(-10.0, 7.6 + bob) + torso_shift, Vector2(10.0, 7.6 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.11), 2.0)
	_draw_diamond(Vector2(0.0, 8.6 + bob) + torso_shift, 2.1, Color(1.0, 1.0, 1.0, 0.85))
	draw_line(Vector2(0.0, -6.0 + bob) + torso_shift, Vector2(0.0, 20.0 + bob) + torso_shift, Color(1, 1, 1, 0.14), 1.0)
	for side in [-1.0, 1.0]:
		var rope_top: Vector2 = Vector2(side * 6.8, 8.0 + bob) + torso_shift
		draw_line(rope_top, rope_top + Vector2(side * 2.0, 5.0), Color(1.0, 1.0, 1.0, 0.08), 1.0)
		draw_circle(rope_top + Vector2(side * 2.4, 6.4), 1.0, Color(1.0, 1.0, 1.0, 0.14))
	_draw_diamond(Vector2(0.0, 7.0 + bob) + torso_shift, 3.0 + sin(t * 4.0) * 0.18, paper)
	var head_center := Vector2(0.0, -15.0 + bob)
	_draw_oval(head_center, Vector2(8.7, 10.1), ink)
	var hat_brim: PackedVector2Array = PackedVector2Array([
		Vector2(-19.0, -21.0 + bob), Vector2(19.0, -21.0 + bob), Vector2(12.2, -15.8 + bob), Vector2(-12.2, -15.8 + bob)
	])
	draw_colored_polygon(hat_brim, ink)
	var under_brim: PackedVector2Array = PackedVector2Array([
		Vector2(-10.5, -18.0 + bob), Vector2(10.5, -18.0 + bob), Vector2(7.0, -15.4 + bob), Vector2(-7.0, -15.4 + bob)
	])
	draw_colored_polygon(under_brim, Color(1.0, 1.0, 1.0, 0.04))
	var hat_body: PackedVector2Array = PackedVector2Array([
		Vector2(-9.6, -20.4 + bob), Vector2(9.1, -20.4 + bob), Vector2(8.0, -31.2 + bob), Vector2(3.0, -43.5 + bob + sway),
		Vector2(-1.6, -39.0 + bob + sway * 0.55), Vector2(-8.4, -31.2 + bob)
	])
	draw_colored_polygon(hat_body, ink)
	draw_line(Vector2(-7.0, -24.1 + bob), Vector2(6.6, -24.1 + bob), paper, 1.2)
	_draw_diamond(Vector2(4.6, -28.5 + bob), 1.8, Color(1.0, 1.0, 1.0, 0.42))
	_draw_eyes(head_center, paper)
	_draw_orbit_arms(bob, ink)

func _draw_orbit_arms(bob: float, ink: Color) -> void:
	var left_hand: Vector2 = Vector2(-15.0, 5.0 + bob)
	var right_hand: Vector2 = Vector2(13.0, 2.0 + bob)
	draw_line(Vector2(-7.4, -2.0 + bob), left_hand, ink, 2.8)
	draw_line(Vector2(7.4, -2.5 + bob), right_hand, ink, 2.8)
	draw_colored_polygon(PackedVector2Array([left_hand + Vector2(-2.6, -0.8), left_hand + Vector2(0.1, -1.2), left_hand + Vector2(1.4, 1.1), left_hand + Vector2(-1.4, 1.7)]), Color(1.0, 1.0, 1.0, 0.05))
	draw_colored_polygon(PackedVector2Array([right_hand + Vector2(-0.8, -1.6), right_hand + Vector2(2.1, -0.7), right_hand + Vector2(1.2, 1.7), right_hand + Vector2(-1.6, 1.0)]), Color(1.0, 1.0, 1.0, 0.05))
	_draw_oval(left_hand + Vector2(-0.4, 0.8), Vector2(3.0, 2.1), ink)
	_draw_oval(right_hand + Vector2(0.6, 0.3), Vector2(3.0, 2.1), ink)
	var focus: Vector2 = right_hand + Vector2(6.0 + sin(t * 3.4) * 1.3, -5.0 + cos(t * 4.0) * 1.3)
	draw_line(right_hand, focus, Color(0.08, 0.08, 0.08, 0.34), 1.1)
	_draw_diamond(focus, 1.8 + sin(t * 4.6) * 0.24, Color(1, 1, 1, 0.40))

func _draw_storm_mage(bob: float, ink: Color, paper: Color) -> void:
	var gust: float = sin(t * 2.6) * 0.7
	_draw_legs(bob, ink)
	var rear_cloak: PackedVector2Array = PackedVector2Array([
		Vector2(-16.0, -8.0 + bob), Vector2(16.0, -8.0 + bob), Vector2(22.0, 3.0 + bob + gust * 0.30),
		Vector2(18.0, 17.0 + bob), Vector2(8.0, 25.0 + bob), Vector2(0.0, 22.0 + bob),
		Vector2(-8.0, 25.0 + bob), Vector2(-18.0, 17.0 + bob), Vector2(-22.0, 3.0 + bob - gust * 0.30)
	])
	draw_colored_polygon(rear_cloak, Color(0.05, 0.05, 0.05, 0.44))
	var coat: PackedVector2Array = PackedVector2Array([
		Vector2(-13.2, -8.0 + bob), Vector2(13.2, -8.0 + bob), Vector2(12.0, 4.0 + bob),
		Vector2(18.0, 19.5 + bob), Vector2(8.2, 18.0 + bob), Vector2(0.0, 24.0 + bob),
		Vector2(-8.2, 18.0 + bob), Vector2(-18.0, 19.5 + bob), Vector2(-12.0, 4.0 + bob)
	])
	draw_colored_polygon(coat, ink)
	var inner_panel: PackedVector2Array = PackedVector2Array([
		Vector2(-4.4, -3.5 + bob), Vector2(4.4, -3.5 + bob), Vector2(5.2, 16.0 + bob), Vector2(0.0, 21.8 + bob), Vector2(-5.2, 16.0 + bob)
	])
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var mantle: PackedVector2Array = PackedVector2Array([
		Vector2(-17.0, -8.8 + bob), Vector2(17.0, -8.8 + bob), Vector2(11.0, -1.4 + bob), Vector2(4.0, 1.6 + bob), Vector2(0.0, 2.4 + bob), Vector2(-4.0, 1.6 + bob), Vector2(-11.0, -1.4 + bob)
	])
	draw_colored_polygon(mantle, Color(0.07, 0.07, 0.07, 0.95))
	draw_line(Vector2(0.0, -1.5 + bob), Vector2(0.0, 22.0 + bob), Color(1.0, 1.0, 1.0, 0.14), 1.0)
	draw_polyline(PackedVector2Array([Vector2(-6.5, 3.0 + bob), Vector2(1.8, 8.6 + bob), Vector2(-2.5, 13.8 + bob), Vector2(7.0, 18.2 + bob)]), paper, 1.45)
	draw_line(Vector2(-10.0, 7.3 + bob), Vector2(10.0, 7.3 + bob), Color(1.0, 1.0, 1.0, 0.07), 1.1)
	_draw_diamond(Vector2(0.0, 8.1 + bob), 2.3, Color(1.0, 1.0, 1.0, 0.86))
	for side in [-1.0, 1.0]:
		var tassel_top: Vector2 = Vector2(side * 7.4, 8.7 + bob)
		draw_line(tassel_top, tassel_top + Vector2(side * 2.0, 5.0), Color(1.0, 1.0, 1.0, 0.08), 1.0)
		draw_circle(tassel_top + Vector2(side * 2.5, 6.5), 1.0, Color(1.0, 1.0, 1.0, 0.16))
	var head_center: Vector2 = Vector2(0.0, -15.0 + bob)
	_draw_oval(head_center, Vector2(8.9, 10.3), ink)
	var hood: PackedVector2Array = PackedVector2Array([
		Vector2(-13.0, -21.0 + bob), Vector2(13.0, -21.0 + bob), Vector2(11.2, -33.0 + bob), Vector2(4.0, -42.0 + bob + gust), Vector2(-1.0, -39.0 + bob + gust * 0.5), Vector2(-10.8, -31.0 + bob)
	])
	draw_colored_polygon(hood, ink)
	var crown: PackedVector2Array = PackedVector2Array([
		Vector2(-17.0, -20.0 + bob), Vector2(-11.2, -36.0 + bob), Vector2(-4.8, -31.0 + bob), Vector2(-1.0, -44.0 + bob), Vector2(3.4, -35.0 + bob), Vector2(8.4, -41.0 + bob), Vector2(15.8, -20.0 + bob)
	])
	draw_colored_polygon(crown, ink)
	draw_line(Vector2(-9.0, -24.5 + bob), Vector2(9.0, -24.5 + bob), paper, 1.1)
	draw_circle(Vector2(0.5, -31.0 + bob), 1.0, Color(1.0, 1.0, 1.0, 0.22))
	_draw_eyes(head_center, paper)
	_draw_arms(bob, ink, 4.2)
	for side in [-1.0, 1.0]:
		var hand: Vector2 = Vector2(side * 18.0, 5.0 + bob)
		for bolt in range(2):
			var j: float = float(bolt)
			var tip: Vector2 = hand + Vector2(side * (4.5 + j * 3.2), -5.5 - j * 2.8 + sin(t * 7.0 + side + j) * 2.1)
			draw_line(hand, tip, Color(0.82, 0.92, 1.0, 0.20), 2.1 - j * 0.35)
			draw_line(hand, tip, Color(0.08, 0.08, 0.08, 0.24), 1.0)
			draw_circle(tip, 1.1, Color(1.0, 1.0, 1.0, 0.18))

func _draw_rift_mage(bob: float, ink: Color, paper: Color) -> void:
	_draw_legs(bob, ink)
	var left: PackedVector2Array = PackedVector2Array([Vector2(-15, -7 + bob), Vector2(-1, -8 + bob), Vector2(-2, 19 + bob), Vector2(-12, 25 + bob), Vector2(-20, 16 + bob)])
	var right: PackedVector2Array = PackedVector2Array([Vector2(1, -8 + bob), Vector2(12, -6 + bob), Vector2(17, 15 + bob), Vector2(6, 18 + bob), Vector2(2, 22 + bob)])
	draw_colored_polygon(left, ink)
	draw_colored_polygon(right, Color(0.08, 0.08, 0.08, 0.76))
	draw_line(Vector2(0, -7 + bob), Vector2(-2, 20 + bob), paper, 1.4)
	_draw_oval(Vector2(0, -14 + bob), Vector2(10, 11), ink)
	var hood: PackedVector2Array = PackedVector2Array([Vector2(-15, -19 + bob), Vector2(15, -19 + bob), Vector2(10, -34 + bob), Vector2(2, -39 + bob), Vector2(-8, -35 + bob), Vector2(-13, -27 + bob)])
	draw_colored_polygon(hood, ink)
	draw_line(Vector2(1, -34 + bob), Vector2(-1, -18 + bob), paper, 1.2)
	_draw_eyes(Vector2(0, -14 + bob), paper)
	_draw_arms(bob, ink, -2.0)

func _draw_samurai_mage(bob: float, ink: Color, paper: Color) -> void:
	var cloth_dark: Color = Color(0.06, 0.06, 0.07, 0.97)
	var cloth_mid: Color = Color(0.10, 0.10, 0.12, 0.96)
	var crimson: Color = Color(0.62, 0.19, 0.22, 0.82)
	var gold: Color = Color(0.83, 0.69, 0.40, 0.66)
	_draw_legs(bob, ink)
	var rear_cloak: PackedVector2Array = PackedVector2Array([Vector2(-16.0, -7.0 + bob), Vector2(16.0, -7.0 + bob), Vector2(19.5, 2.5 + bob), Vector2(16.0, 15.5 + bob), Vector2(8.0, 24.5 + bob), Vector2(0.0, 21.0 + bob), Vector2(-8.0, 24.5 + bob), Vector2(-16.0, 15.5 + bob), Vector2(-19.5, 2.5 + bob)])
	draw_colored_polygon(rear_cloak, Color(0.04, 0.04, 0.04, 0.34))
	var hakama: PackedVector2Array = PackedVector2Array([Vector2(-15.0, 2.5 + bob), Vector2(-6.2, -0.8 + bob), Vector2(0.0, 18.8 + bob), Vector2(6.2, -0.8 + bob), Vector2(15.0, 2.5 + bob), Vector2(12.4, 18.4 + bob), Vector2(5.4, 16.8 + bob), Vector2(0.0, 22.5 + bob), Vector2(-5.4, 16.8 + bob), Vector2(-12.4, 18.4 + bob)])
	draw_colored_polygon(hakama, cloth_dark)
	var torso: PackedVector2Array = PackedVector2Array([Vector2(-14.0, -10.6 + bob), Vector2(14.0, -10.6 + bob), Vector2(11.8, 5.8 + bob), Vector2(2.0, 10.6 + bob), Vector2(-12.2, 6.2 + bob)])
	draw_colored_polygon(torso, cloth_mid)
	var inner_panel: PackedVector2Array = PackedVector2Array([Vector2(-4.6, -5.2 + bob), Vector2(3.9, -5.2 + bob), Vector2(4.5, 13.4 + bob), Vector2(0.0, 18.5 + bob), Vector2(-4.7, 13.4 + bob)])
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var sash: PackedVector2Array = PackedVector2Array([Vector2(-11.5, 4.5 + bob), Vector2(11.5, 4.5 + bob), Vector2(9.8, 8.8 + bob), Vector2(-9.8, 8.8 + bob)])
	draw_colored_polygon(sash, crimson)
	draw_line(Vector2(-8.8, -4.4 + bob), Vector2(7.2, 4.8 + bob), paper, 1.2)
	for fold in range(4):
		var xx: float = -5.8 + float(fold) * 3.8
		draw_line(Vector2(xx, 6.0 + bob), Vector2(xx * 0.55, 19.8 + bob), Color(1.0, 1.0, 1.0, 0.055), 0.8)
	_draw_diamond(Vector2(0.0, 6.8 + bob), 1.8, gold)
	var head_center: Vector2 = Vector2(0.0, -17.2 + bob)
	_draw_oval(head_center, Vector2(10.7, 10.9), ink)
	draw_line(head_center + Vector2(-10.4, -1.2), head_center + Vector2(10.4, -1.2), paper, 1.55)
	draw_circle(head_center + Vector2(8.8, -1.1), 1.2, cloth_dark)
	draw_line(head_center + Vector2(8.2, -2.2), head_center + Vector2(16.2, -8.3), ink, 1.75)
	draw_line(head_center + Vector2(8.2, -1.0), head_center + Vector2(17.2, 0.8), ink, 1.45)
	_draw_eyes(head_center, paper)
	var sheath_dir := Vector2(0.96, 0.24).normalized()
	var sheath_center := Vector2(-8.6, 8.0 + bob)
	draw_line(sheath_center - sheath_dir * 7.0, sheath_center + sheath_dir * 25.6, Color(0.07, 0.07, 0.07, 0.98), 3.5)
	draw_line(sheath_center + sheath_dir * 4.0, sheath_center + sheath_dir * 16.5, Color(crimson.r, crimson.g, crimson.b, 0.62), 1.0)
	draw_line(sheath_center + sheath_dir * 17.8, sheath_center + sheath_dir * 22.8, gold, 1.0)
	draw_circle(sheath_center - sheath_dir * 0.4, 1.05, gold)
	draw_line(Vector2(7.0, -2.2 + bob), Vector2(14.5, 3.8 + bob), ink, 2.8)
	draw_line(Vector2(-7.0, -2.2 + bob), Vector2(-13.8, 4.8 + bob), ink, 2.8)

func _draw_samurai_magic() -> void:
	var angle: float = -0.12 + sin(t * 1.2) * 0.08
	draw_arc(Vector2(8, 0), 54.0, angle - 0.66, angle + 0.08, 22, Color(1.0, 0.93, 0.95, 0.18), 5.2)
	draw_arc(Vector2(8, 0), 54.0, angle + 0.02, angle + 0.76, 22, Color(1.0, 0.93, 0.95, 0.10), 3.2)
	draw_arc(Vector2(8, 0), 54.0, angle - 0.66, angle + 0.08, 22, Color(0.08, 0.08, 0.08, 0.20), 1.5)
	var tip := Vector2(cos(angle), sin(angle)) * 48.0
	draw_line(Vector2(-6, 2), tip, Color(1.0, 0.96, 0.98, 0.12), 2.2)
	draw_line(Vector2(-6, 2), tip, Color(0.08, 0.08, 0.08, 0.18), 1.0)

func _draw_legs(bob: float, ink: Color) -> void:


	draw_line(Vector2(-6, 13 + bob), Vector2(-7, 20), ink, 3.0)
	draw_line(Vector2(6, 13 + bob), Vector2(7, 20), ink, 3.0)
	draw_line(Vector2(-11, 20), Vector2(-3, 20), ink, 2.3)
	draw_line(Vector2(3, 20), Vector2(11, 20), ink, 2.3)

func _draw_arms(bob: float, ink: Color, spread: float) -> void:
	draw_line(Vector2(-9, -1 + bob), Vector2(-14 - spread, 7 + bob), ink, 3.0)
	draw_line(Vector2(9, -1 + bob), Vector2(14 + spread, 7 + bob), ink, 3.0)
	_draw_oval(Vector2(-14 - spread, 8 + bob), Vector2(3.2, 2.3), ink)
	_draw_oval(Vector2(14 + spread, 8 + bob), Vector2(3.2, 2.3), ink)

func _draw_eyes(center: Vector2, paper: Color) -> void:
	var look: Vector2 = aim_direction * 1.6
	draw_circle(center + Vector2(-4, 0) + look, 2.3, paper)
	draw_circle(center + Vector2(4, 0) + look, 2.3, paper)
	draw_circle(center + Vector2(-4, 0) + look + aim_direction * 0.45, 0.65, Color("#111111"))
	draw_circle(center + Vector2(4, 0) + look + aim_direction * 0.45, 0.65, Color("#111111"))

func _draw_magic_stones() -> void:
	var center: Vector2 = Vector2(0.0, -5.0)
	var points: Array[Vector2] = []
	for i in range(6):
		var a: float = t * 0.62 + float(i) * TAU / 6.0
		var pos: Vector2 = Vector2(cos(a) * 48.0, sin(a) * 37.0 - 5.0)
		points.append(pos)
		var dir: Vector2 = (pos - center).normalized()
		var tangent: Vector2 = Vector2(-dir.y, dir.x)
		draw_arc(center, pos.distance_to(center), a - 0.24, a + 0.24, 12, Color(0.08, 0.08, 0.08, 0.06), 1.0)
		for trail_i in range(2, -1, -1):
			var trail_pos: Vector2 = pos - tangent * float(trail_i + 1) * 4.8
			draw_circle(trail_pos, 5.8 - float(trail_i) * 0.9, Color(0.84, 0.93, 1.0, (0.12 - float(trail_i) * 0.03) * 0.34))
		draw_circle(pos, 8.8, Color(0.84, 0.93, 1.0, 0.08))
		_draw_diamond(pos, 5.0 + sin(t * 4.0 + float(i)) * 0.35, Color("#faf7ef"))
		draw_arc(pos, 7.0, 0.0, TAU, 14, Color(0.08, 0.08, 0.08, 0.38), 1.1)
		draw_line(center + dir * 14.0, pos - dir * 7.0, Color(0.08, 0.08, 0.08, 0.10), 1.0)
	for i in range(points.size()):
		var a_pt: Vector2 = points[i]
		var b_pt: Vector2 = points[(i + 1) % points.size()]
		if a_pt.distance_to(b_pt) < 52.0:
			draw_line(a_pt, b_pt, Color(0.08, 0.08, 0.08, 0.04), 1.0)

func _draw_storm_magic() -> void:
	for i in range(5):
		var a: float = t * 1.35 + float(i) * TAU / 5.0
		var p: Vector2 = Vector2(cos(a) * 39.0, sin(a) * 27.0 - 8.0)
		var p2: Vector2 = p + Vector2(sin(a * 2.0) * 5.0, -8.0)
		draw_circle(p, 8.0, Color(0.82, 0.92, 1.0, 0.03))
		draw_line(p, p2, Color(0.82, 0.92, 1.0, 0.20), 3.0)
		draw_line(p, p2, Color(0.08, 0.08, 0.08, 0.34), 1.3)
		draw_circle(p2, 1.3, Color(0.08, 0.08, 0.08, 0.85))

func _draw_rift_magic() -> void:
	for i in range(2):
		var side: float = -1.0 if i == 0 else 1.0
		var rc: Vector2 = Vector2(side * 35.0, -8.0)
		draw_arc(rc, 10.5 + sin(t * 3.0 + float(i)), -1.25, 1.25, 14, Color(0.82, 0.94, 1.0, 0.18), 3.0)
		draw_arc(rc, 10.5 + sin(t * 3.0 + float(i)), -1.25, 1.25, 14, Color(0.08, 0.08, 0.08, 0.38), 1.5)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		pts.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(pts, color)

func _draw_diamond(center: Vector2, radius_value: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([center + Vector2(0, -radius_value), center + Vector2(radius_value * 0.75, 0), center + Vector2(0, radius_value), center + Vector2(-radius_value * 0.75, 0)])
	draw_colored_polygon(poly, color)
