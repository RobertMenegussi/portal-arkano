extends Node2D

var pieces: Array = []
var elapsed: float = 0.0
var settled: bool = false
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("run_decal")
	z_index = 10
	pieces = [
		{"kind":"skull", "pos":Vector2(0,-18), "vel":Vector2(randf_range(-65,65), randf_range(-165,-115)), "rot":0.0, "spin":randf_range(-6.0,6.0)},
		{"kind":"bone", "pos":Vector2(-8,0), "vel":Vector2(randf_range(-110,-50), randf_range(-135,-80)), "rot":0.0, "spin":randf_range(-7.0,-3.0)},
		{"kind":"bone", "pos":Vector2(8,0), "vel":Vector2(randf_range(50,110), randf_range(-135,-80)), "rot":0.0, "spin":randf_range(3.0,7.0)},
		{"kind":"bone", "pos":Vector2(-5,9), "vel":Vector2(randf_range(-80,-30), randf_range(-100,-60)), "rot":0.0, "spin":randf_range(-5.0,2.0)},
		{"kind":"bone", "pos":Vector2(5,9), "vel":Vector2(randf_range(30,80), randf_range(-100,-60)), "rot":0.0, "spin":randf_range(-2.0,5.0)}
	]

func _process(delta: float) -> void:
	if settled:
		return
	elapsed += delta

	for piece in pieces:
		var pos: Vector2 = piece["pos"]
		var vel: Vector2 = piece["vel"]
		var rot: float = piece["rot"]
		var spin: float = piece["spin"]

		vel.y += 350.0 * delta
		pos += vel * delta
		rot += spin * delta

		if pos.y > 19.0:
			pos.y = 19.0
			if absf(vel.y) > 20.0:
				vel.y *= -0.20
			else:
				vel.y = 0.0
			vel.x *= 0.62
			spin *= 0.60

		piece["pos"] = pos
		piece["vel"] = vel
		piece["rot"] = rot
		piece["spin"] = spin

	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()
	if elapsed >= 1.0:
		var batch = get_tree().get_first_node_in_group("death_decal_batch")
		if is_instance_valid(batch) and batch.has_method("add_skeleton"):
			batch.add_skeleton(global_position,pieces)
			queue_free()
			return
		settled = true
		set_process(false)

func _draw() -> void:
	for piece in pieces:
		var pos: Vector2 = piece["pos"]
		var rot: float = piece["rot"]
		if piece["kind"] == "skull":
			draw_circle(pos, 7.5, Color("#f6f1e5"))
			draw_arc(pos, 7.5, 0.0, TAU, 20, Color("#171717"), 1.4)
			draw_circle(pos + Vector2(-2.8, -0.8).rotated(rot), 1.6, Color("#171717"))
			draw_circle(pos + Vector2(2.8, -0.8).rotated(rot), 1.6, Color("#171717"))
		else:
			var dir := Vector2(9.0, 0).rotated(rot)
			draw_line(pos - dir, pos + dir, Color("#171717"), 2.4)
