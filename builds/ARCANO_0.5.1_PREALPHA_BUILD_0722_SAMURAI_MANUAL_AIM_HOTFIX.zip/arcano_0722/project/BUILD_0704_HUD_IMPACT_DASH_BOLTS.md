# BUILD 0704 — HUD impact animation + dash bolt containers

## Changes
- HUD portrait now has a clearer hit impact animation when the player takes damage.
- The face jerks on impact and shows extra anime-like impact streaks.
- Dash display was redesigned on the old HUD:
  - removed the seconds readout
  - dash is now shown as lightning bolt containers above the portrait
  - each bolt represents one dash charge
  - available charges appear full
  - the next recovering charge fills progressively until it returns
  - extra dash charges from runes naturally create more bolt icons

## Files changed
- hud_display.gd
- endless_main.gd
