extends Area2D

@export var speed: float = 410.0
@export var damage: int = 1
@export var lifetime: float = 2.7

var direction: Vector2 = Vector2.RIGHT
var age: float = 0.0
var dodge_awarded: bool = false
var target_player = null
var expire_at_msec: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy_projectile")
	collision_layer = 16
	collision_mask = 1 | 2
	monitoring = true
	z_index = 26
	rotation = direction.angle()

	var collider := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(18, 4)
	collider.shape = shape
	add_child(collider)

	body_entered.connect(_on_body_entered)
	target_player = get_tree().get_first_node_in_group("player")
	expire_at_msec = Time.get_ticks_msec()+int(lifetime*1000.0)

func _physics_process(delta: float) -> void:
	age += delta
	if Time.get_ticks_msec() >= expire_at_msec:
		queue_free()
		return
	global_position += direction*speed*delta
	if not dodge_awarded and is_instance_valid(target_player):
		if target_player.get("dash_active") == true and global_position.distance_squared_to(target_player.global_position) < 34.0*34.0:
			dodge_awarded = true
			if target_player.has_method("on_perfect_dodge"):
				target_player.on_perfect_dodge()

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		if body.get("dash_active") == true and not dodge_awarded and body.has_method("on_perfect_dodge"):
			dodge_awarded = true
			body.on_perfect_dodge()
		body.take_damage(damage, direction)
		queue_free()
	elif body is StaticBody2D:
		queue_free()

func _draw() -> void:
	draw_line(Vector2(-12, 0), Vector2(10, 0), Color("#171717"), 2.0)
	draw_colored_polygon(PackedVector2Array([
		Vector2(12, 0),
		Vector2(5, -4),
		Vector2(5, 4)
	]), Color("#171717"))
	draw_line(Vector2(-12, 0), Vector2(-18, -5), Color("#171717"), 1.4)
	draw_line(Vector2(-12, 0), Vector2(-18, 5), Color("#171717"), 1.4)
	draw_line(Vector2(-28, 0), Vector2(-16, 0), Color(0.08, 0.08, 0.08, 0.10), 1.3)
