extends Control

var controller
var t: float = 0.0
var redraw_timer: float = 0.0

func configure(source) -> void:
	controller = source

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	redraw_timer -= delta
	if redraw_timer <= 0.0:
		redraw_timer = 1.0/30.0
		queue_redraw()

func _draw() -> void:
	if not is_instance_valid(controller):
		return
	var current: float = float(controller.xp)
	var needed: float = maxf(1.0, float(controller.xp_needed))
	var ratio: float = clampf(current / needed, 0.0, 1.0)
	var ink: Color = Color(0.07,0.07,0.07,0.78)
	var ghost: Color = Color(0.07,0.07,0.07,0.12)
	var soft: Color = Color(0.07,0.07,0.07,0.40)
	var font = ThemeDB.fallback_font

	# Small rune crest ties XP to level without looking like a stock progress bar.
	var crest: Vector2 = Vector2(8,16)
	_draw_diamond(crest,5.0,ink)
	draw_arc(crest,9.0,-PI*0.72,PI*0.72,16,ghost,1.2)

	var start: Vector2 = Vector2(24,22)
	var end: Vector2 = Vector2(250,22)
	# uneven twin strokes = hand-drawn channel
	draw_line(start,end,ghost,3.0)
	draw_line(start+Vector2(0,-1),end+Vector2(0,-1),Color(0.07,0.07,0.07,0.07),1.0)
	var fill_end: Vector2 = start.lerp(end,ratio)
	draw_line(start,fill_end,ink,3.0)
	# progression notches
	for i in range(9):
		var f: float = float(i)/8.0
		var p: Vector2 = start.lerp(end,f)
		var lit: bool = f <= ratio + 0.001
		var h: float = 3.0 if i % 2 == 0 else 2.0
		draw_line(p+Vector2(0,-h),p+Vector2(0,h),ink if lit else ghost,1.0)
	# moving ink fleck at the current edge
	if ratio > 0.01 and ratio < 0.995:
		var pulse: float = 1.8 + sin(t*7.0)*0.5
		draw_circle(fill_end,pulse,Color(0.08,0.08,0.08,0.46))

	if font != null:
		draw_string(font,Vector2(24,11),Loc.t("hud.experience"),HORIZONTAL_ALIGNMENT_LEFT,120,8,soft)
		draw_string(font,Vector2(174,11),str(int(current))+" / "+str(int(needed)),HORIZONTAL_ALIGNMENT_RIGHT,76,8,soft)

func _draw_diamond(center: Vector2, radius_value: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center+Vector2(0,-radius_value),
		center+Vector2(radius_value*0.74,0),
		center+Vector2(0,radius_value),
		center+Vector2(-radius_value*0.74,0)
	])
	draw_colored_polygon(poly,color)
