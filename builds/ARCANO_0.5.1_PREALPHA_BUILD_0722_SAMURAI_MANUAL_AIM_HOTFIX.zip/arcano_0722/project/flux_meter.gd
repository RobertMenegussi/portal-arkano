extends Control

var player
var t: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if not is_instance_valid(player):
		return
	var ink: Color = Color("#111111")
	var font = ThemeDB.fallback_font
	var panel: Rect2 = Rect2(Vector2.ZERO,size)
	draw_rect(panel,Color(1,1,1,0.78),true)
	draw_rect(panel,Color(0.08,0.08,0.08,0.14),false,1.0)
	var ratio: float = clampf(player.flux/100.0,0.0,1.0)
	var bar: Rect2 = Rect2(Vector2(62,14),Vector2(maxf(0.0,size.x-78.0),8))
	draw_rect(bar,Color(0.08,0.08,0.08,0.08),true)
	if player.flux_active:
		var pulse: float = 0.72+sin(t*10.0)*0.12
		draw_rect(Rect2(bar.position,Vector2(bar.size.x,bar.size.y)),Color(0.05,0.05,0.05,pulse),true)
		for i in range(4):
			var x: float = bar.position.x+fmod(t*85.0+float(i)*41.0,maxf(1.0,bar.size.x))
			draw_line(Vector2(x,bar.position.y-2),Vector2(x-9,bar.end.y+2),Color(1,1,1,0.28),1.0)
	else:
		draw_rect(Rect2(bar.position,Vector2(bar.size.x*ratio,bar.size.y)),ink,true)
	if font != null:
		draw_string(font,Vector2(10,22),Loc.t("hud.flow"),HORIZONTAL_ALIGNMENT_LEFT,48,9,Color(0.08,0.08,0.08,0.42))
		var state_text: String = Loc.t("hud.surge") if player.flux_active else (Loc.t("hud.resonance")+" %ds" % int(ceil(float(player.flux_recharge_timer))) if float(player.flux_recharge_timer) > 0.0 else str(int(player.flux))+"%")
		draw_string(font,Vector2(62,38),state_text,HORIZONTAL_ALIGNMENT_LEFT,size.x-76.0,9,Color(0.08,0.08,0.08,0.48))
