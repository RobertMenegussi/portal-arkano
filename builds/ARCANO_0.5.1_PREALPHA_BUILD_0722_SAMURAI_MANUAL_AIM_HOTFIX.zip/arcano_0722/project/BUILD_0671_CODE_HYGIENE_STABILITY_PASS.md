# ARCANO 0.5.1-prealpha — Build 0671

## Code Hygiene / Stability Pass

Targeted cleanup based on the Godot runtime error and GDScript warnings reported during Build 0670 playtesting. No gameplay, balance, content, visual design, Rune behavior, enemy count, music, or tutorial flow was intentionally changed in this pass.

### Runtime fix
- `player.gd`: fixed `Camera2D.make_current()` initialization order.
- The dynamic camera is now explicitly enabled, added to the SceneTree, and only then made current.
- This removes the reported `!enabled || !is_inside_tree()` condition at player startup instead of suppressing it.

### GDScript warning cleanup
- Renamed local `ease` variables in `tutorial_dialogue_panel.gd` to avoid shadowing the built-in `ease()` function.
- Replaced intentional integer layout division with explicit floating division + `floori()` in:
  - `initial_language_screen.gd`
  - `run_inventory_panel.gd`
  - `hud_display.gd`
- Renamed local `name` variables that shadow `Node.name` in:
  - `run_inventory_panel.gd`
  - `hud_display.gd`
- Renamed built-in-shadowing locals:
  - `len` -> `cut_length` in `arcano_logo.gd`
  - `seed` -> contextual seed names in `endless_menu_backdrop.gd`
- Removed the dead `phrase_spoken` signal path from `menu_blob.gd`/legacy `main.gd`; it was connected but had no emitter.
- Marked intentionally unused parameters with underscore names in `radial_menu_blur.gd` and `hud_display.gd`.
- Renamed the `xp_orb.gd` pickup-radius parameter so it no longer shadows the orb's `value` member.
- Removed reported dead locals from:
  - `boss_bone_cage.gd`
  - `player.gd`
  - `endless_catalog.gd`

### Extra hygiene found during the same pass
- Legacy `main.gd` contained three additional locals named `seed`, which also shadow the GDScript built-in. These were renamed without changing their math.

## Reported diagnostics addressed
The pass targets all 22 diagnostics from the supplied Godot output:
- 1 Camera2D runtime condition error
- 2 `ease` shadow warnings
- 3 integer-division warnings
- 4 `name`/base-class shadow warnings
- 1 `len` built-in shadow warning
- 1 unused signal warning
- 1 unused `_process` parameter warning
- 1 `seed` built-in shadow warning
- 1 parameter shadow warning in XP orb
- 3 unused HUD parameters
- 4 unused/dead local warnings

## Validation
- Build constant bumped to `0671`.
- All reported warning patterns were checked after patching.
- `res://` load/preload targets were checked.
- GDScript delimiter/string sanity scan passed.
- No Godot executable is installed in this environment, so the final authoritative check is opening/running the project in Godot and confirming the Output/Debugger remains clean.
