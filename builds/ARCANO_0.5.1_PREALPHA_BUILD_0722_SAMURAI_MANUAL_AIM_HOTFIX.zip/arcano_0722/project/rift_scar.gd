extends Node2D

const ArcaneBurstScript = preload("res://arcane_burst.gd")

var direction: Vector2 = Vector2.RIGHT
var length: float = 340.0
var width: float = 28.0
var damage: int = 1
var tick_interval: float = 0.90
var duration: float = 4.0
var grow_duration: float = 0.18
var owner_player
var pull_strength: float = 0.0
var end_burst: bool = false

var t: float = 0.0
var hit_check_timer: float = 0.0
var next_hit_time: Dictionary = {}
var path_points: Array = []
var branch_data: Array = []
var cached_controller = null
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 18
	add_to_group("rift_scar")
	if direction.length_squared() < 0.001:
		direction = Vector2.RIGHT
	direction = direction.normalized()
	rotation = direction.angle()
	_build_crack()
	cached_controller = get_tree().get_first_node_in_group("endless_controller")
	get_tree().call_group("audio_bus", "play_rift")
	get_tree().call_group("screen_fx", "pulse_rift_cast")

func _process(delta: float) -> void:
	t += delta
	hit_check_timer -= delta
	if hit_check_timer <= 0.0:
		hit_check_timer = 0.14
		_damage_enemies()
	if t >= duration:
		if end_burst:
			var burst = ArcaneBurstScript.new()
			burst.radius = maxf(48.0,width*2.2)
			burst.damage = maxi(1,damage)
			burst.global_position = global_position+direction*length
			get_tree().current_scene.add_child(burst)
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/24.0
		queue_redraw()

func _growth() -> float:
	return clampf(t / maxf(0.01, grow_duration), 0.0, 1.0)

func _fade() -> float:
	var remaining: float = duration - t
	if remaining >= 0.65:
		return 1.0
	return clampf(remaining / 0.65, 0.0, 1.0)

func _damage_enemies() -> void:
	var growth: float = _growth()
	if growth <= 0.02:
		return
	var start_world: Vector2 = global_position
	var end_world: Vector2 = global_position + direction * length * growth
	var now: float = t
	var query_center: Vector2 = (start_world+end_world)*0.5
	var query_radius: float = start_world.distance_to(end_world)*0.5+width*2.8+24.0
	var targets: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		targets = cached_controller.get_nearby_enemies(query_center,query_radius)
	targets.append_array(get_tree().get_nodes_in_group("basic_target"))
	for enemy in targets:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		if enemy.get("dead") == true:
			continue
		var id: int = enemy.get_instance_id()
		if float(next_hit_time.get(id, -1.0)) > now:
			continue
		var dist: float = _distance_to_segment(enemy.global_position, start_world, end_world)
		if pull_strength > 0.0 and dist <= width*2.4 and enemy.has_method("apply_external_force"):
			var closest: Vector2 = _closest_point_on_segment(enemy.global_position,start_world,end_world)
			var pull_dir: Vector2 = (closest-enemy.global_position).normalized()
			enemy.apply_external_force(pull_dir*pull_strength)
		if dist <= width:
			next_hit_time[id] = now + tick_interval
			enemy.take_damage(maxi(1, damage), direction)
			get_tree().call_group("screen_fx", "pulse_rift_hit")

func _closest_point_on_segment(point: Vector2,a: Vector2,b: Vector2) -> Vector2:
	var ab: Vector2 = b-a
	var denom: float = ab.length_squared()
	if denom <= 0.0001:
		return a
	var u: float = clampf((point-a).dot(ab)/denom,0.0,1.0)
	return a+ab*u

func _distance_to_segment(point: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var denom: float = ab.length_squared()
	if denom <= 0.0001:
		return point.distance_to(a)
	var u: float = clampf((point - a).dot(ab) / denom, 0.0, 1.0)
	return point.distance_to(a + ab * u)

func _build_crack() -> void:
	path_points.clear()
	branch_data.clear()
	var count: int = 14
	for i in range(count):
		var f: float = float(i) / float(count - 1)
		var x: float = length * f
		var envelope: float = sin(f * PI)
		var y: float = sin(float(i) * 2.17 + 0.8) * (5.0 + envelope * 8.0)
		if i == 0 or i == count - 1:
			y = 0.0
		path_points.append(Vector2(x, y))
		if i > 1 and i < count - 2 and i % 2 == 0:
			var side: float = -1.0 if i % 4 == 0 else 1.0
			branch_data.append({
				"index": i,
				"side": side,
				"length": 18.0 + float(i % 3) * 7.0
			})

func _draw() -> void:
	if path_points.size() < 2:
		return
	var growth: float = _growth()
	var fade: float = _fade()
	var ink: Color = Color(0.04, 0.04, 0.04, 0.84 * fade)
	var soft: Color = Color(0.76, 0.90, 0.98, 0.10 * fade)
	var max_x: float = length * growth

	draw_line(Vector2(0, width), Vector2(max_x, width), Color(0.04, 0.04, 0.04, 0.03 * fade), 1.0)
	draw_line(Vector2(0, -width), Vector2(max_x, -width), Color(0.04, 0.04, 0.04, 0.03 * fade), 1.0)
	for i in range(5):
		var scan_y: float = lerpf(-width * 0.82, width * 0.82, float(i) / 4.0)
		draw_line(Vector2(0, scan_y), Vector2(max_x, scan_y), Color(soft.r, soft.g, soft.b, 0.015 * fade), 1.0)

	for i in range(path_points.size() - 1):
		var a: Vector2 = path_points[i]
		var b: Vector2 = path_points[i + 1]
		if a.x > max_x:
			break
		if b.x > max_x:
			var ratio: float = clampf((max_x - a.x) / maxf(0.001, b.x - a.x), 0.0, 1.0)
			b = a.lerp(b, ratio)
		draw_line(a, b, Color(soft.r, soft.g, soft.b, 0.18 * fade), 5.0)
		draw_line(a, b, ink, 2.8)
		draw_line(a + Vector2(0, 2.0), b + Vector2(0, 2.0), Color(0.04, 0.04, 0.04, 0.22 * fade), 1.0)

	for branch_value in branch_data:
		var branch: Dictionary = branch_value
		var idx: int = int(branch.get("index", 0))
		if idx < 0 or idx >= path_points.size():
			continue
		var origin: Vector2 = path_points[idx]
		if origin.x > max_x:
			continue
		var side: float = float(branch.get("side", 1.0))
		var branch_len: float = float(branch.get("length", 20.0))
		var tip: Vector2 = origin + Vector2(branch_len * 0.72, side * branch_len)
		var end_tip: Vector2 = tip + Vector2(branch_len * 0.45, -side * branch_len * 0.28)
		draw_line(origin, tip, Color(soft.r, soft.g, soft.b, 0.10 * fade), 2.6)
		draw_line(origin, tip, Color(ink.r, ink.g, ink.b, 0.46 * fade), 1.4)
		draw_line(tip, end_tip, Color(ink.r, ink.g, ink.b, 0.26 * fade), 1.0)

	if growth >= 0.98:
		for i in range(10):
			var f2: float = (float(i) + 0.5) / 10.0
			var base: Vector2 = Vector2(length * f2, sin(float(i) * 2.17 + 0.8) * 6.0)
			var phase: float = fmod(t * (0.58 + float(i) * 0.035) + float(i) * 0.13, 1.0)
			var lift: float = 7.0 + phase * 18.0
			var sway: float = sin(t * 2.7 + float(i)) * 4.8
			var alpha: float = (1.0 - phase) * 0.12 * fade
			draw_line(base + Vector2(sway * 0.2, -1.0), base + Vector2(sway, -lift), Color(soft.r, soft.g, soft.b, alpha * 0.74), 1.0)
			draw_line(base, base + Vector2(sway * 0.45, -lift * 0.68), Color(ink.r, ink.g, ink.b, alpha), 1.0)
