extends CharacterBody2D

const ArrowScript = preload("res://enemy_arrow.gd")
const SlimeDeathScript = preload("res://slime_death.gd")
const SkeletonDeathScript = preload("res://skeleton_death.gd")
const HitFxScript = preload("res://hit_fx.gd")
const NecroMinionScript = preload("res://necro_minion.gd")
const ShieldBreakFxScript = preload("res://shield_break_fx.gd")

var enemy_type: String = "slime"
var player
var dead: bool = false
var spawning: bool = true
var spawn_t: float = 0.0

var max_health: int = 3
var health: int = 3
var move_speed: float = 85.0
var detect_radius: float = 500.0

var hit_flash: float = 0.0
var knockback: Vector2 = Vector2.ZERO
var anim_time: float = 0.0
var sketch_timer: float = 0.0
var sketch_frame: int = 0

var attack_state: String = "idle"
var state_time: float = 0.0
var attack_cooldown: float = 0.75
var attack_direction: Vector2 = Vector2.RIGHT
var attack_has_hit: bool = false
var attack_target: Vector2 = Vector2.ZERO
var pounce_duration: float = 0.34
var pounce_elapsed: float = 0.0
var pounce_speed: float = 355.0
var was_hit: bool = false
var support_timer: float = 2.4
var special_timer: float = 0.0
var facing_direction: Vector2 = Vector2.LEFT
var visual_facing_direction: Vector2 = Vector2.LEFT
var visual_motion_direction: Vector2 = Vector2.ZERO
var visual_speed_ratio: float = 0.0
var visual_body_phase: float = 0.0
var rush_has_hit: bool = false
var heal_flash: float = 0.0
var shield_max: int = 4
var shield_health: int = 4
var shield_broken: bool = false
var shield_stun: float = 0.0
var summon_flash: float = 0.0
var endless_controller
var visual_redraw_timer: float = 0.0
var contact_cooldown: float = 0.0
var brute_charge_speed: float = 340.0
var separation_frame: int = 0
var cached_separation_push: Vector2 = Vector2.ZERO
var ai_tick_timer: float = 0.0
var ai_accumulator: float = 0.0
var cached_player_delta: Vector2 = Vector2.ZERO
var cached_player_distance_sq: float = 99999999.0

func configure(kind: String, target) -> void:
	enemy_type = kind
	player = target
	match enemy_type:
		"skeleton":
			max_health = 3
			health = 3
			move_speed = 72.0
			detect_radius = 620.0
		"stalker":
			max_health = 3
			health = 3
			move_speed = 172.0
			detect_radius = 780.0
		"spider":
			# Paper-fast spider: very fragile, dangerous by speed/quantity rather than bulk.
			max_health = 1
			health = 1
			move_speed = 158.0
			detect_radius = 760.0
		"brute":
			max_health = 9
			health = 9
			move_speed = 58.0
			detect_radius = 680.0
		"shaman":
			max_health = 5
			health = 5
			move_speed = 62.0
			detect_radius = 650.0
		"warder":
			max_health = 6
			health = 6
			move_speed = 66.0
			detect_radius = 620.0
		_:
			max_health = 1
			health = 1
			move_speed = 92.0
			detect_radius = 560.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy")
	collision_layer = 4
	collision_mask = 1
	z_index = 24

	var collider := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 16.8 if enemy_type == "brute" else (14.0 if enemy_type == "warder" else (11.0 if enemy_type == "skeleton" or enemy_type == "shaman" else (8.7 if enemy_type == "spider" else 12.3)))
	collider.shape = shape
	collider.position = Vector2(0, 7)
	add_child(collider)

	ai_tick_timer = randf_range(0.0, 0.055)
	ai_accumulator = 0.0
	modulate.a = 0.0
	if enemy_type == "skeleton" or enemy_type == "shaman" or enemy_type == "warder" or enemy_type == "brute":
		scale = Vector2(0.28, 1.05)
	else:
		scale = Vector2(1.12, 0.08)

func _physics_process(delta: float) -> void:
	if dead:
		return

	anim_time += delta
	visual_body_phase += delta * (4.2 + clampf(velocity.length() / maxf(1.0, move_speed), 0.0, 1.6) * 4.6)
	hit_flash = move_toward(hit_flash, 0.0, delta * 7.0)
	heal_flash = move_toward(heal_flash, 0.0, delta * 3.0)
	summon_flash = move_toward(summon_flash, 0.0, delta * 2.6)
	shield_stun = maxf(0.0, shield_stun - delta)
	knockback = knockback.move_toward(Vector2.ZERO, delta * 700.0)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	contact_cooldown = maxf(0.0, contact_cooldown - delta)

	if spawning:
		_update_spawn(delta)
		visual_redraw_timer -= delta
		if visual_redraw_timer <= 0.0:
			visual_redraw_timer = 1.0 / 24.0
			_update_sketch(0.10)
			queue_redraw()
		return

	if not is_instance_valid(player):
		velocity = knockback
		return

	cached_player_delta = player.global_position - global_position
	cached_player_distance_sq = cached_player_delta.length_squared()
	var horde_tier: int = 0
	if is_instance_valid(endless_controller) and endless_controller.has_method("get_horde_performance_tier"):
		horde_tier = int(endless_controller.get_horde_performance_tier())

	# Very distant enemies use cheap direct steering. This is intentionally independent
	# from their visual animation; when they approach the player they seamlessly return
	# to the full state machine.
	if is_instance_valid(endless_controller) and cached_player_distance_sq > 500.0 * 500.0 and attack_state == "idle":
		if cached_player_distance_sq > 0.001:
			velocity = cached_player_delta.normalized() * move_speed + knockback
			global_position += velocity * delta
		_update_visual_pose(delta)
		visual_redraw_timer -= delta
		if visual_redraw_timer <= 0.0:
			visual_redraw_timer = 1.0 / (7.0 if horde_tier >= 2 else (9.0 if horde_tier == 1 else 11.0))
			_update_sketch(0.10)
			queue_redraw()
		return

	# Idle enemies do not need a full AI decision every physics frame. Their velocity
	# still integrates every frame, so movement stays smooth while target/steering work
	# is staggered across the horde. Active attacks always remain full-rate.
	var active_state: bool = attack_state != "idle" or shield_stun > 0.0
	var close_combat: bool = cached_player_distance_sq <= 135.0 * 135.0
	var ai_interval: float = 0.0
	if not active_state and not close_combat:
		if cached_player_distance_sq <= 300.0 * 300.0:
			ai_interval = 0.045 if horde_tier == 0 else (0.060 if horde_tier == 1 else 0.075)
		elif cached_player_distance_sq <= 500.0 * 500.0:
			ai_interval = 0.070 if horde_tier == 0 else (0.090 if horde_tier == 1 else 0.115)
		else:
			ai_interval = 0.100

	ai_accumulator += delta
	var run_ai: bool = active_state or close_combat or ai_tick_timer <= 0.0
	if run_ai:
		var ai_delta: float = delta if active_state or close_combat else maxf(delta, ai_accumulator)
		ai_accumulator = 0.0
		ai_tick_timer = ai_interval
		match enemy_type:
			"skeleton":
				_update_skeleton(ai_delta)
			"stalker":
				_update_stalker(ai_delta)
			"spider":
				_update_spider(ai_delta)
			"brute":
				_update_brute(ai_delta)
			"shaman":
				_update_shaman(ai_delta)
			"warder":
				_update_warder(ai_delta)
			_:
				_update_slime(ai_delta)
	else:
		ai_tick_timer -= delta

	_update_visual_pose(delta)
	_apply_soft_separation()
	move_and_slide()

	visual_redraw_timer -= delta
	if visual_redraw_timer <= 0.0:
		var active_anim: bool = attack_state != "idle" or hit_flash > 0.02 or summon_flash > 0.02
		if cached_player_distance_sq < 260.0 * 260.0:
			if horde_tier >= 2:
				visual_redraw_timer = 1.0 / (22.0 if active_anim else 17.0)
			elif horde_tier == 1:
				visual_redraw_timer = 1.0 / (26.0 if active_anim else 20.0)
			else:
				visual_redraw_timer = 1.0 / (30.0 if active_anim else 24.0)
		elif cached_player_distance_sq < 500.0 * 500.0:
			visual_redraw_timer = 1.0 / (11.0 if horde_tier >= 2 else (14.0 if horde_tier == 1 else 16.0))
		else:
			visual_redraw_timer = 1.0 / (7.0 if horde_tier >= 2 else 9.0)
		_update_sketch(0.10)
		queue_redraw()

func _update_visual_pose(delta: float) -> void:
	var target_face: Vector2 = facing_direction
	if is_instance_valid(player):
		var to_player: Vector2 = player.global_position - global_position
		if to_player.length_squared() > 0.001:
			target_face = to_player.normalized()
	if attack_state == "rush" or attack_state == "pounce" or attack_state == "windup":
		if attack_direction.length_squared() > 0.001:
			target_face = attack_direction.normalized()
	if target_face.length_squared() <= 0.001:
		target_face = Vector2.LEFT
	if visual_facing_direction.length_squared() <= 0.001:
		visual_facing_direction = target_face
	else:
		visual_facing_direction = visual_facing_direction.lerp(target_face, clampf(delta * 8.5, 0.0, 1.0)).normalized()
	var target_motion: Vector2 = velocity.normalized() if velocity.length_squared() > 4.0 else Vector2.ZERO
	visual_motion_direction = visual_motion_direction.lerp(target_motion, clampf(delta * 7.0, 0.0, 1.0))
	if visual_motion_direction.length() < 0.02:
		visual_motion_direction = Vector2.ZERO
	visual_speed_ratio = lerpf(visual_speed_ratio, clampf(velocity.length() / maxf(1.0, move_speed), 0.0, 1.5), clampf(delta * 6.0, 0.0, 1.0))

func _visual_detail_level() -> int:
	if not is_instance_valid(player):
		return 0
	var d2: float = global_position.distance_squared_to(player.global_position)
	if d2 <= 280.0*280.0:
		return 2
	if d2 <= 520.0*520.0:
		return 1
	return 0

func _visual_look() -> Vector2:
	if visual_facing_direction.length_squared() > 0.001:
		return visual_facing_direction.normalized()
	if facing_direction.length_squared() > 0.001:
		return facing_direction.normalized()
	return Vector2.LEFT

func _update_spawn(delta: float) -> void:
	spawn_t = minf(1.0, spawn_t + delta / 0.60)
	var e: float = 1.0 - pow(1.0 - spawn_t, 3.0)
	modulate.a = clampf(spawn_t * 1.8, 0.0, 1.0)

	var target_scale: float = 0.72
	if enemy_type == "brute":
		target_scale = 0.76
	elif enemy_type == "skeleton" or enemy_type == "shaman" or enemy_type == "warder":
		target_scale = 0.74
	elif enemy_type == "spider" or enemy_type == "stalker":
		target_scale = 0.70
	if enemy_type == "skeleton" or enemy_type == "shaman" or enemy_type == "warder" or enemy_type == "brute":
		scale = Vector2(lerpf(0.28, target_scale, e), lerpf(1.05, target_scale, e))
	else:
		scale = Vector2(lerpf(1.12, target_scale, e), lerpf(0.08, target_scale, e))

	if spawn_t >= 1.0:
		spawning = false
		if enemy_type == "brute":
			scale = Vector2(0.76,0.76)
		elif enemy_type == "skeleton" or enemy_type == "shaman" or enemy_type == "warder":
			scale = Vector2(0.74,0.74)
		elif enemy_type == "spider" or enemy_type == "stalker":
			scale = Vector2(0.70,0.70)
		else:
			scale = Vector2(0.72,0.72)
		modulate = Color.WHITE

func _update_slime(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return

	var to_player: Vector2 = player.global_position - global_position
	var dist: float = to_player.length()

	if attack_state == "windup":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "pounce"
			pounce_elapsed = 0.0
			state_time = pounce_duration
			attack_direction = (attack_target - global_position).normalized()
			if attack_direction.length_squared() < 0.001:
				attack_direction = to_player.normalized()
			var target_distance: float = global_position.distance_to(attack_target)
			pounce_speed = minf(355.0, target_distance / maxf(0.01, pounce_duration))
			get_tree().call_group("audio_bus", "play_slime_attack")
		return

	if attack_state == "pounce":
		pounce_elapsed += delta
		state_time -= delta
		velocity = attack_direction * pounce_speed + knockback
		if state_time <= 0.0:
			attack_state = "land"
			state_time = 0.12
			velocity = Vector2.ZERO
			var allow_land_feedback: bool = true
			if is_instance_valid(endless_controller) and endless_controller.has_method("allow_enemy_hit_feedback"):
				allow_land_feedback = endless_controller.allow_enemy_hit_feedback()
			if allow_land_feedback:
				get_tree().call_group("screen_fx", "pulse_enemy_land")
			if global_position.distance_squared_to(player.global_position) <= 43.0*43.0:
				player.take_damage(1, attack_direction)
		return

	if attack_state == "land":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "recover"
			state_time = 0.38
			attack_cooldown = 1.12
		return

	if attack_state == "recover":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return

	if dist < 138.0 and attack_cooldown <= 0.0:
		attack_state = "windup"
		state_time = 0.52
		attack_target = player.global_position
		attack_direction = to_player.normalized()
		velocity = Vector2.ZERO
	elif dist < detect_radius and dist > 60.0:
		velocity = to_player.normalized() * move_speed + knockback
	else:
		velocity = knockback

func _update_skeleton(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return

	var to_player: Vector2 = player.global_position - global_position
	var dist: float = to_player.length()
	if attack_state != "windup" and to_player.length_squared() > 0.001:
		attack_direction = to_player.normalized()

	if attack_state == "windup":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			_fire_arrow()
			attack_state = "recover"
			state_time = 0.34
			attack_cooldown = 1.48
		return

	if attack_state == "recover":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return

	if dist >= 175.0 and dist <= 370.0 and attack_cooldown <= 0.0:
		attack_state = "windup"
		state_time = 0.66
		velocity = Vector2.ZERO
	elif dist > 340.0 and dist < detect_radius:
		velocity = to_player.normalized() * move_speed + knockback
	elif dist < 165.0:
		velocity = -to_player.normalized() * move_speed * 0.92 + knockback
	else:
		velocity = knockback


func _update_stalker(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	if to_player.length_squared() > 0.001:
		facing_direction = to_player.normalized()
	if attack_state == "windup":
		state_time -= delta
		velocity = -facing_direction*34.0+knockback
		if state_time <= 0.0:
			attack_state = "rush"
			state_time = 0.42
			attack_direction = facing_direction
			rush_has_hit = false
		return
	if attack_state == "rush":
		state_time -= delta
		velocity = attack_direction*560.0+knockback
		if not rush_has_hit and global_position.distance_squared_to(player.global_position) < 38.0*38.0:
			rush_has_hit = true
			player.take_damage(1,attack_direction)
		if state_time <= 0.0:
			attack_state = "recover"
			state_time = 0.72
			attack_cooldown = randf_range(1.15,1.65)
		return
	if attack_state == "recover":
		state_time -= delta
		var side_recover: Vector2 = Vector2(-facing_direction.y,facing_direction.x)
		velocity = -facing_direction*64.0+side_recover*42.0*sin(anim_time*3.0)+knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return
	if dist < 330.0 and attack_cooldown <= 0.0:
		attack_state = "windup"
		state_time = 0.28
		attack_direction = facing_direction
		velocity = Vector2.ZERO
	elif dist < detect_radius:
		var side: Vector2 = Vector2(-facing_direction.y,facing_direction.x)
		velocity = facing_direction*move_speed+side*sin(anim_time*4.4+float(get_instance_id()%7))*58.0+knockback
	else:
		velocity = knockback

func _update_spider(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	var dir: Vector2 = to_player.normalized() if to_player.length_squared() > 0.001 else Vector2.RIGHT
	facing_direction = dir
	if attack_state == "recover":
		state_time -= delta
		velocity = -dir*move_speed*0.82+knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return
	if dist <= 30.0 and contact_cooldown <= 0.0:
		player.take_damage(1,dir)
		contact_cooldown = 0.95
		attack_state = "recover"
		state_time = 0.26
		velocity = -dir*move_speed+knockback
		return
	if dist < detect_radius:
		var weave: Vector2 = Vector2(-dir.y,dir.x)*sin(anim_time*7.0+float(get_instance_id()%5))*24.0
		velocity = dir*move_speed+weave+knockback
	else:
		velocity = knockback

func _update_brute(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	var dir: Vector2 = to_player.normalized() if to_player.length_squared() > 0.001 else Vector2.RIGHT
	facing_direction = dir
	if attack_state == "windup":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "rush"
			state_time = 0.48
			attack_direction = dir
			rush_has_hit = false
		return
	if attack_state == "rush":
		state_time -= delta
		velocity = attack_direction*brute_charge_speed+knockback
		if not rush_has_hit and global_position.distance_squared_to(player.global_position) < 46.0*46.0:
			rush_has_hit = true
			player.take_damage(1,attack_direction)
			get_tree().call_group("screen_fx","pulse_boss")
		if state_time <= 0.0:
			attack_state = "recover"
			state_time = 0.65
			attack_cooldown = 2.4
		return
	if attack_state == "recover":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return
	if dist < 185.0 and attack_cooldown <= 0.0:
		attack_state = "windup"
		state_time = 0.72
		attack_direction = dir
		velocity = Vector2.ZERO
	elif dist < detect_radius:
		velocity = dir*move_speed+knockback
	else:
		velocity = knockback

func _update_shaman(delta: float) -> void:
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	if to_player.length_squared() > 0.001:
		facing_direction = to_player.normalized()
	support_timer -= delta
	if support_timer <= 0.0:
		support_timer = 3.0
		if _count_owned_minions() < 4:
			_summon_minions(2)
		else:
			_fire_necro_bolt()
	if dist < 190.0:
		velocity = -facing_direction*move_speed+knockback
	elif dist > 330.0 and dist < detect_radius:
		velocity = facing_direction*move_speed*0.74+knockback
	else:
		var side: Vector2 = Vector2(-facing_direction.y,facing_direction.x)
		velocity = side*30.0+knockback

func _count_owned_minions() -> int:
	var count: int = 0
	for minion in get_tree().get_nodes_in_group("necro_minion"):
		if is_instance_valid(minion) and int(minion.get_meta("owner_necro",0)) == get_instance_id():
			count += 1
	return count

func _summon_minions(amount: int) -> void:
	summon_flash = 1.0
	for i in range(amount):
		var minion = NecroMinionScript.new()
		minion.configure(player)
		var a: float = anim_time*1.7+float(i)*PI
		minion.global_position = global_position+Vector2(cos(a)*34.0,sin(a)*26.0)
		minion.set_meta("owner_necro",get_instance_id())
		get_tree().current_scene.add_child(minion)
	get_tree().call_group("screen_fx","pulse_spawn")
	get_tree().call_group("audio_bus","play_necro_summon")

func _fire_necro_bolt() -> void:
	if not is_instance_valid(player):
		return
	var dir: Vector2 = (player.global_position-global_position).normalized()
	var arrow = ArrowScript.new()
	arrow.direction = dir
	arrow.speed = 345.0
	arrow.global_position = global_position+dir*22.0
	get_tree().current_scene.add_child(arrow)
	get_tree().call_group("audio_bus","play_enemy_shot")

func _update_warder(delta: float) -> void:
	if shield_stun > 0.0:
		velocity = knockback
		attack_state = "recover"
		state_time = shield_stun
		return
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		return
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	if to_player.length_squared() > 0.001 and attack_state != "rush":
		facing_direction = to_player.normalized()
	if attack_state == "windup":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "rush"
			state_time = 0.42
			attack_direction = facing_direction
			rush_has_hit = false
		return
	if attack_state == "rush":
		state_time -= delta
		velocity = attack_direction*325.0+knockback
		if not rush_has_hit and global_position.distance_squared_to(player.global_position) < 44.0*44.0:
			rush_has_hit = true
			player.take_damage(1,attack_direction)
		if state_time <= 0.0:
			attack_state = "recover"
			state_time = 0.48
			attack_cooldown = 1.25
		return
	if attack_state == "recover":
		state_time -= delta
		velocity = knockback
		if state_time <= 0.0:
			attack_state = "idle"
		return
	if dist < 155.0 and attack_cooldown <= 0.0:
		attack_state = "windup"
		state_time = 0.62
		attack_direction = facing_direction
	elif dist < detect_radius and dist > 62.0:
		velocity = facing_direction*move_speed+knockback
	else:
		velocity = knockback

func _fire_arrow() -> void:
	if not is_instance_valid(player):
		return
	if is_instance_valid(endless_controller) and endless_controller.has_method("request_skeleton_shot"):
		if not endless_controller.request_skeleton_shot():
			attack_cooldown = randf_range(0.35,0.70)
			return
	var dir: Vector2 = attack_direction.normalized()
	get_tree().call_group("audio_bus", "play_enemy_shot")
	var arrow = ArrowScript.new()
	arrow.direction = dir
	arrow.global_position = global_position + dir * 20.0 + Vector2(0, -5)
	get_tree().current_scene.add_child(arrow)

func _apply_soft_separation() -> void:
	# Crowd steering is intentionally approximate. Reusing a cached push keeps the
	# swarm organic without turning 150-200 enemies into an O(n²) neighbor problem.
	separation_frame += 1
	var horde_tier: int = 0
	if is_instance_valid(endless_controller) and endless_controller.has_method("get_horde_performance_tier"):
		horde_tier = int(endless_controller.get_horde_performance_tier())
	var recalc_every: int = 6 if horde_tier == 0 else (9 if horde_tier == 1 else 12)
	if (separation_frame + int(get_instance_id() % recalc_every)) % recalc_every == 0:
		var push: Vector2 = Vector2.ZERO
		if is_instance_valid(player):
			var away: Vector2 = global_position - player.global_position
			var d2_player: float = away.length_squared()
			if d2_player > 0.0001 and d2_player < 44.0 * 44.0 and attack_state != "pounce":
				var dist_player: float = sqrt(d2_player)
				push += away / dist_player * (44.0 - dist_player) * 7.0

		var candidates: Array = []
		if is_instance_valid(endless_controller) and endless_controller.has_method("get_nearby_enemies"):
			candidates = endless_controller.get_nearby_enemies(global_position, 42.0)
		else:
			candidates = get_tree().get_nodes_in_group("enemy")
		var max_neighbors: int = 10 if horde_tier == 0 else (8 if horde_tier == 1 else 6)
		var checked: int = 0
		for other in candidates:
			if checked >= max_neighbors:
				break
			if other == self or not is_instance_valid(other):
				continue
			checked += 1
			var delta_pos: Vector2 = global_position - other.global_position
			var d2: float = delta_pos.length_squared()
			if d2 > 0.0001 and d2 < 1156.0:
				var d: float = sqrt(d2)
				push += delta_pos / d * (34.0 - d) * 4.0
		cached_separation_push = push
	velocity += cached_separation_push

func take_damage(amount: int, hit_direction: Vector2) -> void:
	if dead or spawning:
		return
	if enemy_type == "spider" and is_instance_valid(player):
		var source_class: String = str(player.mage_type)
		if source_class == "storm" or source_class == "rift":
			amount = 1
		else:
			amount = maxi(2,amount)
	if enemy_type == "warder" and not shield_broken:
		var incoming: Vector2 = hit_direction.normalized()
		var frontal_hit: bool = facing_direction.length_squared() > 0.001 and incoming.dot(facing_direction) < -0.20
		if frontal_hit and attack_state != "recover":
			shield_health = maxi(0,shield_health-maxi(1,amount))
			hit_flash = 0.55
			knockback = incoming*34.0
			get_tree().call_group("audio_bus","play_enemy_hit")
			get_tree().call_group("screen_fx","pulse_enemy_hit")
			if shield_health <= 0:
				_break_shield()
			return

	health -= amount
	hit_flash = 1.0
	was_hit = true
	knockback = hit_direction.normalized() * (95.0 if enemy_type == "warder" else 135.0)

	var spawn_fx: bool = true
	if is_instance_valid(endless_controller) and endless_controller.has_method("allow_cosmetic_fx"):
		spawn_fx = endless_controller.allow_cosmetic_fx()
	if spawn_fx:
		var fx = HitFxScript.new()
		fx.global_position = global_position
		fx.direction = hit_direction
		fx.tint = Color("#111111")
		get_tree().current_scene.add_child(fx)

	var allow_hit_feedback: bool = true
	if is_instance_valid(endless_controller) and endless_controller.has_method("allow_enemy_hit_feedback"):
		allow_hit_feedback = endless_controller.allow_enemy_hit_feedback()
	if allow_hit_feedback:
		get_tree().call_group("audio_bus", "play_enemy_hit")
		get_tree().call_group("screen_fx", "pulse_enemy_hit")
	if is_instance_valid(player):
		player.on_enemy_hit(1.0)

	if health <= 0:
		_die()

func _break_shield() -> void:
	if shield_broken:
		return
	shield_broken = true
	shield_health = 0
	shield_stun = 1.05
	attack_state = "recover"
	state_time = 1.05
	var fx = ShieldBreakFxScript.new()
	fx.global_position = global_position+facing_direction*17.0
	get_tree().current_scene.add_child(fx)
	get_tree().call_group("screen_fx","pulse_boss")
	get_tree().call_group("audio_bus","play_shield_break")

func heal_enemy(amount: int) -> void:
	if dead:
		return
	health = mini(max_health,health+amount)
	heal_flash = 1.0
	queue_redraw()

func apply_external_force(force: Vector2) -> void:
	knockback += force

func _die() -> void:
	dead = true
	if enemy_type == "shaman":
		for minion in get_tree().get_nodes_in_group("necro_minion"):
			if is_instance_valid(minion) and int(minion.get_meta("owner_necro",0)) == get_instance_id():
				minion.queue_free()
	collision_layer = 0
	collision_mask = 0
	velocity = Vector2.ZERO

	var death_fx
	if enemy_type == "skeleton" or enemy_type == "shaman" or enemy_type == "warder" or enemy_type == "brute":
		death_fx = SkeletonDeathScript.new()
	else:
		death_fx = SlimeDeathScript.new()

	var spawn_death_fx: bool = true
	if is_instance_valid(endless_controller) and endless_controller.has_method("allow_cosmetic_fx"):
		spawn_death_fx = endless_controller.allow_cosmetic_fx()
	if spawn_death_fx:
		death_fx.global_position = global_position
		get_tree().current_scene.add_child(death_fx)

	get_tree().call_group("endless_controller","on_enemy_defeated",global_position,enemy_type,false)
	if is_instance_valid(player):
		player.on_enemy_killed(false)
	var reward: int = 1
	if enemy_type == "skeleton" or enemy_type == "stalker":
		reward = 2
	elif enemy_type == "shaman" or enemy_type == "warder" or enemy_type == "brute":
		reward = 3
	get_tree().call_group("game_controller", "add_fragments", reward)
	var allow_death_feedback: bool = true
	if is_instance_valid(endless_controller) and endless_controller.has_method("allow_enemy_death_feedback"):
		allow_death_feedback = endless_controller.allow_enemy_death_feedback()
	if allow_death_feedback:
		get_tree().call_group("screen_fx", "pulse_kill")
		get_tree().call_group("audio_bus", "play_enemy_die")
	queue_free()

func _update_sketch(delta: float) -> void:
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.090
		sketch_frame += 1

func sketch_jitter(index: int, amount: float) -> float:
	return sin(float(sketch_frame) * 2.31 + float(index) * 3.79) * amount * 0.45

func _draw_health_bar() -> void:
	if not was_hit:
		return
	var ratio: float = clampf(float(health) / float(max_health), 0.0, 1.0)
	draw_line(Vector2(-17, -42), Vector2(17, -42), Color(0.15, 0.15, 0.15, 0.28), 4.0)
	draw_line(Vector2(-17, -42), Vector2(-17 + 34.0 * ratio, -42), Color("#111111"), 2.0)

func _draw() -> void:
	match enemy_type:
		"skeleton":
			_draw_skeleton()
		"stalker":
			_draw_stalker()
		"spider":
			_draw_spider()
		"brute":
			_draw_brute()
		"shaman":
			_draw_shaman()
		"warder":
			_draw_warder()
		_:
			_draw_slime()
	_draw_health_bar()
	_draw_flux_reaction()

func _draw_flux_reaction() -> void:
	if not is_instance_valid(player) or not player.flux_active or _visual_detail_level() <= 0:
		return
	var pulse: float = 0.10+absf(sin(anim_time*7.0))*0.07
	draw_arc(Vector2(0,2),24.0+sin(anim_time*4.0)*2.0,0.0,TAU,24,Color(0.08,0.08,0.08,pulse),1.2)
	var toward: Vector2 = (player.global_position-global_position).normalized()
	draw_line(toward*18.0,toward*31.0,Color(0.08,0.08,0.08,0.14),1.2)

func _draw_slime() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"), hit_flash * 0.70)
	var detail: int = _visual_detail_level()
	var bounce: float = sin(anim_time * 7.0) * 1.2
	var look: Vector2 = _visual_look()
	var windup: float = 0.0
	if attack_state == "windup":
		windup = clampf(1.0 - state_time / 0.52, 0.0, 1.0)
	var leap_ratio: float = 0.0
	if attack_state == "pounce":
		leap_ratio = clampf(pounce_elapsed / pounce_duration, 0.0, 1.0)
	var leap_height: float = sin(leap_ratio * PI) * 16.0
	var sx: float = 1.0 + windup * 0.30
	var sy: float = 1.0 - windup * 0.24
	if attack_state == "pounce":
		sx = 0.84 + sin(leap_ratio * PI) * 0.10
		sy = 1.12 - sin(leap_ratio * PI) * 0.06
	elif attack_state == "land":
		sx = 1.34
		sy = 0.68
	var shadow_passes: int = 2 if detail > 0 else 1
	for pass_i in range(shadow_passes):
		var off: Vector2 = Vector2(sketch_jitter(10 + pass_i, 1.0), sketch_jitter(20 + pass_i, 0.8))
		_draw_oval(off + Vector2(0, 15), Vector2(20, 6), Color(0.10, 0.09, 0.08, 0.08))
	var body_offset_y: float = bounce - leap_height
	var points: PackedVector2Array = PackedVector2Array()
	var point_count: int = 18 if detail <= 0 else 22
	for i in range(point_count):
		var a: float = TAU * float(i) / float(point_count)
		var wobble_value: float = 1.0 + sin(float(i) * 2.2 + float(sketch_frame)) * 0.075
		var px: float = cos(a) * 18.5 * sx * wobble_value
		var py: float = sin(a) * 13.5 * sy * wobble_value + 2.0 + body_offset_y
		if py > 7.0 and attack_state != "pounce":
			py += absf(sin(float(i) * 1.6 + anim_time * 5.0)) * 2.8
		points.append(Vector2(px, py))
	draw_colored_polygon(points, ink)
	var eye_shift: Vector2 = Vector2(look.x * 1.2, look.y * 0.8)
	var left_eye: Vector2 = Vector2(-6, -2 + body_offset_y)
	var right_eye: Vector2 = Vector2(6, -2 + body_offset_y)
	draw_circle(left_eye, 2.35, Color("#fffdf7"))
	draw_circle(right_eye, 2.35, Color("#fffdf7"))
	draw_circle(left_eye + eye_shift, 0.65, Color("#111111"))
	draw_circle(right_eye + eye_shift, 0.65, Color("#111111"))
	_sketch_line(Vector2(-5, 6 + body_offset_y), Vector2(5, 7 + body_offset_y), Color("#fffdf7"), 1.4, 1 if detail <= 0 else 2, 50)
	if detail >= 2:
		draw_arc(Vector2(-3, 1 + body_offset_y), 10.0, -2.6, -0.6, 14, Color(1,1,1,0.055), 0.8)
		for i in range(3):
			var bubble: Vector2 = Vector2(-8.0 + float(i) * 7.2, 9.0 + body_offset_y + sin(anim_time*2.8+float(i))*0.5)
			draw_circle(bubble, 1.0 + float(i%2)*0.35, Color(1,1,1,0.045))
	if attack_state == "windup":
		var local_target: Vector2 = attack_target - global_position
		var max_len: float = minf(local_target.length(), 132.0)
		var dir: Vector2 = local_target.normalized()
		if dir.length_squared() < 0.001:
			dir = attack_direction
		var end_pos: Vector2 = dir * max_len
		for i in range(4):
			var part: float = float(i + 1) / 5.0
			draw_circle(end_pos * part, 1.4 + windup * 0.5, Color(0.08,0.08,0.08,0.12 + windup * 0.11))
		draw_arc(end_pos, 18.0 + windup * 5.0, 0.0, TAU, 20, Color(0.08,0.08,0.08,0.15 + windup * 0.15), 1.2)
		_draw_attack_arrow(dir, 24.0 + windup * 10.0, 0.16 + windup * 0.18)
	elif attack_state == "land":
		var land_ratio: float = clampf(state_time / 0.12, 0.0, 1.0)
		draw_arc(Vector2.ZERO, lerpf(42.0, 18.0, land_ratio), 0.0, TAU, 24, Color(0.08,0.08,0.08,0.14 * land_ratio), 1.5)

func _draw_skeleton() -> void:
	var ink: Color = Color("#151515").lerp(Color("#777777"), hit_flash * 0.70)
	var bone: Color = Color("#f1ece1")
	var cloth: Color = Color(0.08,0.08,0.09,0.94)
	var cloth_soft: Color = Color(0.14,0.14,0.15,0.84)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var side: Vector2 = Vector2(-look.y, look.x)
	var moving_now: bool = visual_speed_ratio > 0.10
	var gait: float = sin(visual_body_phase * 1.65) if moving_now else 0.0
	var step: float = gait * 3.1
	var lift_l: float = maxf(0.0,gait)*2.8 if moving_now else 0.0
	var lift_r: float = maxf(0.0,-gait)*2.8 if moving_now else 0.0
	var bob: float = absf(gait) * 0.75 if moving_now else sin(anim_time*2.2)*0.18
	var windup: float = clampf(1.0-state_time/0.66,0.0,1.0) if attack_state == "windup" else 0.0
	var recover: float = clampf(state_time/0.34,0.0,1.0) if attack_state == "recover" else 0.0
	var torso_shift: Vector2 = look*(1.0+windup*2.1)-side*windup*0.8
	var head_shift: Vector2 = look*(1.1+windup*0.8)
	_draw_oval(Vector2(0,22),Vector2(18,5),Color(0.08,0.08,0.08,0.055))
	# staggered bony walk
	draw_line(Vector2(-5,8+bob)+torso_shift*0.25,Vector2(-7+step,20-lift_l),ink,2.4)
	draw_line(Vector2(5,8+bob)+torso_shift*0.25,Vector2(7-step,20-lift_r),ink,2.4)
	draw_line(Vector2(-10+step,20-lift_l),Vector2(-4+step,20-lift_l),ink,1.9)
	draw_line(Vector2(4-step,20-lift_r),Vector2(10-step,20-lift_r),ink,1.9)
	# tattered waist cloth makes the body read like a real enemy design instead of lines.
	var waist_cloth: PackedVector2Array = PackedVector2Array([
		Vector2(-9,4+bob),Vector2(9,4+bob),Vector2(8,11+bob),Vector2(3,9+bob),Vector2(0,13+bob),Vector2(-4,9+bob),Vector2(-9,11+bob)
	])
	for i in range(waist_cloth.size()):
		waist_cloth[i] += torso_shift*0.25
	draw_colored_polygon(waist_cloth,cloth)
	# spine + ribs
	draw_line(Vector2(0,8+bob)+torso_shift*0.25,Vector2(0,-10+bob)+torso_shift*0.42,ink,2.5)
	var rib_count: int = 3 if detail <= 0 else 5
	for i in range(rib_count):
		var yy: float = -8.0+float(i)*3.3+bob
		draw_arc(Vector2(0,yy)+torso_shift*0.34,9.7-float(i)*0.55,0.10,PI-0.10,14,ink,1.65)
	# ragged archer shoulder mantle
	var mantle: PackedVector2Array = PackedVector2Array([
		Vector2(-11,-11+bob),Vector2(10,-11+bob),Vector2(13,-6+bob),Vector2(8,-2+bob),Vector2(2,-4+bob),Vector2(-4,-2+bob),Vector2(-12,-5+bob)
	])
	for i in range(mantle.size()):
		mantle[i] += torso_shift*0.38
	draw_colored_polygon(mantle,cloth_soft)
	if detail >= 1:
		draw_line(mantle[0],mantle[2],Color(1,1,1,0.05),0.9)
		draw_line(mantle[5],mantle[3],Color(0.04,0.04,0.04,0.20),0.9)
	# quiver strapped behind the torso; arrows bounce while walking.
	var quiver_base: Vector2 = Vector2(-8,1+bob)+torso_shift*0.25-side*3.0
	var quiver_top: Vector2 = quiver_base-look*4.0+Vector2(-2,-17)-side*gait*0.5
	draw_line(quiver_base,quiver_top,Color(0.06,0.06,0.06,0.95),3.0)
	for qi in range(3 if detail >= 1 else 2):
		var qoff: Vector2 = side*(float(qi)-1.0)*1.8
		var shaft_start: Vector2 = quiver_top+qoff
		var shaft_tip: Vector2 = shaft_start+Vector2(0,-8.0-float(qi))
		draw_line(shaft_start,shaft_tip,ink,0.9)
		draw_line(shaft_tip,shaft_tip+side*2.0,Color(1,1,1,0.10),0.8)
	# skull follows the target
	var skull_center: Vector2 = Vector2(0,-22+bob)+head_shift
	draw_circle(skull_center,11.0,bone)
	draw_arc(skull_center,11.0,0.0,TAU,22,ink,1.4)
	var eye_shift: Vector2 = look*0.85
	draw_circle(skull_center+Vector2(-4,-1)+eye_shift,2.6,ink)
	draw_circle(skull_center+Vector2(4,-1)+eye_shift,2.6,ink)
	if detail >= 1:
		draw_circle(skull_center+Vector2(-4,-1)+eye_shift*1.3,0.5,Color(1,1,1,0.16))
		draw_circle(skull_center+Vector2(4,-1)+eye_shift*1.3,0.5,Color(1,1,1,0.16))
	draw_colored_polygon(PackedVector2Array([skull_center+Vector2(0,1),skull_center+Vector2(-2,5),skull_center+Vector2(2,5)]),ink)
	draw_line(skull_center+Vector2(-6,8),skull_center+Vector2(6,8),ink,1.3)
	if detail >= 1:
		for tx in [-4.0,-1.3,1.3,4.0]:
			draw_line(skull_center+Vector2(tx,8),skull_center+Vector2(tx,11.2),ink,0.8)
	# real bow pose: one hand holds bow forward, the other pulls the string toward the cheek.
	var bow_hand: Vector2 = Vector2(8,-5+bob)+torso_shift*0.35+look*(7.0+windup*5.0)
	var pull_hand: Vector2 = Vector2(-7,-6+bob)+torso_shift*0.35-look*(2.0+windup*8.0)+side*(2.0*windup)
	draw_line(Vector2(7,-8+bob)+torso_shift*0.35,bow_hand,ink,2.0)
	draw_line(Vector2(-7,-8+bob)+torso_shift*0.35,pull_hand,ink,1.9)
	draw_circle(bow_hand,2.1,bone)
	draw_circle(pull_hand,2.1,bone)
	var bow_center: Vector2 = bow_hand+look*2.0
	var bow_top: Vector2 = bow_center+side*18.0+look*4.0
	var bow_bottom: Vector2 = bow_center-side*18.0+look*4.0
	var bow_curve: PackedVector2Array = PackedVector2Array()
	var bow_points: int = 9 if detail <= 0 else 13
	for i in range(bow_points):
		var q: float = float(i)/float(bow_points-1)
		bow_curve.append(bow_top.lerp(bow_bottom,q)+look*sin(q*PI)*(7.0+windup*2.0))
	draw_polyline(bow_curve,ink,2.0)
	draw_line(bow_top,pull_hand,ink,1.0)
	draw_line(bow_bottom,pull_hand,ink,1.0)
	var arrow_tail: Vector2 = pull_hand-look*5.0
	var arrow_tip: Vector2 = bow_center+look*(16.0+windup*10.0)
	draw_line(arrow_tail,arrow_tip,ink,1.6)
	draw_colored_polygon(PackedVector2Array([arrow_tip+look*4.0,arrow_tip-look*2.0+side*2.5,arrow_tip-look*2.0-side*2.5]),ink)
	if attack_state == "windup":
		draw_arc(bow_center,10.0+windup*5.0,look.angle()-0.55,look.angle()+0.55,14,Color(1,1,1,0.05+windup*0.05),1.0)
		_draw_attack_arrow(look,68.0+windup*20.0,0.15+windup*0.20)
	elif attack_state == "recover" and recover > 0.0:
		draw_line(bow_hand,bow_hand-look*(5.0*recover),Color(1,1,1,0.05),1.0)

func _draw_stalker() -> void:
	var ink: Color = Color("#101010").lerp(Color("#777777"),hit_flash*0.68)
	var body_dark: Color = Color(0.06,0.06,0.07,0.98)
	var membrane: Color = Color(0.11,0.11,0.13,0.72)
	var pale: Color = Color(1.0,0.985,0.95,0.88)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var side: Vector2 = Vector2(-look.y,look.x)
	var fly: float = sin(anim_time*8.2+float(get_instance_id()%9))*2.2
	var windup: float = clampf(1.0-state_time/0.28,0.0,1.0) if attack_state == "windup" else 0.0
	var rush_ratio: float = clampf(state_time/0.42,0.0,1.0) if attack_state == "rush" else 0.0
	var speed_factor: float = clampf(visual_speed_ratio,0.0,1.5)
	var wing_phase: float = anim_time*(10.5+speed_factor*2.4)
	var wing_open: float = 0.30+absf(sin(wing_phase))*0.70
	if attack_state == "windup":
		wing_open *= 0.34
	if attack_state == "rush":
		wing_open = 0.22+rush_ratio*0.10
	var stretch: float = 1.0+(0.34 if attack_state == "rush" else 0.0)
	var lean: Vector2 = look*((12.0+speed_factor*3.0) if attack_state == "rush" else (windup*2.0+speed_factor*1.4))
	_draw_oval(Vector2(0,24),Vector2(16,4),Color(0.08,0.08,0.08,0.045))
	# articulated wings with membrane ribs
	for side_sign in [-1.0,1.0]:
		var shoulder: Vector2 = Vector2(side_sign*6.0,-3+fly)+lean*0.22
		var elbow: Vector2 = shoulder+Vector2(side_sign*(12.0+8.0*wing_open),-10.0-5.0*wing_open)
		var tip: Vector2 = elbow+Vector2(side_sign*(13.0+10.0*wing_open),8.0+7.0*(1.0-wing_open))
		var lower: Vector2 = shoulder+Vector2(side_sign*(13.0+5.0*wing_open),11.0)
		var wing_poly: PackedVector2Array = PackedVector2Array([shoulder,elbow,tip,lower])
		draw_colored_polygon(wing_poly,membrane)
		draw_line(shoulder,elbow,ink,2.0)
		draw_line(elbow,tip,ink,1.7)
		draw_line(shoulder,lower,ink,1.5)
		if detail >= 1:
			draw_line(shoulder,tip,Color(1,1,1,0.045),0.8)
			draw_line(elbow,lower,Color(0.04,0.04,0.04,0.20),0.8)
	# tapered predator torso
	var body_center: Vector2 = lean*0.30+Vector2(0,fly)
	var body: PackedVector2Array = PackedVector2Array([
		body_center+Vector2(-8,-7),body_center+Vector2(0,-14),body_center+Vector2(8,-7),body_center+Vector2(9,6),body_center+Vector2(0,17*stretch),body_center+Vector2(-9,6)
	])
	draw_colored_polygon(body,body_dark)
	if detail >= 1:
		draw_line(body_center+Vector2(-4,-5),body_center+Vector2(0,10),Color(1,1,1,0.055),0.8)
		draw_line(body_center+Vector2(4,-5),body_center+Vector2(0,10),Color(1,1,1,0.035),0.8)
	# long tail trails opposite the target direction
	var tail_root: Vector2 = body_center+Vector2(0,13*stretch)
	var tail_mid: Vector2 = tail_root-look*10.0+side*sin(anim_time*5.0)*3.5
	var tail_tip: Vector2 = tail_mid-look*11.0-side*sin(anim_time*4.3)*4.0
	draw_polyline(PackedVector2Array([tail_root,tail_mid,tail_tip]),ink,1.7)
	draw_colored_polygon(PackedVector2Array([tail_tip,tail_tip-look*4.5+side*2.5,tail_tip-look*3.0-side*2.5]),ink)
	# horned head and target-tracking eyes
	var head_center: Vector2 = body_center+look*(3.0+windup*2.0)+Vector2(0,-8)
	var head: PackedVector2Array = PackedVector2Array([
		head_center+Vector2(-6,-5),head_center+Vector2(-2,-9),head_center+Vector2(0,-6),head_center+Vector2(3,-10),head_center+Vector2(7,-4),head_center+Vector2(6,4),head_center+Vector2(0,7),head_center+Vector2(-6,4)
	])
	draw_colored_polygon(head,ink)
	var eye_shift: Vector2 = look*0.9
	draw_circle(head_center+Vector2(-3,-1),2.0,pale)
	draw_circle(head_center+Vector2(3,-1),2.0,pale)
	draw_circle(head_center+Vector2(-3,-1)+eye_shift,0.65,ink)
	draw_circle(head_center+Vector2(3,-1)+eye_shift,0.65,ink)
	# claws become visible near the player and reach forward during rush.
	for hand_sign in [-1.0,1.0]:
		var claw_root: Vector2 = body_center+Vector2(hand_sign*5,4)+look*(3.0+windup*2.0)
		var claw_hand: Vector2 = claw_root+look*(8.0+(8.0 if attack_state=="rush" else 0.0))+side*hand_sign*4.5
		draw_line(claw_root,claw_hand,ink,1.8)
		if detail >= 1:
			for ci in range(2):
				var cside: float = -1.0+float(ci)*2.0
				draw_line(claw_hand,claw_hand+look*4.0+side*cside*1.8,ink,0.9)
	if attack_state == "windup":
		_draw_attack_arrow(look,76.0+windup*36.0,0.17+windup*0.21)
	elif attack_state == "rush":
		for i in range(4):
			var back: Vector2 = -look*(18.0+float(i)*14.0)
			draw_line(back-side*8.0,back+side*8.0,Color(0.08,0.08,0.08,0.14-float(i)*0.025),1.4)
		draw_arc(look*12.0,18.0+rush_ratio*4.0,look.angle()-0.55,look.angle()+0.55,14,Color(1,1,1,0.06),1.0)

func _draw_spider() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"), hit_flash * 0.68)
	var shell_dark: Color = Color(0.08, 0.08, 0.08, 0.98)
	var shell_mid: Color = Color(0.13, 0.13, 0.13, 0.90)
	var pale: Color = Color(1.0, 0.985, 0.95, 0.16)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var moving_now: bool = visual_speed_ratio > 0.18
	var speed_factor: float = clampf(visual_speed_ratio, 0.0, 1.5)
	var body_bob: float = sin(visual_body_phase*1.9) * 0.95 if moving_now else sin(anim_time * 3.0) * 0.30
	var crouch: float = 1.5 if attack_state == "recover" else 0.0
	var head_twitch: float = sin(anim_time * 8.0) * 0.55
	var horizontal_look: float = clampf(look.x,-1.0,1.0)
	var abdomen_center := Vector2(-4.8, 4.5 + body_bob + crouch * 0.25)
	var thorax_center := Vector2(4.0, -4.4 + body_bob * 0.55)
	var head_center := Vector2(10.8 + horizontal_look*2.8, -8.0 + body_bob * 0.3 + head_twitch + look.y*1.2)
	_draw_oval(Vector2(2, 16), Vector2(18, 4.0), Color(0.08, 0.08, 0.08, 0.055))
	for side_index in range(2):
		var side_sign: float = -1.0 if side_index == 0 else 1.0
		for leg in range(4):
			var phase: float = visual_body_phase*2.1 + float(leg)*1.18 + float(side_index)*PI
			var stride: float = sin(phase)*(4.0+speed_factor*1.8) if moving_now else sin(phase)*0.8
			var lift: float = maxf(0.0,cos(phase))*3.0 if moving_now else 0.0
			var front_bias: float = 1.0-float(leg)/3.0
			var root_y: float = -7.0+float(leg)*4.7+body_bob*0.45
			var root_x: float = lerpf(5.2,-2.4,float(leg)/3.0)
			var root := Vector2(root_x*side_sign,root_y)
			var knee := Vector2(side_sign*(14.0+front_bias*5.0),root_y-6.0-lift*0.42)
			var tip := Vector2(side_sign*(27.0+float(leg)*1.6+front_bias*1.8)+stride,root_y+6.2-lift)
			if attack_state == "recover":
				tip += -look * (4.0 + front_bias)
			var passes: int = 1 if detail <= 0 else 2
			_sketch_line(root,knee,ink,2.0,passes,100+side_index*20+leg*3)
			_sketch_line(knee,tip,ink,1.6,passes,200+side_index*20+leg*3)
			draw_circle(knee,1.2,shell_dark)
			if detail >= 1:
				var segment_dir: Vector2 = (tip-knee).normalized()
				var segment_side: Vector2 = Vector2(-segment_dir.y,segment_dir.x)
				draw_line(knee+segment_dir,knee+segment_dir*3.6+segment_side*side_sign*1.5,Color(0.08,0.08,0.08,0.23),0.8)
	_draw_oval(abdomen_center,Vector2(11.5,12.5),shell_dark)
	_draw_oval(abdomen_center+Vector2(-0.7,0.6),Vector2(9.5,10.0),shell_mid)
	var thorax_shape: PackedVector2Array = PackedVector2Array([thorax_center+Vector2(-7.5,-5.0),thorax_center+Vector2(1.4,-7.2),thorax_center+Vector2(8.0,-1.8),thorax_center+Vector2(6.8,5.0),thorax_center+Vector2(-1.0,7.2),thorax_center+Vector2(-8.0,2.4)])
	draw_colored_polygon(thorax_shape,shell_dark)
	var head_shape: PackedVector2Array = PackedVector2Array([head_center+Vector2(-4.0,-4.5),head_center+Vector2(4.2,-5.5),head_center+Vector2(7.0,-0.8),head_center+Vector2(6.2,4.6),head_center+Vector2(0,6.4),head_center+Vector2(-5.0,2.4)])
	draw_colored_polygon(head_shape,shell_dark)
	if detail >= 1:
		for ridge in range(3):
			var rr: float = float(ridge)/2.0
			var yy: float = -4.2+rr*8.5
			draw_arc(abdomen_center+Vector2(-1.0,yy*0.04),8.3-rr, -2.55,-0.35,12,Color(1,1,1,0.08-rr*0.015),0.9)
		draw_line(abdomen_center+Vector2(-5.8,-1.4),abdomen_center+Vector2(2.8,5.8),pale,0.9)
	var eye_shift: Vector2 = look*0.65
	var eye_offsets: Array[Vector2] = [Vector2(-1.7,-1.8),Vector2(1.1,-2.3),Vector2(3.8,-1.6),Vector2(-0.1,0.8),Vector2(2.6,0.4)]
	var eye_count: int = 3 if detail <= 0 else 5
	for idx in range(eye_count):
		var ep: Vector2 = head_center+eye_offsets[idx]
		var radius: float = 1.15 if idx < 3 else 0.9
		draw_circle(ep,radius,Color("#fffdf7"))
		draw_circle(ep+eye_shift*0.45,radius*0.40,Color(0.08,0.08,0.08,0.86))
	if detail >= 1:
		var pal_twitch: float = sin(anim_time*12.0)*1.5
		_sketch_line(head_center+Vector2(-1.0,2.3),head_center+Vector2(6.4+pal_twitch,6.6),ink,1.1,1,320)
		_sketch_line(head_center+Vector2(2.5,2.1),head_center+Vector2(7.8-pal_twitch,1.2),ink,1.1,1,330)
		var fang_left: PackedVector2Array = PackedVector2Array([head_center+Vector2(1.8,2.4),head_center+Vector2(4.7,3.7),head_center+Vector2(3.5,8.2)])
		var fang_right: PackedVector2Array = PackedVector2Array([head_center+Vector2(4.0,1.8),head_center+Vector2(6.8,2.8),head_center+Vector2(6.2,7.1)])
		draw_colored_polygon(fang_left,shell_dark)
		draw_colored_polygon(fang_right,shell_dark)
	if contact_cooldown > 0.55:
		draw_arc(head_center,12.0,-0.3,0.35,10,Color(0.08,0.08,0.08,0.14),1.0)

func _draw_brute() -> void:
	var ink: Color = Color("#101010").lerp(Color("#777777"),hit_flash*0.68)
	var bone: Color = Color("#eee9dc")
	var armor: Color = Color(0.09,0.09,0.10,0.95)
	var armor_mid: Color = Color(0.15,0.15,0.16,0.88)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var side: Vector2 = Vector2(-look.y,look.x)
	var moving_now: bool = visual_speed_ratio > 0.08
	var gait: float = sin(visual_body_phase*1.20) if moving_now else 0.0
	var step: float = gait*2.5
	var bob: float = absf(gait)*0.65 if moving_now else sin(anim_time*2.0)*0.18
	var windup: float = clampf(1.0-state_time/0.72,0.0,1.0) if attack_state == "windup" else 0.0
	var rushing: bool = attack_state == "rush"
	var crouch: float = windup*5.0
	var rush_lean: Vector2 = look*(8.0 if rushing else windup*2.8)
	var torso_shift: Vector2 = rush_lean*0.34+Vector2(0,crouch*0.35)
	_draw_oval(Vector2(0,28),Vector2(26,6),Color(0.08,0.08,0.08,0.065))
	# thick, stomping legs
	draw_line(Vector2(-8,12+bob)+torso_shift*0.25,Vector2(-10+step,26),ink,4.2)
	draw_line(Vector2(8,12+bob)+torso_shift*0.25,Vector2(10-step,26),ink,4.2)
	draw_line(Vector2(-14+step,26),Vector2(-6+step,26),ink,3.2)
	draw_line(Vector2(6-step,26),Vector2(14-step,26),ink,3.2)
	# hunched armored mass
	var body: PackedVector2Array = PackedVector2Array([
		Vector2(-22,16+bob),Vector2(-22,-4+bob),Vector2(-14,-17+bob),Vector2(-7,-21+bob),Vector2(7,-21+bob),Vector2(15,-17+bob),Vector2(22,-4+bob),Vector2(23,16+bob),Vector2(10,23+bob),Vector2(-10,23+bob)
	])
	for i in range(body.size()):
		body[i] += torso_shift
	draw_colored_polygon(body,armor_mid)
	draw_polyline(PackedVector2Array([body[0],body[1],body[2],body[3],body[4],body[5],body[6],body[7],body[8],body[9],body[0]]),ink,1.4)
	# shoulder plates make silhouette much stronger
	for shoulder_sign in [-1.0,1.0]:
		var sc: Vector2 = Vector2(shoulder_sign*17,-10+bob)+torso_shift
		var plate: PackedVector2Array = PackedVector2Array([sc+Vector2(-6*shoulder_sign,-5),sc+Vector2(5*shoulder_sign,-7),sc+Vector2(8*shoulder_sign,1),sc+Vector2(3*shoulder_sign,7),sc+Vector2(-5*shoulder_sign,5)])
		draw_colored_polygon(plate,armor)
		if detail >= 1:
			draw_line(plate[0],plate[2],Color(1,1,1,0.05),0.9)
	# crossing chest straps / buckle
	draw_line(Vector2(-11,-10+bob)+torso_shift,Vector2(10,10+bob)+torso_shift,Color(0.04,0.04,0.04,0.70),2.2)
	draw_line(Vector2(11,-10+bob)+torso_shift,Vector2(-8,10+bob)+torso_shift,Color(0.04,0.04,0.04,0.58),2.0)
	draw_circle(Vector2(0,2+bob)+torso_shift,2.2,bone)
	# arms swing while walking; during windup both fists pull back then punch forward during rush.
	var arm_swing: float = gait*3.5 if moving_now else 0.0
	var left_shoulder: Vector2 = Vector2(-18,-7+bob)+torso_shift
	var right_shoulder: Vector2 = Vector2(18,-7+bob)+torso_shift
	var attack_pull: Vector2 = -look*(windup*8.0)
	var rush_push: Vector2 = look*(10.0 if rushing else 0.0)
	var left_elbow: Vector2 = left_shoulder+Vector2(-8,10+arm_swing)+attack_pull*0.6
	var right_elbow: Vector2 = right_shoulder+Vector2(8,10-arm_swing)+attack_pull*0.6
	var left_fist: Vector2 = left_elbow+Vector2(-4,10)+attack_pull+rush_push
	var right_fist: Vector2 = right_elbow+Vector2(4,10)+attack_pull+rush_push*1.15
	draw_line(left_shoulder,left_elbow,ink,4.6)
	draw_line(left_elbow,left_fist,ink,5.0)
	draw_line(right_shoulder,right_elbow,ink,4.6)
	draw_line(right_elbow,right_fist,ink,5.0)
	_draw_oval(left_fist,Vector2(5.7,4.7),ink)
	_draw_oval(right_fist,Vector2(5.7,4.7),ink)
	# cloth wraps on fists
	if detail >= 1:
		for fist in [left_fist,right_fist]:
			draw_line(fist+Vector2(-4,-1),fist+Vector2(4,1),Color(1,1,1,0.08),1.0)
			draw_line(fist+Vector2(-3,2),fist+Vector2(3,-2),Color(1,1,1,0.05),0.9)
	# horned skull follows the player
	var skull_center: Vector2 = Vector2(0,-24+bob)+look*1.5+torso_shift*0.25
	draw_circle(skull_center,11.2,bone)
	draw_arc(skull_center,11.2,0.0,TAU,22,ink,1.4)
	var horn_l: PackedVector2Array = PackedVector2Array([skull_center+Vector2(-8,-7),skull_center+Vector2(-16,-13),skull_center+Vector2(-11,-2)])
	var horn_r: PackedVector2Array = PackedVector2Array([skull_center+Vector2(8,-7),skull_center+Vector2(16,-13),skull_center+Vector2(11,-2)])
	draw_colored_polygon(horn_l,ink)
	draw_colored_polygon(horn_r,ink)
	var eye_shift: Vector2 = look*0.75
	draw_circle(skull_center+Vector2(-4,-1)+eye_shift,2.3,ink)
	draw_circle(skull_center+Vector2(4,-1)+eye_shift,2.3,ink)
	draw_colored_polygon(PackedVector2Array([skull_center+Vector2(0,1),skull_center+Vector2(-2,5),skull_center+Vector2(2,5)]),ink)
	if detail >= 1:
		draw_line(skull_center+Vector2(-6,8),skull_center+Vector2(6,8),ink,1.2)
	if attack_state == "windup":
		draw_arc(Vector2.ZERO,30.0+windup*7.0,0.0,TAU,22,Color(0.08,0.08,0.08,0.08+windup*0.11),1.8)
		_draw_attack_arrow(look,82.0+windup*40.0,0.17+windup*0.20)
	elif attack_state == "rush":
		for i in range(4):
			var back: Vector2 = -look*(16.0+float(i)*13.0)
			draw_circle(back,2.7,Color(0.08,0.08,0.08,0.10-float(i)*0.016))
		draw_line(-look*20.0-side*12.0,-look*36.0-side*12.0,Color(1,1,1,0.05),1.0)
		draw_line(-look*20.0+side*12.0,-look*36.0+side*12.0,Color(1,1,1,0.05),1.0)

func _draw_shaman() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.68)
	var bone: Color = Color("#f2ede2")
	var robe_dark: Color = Color(0.07,0.07,0.08,0.94)
	var robe_mid: Color = Color(0.12,0.12,0.14,0.84)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var side: Vector2 = Vector2(-look.y,look.x)
	var moving_now: bool = visual_speed_ratio > 0.10
	var gait: float = sin(visual_body_phase*1.25) if moving_now else 0.0
	var bob: float = sin(anim_time*4.0)*0.75 + absf(gait)*0.35
	var sway: float = gait*1.8 if moving_now else sin(anim_time*2.4)*0.65
	var cast_energy: float = clampf(summon_flash,0.0,1.0)
	var torso_shift: Vector2 = look*0.8+Vector2(sway*0.16,0)
	_draw_oval(Vector2(0,23),Vector2(20,5),Color(0.08,0.08,0.08,0.055))
	# rear robe and front layered panel
	var robe: PackedVector2Array = PackedVector2Array([Vector2(-17,20+bob),Vector2(-14,-7+bob),Vector2(-8,-16+bob),Vector2(7,-16+bob),Vector2(15,-6+bob),Vector2(18,20+bob),Vector2(6,16+bob),Vector2(0,24+bob),Vector2(-7,16+bob)])
	for i in range(robe.size()):
		robe[i] += torso_shift*0.25
	draw_colored_polygon(robe,robe_dark)
	var panel: PackedVector2Array = PackedVector2Array([Vector2(-5,-8+bob),Vector2(5,-8+bob),Vector2(6,15+bob),Vector2(0,21+bob),Vector2(-6,15+bob)])
	for i in range(panel.size()):
		panel[i] += torso_shift*0.25
	draw_colored_polygon(panel,robe_mid)
	if detail >= 1:
		draw_line(panel[0],panel[3],Color(1,1,1,0.055),0.9)
		draw_line(panel[1],panel[3],Color(0.04,0.04,0.04,0.18),0.9)
	# large hood with moving tip and visible collar
	var hood: PackedVector2Array = PackedVector2Array([Vector2(-14,-18+bob),Vector2(14,-18+bob),Vector2(9,-34+bob),Vector2(1,-43+bob+sway*0.35),Vector2(-9,-33+bob)])
	for i in range(hood.size()):
		hood[i] += torso_shift*0.18
	draw_colored_polygon(hood,ink)
	var collar: PackedVector2Array = PackedVector2Array([Vector2(-12,-13+bob),Vector2(-3,-9+bob),Vector2(0,-4+bob),Vector2(4,-9+bob),Vector2(12,-13+bob),Vector2(9,-5+bob),Vector2(-9,-5+bob)])
	for i in range(collar.size()):
		collar[i] += torso_shift*0.20
	draw_colored_polygon(collar,Color(1,1,1,0.05))
	var skull_center: Vector2 = Vector2(0,-22+bob)+look*1.0+torso_shift*0.15
	draw_circle(skull_center,8.2,bone)
	draw_arc(skull_center,8.2,0,TAU,18,ink,1.0)
	var eye_shift: Vector2 = look*0.58
	draw_circle(skull_center+Vector2(-3,-1)+eye_shift,2.0,ink)
	draw_circle(skull_center+Vector2(3,-1)+eye_shift,2.0,ink)
	# sleeves / hands react to focus
	var staff_hand: Vector2 = Vector2(12,-2+bob)+torso_shift*0.25+look*2.3+side*sway*0.18
	var free_hand: Vector2 = Vector2(-13,0+bob)+torso_shift*0.25-look*2.0+side*sin(anim_time*3.4)*1.7
	draw_line(Vector2(8,-7+bob)+torso_shift*0.20,staff_hand,ink,2.5)
	draw_line(Vector2(-8,-7+bob)+torso_shift*0.20,free_hand,ink,2.4)
	var sleeve_l: PackedVector2Array = PackedVector2Array([free_hand+Vector2(-4,-2),free_hand+Vector2(1,-3),free_hand+Vector2(3,2),free_hand+Vector2(-2,3)])
	var sleeve_r: PackedVector2Array = PackedVector2Array([staff_hand+Vector2(-3,-2),staff_hand+Vector2(3,-2),staff_hand+Vector2(3,2),staff_hand+Vector2(-2,3)])
	draw_colored_polygon(sleeve_l,robe_mid)
	draw_colored_polygon(sleeve_r,robe_mid)
	draw_circle(free_hand,2.0,bone)
	draw_circle(staff_hand,2.0,bone)
	# crooked staff with a little skull/lantern at the end.
	var staff_bottom: Vector2 = staff_hand-look*2.0+Vector2(6,27)
	var staff_mid: Vector2 = staff_hand+look*4.0+Vector2(4,-13)+side*sin(anim_time*2.8)*1.2
	var staff_top: Vector2 = staff_hand+look*9.0+Vector2(7,-28)
	draw_polyline(PackedVector2Array([staff_bottom,staff_hand,staff_mid,staff_top]),ink,2.3)
	draw_circle(staff_top,5.3,bone)
	draw_arc(staff_top,5.3,0.0,TAU,14,ink,1.1)
	draw_circle(staff_top+Vector2(-2,-1)+eye_shift*0.4,1.1,ink)
	draw_circle(staff_top+Vector2(2,-1)+eye_shift*0.4,1.1,ink)
	draw_line(staff_top+Vector2(-2,3),staff_top+Vector2(2,3),ink,0.8)
	# ritual hand animation / orbiting runes gets stronger at summon time
	var aura_alpha: float = 0.08+cast_energy*0.26
	var aura_count: int = 3 if detail <= 0 else 5
	for i in range(aura_count):
		var a: float = anim_time*(1.4+cast_energy*0.8)+float(i)*TAU/float(aura_count)
		var r: float = 9.0+cast_energy*10.0
		var rune_pos: Vector2 = free_hand+Vector2(cos(a)*r,sin(a)*r*0.62)
		draw_circle(rune_pos,1.5,Color(0.08,0.08,0.08,aura_alpha))
		if detail >= 2 and i % 2 == 0:
			draw_line(rune_pos,rune_pos+Vector2(cos(a),sin(a))*3.0,Color(1,1,1,0.05+cast_energy*0.05),0.8)
	if detail >= 2:
		draw_arc(free_hand,6.5+sin(anim_time*4.2),0.0,TAU,14,Color(1,1,1,0.06+cast_energy*0.08),1.0)
	if summon_flash > 0.0:
		draw_arc(Vector2(0,4),30.0+summon_flash*12.0,0.0,TAU,24,Color(0.08,0.08,0.08,0.17*summon_flash),1.3)

func _draw_warder() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.68)
	var bone: Color = Color("#f3eee4")
	var armor_light: Color = Color(0.91,0.90,0.86,0.92)
	var armor_dark: Color = Color(0.10,0.10,0.11,0.94)
	var detail: int = _visual_detail_level()
	var look: Vector2 = _visual_look()
	var side: Vector2 = Vector2(-look.y,look.x)
	var moving_now: bool = visual_speed_ratio > 0.08
	var gait: float = sin(visual_body_phase*1.4) if moving_now else 0.0
	var step: float = gait*2.6
	var bob: float = absf(gait)*0.55 if moving_now else sin(anim_time*2.0)*0.12
	var windup: float = clampf(1.0-state_time/0.62,0.0,1.0) if attack_state == "windup" else 0.0
	var rush: float = 1.0 if attack_state == "rush" else 0.0
	var brace: float = maxf(windup,rush)
	var torso_shift: Vector2 = look*(1.0+brace*2.4)
	_draw_oval(Vector2(0,23),Vector2(23,6),Color(0.08,0.08,0.08,0.065))
	draw_line(Vector2(-6,9+bob)+torso_shift*0.20,Vector2(-9+step,23),ink,3.2)
	draw_line(Vector2(6,9+bob)+torso_shift*0.20,Vector2(9-step,23),ink,3.2)
	draw_line(Vector2(-12+step,23),Vector2(-6+step,23),ink,2.3)
	draw_line(Vector2(6-step,23),Vector2(12-step,23),ink,2.3)
	# layered torso armor
	var torso: PackedVector2Array = PackedVector2Array([Vector2(-14,8+bob),Vector2(-13,-12+bob),Vector2(13,-12+bob),Vector2(15,8+bob),Vector2(7,15+bob),Vector2(-7,15+bob)])
	for i in range(torso.size()):
		torso[i] += torso_shift*0.28
	draw_colored_polygon(torso,armor_light)
	draw_polyline(PackedVector2Array([torso[0],torso[1],torso[2],torso[3],torso[4],torso[5],torso[0]]),ink,1.4)
	var chest_plate: PackedVector2Array = PackedVector2Array([Vector2(-9,-8+bob),Vector2(9,-8+bob),Vector2(10,3+bob),Vector2(0,10+bob),Vector2(-10,3+bob)])
	for i in range(chest_plate.size()):
		chest_plate[i] += torso_shift*0.28
	draw_colored_polygon(chest_plate,Color(1,1,1,0.08))
	if detail >= 1:
		draw_line(chest_plate[0],chest_plate[3],Color(0.08,0.08,0.08,0.14),1.0)
		draw_line(chest_plate[1],chest_plate[3],Color(1,1,1,0.08),0.9)
	# helmet/skull combination
	var skull_center: Vector2 = Vector2(0,-23+bob)+look*1.0+torso_shift*0.15
	draw_circle(skull_center,10.6,bone)
	var helmet: PackedVector2Array = PackedVector2Array([skull_center+Vector2(-11,-2),skull_center+Vector2(-8,-10),skull_center+Vector2(0,-14),skull_center+Vector2(8,-10),skull_center+Vector2(11,-2),skull_center+Vector2(7,-4),skull_center+Vector2(-7,-4)])
	draw_colored_polygon(helmet,armor_dark)
	draw_line(skull_center+Vector2(-10,-2),skull_center+Vector2(10,-2),Color(1,1,1,0.10),1.0)
	var eye_shift: Vector2 = look*0.7
	draw_circle(skull_center+Vector2(-4,1)+eye_shift,2.1,ink)
	draw_circle(skull_center+Vector2(4,1)+eye_shift,2.1,ink)
	# shield braced toward target; during rush it moves forward and blocks more of the body.
	var shield_center: Vector2 = look*(18.0+brace*4.0)+side*3.0+Vector2(0,2+bob)+torso_shift*0.20
	# spear hand and shaft are independently posed.
	var spear_hand: Vector2 = Vector2(-7,0+bob)+torso_shift*0.25-side*3.0-look*windup*2.0
	var spear_dir: Vector2 = (look+side*(0.12*(1.0-windup))).normalized()
	var spear_tip: Vector2 = spear_hand+spear_dir*(34.0+windup*13.0)-side*(7.0-4.0*windup)
	var spear_back: Vector2 = spear_hand-spear_dir*20.0+side*4.0
	draw_line(spear_back,spear_tip,ink,2.1)
	draw_colored_polygon(PackedVector2Array([spear_tip+spear_dir*5.5,spear_tip-spear_dir*2.0+side*2.5,spear_tip-spear_dir*2.0-side*2.5]),ink)
	draw_circle(spear_hand,2.2,bone)
	if not shield_broken:
		var shield: PackedVector2Array = PackedVector2Array([shield_center+side*15.0-look*6.0,shield_center+side*13.0+look*10.0,shield_center+look*17.0,shield_center-side*13.0+look*10.0,shield_center-side*15.0-look*6.0])
		draw_colored_polygon(shield,armor_dark)
		draw_polyline(PackedVector2Array([shield[0],shield[1],shield[2],shield[3],shield[4],shield[0]]),Color("#fffdf7"),1.0)
		# central emblem reads at gameplay scale.
		draw_line(shield_center-side*6.0,shield_center+side*6.0,Color(1,1,1,0.10),1.0)
		draw_line(shield_center-look*5.0,shield_center+look*8.0,Color(1,1,1,0.08),1.0)
		var ratio: float = float(shield_health)/float(maxi(1,shield_max))
		if ratio < 0.76:
			draw_line(shield_center-side*3.0,shield_center+look*8.0+side*5.0,Color("#fffdf7"),1.2)
		if ratio < 0.51:
			draw_line(shield_center+look*2.0,shield_center-look*7.0-side*7.0,Color("#fffdf7"),1.1)
		if ratio < 0.26:
			draw_line(shield_center+side*6.0,shield_center+look*12.0-side*4.0,Color("#fffdf7"),1.1)
		if detail >= 1:
			for i in range(shield_max):
				draw_circle(Vector2(-9.0+float(i)*6.0,-43),1.6,ink if i < shield_health else Color(0.08,0.08,0.08,0.08))
	else:
		draw_line(Vector2(-12,-3+bob),Vector2(-23,11+bob),ink,2.1)
		draw_line(Vector2(12,-3+bob),Vector2(23,11+bob),ink,2.1)
		draw_arc(Vector2(0,-4+bob),24.0,PI*0.12,PI*0.88,16,Color(0.08,0.08,0.08,0.09),1.0)
	if attack_state == "windup":
		draw_arc(shield_center,18.0+windup*3.0,look.angle()-0.55,look.angle()+0.55,16,Color(1,1,1,0.05+windup*0.04),1.0)
		_draw_attack_arrow(look,52.0+windup*26.0,0.13+windup*0.18)
	elif attack_state == "rush":
		for i in range(3):
			var back: Vector2 = -look*(14.0+float(i)*12.0)
			draw_line(back-side*8.0,back+side*8.0,Color(0.08,0.08,0.08,0.10-float(i)*0.02),1.2)

func _draw_attack_arrow(dir: Vector2, length_value: float, alpha: float) -> void:
	if dir.length_squared() < 0.001:
		return
	var d: Vector2 = dir.normalized()
	var side: Vector2 = Vector2(-d.y, d.x)
	var start: Vector2 = d * 18.0
	var tip: Vector2 = d * length_value
	draw_line(start, tip, Color(0.08,0.08,0.08,alpha), 2.0)
	draw_line(tip, tip - d * 11.0 + side * 7.0, Color(0.08,0.08,0.08,alpha), 2.0)
	draw_line(tip, tip - d * 11.0 - side * 7.0, Color(0.08,0.08,0.08,alpha), 2.0)

func _sketch_line(a: Vector2, b: Vector2, color: Color, width: float, passes: int, seed_value: int) -> void:
	for i in range(passes):
		var off_a := Vector2(sketch_jitter(seed_value + i * 2, 0.9), sketch_jitter(seed_value + i * 2 + 1, 0.9))
		var off_b := Vector2(sketch_jitter(seed_value + 20 + i * 2, 0.9), sketch_jitter(seed_value + 21 + i * 2, 0.9))
		draw_line(a + off_a, b + off_b, color, width)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(20):
		var a: float = TAU * float(i) / 20.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)


func _exit_tree() -> void:
	if is_instance_valid(endless_controller) and endless_controller.has_method("notify_enemy_removed"):
		endless_controller.notify_enemy_removed(get_instance_id())
