# BUILD 0717 — More Flow per hit

- Increased Flow gain per normal hit from 0.18 to 0.30.
- Existing strength multipliers remain: elite hits use 1.2x and boss hits use 1.4x.
- Kill/elite Flow rewards from 0715 remain unchanged.
