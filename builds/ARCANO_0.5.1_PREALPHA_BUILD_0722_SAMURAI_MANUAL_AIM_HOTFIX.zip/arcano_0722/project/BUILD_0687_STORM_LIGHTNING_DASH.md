# BUILD 0687 — STORM LIGHTNING DASH

## Focus
Storm only.

## Changes
- Storm dash now visually transforms the mage into a lightning form during the active dash window.
- Added a storm-specific dash body replacement while dashing, so the class reads like a bolt/teleport burst instead of a normal slide.
- Added new storm dash trail, front arc and branching lightning visuals.
- Added a short storm dash recovery flash so the return to human form feels more impactful.
- Increased the emphasis of Storm lightning effects during and right after dashing.

## Files changed
- player.gd
- endless_main.gd
