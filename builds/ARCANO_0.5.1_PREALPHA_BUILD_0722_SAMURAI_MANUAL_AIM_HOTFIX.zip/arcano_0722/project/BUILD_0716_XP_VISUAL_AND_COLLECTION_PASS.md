# BUILD 0716 — XP visual and collection pass

## Goals
- Improve the visual impact when XP drops from enemies.
- Make vase XP burst outward first, then get sucked into the player with a satisfying flow.
- Make XP orbs more readable and more integrated with the game's current visual style.

## Main changes
- Reworked `xp_orb.gd` visuals with stronger glow, layered crystal shape, sparkle accents and movement trails.
- Added launch/burst motion to XP drops from enemies so they pop out instead of appearing flat.
- Added smooth delayed attraction support to XP orbs.
- Vase XP now spreads in a small burst around the vase, then auto-pulls toward the player after a short delay.
- Rare XP from vases follows the same satisfying burst-then-suck behavior.
- Rare XP cache consumable also uses the improved orb motion.

## Files changed
- xp_orb.gd
- endless_main.gd
