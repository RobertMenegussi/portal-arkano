extends CharacterBody2D

signal intro_cutscene_requested
signal defeat_cutscene_requested
signal defeated_event
signal post_defeat_interaction_requested

const ArrowScript = preload("res://enemy_arrow.gd")
const HitFxScript = preload("res://hit_fx.gd")
const ShockwaveScript = preload("res://boss_shockwave.gd")
const MarkStrikeScript = preload("res://boss_mark_strike.gd")
const BoneCageScript = preload("res://boss_bone_cage.gd")
const EnemyScript = preload("res://enemy.gd")
const BoneLanesScript = preload("res://boss_bone_lanes.gd")

var player
var active: bool = false
var battle_started: bool = false
var intro_requested: bool = false
var cutscene_locked: bool = false
var defeated: bool = false
var resolved: bool = false
var post_interaction_done: bool = false
var health: int = 36
var max_health: int = 36
var cooldown: float = 1.0
var attack_index: int = 0
var state: String = "idle"
var state_time: float = 0.0
var aim_direction: Vector2 = Vector2.LEFT
var hit_flash: float = 0.0
var knockback: Vector2 = Vector2.ZERO
var anim_t: float = 0.0
var frame_id: int = 0
var sketch_timer: float = 0.0
var defeat_progress: float = 0.0
var e_was_down: bool = false
var leap_target: Vector2 = Vector2.ZERO
var cage_target: Vector2 = Vector2.ZERO
var leap_visual: float = 0.0
var summon_stage: int = 0
var phase_flash: float = 0.0
var multi_leap_left: int = 0
var lanes_horizontal: bool = false
var fan_repeat_left: int = 0
var phase_announced: int = 1

var battle_intro_lines: Array = [
	{"who":"Olheiro Distante", "tone":"soft", "text":"...para aí."},
	{"who":"Mago", "tone":"normal", "text":"Você atravessou esse lugar inteiro pra pedir isso?"},
	{"who":"Olheiro Distante", "tone":"mocking", "text":"Atravessei muito mais que isso."},
	{"who":"Olheiro Distante", "tone":"grave", "text":"Dracaris ouviu um rumor. Um mago caminhando onde só apareciam guerreiros."},
	{"who":"Mago", "tone":"normal", "text":"E mandou você me matar?"},
	{"who":"Olheiro Distante", "tone":"soft", "text":"Não."},
	{"who":"Olheiro Distante", "tone":"grave", "text":"Mandou olhar."},
	{"who":"Mago", "tone":"mocking", "text":"Então olha bem."},
	{"who":"Olheiro Distante", "tone":"mocking", "text":"É exatamente o que eu vim fazer."},
	{"who":"Olheiro Distante", "tone":"shout", "text":"Me mostra se o rumor merece chegar até ele!"}
]

var defeated_lines: Array = [
	{"who":"Olheiro Distante", "tone":"hurt", "text":"...droga."},
	{"who":"Mago", "tone":"normal", "text":"Você não parecia alguém que veio só observar."},
	{"who":"Olheiro Distante", "tone":"mocking", "text":"Observar não significa ficar parado."},
	{"who":"Mago", "tone":"grave", "text":"Dracaris sabe que eu tô aqui?"},
	{"who":"Olheiro Distante", "tone":"soft", "text":"Antes de hoje? Não."},
	{"who":"Mago", "tone":"normal", "text":"E agora?"},
	{"who":"Olheiro Distante", "tone":"hurt", "text":"Agora ele sabe que o rumor anda... luta... e vence."},
	{"who":"Mago", "tone":"grave", "text":"Então você veio medir a ameaça."},
	{"who":"Olheiro Distante", "tone":"grave", "text":"Eu vim decidir se valia a pena pronunciar seu nome diante dele."},
	{"who":"Mago", "tone":"mocking", "text":"E vale?"},
	{"who":"Olheiro Distante", "tone":"hurt", "text":"...infelizmente pra mim, vale."},
	{"who":"Olheiro Distante", "tone":"grave", "text":"Os quatro guardiões ainda carregam as cores que Dracaris arrancou do mundo."},
	{"who":"Olheiro Distante", "tone":"grave", "text":"Se continuar andando, cada vitória vai devolver algo a você... e avisar a ele que você está mais perto."},
	{"who":"Mago", "tone":"soft", "text":"Ótimo."},
	{"who":"Olheiro Distante", "tone":"normal", "text":"Ótimo?"},
	{"who":"Mago", "tone":"mocking", "text":"Economiza o trabalho de apresentação."}
]

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	collision_layer = 0
	collision_mask = 0
	z_index = 25
	visible = false
	add_to_group("enemy")
	add_to_group("mini_boss")
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 21.0
	collider.shape = shape
	collider.position = Vector2(0,10)
	add_child(collider)

func _process(delta: float) -> void:
	if process_mode != Node.PROCESS_MODE_ALWAYS:
		return
	anim_t += delta
	_update_sketch(delta)
	queue_redraw()

func _physics_process(delta: float) -> void:
	anim_t += delta
	_update_sketch(delta)
	hit_flash = move_toward(hit_flash,0.0,delta*7.0)
	knockback = knockback.move_toward(Vector2.ZERO,delta*640.0)
	leap_visual = move_toward(leap_visual,0.0,delta*4.0)
	phase_flash = move_toward(phase_flash,0.0,delta*2.2)

	if defeated:
		velocity = Vector2.ZERO
		_update_post_defeat_interaction()
		queue_redraw()
		return
	if cutscene_locked:
		velocity = Vector2.ZERO
		queue_redraw()
		return

	if not intro_requested and not battle_started and is_instance_valid(player):
		if global_position.distance_to(player.global_position) < 260.0:
			intro_requested = true
			intro_cutscene_requested.emit()
		return

	if not active or not battle_started or not is_instance_valid(player) or not player.active:
		velocity = Vector2.ZERO
		queue_redraw()
		return

	cooldown = maxf(0.0,cooldown-delta)
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	if to_player.length_squared() > 0.001:
		aim_direction = to_player.normalized()

	match state:
		"leap_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				state = "leap"
				state_time = 0.42 if _current_phase() >= 2 else 0.48
				leap_visual = 1.0
				get_tree().call_group("screen_fx","pulse_boss")
		"leap":
			state_time -= delta
			var desired: Vector2 = leap_target-global_position
			velocity = desired / maxf(state_time,0.08)
			var max_speed: float = 650.0 if _current_phase() >= 3 else 590.0
			if velocity.length() > max_speed:
				velocity = velocity.normalized()*max_speed
			if state_time <= 0.0 or desired.length() < 18.0:
				_land_leap()
		"parry":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_fire_fan(5,0.34,520.0)
				_recover(0.32,0.66 if _current_phase() >= 3 else 0.82)
		"cage_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_spawn_bone_cage()
				if _current_phase() >= 2:
					_spawn_mark()
				_recover(0.46,0.78 if _current_phase() >= 3 else 1.02)
		"shockwave_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_spawn_shockwaves(4 if _current_phase() >= 3 else 3,190.0 if _current_phase() >= 3 else 165.0)
				_recover(0.50,0.76 if _current_phase() >= 3 else 0.98)
		"mark_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_spawn_mark()
				if _current_phase() >= 3:
					_spawn_shockwaves(2,140.0)
				_recover(0.42,0.72 if _current_phase() >= 3 else 0.94)
		"fan_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_fire_fan(9 if _current_phase() >= 3 else 7,0.74 if _current_phase() >= 3 else 0.58,500.0)
				if fan_repeat_left > 0:
					fan_repeat_left -= 1
					state = "fan_windup"
					state_time = 0.34
				else:
					_recover(0.34,0.74 if _current_phase() >= 3 else 0.92)
		"lanes_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_spawn_bone_lanes()
				if _current_phase() >= 3:
					_spawn_mark()
				_recover(0.44,0.78)
		"recover":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				state = "idle"
		_:
			var phase: int = _current_phase()
			if dist > 255.0:
				velocity = aim_direction*(102.0 if phase >= 2 else 86.0)+knockback
			elif dist < 145.0:
				velocity = -aim_direction*(92.0 if phase >= 3 else 78.0)+knockback
			else:
				var side: Vector2 = Vector2(-aim_direction.y,aim_direction.x)
				velocity = side*(36.0 if phase >= 2 else 18.0)+knockback
			if cooldown <= 0.0:
				_begin_next_attack()

	move_and_slide()
	queue_redraw()

func _begin_next_attack() -> void:
	var phase: int = _current_phase()
	var pattern: int = attack_index % 6
	if phase == 1:
		match pattern:
			0:
				_start_leap_combo(1)
			1:
				state = "fan_windup"
				state_time = 0.62
				fan_repeat_left = 0
			2:
				state = "cage_windup"
				state_time = 0.68
				cage_target = player.global_position
			3:
				state = "shockwave_windup"
				state_time = 0.54
			4:
				state = "mark_windup"
				state_time = 0.50
			_:
				state = "parry"
				state_time = 0.78
	elif phase == 2:
		match pattern:
			0:
				_start_leap_combo(2)
			1:
				state = "lanes_windup"
				state_time = 0.52
			2:
				state = "fan_windup"
				state_time = 0.50
				fan_repeat_left = 0
			3:
				state = "cage_windup"
				state_time = 0.55
				cage_target = player.global_position
			4:
				state = "parry"
				state_time = 0.64
			_:
				state = "mark_windup"
				state_time = 0.40
	else:
		match pattern:
			0:
				_start_leap_combo(3)
			1:
				state = "lanes_windup"
				state_time = 0.44
			2:
				state = "fan_windup"
				state_time = 0.42
				fan_repeat_left = 1
			3:
				state = "cage_windup"
				state_time = 0.46
				cage_target = player.global_position
			4:
				state = "shockwave_windup"
				state_time = 0.38
			_:
				state = "parry"
				state_time = 0.52
	attack_index += 1

func _start_leap_combo(count: int) -> void:
	multi_leap_left = maxi(0,count-1)
	state = "leap_windup"
	state_time = 0.50 if count <= 1 else 0.40
	leap_target = player.global_position

func _recover(duration: float, next_cooldown: float) -> void:
	state = "recover"
	state_time = duration
	cooldown = next_cooldown

func _land_leap() -> void:
	velocity = Vector2.ZERO
	if is_instance_valid(player) and global_position.distance_to(player.global_position) < 74.0:
		player.take_damage(1,(player.global_position-global_position).normalized())
	var phase: int = _current_phase()
	_spawn_shockwaves(2 if phase < 3 else 3,128.0 if phase < 3 else 148.0)
	get_tree().call_group("screen_fx","pulse_boss")
	if multi_leap_left > 0 and is_instance_valid(player):
		multi_leap_left -= 1
		state = "leap_windup"
		state_time = 0.24
		leap_target = player.global_position
	else:
		_recover(0.38 if phase >= 2 else 0.52,0.72 if phase >= 3 else (0.88 if phase == 2 else 1.12))


func _current_phase() -> int:
	if max_health <= 0:
		return 1
	var ratio: float = float(health)/float(max_health)
	if ratio <= 0.34:
		return 3
	if ratio <= 0.67:
		return 2
	return 1

func _fire_fan(count: int, spread: float, speed_value: float) -> void:
	if not is_instance_valid(player):
		return
	var base: Vector2 = (player.global_position-global_position).normalized()
	for i in range(count):
		var t_value: float = 0.5 if count <= 1 else float(i)/float(count-1)
		var angle: float = lerpf(-spread,spread,t_value)
		var arrow = ArrowScript.new()
		arrow.direction = base.rotated(angle)
		arrow.speed = speed_value
		arrow.global_position = global_position+arrow.direction*29.0+Vector2(0,-8)
		get_tree().current_scene.add_child(arrow)
	get_tree().call_group("audio_bus","play_enemy_shot")
	get_tree().call_group("screen_fx","pulse_boss")

func _spawn_bone_lanes() -> void:
	var lanes = BoneLanesScript.new()
	lanes_horizontal = not lanes_horizontal
	var offsets: Array = []
	if _current_phase() >= 3:
		offsets = [-210.0,-105.0,0.0,105.0,210.0]
	else:
		offsets = [-180.0,-60.0,60.0,180.0]
	lanes.configure(player,lanes_horizontal,offsets)
	lanes.global_position = Vector2(1810,625)
	get_tree().current_scene.add_child(lanes)
	get_tree().call_group("screen_fx","pulse_boss_mark")

func _counter_shot() -> void:
	if not is_instance_valid(player):
		return
	var dir: Vector2 = (player.global_position-global_position).normalized()
	var arrow = ArrowScript.new()
	arrow.direction = dir
	arrow.global_position = global_position+dir*28.0+Vector2(0,-8)
	get_tree().current_scene.add_child(arrow)
	get_tree().call_group("audio_bus","play_enemy_shot")

func _spawn_bone_cage() -> void:
	var cage = BoneCageScript.new()
	cage.configure(player, cage_target)
	get_tree().current_scene.add_child(cage)
	get_tree().call_group("screen_fx", "pulse_boss_mark")

func _spawn_shockwaves(waves: int = 3, radius: float = 150.0) -> void:
	var wave = ShockwaveScript.new()
	wave.configure(player)
	wave.wave_count = waves
	wave.max_radius = radius
	wave.global_position = global_position
	get_tree().current_scene.add_child(wave)
	get_tree().call_group("screen_fx","pulse_boss")

func _spawn_mark() -> void:
	var mark = MarkStrikeScript.new()
	mark.configure(player)
	get_tree().current_scene.add_child(mark)

func _reflect_attack(hit_direction: Vector2) -> void:
	var dir: Vector2 = -hit_direction.normalized()
	if dir.length_squared() < 0.001 and is_instance_valid(player):
		dir = (player.global_position-global_position).normalized()
	var arrow = ArrowScript.new()
	arrow.direction = dir
	arrow.global_position = global_position+dir*28.0+Vector2(0,-8)
	get_tree().current_scene.add_child(arrow)
	get_tree().call_group("screen_fx","pulse_boss")
	get_tree().call_group("audio_bus","play_enemy_shot")

func _update_post_defeat_interaction() -> void:
	if resolved or post_interaction_done or not is_instance_valid(player) or not player.active:
		return
	var down: bool = Input.is_key_pressed(KEY_E)
	if down and not e_was_down:
		post_interaction_done = true
		post_defeat_interaction_requested.emit()
	e_was_down = down

func begin_intro_cutscene() -> void:
	cutscene_locked = true
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = true
	collision_layer = 0
	collision_mask = 0
	scale = Vector2(0.38,0.08)
	modulate.a = 0.0

func finish_intro_cutscene() -> void:
	cutscene_locked = false
	battle_started = true
	active = true
	process_mode = Node.PROCESS_MODE_PAUSABLE
	collision_layer = 4
	collision_mask = 1
	scale = Vector2(0.92,0.92)
	modulate.a = 1.0
	cooldown = 0.75

func begin_defeat_cutscene() -> void:
	defeated = true
	active = false
	cutscene_locked = true
	process_mode = Node.PROCESS_MODE_ALWAYS
	collision_layer = 0
	collision_mask = 0
	velocity = Vector2.ZERO
	defeat_progress = 0.0

func finish_defeat_pose() -> void:
	defeat_progress = 1.0
	cutscene_locked = false
	process_mode = Node.PROCESS_MODE_PAUSABLE
	post_interaction_done = false
	e_was_down = Input.is_key_pressed(KEY_E)

func take_damage(amount: int, hit_direction: Vector2) -> void:
	if defeated or cutscene_locked or not active:
		return
	if state == "parry":
		_reflect_attack(hit_direction)
		return
	var final_amount: int = amount
	if is_instance_valid(player) and "endless_elite_damage_bonus" in player:
		var bonus: float = float(player.endless_elite_damage_bonus)
		if bonus > 0.0:
			var scaled: float = float(amount)*(1.0+bonus)
			final_amount = int(floor(scaled))
			if randf() < scaled-float(final_amount):
				final_amount += 1
	health -= maxi(1,final_amount)
	hit_flash = 1.0
	_check_phase_summons()
	knockback = hit_direction.normalized()*145.0
	var fx = HitFxScript.new()
	fx.global_position = global_position
	fx.direction = hit_direction
	fx.tint = Color("#111111")
	get_tree().current_scene.add_child(fx)
	get_tree().call_group("audio_bus", "play_enemy_hit")
	get_tree().call_group("screen_fx", "pulse_enemy_hit")
	if is_instance_valid(player):
		player.on_enemy_hit(1.4)
	if health <= 0:
		health = 0
		active = false
		_dismiss_summons()
		defeated_event.emit()
		defeat_cutscene_requested.emit()


func _check_phase_summons() -> void:
	if max_health <= 0 or defeated:
		return
	var ratio: float = float(health) / float(max_health)
	if summon_stage < 1 and ratio <= 0.70:
		summon_stage = 1
		phase_announced = 2
		_summon_group(["stalker","slime","slime"])
		phase_flash = 1.0
		cooldown = 0.15
	elif summon_stage < 2 and ratio <= 0.45:
		summon_stage = 2
		_summon_group(["warder","shaman"])
		phase_flash = 1.0
		cooldown = 0.12
	elif summon_stage < 3 and ratio <= 0.25:
		summon_stage = 3
		phase_announced = 3
		_summon_group(["stalker","skeleton","shaman"])
		phase_flash = 1.0
		cooldown = 0.05

func _summon_group(kinds: Array) -> void:
	phase_flash = 1.0
	get_tree().call_group("screen_fx","pulse_boss")
	for i in range(kinds.size()):
		var angle: float = TAU * float(i) / maxf(1.0,float(kinds.size())) + 0.35
		var radius: float = 118.0 + float(i % 2) * 38.0
		var spawn_pos: Vector2 = global_position + Vector2(cos(angle),sin(angle)) * radius
		var enemy = EnemyScript.new()
		enemy.configure(str(kinds[i]),player)
		enemy.global_position = spawn_pos
		get_tree().current_scene.add_child(enemy)
		enemy.add_to_group("boss_summon")

func _dismiss_summons() -> void:
	for enemy in get_tree().get_nodes_in_group("boss_summon"):
		if is_instance_valid(enemy):
			enemy.queue_free()

func apply_external_force(force: Vector2) -> void:
	knockback += force*0.38

func resolve_outcome(spared: bool) -> void:
	resolved = true
	cutscene_locked = false
	process_mode = Node.PROCESS_MODE_PAUSABLE
	if spared:
		modulate = Color(1,1,1,0.72)
	else:
		modulate = Color(0.70,0.70,0.70,1.0)

func _update_sketch(delta: float) -> void:
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.068
		frame_id += 1

func _j(index: int, amount: float) -> float:
	return sin(float(frame_id)*2.1+float(index)*3.9)*amount

func _sketch_line(a: Vector2,b: Vector2,color: Color,width: float,passes: int,seed_value: int) -> void:
	for i in range(passes):
		var off_a: Vector2 = Vector2(_j(seed_value+i*2,1.0),_j(seed_value+i*2+1,1.0))
		var off_b: Vector2 = Vector2(_j(seed_value+20+i*2,1.0),_j(seed_value+21+i*2,1.0))
		draw_line(a+off_a,b+off_b,color,width)

func _draw_oval(center: Vector2,radii: Vector2,color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU*float(i)/24.0
		points.append(center+Vector2(cos(a)*radii.x,sin(a)*radii.y))
	draw_colored_polygon(points,color)

func _with_alpha(color: Color,alpha: float) -> Color:
	return Color(color.r,color.g,color.b,color.a*alpha)

func _draw() -> void:
	if not visible:
		return
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.68)
	var paper: Color = Color("#f7f2e8")
	var bob: float = sin(anim_t*5.0)*1.0 if active else 0.0
	var lift: float = -22.0*clampf(leap_visual,0.0,1.0)
	_draw_oval(Vector2(0,28),Vector2(31,8),Color(0.10,0.10,0.10,0.08))
	if defeat_progress > 0.0:
		var fall: float = clampf(defeat_progress,0.0,1.0)
		_draw_standing_pose(bob+lift,ink,paper,1.0-fall)
		_draw_defeated_pose(ink,paper,fall)
	else:
		_draw_standing_pose(bob+lift,ink,paper,1.0)
	if state == "parry" and not defeated:
		for i in range(3):
			draw_arc(Vector2.ZERO,34.0+float(i)*5.0,-1.35,1.35,20,Color(0.08,0.08,0.08,0.18),2.0)
	if state == "leap_windup":
		draw_arc(Vector2.ZERO,40.0,0.0,TAU,30,Color(0.08,0.08,0.08,0.18),1.4)
		if is_instance_valid(player):
			var leap_dir: Vector2 = (leap_target-global_position).normalized()
			draw_line(leap_dir*28.0,leap_dir*98.0,Color(0.08,0.08,0.08,0.22),2.0)
	if state == "fan_windup" and is_instance_valid(player):
		var base_dir: Vector2 = (player.global_position-global_position).normalized()
		var spread_value: float = 0.74 if _current_phase() >= 3 else 0.58
		for i in range(5):
			var tv: float = float(i)/4.0
			var d: Vector2 = base_dir.rotated(lerpf(-spread_value,spread_value,tv))
			draw_line(d*26.0,d*86.0,Color(0.08,0.08,0.08,0.14),1.0)
	if state == "lanes_windup":
		for i in range(3):
			draw_arc(Vector2.ZERO,38.0+float(i)*7.0,0.0,TAU,26,Color(0.08,0.08,0.08,0.10),1.0)
	if phase_flash > 0.02:
		for i in range(3):
			draw_arc(Vector2.ZERO,46.0 + float(i)*10.0 + (1.0-phase_flash)*18.0,0.0,TAU,30,Color(0.08,0.08,0.08,0.12*phase_flash),1.3)
	if defeated and not resolved and not post_interaction_done:
		_draw_permanent_prompt()

func _draw_standing_pose(bob: float,ink: Color,paper: Color,alpha: float) -> void:
	if alpha <= 0.01:
		return
	var i_col: Color = _with_alpha(ink,alpha)
	var p_col: Color = _with_alpha(paper,alpha)
	var step: float = sin(anim_t*8.0)*4.0 if active and state == "idle" else 0.0
	_sketch_line(Vector2(-7,14+bob),Vector2(-12+step,30+bob),i_col,3.2,3,0)
	_sketch_line(Vector2(7,14+bob),Vector2(12-step,30+bob),i_col,3.2,3,10)
	_sketch_line(Vector2(0,-1+bob),Vector2(0,16+bob),i_col,3.5,3,20)
	_sketch_line(Vector2(-15,1+bob),Vector2(15,1+bob),i_col,2.4,2,23)
	for y in [-10.0,-5.0,0.0,5.0]:
		draw_arc(Vector2(0,y+bob),11.5,0.22,PI-0.22,18,i_col,2.2)
	# ragged scout cloak
	var cloak: PackedVector2Array = PackedVector2Array([Vector2(-15,0+bob),Vector2(-22,19+bob),Vector2(-8,15+bob),Vector2(0,23+bob),Vector2(11,15+bob),Vector2(18,20+bob),Vector2(14,0+bob)])
	draw_colored_polygon(cloak,_with_alpha(Color(0.11,0.11,0.11,0.38),alpha))
	draw_circle(Vector2(0,-24+bob),14.0,p_col)
	for pass_i in range(3):
		draw_arc(Vector2(_j(30+pass_i,0.8),-24+bob+_j(40+pass_i,0.6)),14.0,0.0,TAU,26,i_col,1.5)
	draw_circle(Vector2(-5,-25+bob),2.8,i_col)
	draw_circle(Vector2(5,-25+bob),2.8,i_col)
	draw_line(Vector2(-6,-16+bob),Vector2(6,-16+bob),i_col,1.5)
	# eye sigil on forehead identifies him as Dracaris' scout
	draw_arc(Vector2(0,-39+bob),10.0,-0.5,0.5,12,_with_alpha(Color(0.08,0.08,0.08,0.34),alpha),1.2)
	draw_circle(Vector2(0,-39+bob),2.0,_with_alpha(ink,alpha))
	var bow_dir: float = 1.0 if aim_direction.x >= 0.0 else -1.0
	var shoulder: Vector2 = Vector2(13.0*bow_dir,-1.0+bob)
	var bow_hand: Vector2 = shoulder+Vector2(12.0*bow_dir,-3.0)
	var upper: Vector2 = bow_hand+Vector2(10.0*bow_dir,-18.0)
	var lower: Vector2 = bow_hand+Vector2(10.0*bow_dir,18.0)
	var string_anchor: Vector2 = bow_hand+Vector2(-6.0*bow_dir,0.0)
	var bow_points: PackedVector2Array = PackedVector2Array()
	for n in range(13):
		var tt: float = float(n)/12.0
		var pt: Vector2 = upper.lerp(lower,tt)
		pt.x += sin(tt*PI)*10.0*bow_dir
		bow_points.append(pt)
	draw_polyline(bow_points,i_col,2.4)
	draw_line(upper,string_anchor,i_col,1.1)
	draw_line(lower,string_anchor,i_col,1.1)
	_sketch_line(shoulder,bow_hand,i_col,2.4,2,60)

func _draw_defeated_pose(ink: Color,paper: Color,alpha: float) -> void:
	if alpha <= 0.01:
		return
	var i_col: Color = _with_alpha(ink,alpha)
	var p_col: Color = _with_alpha(paper,alpha)
	var sink: float = lerpf(0.0,10.0,alpha)
	_sketch_line(Vector2(-5,5+sink),Vector2(-18,20+sink),i_col,3.0,3,0)
	_sketch_line(Vector2(5,8+sink),Vector2(22,18+sink),i_col,3.0,3,10)
	_sketch_line(Vector2(0,-5+sink),Vector2(8,10+sink),i_col,3.2,3,20)
	_sketch_line(Vector2(8,4+sink),Vector2(20,22+sink),i_col,2.6,2,22)
	for y in [-10.0,-6.0,-2.0,2.0]:
		draw_arc(Vector2(4,y+sink),12.0,0.28,PI-0.28,16,i_col,2.1)
	draw_circle(Vector2(8,-21+sink),14.0,p_col)
	draw_arc(Vector2(8,-21+sink),14.0,0.0,TAU,26,i_col,1.6)
	draw_circle(Vector2(3,-22+sink),2.9,i_col)
	draw_circle(Vector2(13,-22+sink),2.9,i_col)
	draw_line(Vector2(2,-13+sink),Vector2(14,-13+sink),i_col,1.4)
	draw_line(Vector2(-28,20+sink),Vector2(-6,24+sink),_with_alpha(ink,alpha*0.65),1.8)
	draw_line(Vector2(-30,13+sink),Vector2(-20,22+sink),_with_alpha(ink,alpha*0.65),1.5)

func _draw_permanent_prompt() -> void:
	var center: Vector2 = Vector2(0,-76)
	_draw_oval(center,Vector2(28,12),Color(1,1,1,0.94))
	draw_arc(center,28.0,0.0,TAU,26,Color(0.08,0.08,0.08,0.34),1.2)
	draw_arc(center,33.0,-PI*0.4,PI*0.4,18,Color(0.08,0.08,0.08,0.10+absf(sin(anim_t*3.0))*0.08),1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(-8,-71),"E",HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("#111111"))
