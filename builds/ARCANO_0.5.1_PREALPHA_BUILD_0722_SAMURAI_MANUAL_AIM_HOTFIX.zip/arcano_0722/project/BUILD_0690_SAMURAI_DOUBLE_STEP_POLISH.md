# BUILD 0690 — SAMURAI DOUBLE-STEP DASH + POLISH

## Focus
Follow-up Samurai polish pass.

## Dash
- Toned down the Samurai dash so it is no longer excessively long/overpowered.
- Kept the 2-charge identity and 4 second full refill behavior.
- Reworked the active dash into a two-step iai sequence: a quick first cut followed immediately by a second cut ("zum zum").
- Added phase-based slash visuals so each half of the dash reads like a distinct cut.

## Visuals
- Refined the Samurai proportions to reduce the chunky body / too-thin head read.
- Enlarged and refined the head silhouette.
- Slimmed and reshaped the torso and clothing layers.
- Added richer costume detail while keeping the muted crimson/gold accents the player liked.
- Updated the class preview to match the in-game Samurai art.

## Files changed
- player.gd
- mage_preview.gd
- endless_main.gd
