# BUILD 0701 — CLASSIC SLIME RESTORE

## Change
- Restored the slime visual from the pre-rework version (Build 0697 lineage).
- Removed the imp / hopper replacement visuals.
- Kept all newer Samurai, spider, dash and other gameplay/visual improvements intact.

## Files changed
- enemy.gd
- endless_main.gd
