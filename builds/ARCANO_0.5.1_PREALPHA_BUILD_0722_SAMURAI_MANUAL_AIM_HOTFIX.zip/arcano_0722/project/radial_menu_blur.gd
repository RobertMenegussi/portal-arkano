extends ColorRect

var open_amount: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	color = Color(1,1,1,1)
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = load("res://radial_blur.gdshader")
	material = mat
	visible = false

func _process(_delta: float) -> void:
	visible = open_amount > 0.001
	if material is ShaderMaterial:
		(material as ShaderMaterial).set_shader_parameter("strength", clampf(open_amount, 0.0, 1.0))
