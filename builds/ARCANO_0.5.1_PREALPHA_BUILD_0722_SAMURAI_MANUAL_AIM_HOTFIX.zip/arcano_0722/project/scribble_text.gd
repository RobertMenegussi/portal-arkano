extends Control

@export var text: String = ""
@export var font_size: int = 18
@export var ink: Color = Color("#111111")
@export var centered: bool = false
@export var jitter_amount: float = 0.45
@export var line_spacing: float = 1.22

var frame_id: int = 0
var timer: float = 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
	timer -= delta
	if timer <= 0.0:
		timer = 0.08
		frame_id += 1
		queue_redraw()

func _draw() -> void:
	var font = ThemeDB.fallback_font
	if font == null:
		return

	var lines: PackedStringArray = text.split("\n")
	var y: float = 0.0
	var line_h: float = float(font_size) * line_spacing
	var wobble_scale: float = clampf(jitter_amount, 0.0, 1.0)

	for line_idx in range(lines.size()):
		var line: String = lines[line_idx]
		var width: float = font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
		var x: float = 0.0
		if centered:
			x = maxf(0.0, (size.x - width) * 0.5)
		var oy: float = sin(float(frame_id) * 0.28 + float(line_idx) * 0.85) * (0.35 * wobble_scale)
		var ox: float = cos(float(frame_id) * 0.22 + float(line_idx) * 0.55) * (0.25 * wobble_scale)
		draw_string(font, Vector2(x + 0.55 + ox, y + float(font_size) + 0.55 + oy), line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(ink.r, ink.g, ink.b, 0.16))
		draw_string(font, Vector2(x - 0.35 + ox * 0.7, y + float(font_size) - 0.25 + oy * 0.7), line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(ink.r, ink.g, ink.b, 0.10))
		draw_string(font, Vector2(x, y + float(font_size)), line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, ink)
		y += line_h
