extends Node2D

var t: float = 0.0
var emotion: String = "calm"
var ward_radius: float = 335.0

func _ready() -> void:
	z_index = 28
	process_mode = Node.PROCESS_MODE_ALWAYS

func set_emotion(value: String) -> void:
	emotion = value
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	var bob: float = sin(t*2.0)*1.2
	var ink := Color("#151515")
	var paper := Color("#eee8da")
	var c := Vector2(0,bob)
	# A quiet ink ward marks the edge of the lesson without feeling like an invisible wall.
	var ward_pulse: float = 0.5+sin(t*1.8)*0.5
	var ward_ink := Color(0.08,0.09,0.085,0.10+ward_pulse*0.025)
	for i in range(12):
		var a0: float = TAU*float(i)/12.0+0.035
		var a1: float = a0+0.34
		draw_arc(Vector2.ZERO,ward_radius,a0,a1,10,ward_ink,1.15)
	for i in range(4):
		var a: float = TAU*float(i)/4.0+t*0.025
		var marker: Vector2 = Vector2.RIGHT.rotated(a)*ward_radius
		var tangent: Vector2 = Vector2.RIGHT.rotated(a+PI*0.25)*3.0
		draw_line(marker-tangent,marker+tangent,Color(0.08,0.09,0.085,0.10),1.0)
	draw_circle(c+Vector2(2,27),Vector2(26,7).x,Color(0,0,0,0.06))
	# robe
	var robe := PackedVector2Array([c+Vector2(-17,-2),c+Vector2(17,-2),c+Vector2(22,28),c+Vector2(6,22),c+Vector2(0,31),c+Vector2(-7,22),c+Vector2(-22,28)])
	draw_colored_polygon(robe,ink)
	# sash and hanging charm
	draw_line(c+Vector2(-13,10),c+Vector2(13,10),paper,1.6)
	draw_circle(c+Vector2(0,17),2.4,paper)
	# head / wide straw-like hat
	draw_circle(c+Vector2(0,-15),11.0,ink)
	var brim := PackedVector2Array([c+Vector2(-25,-23),c+Vector2(25,-23),c+Vector2(16,-16),c+Vector2(-17,-16)])
	draw_colored_polygon(brim,ink)
	var top := PackedVector2Array([c+Vector2(-14,-23),c+Vector2(14,-23),c+Vector2(5,-39),c+Vector2(-5,-39)])
	draw_colored_polygon(top,ink)
	# face reactions
	match emotion:
		"happy":
			draw_arc(c+Vector2(-4,-15),2.4,0.0,PI,10,paper,1.4)
			draw_arc(c+Vector2(4,-15),2.4,0.0,PI,10,paper,1.4)
		"serious":
			draw_line(c+Vector2(-7,-18),c+Vector2(-2,-16),paper,1.4)
			draw_line(c+Vector2(7,-18),c+Vector2(2,-16),paper,1.4)
			draw_circle(c+Vector2(-4,-14),1.5,paper)
			draw_circle(c+Vector2(4,-14),1.5,paper)
		"surprised":
			draw_circle(c+Vector2(-4,-15),2.2,paper)
			draw_circle(c+Vector2(4,-15),2.2,paper)
			draw_circle(c+Vector2(0,-8),2.0,paper)
		_:
			draw_circle(c+Vector2(-4,-15),1.6,paper)
			draw_circle(c+Vector2(4,-15),1.6,paper)
	# staff
	draw_line(c+Vector2(24,-6),c+Vector2(27,32),ink,3.0)
	draw_arc(c+Vector2(25,-10),8.0,-1.2,1.1,16,ink,2.3)
