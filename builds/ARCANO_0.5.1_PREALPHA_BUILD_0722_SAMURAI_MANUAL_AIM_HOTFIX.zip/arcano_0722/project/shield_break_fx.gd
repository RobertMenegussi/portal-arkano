extends Node2D

var t: float = 0.0
var life: float = 0.42
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 80

func _process(delta: float) -> void:
	t += delta
	if t >= life:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _draw() -> void:
	var p: float = clampf(t / life, 0.0, 1.0)
	var alpha: float = 1.0 - p
	for i in range(9):
		var a: float = float(i) * TAU / 9.0 + float(i % 2) * 0.18
		var start: Vector2 = Vector2(cos(a), sin(a)) * (12.0 + p * 10.0)
		var end: Vector2 = Vector2(cos(a), sin(a)) * (28.0 + p * 42.0)
		draw_line(start, end, Color(0.08,0.08,0.08,0.34 * alpha), 2.0)
		draw_circle(end, 2.2, Color(0.08,0.08,0.08,0.18 * alpha))
	draw_arc(Vector2.ZERO, 22.0 + p * 34.0, 0.0, TAU, 28, Color(0.08,0.08,0.08,0.24 * alpha), 2.0)
