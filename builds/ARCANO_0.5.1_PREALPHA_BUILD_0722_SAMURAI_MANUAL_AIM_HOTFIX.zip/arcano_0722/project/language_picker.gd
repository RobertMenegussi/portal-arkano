extends Control

signal language_selected(code: String)

var open: bool = false
var hover: float = 0.0
var t: float = 0.0
var option_rects: Array[Rect2] = []
var option_codes: Array[String] = ["en", "pt_BR", "ja", "es"]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	custom_minimum_size = Vector2(190, 190)

func _process(delta: float) -> void:
	t += delta
	var icon_rect := Rect2(Vector2(0, 0), Vector2(36, 36))
	hover = move_toward(hover, 1.0 if icon_rect.has_point(get_local_mouse_position()) else 0.0, delta * 8.0)
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var pos: Vector2 = event.position
		if Rect2(Vector2.ZERO, Vector2(36, 36)).has_point(pos):
			open = not open
			accept_event()
			return
		if open:
			for i in range(option_rects.size()):
				if option_rects[i].has_point(pos):
					language_selected.emit(option_codes[i])
					open = false
					accept_event()
					return
			open = false
			accept_event()

func _draw() -> void:
	var ink := Color(0.94, 0.93, 0.88, 0.74 + hover * 0.20)
	var bg := Color(0.04, 0.05, 0.048, 0.68 + hover * 0.18)
	draw_circle(Vector2(18, 18), 17.0, bg)
	draw_arc(Vector2(18, 18), 10.8, 0.0, TAU, 28, ink, 1.4)
	draw_arc(Vector2(18, 18), 5.0, -PI * 0.5, PI * 0.5, 18, ink, 1.0)
	draw_arc(Vector2(18, 18), 5.0, PI * 0.5, PI * 1.5, 18, ink, 1.0)
	draw_line(Vector2(8, 18), Vector2(28, 18), ink, 1.0)
	if not open:
		return
	var panel := Rect2(Vector2(0, 44), Vector2(176, 138))
	draw_rect(panel, Color(0.035, 0.043, 0.041, 0.97), true)
	draw_rect(panel, Color(1, 1, 1, 0.10), false, 1.0)
	var font = ThemeDB.fallback_font
	if font == null:
		return
	draw_string(font, Vector2(12, 62), Loc.t("lang.title"), HORIZONTAL_ALIGNMENT_LEFT, 145, 10, Color(0.94, 0.93, 0.89, 0.70))
	option_rects.clear()
	for i in range(option_codes.size()):
		var r := Rect2(Vector2(8, 70 + i * 25), Vector2(160, 22))
		option_rects.append(r)
		var selected: bool = Loc.get_language() == option_codes[i]
		draw_rect(r, Color(1, 1, 1, 0.09 if selected else 0.03), true)
		if selected:
			draw_line(r.position + Vector2(6, r.size.y - 4), r.position + Vector2(r.size.x - 6, r.size.y - 4), Color(1, 1, 1, 0.16), 1.0)
		draw_string(font, r.position + Vector2(8, 15), Loc.language_label(option_codes[i]), HORIZONTAL_ALIGNMENT_LEFT, 138, 10, Color(0.95, 0.94, 0.90, 0.92 if selected else 0.64))
