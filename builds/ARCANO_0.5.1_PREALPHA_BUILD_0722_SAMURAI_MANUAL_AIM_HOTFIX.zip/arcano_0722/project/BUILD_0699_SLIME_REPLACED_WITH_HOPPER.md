# BUILD 0699 — SLIME REPLACED WITH HOPPER CRITTER

## Focus
The former slime enemy has been visually replaced with a completely different creature design.

## What changed
- `_draw_slime()` no longer draws a slime/blob.
- The enemy is now presented as a small feral hopper / cave critter with:
  - a separate head silhouette
  - ears / horn-like tufts
  - paws and hind legs
  - tail, fangs and back spikes
  - richer body layering and highlights
- Existing gameplay behavior remains intact (same pounce/windup/land logic), but the visual identity is now a new creature rather than a slime.

## Files changed
- enemy.gd
- endless_main.gd
