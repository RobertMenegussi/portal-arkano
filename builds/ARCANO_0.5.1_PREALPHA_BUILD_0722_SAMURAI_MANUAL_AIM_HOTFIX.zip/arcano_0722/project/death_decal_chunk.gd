extends Node2D

const MAX_DECALS: int = 64
var decals: Array = []

func is_full() -> bool:
	return decals.size() >= MAX_DECALS

func add_slime(world_pos: Vector2) -> void:
	decals.append({"kind":"slime","pos":to_local(world_pos)})
	queue_redraw()

func add_skeleton(world_pos: Vector2,pieces: Array) -> void:
	var origin: Vector2 = to_local(world_pos)
	var stored: Array = []
	for piece_value in pieces:
		var piece: Dictionary = piece_value
		var piece_pos: Vector2 = piece.get("pos",Vector2.ZERO)
		stored.append({
			"kind":str(piece.get("kind","bone")),
			"pos":origin+piece_pos,
			"rot":float(piece.get("rot",0.0))
		})
	decals.append({"kind":"skeleton","pieces":stored})
	queue_redraw()

func _draw() -> void:
	for decal_value in decals:
		var decal: Dictionary = decal_value
		if str(decal.get("kind","")) == "slime":
			var slime_pos: Vector2 = decal.get("pos",Vector2.ZERO)
			_draw_slime(slime_pos)
		else:
			var piece_list: Array = decal.get("pieces",[])
			_draw_skeleton(piece_list)

func _draw_slime(center: Vector2) -> void:
	var points := PackedVector2Array()
	for i in range(26):
		var a: float = TAU*float(i)/26.0
		points.append(center+Vector2(cos(a)*30.0,sin(a)*2.8)+Vector2(0,14.0))
	draw_colored_polygon(points,Color(0.05,0.05,0.05,0.30))

func _draw_skeleton(pieces: Array) -> void:
	for piece_value in pieces:
		var piece: Dictionary = piece_value
		var pos: Vector2 = piece.get("pos",Vector2.ZERO)
		var rot: float = float(piece.get("rot",0.0))
		if str(piece.get("kind","bone")) == "skull":
			draw_circle(pos,7.5,Color("#f6f1e5"))
			draw_arc(pos,7.5,0.0,TAU,20,Color("#171717"),1.4)
			draw_circle(pos+Vector2(-2.8,-0.8).rotated(rot),1.6,Color("#171717"))
			draw_circle(pos+Vector2(2.8,-0.8).rotated(rot),1.6,Color("#171717"))
		else:
			var dir := Vector2(9.0,0).rotated(rot)
			draw_line(pos-dir,pos+dir,Color("#171717"),2.4)
