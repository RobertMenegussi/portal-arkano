# BUILD 0705 — HUD class head readability pass

## Focus
Make the HUD faces clearly read as each class instead of feeling too similar.

## Main changes
- Orbit HUD face now has a broader hood silhouette, clearer floating stones and a visible robe collar.
- Storm HUD face now has a much clearer pointed hat, brim, mantle/shoulders and lightning identity.
- Samurai HUD face now has a readable headband, side tie and kimono-style collar.
- Kept the impact animation and dash icons from 0704.

## Files changed
- hud_display.gd
- endless_main.gd
