extends CharacterBody2D

signal defeated
signal engaged

const ArrowScript = preload("res://enemy_arrow.gd")
const MarkStrikeScript = preload("res://boss_mark_strike.gd")
const HitFxScript = preload("res://hit_fx.gd")

var player
var active: bool = false
var dead: bool = false
var health: int = 14
var max_health: int = 14
var state: String = "idle"
var state_time: float = 0.0
var cooldown: float = 0.7
var attack_index: int = 0
var dash_left: int = 0
var dash_target: Vector2 = Vector2.ZERO
var dash_direction: Vector2 = Vector2.RIGHT
var hit_flash: float = 0.0
var knockback: Vector2 = Vector2.ZERO
var t: float = 0.0
var sketch_frame: int = 0
var sketch_timer: float = 0.0
var was_hit: bool = false
var second_mark_pending: bool = false
var attack_glow: float = 0.0
var slash_phase: float = 0.0
var threat_scale: float = 1.0
var visual_timer: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy")
	add_to_group("elite")
	collision_layer = 4
	collision_mask = 1
	z_index = 25
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 17.0
	collider.shape = shape
	collider.position = Vector2(0,8)
	add_child(collider)
	scale = Vector2(0.90,0.90)

func _physics_process(delta: float) -> void:
	if dead:
		return
	t += delta
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.065
		sketch_frame += 1
	hit_flash = move_toward(hit_flash,0.0,delta*7.0)
	attack_glow = move_toward(attack_glow,0.0,delta*2.8)
	slash_phase += delta*6.0
	knockback = knockback.move_toward(Vector2.ZERO,delta*620.0)
	if not is_instance_valid(player) or not player.active:
		velocity = knockback
		move_and_slide()
		_request_visual_redraw(delta)
		return
	if not active:
		if global_position.distance_to(player.global_position) < 230.0:
			active = true
			engaged.emit()
			get_tree().call_group("screen_fx","pulse_boss")
			attack_glow = 1.0
		else:
			velocity = Vector2.ZERO
			_request_visual_redraw(delta)
			return
	cooldown = maxf(0.0,cooldown-delta)
	var to_player: Vector2 = player.global_position-global_position
	var dist: float = to_player.length()
	match state:
		"dash_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				dash_target = player.global_position
				dash_direction = (dash_target-global_position).normalized()
				state = "dash"
				state_time = 0.24
				get_tree().call_group("screen_fx","pulse_dash")
				get_tree().call_group("audio_bus","play_dash")
		"dash":
			state_time -= delta
			velocity = dash_direction*(520.0*threat_scale)+knockback
			if global_position.distance_to(player.global_position) < 39.0:
				player.take_damage(1,dash_direction)
			if state_time <= 0.0:
				dash_left -= 1
				if dash_left > 0:
					state = "dash_windup"
					state_time = 0.22
				else:
					_recover(0.38,0.72)
		"fan_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_fire_fan()
				_recover(0.34,0.86)
		"mark_windup":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				_spawn_mark()
				second_mark_pending = true
				state = "mark_follow"
				state_time = 0.30
		"mark_follow":
			state_time -= delta
			if dist < 160.0:
				velocity = -to_player.normalized()*55.0+knockback
			else:
				velocity = knockback
			if state_time <= 0.0:
				if second_mark_pending:
					second_mark_pending = false
					_spawn_mark()
				_recover(0.40,0.88)
		"recover":
			state_time -= delta
			velocity = knockback
			if state_time <= 0.0:
				state = "idle"
		_:
			if dist > 185.0:
				velocity = to_player.normalized()*(118.0*threat_scale)+knockback
			elif dist < 95.0:
				velocity = -to_player.normalized()*(92.0*threat_scale)+knockback
			else:
				var side: Vector2 = Vector2(-to_player.y,to_player.x).normalized()
				velocity = side*(68.0*threat_scale)+knockback
			if cooldown <= 0.0:
				_begin_attack()
	move_and_slide()
	_request_visual_redraw(delta)

func _request_visual_redraw(delta: float) -> void:
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _begin_attack() -> void:
	attack_glow = 1.0
	match attack_index % 3:
		0:
			state = "dash_windup"
			state_time = 0.46
			dash_left = 3
		1:
			state = "fan_windup"
			state_time = 0.58
		2:
			state = "mark_windup"
			state_time = 0.46
	attack_index += 1

func _recover(duration: float, next_cd: float) -> void:
	state = "recover"
	state_time = duration
	cooldown = maxf(0.36,next_cd/maxf(1.0,threat_scale))

func _fire_fan() -> void:
	if not is_instance_valid(player):
		return
	var base: Vector2 = (player.global_position-global_position).normalized()
	for i in range(7):
		var angle: float = lerpf(-0.56,0.56,float(i)/6.0)
		var arrow = ArrowScript.new()
		arrow.direction = base.rotated(angle)
		arrow.speed = 470.0
		arrow.global_position = global_position+arrow.direction*25.0
		get_tree().current_scene.add_child(arrow)
	get_tree().call_group("audio_bus","play_enemy_shot")
	get_tree().call_group("screen_fx","pulse_boss")

func _spawn_mark() -> void:
	var mark = MarkStrikeScript.new()
	mark.configure(player)
	get_tree().current_scene.add_child(mark)

func take_damage(amount: int, hit_direction: Vector2) -> void:
	if dead:
		return
	var final_amount: int = amount
	if is_instance_valid(player) and "endless_elite_damage_bonus" in player:
		var bonus: float = float(player.endless_elite_damage_bonus)
		if bonus > 0.0:
			var scaled: float = float(amount)*(1.0+bonus)
			final_amount = int(floor(scaled))
			if randf() < scaled-float(final_amount):
				final_amount += 1
	health -= maxi(1,final_amount)
	was_hit = true
	hit_flash = 1.0
	knockback = hit_direction.normalized()*110.0
	var fx = HitFxScript.new()
	fx.global_position = global_position
	fx.direction = hit_direction
	get_tree().current_scene.add_child(fx)
	get_tree().call_group("audio_bus","play_enemy_hit")
	get_tree().call_group("screen_fx","pulse_enemy_hit")
	if is_instance_valid(player):
		player.on_enemy_hit(1.2)
	if health <= 0:
		dead = true
		collision_layer = 0
		collision_mask = 0
		velocity = Vector2.ZERO
		get_tree().call_group("endless_controller","on_enemy_defeated",global_position,"elite",true)
		if is_instance_valid(player):
			player.on_enemy_killed(true)
		get_tree().call_group("screen_fx","pulse_kill")
		get_tree().call_group("audio_bus","play_enemy_die")
		defeated.emit()
		queue_free()

func apply_external_force(force: Vector2) -> void:
	knockback += force

func _draw() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.64)
	var paper: Color = Color("#f7f2e8")
	var bob: float = sin(t*5.0)*1.0
	draw_ellipse_shadow()
	# persistent moving wisps keep the elite alive even between attacks.
	for i in range(6):
		var a: float = slash_phase*0.55+float(i)*TAU/6.0
		var r: float = 30.0+sin(slash_phase+float(i))*4.0
		var p: Vector2 = Vector2(cos(a)*r,sin(a)*r*0.56+2.0)
		draw_circle(p,1.6,Color(0.08,0.08,0.08,0.08+attack_glow*0.08))
	var cloak: PackedVector2Array = PackedVector2Array([Vector2(-20,18+bob),Vector2(-13,-10+bob),Vector2(-5,-20+bob),Vector2(8,-18+bob),Vector2(17,-6+bob),Vector2(22,18+bob),Vector2(8,13+bob),Vector2(0,23+bob),Vector2(-9,13+bob)])
	draw_colored_polygon(cloak,Color(0.10,0.10,0.10,0.86))
	draw_polyline(PackedVector2Array([cloak[0],cloak[1],cloak[2],cloak[3],cloak[4],cloak[5],cloak[6],cloak[7],cloak[8],cloak[0]]),ink,1.6)
	draw_circle(Vector2(0,-23+bob),12.0,paper)
	draw_arc(Vector2(0,-23+bob),12.0,0.0,TAU,22,ink,1.5)
	draw_line(Vector2(0,-34+bob),Vector2(0,-12+bob),ink,1.4)
	draw_circle(Vector2(-4,-24+bob),2.3,ink)
	draw_circle(Vector2(4,-24+bob),2.3,ink)
	if is_instance_valid(player) and player.flux_active:
		draw_arc(Vector2(0,2),31.0+sin(slash_phase)*3.0,0.0,TAU,28,Color(0.08,0.08,0.08,0.16),1.4)
		for i in range(3):
			var fa: float = -slash_phase*0.4+float(i)*TAU/3.0
			draw_circle(Vector2(cos(fa)*35.0,sin(fa)*20.0),1.6,Color(0.08,0.08,0.08,0.18))
	# twin blades now leave animated edge highlights.
	var left_tip: Vector2 = Vector2(-30,12+bob)
	var right_tip: Vector2 = Vector2(30,12+bob)
	draw_line(Vector2(-13,-3+bob),left_tip,ink,2.6)
	draw_line(Vector2(13,-3+bob),right_tip,ink,2.6)
	draw_line(Vector2(-16,0+bob),left_tip,Color(1,1,1,0.30),0.9)
	draw_line(Vector2(16,0+bob),right_tip,Color(1,1,1,0.30),0.9)
	if state == "dash_windup":
		var p: float = clampf(1.0-state_time/0.46,0.0,1.0)
		var d: Vector2 = (player.global_position-global_position).normalized() if is_instance_valid(player) else Vector2.RIGHT
		draw_line(Vector2.ZERO,d*82.0,Color(0.08,0.08,0.08,0.10+p*0.20),2.0)
		for i in range(3):
			draw_arc(Vector2.ZERO,25.0+float(i)*9.0, d.angle()-0.5, d.angle()+0.5,12,Color(0.08,0.08,0.08,0.08+p*0.08),1.0)
	elif state == "dash":
		for i in range(4):
			var back: Vector2 = -dash_direction*(14.0+float(i)*13.0)
			draw_line(back+Vector2(-10,0),back+Vector2(10,0),Color(0.08,0.08,0.08,0.13-float(i)*0.02),1.4)
	elif state == "fan_windup":
		var base: Vector2 = (player.global_position-global_position).normalized() if is_instance_valid(player) else Vector2.RIGHT
		for i in range(7):
			var a: float = lerpf(-0.56,0.56,float(i)/6.0)
			var d: Vector2 = base.rotated(a)
			draw_line(d*25.0,d*78.0,Color(0.08,0.08,0.08,0.13),1.1)
			draw_circle(d*82.0,2.0,Color(0.08,0.08,0.08,0.16))
		draw_arc(Vector2.ZERO,34.0,base.angle()-0.65,base.angle()+0.65,20,Color(0.08,0.08,0.08,0.15),1.5)
	elif state == "mark_windup" or state == "mark_follow":
		for i in range(3):
			var r: float = 28.0+float(i)*10.0+sin(slash_phase+float(i))*3.0
			draw_arc(Vector2.ZERO,r,slash_phase*0.2+float(i),slash_phase*0.2+float(i)+PI*1.15,20,Color(0.08,0.08,0.08,0.11),1.1)
	if was_hit:
		var ratio: float = clampf(float(health)/float(max_health),0.0,1.0)
		draw_line(Vector2(-25,-48),Vector2(25,-48),Color(0.08,0.08,0.08,0.16),4.0)
		draw_line(Vector2(-25,-48),Vector2(-25+50.0*ratio,-48),ink,2.0)

func draw_ellipse_shadow() -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(20):
		var a: float = TAU*float(i)/20.0
		pts.append(Vector2(cos(a)*25.0,sin(a)*6.0)+Vector2(0,27))
	draw_colored_polygon(pts,Color(0.08,0.08,0.08,0.07))
