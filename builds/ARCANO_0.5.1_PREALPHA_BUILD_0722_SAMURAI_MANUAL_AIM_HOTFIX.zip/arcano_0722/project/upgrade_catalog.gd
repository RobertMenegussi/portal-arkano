extends RefCounted

const UPGRADE_NAMES: Array = [
	"Mira de Vidro","Núcleo Compacto","Pulso Curto","Fio de Retorno","Horizonte Raso","Selo Prismático","Campo Rúnico","Passo Leve","Vaso Arcano","Pacto Frágil",
	"Olho do Caçador","Núcleo Lapidado","Ritmo Duplo","Retorno Rápido","Horizonte Longo","Selo Bifurcado","Campo Expandido","Passo Fantasma","Vaso Profundo","Pacto Voraz",
	"Íris Imóvel","Coração de Ferro","Batida Arcana","Ciclo Selado","Linha do Horizonte","Selo Ressonante","Domínio Maior","Passo do Vento","Reservatório Antigo","Pacto Cruel",
	"Olhar Absoluto","Núcleo de Guerra","Tempo Rasgado","Recarga Ritual","Alcance Impossível","Selo Proibido","Território Arcano","Passo Sem Peso","Poço de Mana","Pacto do Abismo",
	"Visão Perfeita","Coração Estelar","Ritmo Soberano","Retorno Eterno","Horizonte Final","Selo do Arquimago","Campo de Ruptura","Passo Entre Instantes","Cálice do Surto","Pacto da Última Chama"
]

static func all_ids() -> Array:
	var result: Array = []
	for i in range(UPGRADE_NAMES.size()):
		result.append("upgrade_%02d" % i)
	return result

static func get_upgrade_name(upgrade_id: String) -> String:
	var idx: int = _index_from_id(upgrade_id)
	if idx < 0 or idx >= UPGRADE_NAMES.size():
		return "Slot vazio"
	return str(UPGRADE_NAMES[idx])

static func get_description(upgrade_id: String, mage_type: String) -> String:
	var idx: int = _index_from_id(upgrade_id)
	if idx < 0:
		return ""
	var archetype: int = idx % 10
	var tier: int = int(floor(float(idx) / 10.0)) + 1
	match archetype:
		0:
			match mage_type:
				"storm": return "A queda acompanha melhor a mira. Precisão +%d%%." % (18 + tier * 7)
				"rift": return "A fissura sai mais reta. Precisão +%d%%." % (18 + tier * 7)
				_: return "As pedras quase não dispersam. Precisão +%d%%." % (24 + tier * 8)
		1:
			match mage_type:
				"storm": return "Descargas mais pesadas. +%d dano." % (1 if tier < 4 else 2)
				"rift": return "A ruptura corta mais fundo. +%d dano." % (1 if tier < 4 else 2)
				_: return "Pedras mais densas. +%d dano." % (1 if tier < 4 else 2)
		2:
			match mage_type:
				"storm": return "Canaliza mais rápido. Tempo -%d%%." % (8 + tier * 3)
				"rift": return "Menos intervalo entre cortes. Ataque +%d%%." % (8 + tier * 3)
				_: return "Cadência maior entre pedras. Ataque +%d%%." % (8 + tier * 3)
		3:
			match mage_type:
				"storm": return "Recupera do raio mais cedo. Espera -%d%%." % (7 + tier * 3)
				"rift": return "Recompõe as duas cargas mais rápido. Recarga -%d%%." % (9 + tier * 3)
				_: return "Reconstrói a órbita mais rápido. Recarga -%d%%." % (9 + tier * 3)
		4:
			match mage_type:
				"storm": return "Permite marcar o trovão mais longe. +%d alcance." % (28 + tier * 12)
				"rift": return "A fissura atravessa mais terreno. +%d alcance." % (30 + tier * 14)
				_: return "Pedras viajam mais rápido e seguram melhor a linha. +%d velocidade." % (45 + tier * 20)
		5:
			return _mutation_description(tier, mage_type)
		6:
			match mage_type:
				"storm": return "A área do impacto cresce em %d." % (3 + tier * 2)
				"rift": return "A largura útil da fissura cresce em %d." % (3 + tier * 2)
				_: return "Chance de disparo eco +%d%%." % (4 + tier * 3)
		7:
			return "Movimento +%d e recarga de dash %d%% mais rápida." % [5 + tier * 2, 4 + tier * 2]
		8:
			return "Fluxo enche %d%% mais rápido e o Surto dura +%.1fs." % [8 + tier * 4, 0.25 + float(tier) * 0.12]
		9:
			match mage_type:
				"storm": return "Mais poder, mas conjuração mais pesada: +1 dano, carga +%d%%." % (7 + tier * 2)
				"rift": return "Mais poder, mas recomposição mais lenta: +1 dano, recarga +%d%%." % (8 + tier * 2)
				_: return "Mais poder, mas órbita demora a voltar: +1 dano, recarga +%d%%." % (8 + tier * 2)
	return ""

static func get_effect(upgrade_id: String, mage_type: String) -> Dictionary:
	var idx: int = _index_from_id(upgrade_id)
	if idx < 0:
		return {}
	var archetype: int = idx % 10
	var tier: int = int(floor(float(idx) / 10.0)) + 1
	var e: Dictionary = {}
	match archetype:
		0:
			e["accuracy_mul"] = maxf(0.32, 0.82 - float(tier) * 0.07)
		1:
			e["damage_add"] = 1 if tier < 4 else 2
		2:
			if mage_type == "storm":
				e["charge_mul"] = maxf(0.60, 0.92 - float(tier) * 0.03)
			else:
				e["cooldown_mul"] = maxf(0.58, 0.92 - float(tier) * 0.03)
		3:
			if mage_type == "storm":
				e["storm_recovery_mul"] = maxf(0.62, 0.93 - float(tier) * 0.03)
			else:
				e["reload_mul"] = maxf(0.56, 0.91 - float(tier) * 0.03)
		4:
			if mage_type == "orbit":
				e["projectile_speed_add"] = 45.0 + float(tier) * 20.0
			else:
				e["range_add"] = 28.0 + float(tier) * 13.0
		5:
			e["traits"] = _mutation_traits(tier, mage_type)
		6:
			if mage_type == "orbit":
				e["echo_add"] = 0.04 + float(tier) * 0.03
			else:
				e["radius_add"] = 3.0 + float(tier) * 2.0
		7:
			e["move_speed_add"] = 5.0 + float(tier) * 2.0
			e["dash_recharge_mul"] = maxf(0.64, 0.96 - float(tier) * 0.02)
		8:
			e["flux_gain_mul"] = 1.08 + float(tier) * 0.04
			e["flux_duration_add"] = 0.25 + float(tier) * 0.12
		9:
			e["damage_add"] = 1
			if mage_type == "storm":
				e["charge_mul"] = 1.07 + float(tier) * 0.02
			else:
				e["reload_mul"] = 1.08 + float(tier) * 0.02
	return e

static func _mutation_description(tier: int, mage_type: String) -> String:
	var names: Dictionary = {
		"orbit": ["Ricochete no primeiro impacto.","Impacto divide a pedra em dois estilhaços.","A última pedra do ciclo explode.","Finalizar recarga solta uma onda ao redor.","Pedras orbitando ferem quem encostar."],
		"storm": ["O raio salta para um segundo alvo.","Depois do impacto vem uma segunda descarga.","Cada queda cria um segundo raio menor ao lado.","Esquiva perfeita libera o próximo raio.","Canalização mais pesada aumenta dano e área."],
		"rift": ["A fissura puxa inimigos para a linha.","No meio do trajeto abre cortes laterais.","O fim da fissura explode.","Começar a recarga explode uma defesa curta.","A cicatriz ganha muito mais alcance."]
	}
	var arr: Array = names.get(mage_type, names["orbit"])
	return str(arr[clampi(tier - 1, 0, arr.size() - 1)])

static func _mutation_traits(tier: int, mage_type: String) -> Array:
	var traits: Dictionary = {
		"orbit": ["orbit_ricochet","orbit_split","orbit_last_burst","orbit_reload_burst","orbit_contact"],
		"storm": ["storm_chain","storm_aftershock","storm_twin","storm_dodge_prime","storm_overcharge"],
		"rift": ["rift_gravity","rift_cross","rift_endburst","rift_reload_guard","rift_longscar"]
	}
	var arr: Array = traits.get(mage_type, traits["orbit"])
	return [str(arr[clampi(tier - 1, 0, arr.size() - 1)])]

static func _index_from_id(upgrade_id: String) -> int:
	if not upgrade_id.begins_with("upgrade_"):
		return -1
	return int(upgrade_id.substr(8))
