# BUILD 0691 — SAMURAI TRUE 2-STEP DASH

## Fixes requested
- The Samurai no longer uses a 2-charge dash setup. It is back to a single-activation dash.
- One Samurai dash activation now performs an automatic 2-step sequence (two cuts / two bursts) instead of requiring a second manual press.
- Added an explicit Samurai-only dash pose so the dash no longer looks generic.

## Details
- Samurai dash charges set back to a single stack.
- Dash still chains into step 2 automatically on the same activation.
- Added a custom forward-cutting Samurai dash pose with sword-out silhouette.
- Kept the liked color treatment and design direction, while making the dash read much more uniquely.

## Files changed
- player.gd
- endless_main.gd
