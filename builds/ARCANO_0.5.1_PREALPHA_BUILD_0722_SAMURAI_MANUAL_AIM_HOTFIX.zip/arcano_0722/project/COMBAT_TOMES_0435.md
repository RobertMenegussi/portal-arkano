# Build 0435 — Combat/Tomes foundation

- Dash baseline: 1 charge, 3.0 s recharge.
- Enemy density softened early; pressure ramps more gradually.
- XP curve is less punishing at medium/high levels.
- Tomes re-enabled with a small curated test pool.
- Stat Tome cards show current value + colored delta/percent.
- Class mutations: 2 per class in this test build.
- Dash mutations: Echo do Passo and Reserva Cinética.
- Flux/Surto now clearly states that charges are not consumed and keeps Orbital stones visually present while active.
- Items are intentionally not implemented yet; elite chest remains a temporary heal reward.
