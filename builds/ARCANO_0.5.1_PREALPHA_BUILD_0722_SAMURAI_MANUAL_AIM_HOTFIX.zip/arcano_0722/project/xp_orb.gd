extends Node2D

var player
var value: int = 1
var t: float = 0.0
var forced: bool = false
var collected: bool = false
var controller
var is_rare: bool = false
var visual_timer: float = 0.0
var pickup_radius: float = 118.0
var proximity_timer: float = 0.0
var attracted: bool = false
var spawn_velocity: Vector2 = Vector2.ZERO
var drift_velocity: Vector2 = Vector2.ZERO
var attract_delay: float = 0.0
var auto_pull_after_delay: bool = false
var attraction_speed: float = 0.0
var bob_seed: float = 0.0
var spark_seed: float = 0.0

func configure(target, xp_value: int, owner_controller = null, rare: bool = false) -> void:
	player = target
	value = maxi(1, xp_value)
	controller = owner_controller
	is_rare = rare

func add_value(amount: int) -> void:
	value += maxi(1, amount)

func set_pickup_radius(radius_value: float) -> void:
	pickup_radius = maxf(18.0, radius_value)

func launch(initial_velocity: Vector2, delay_before_attract: float = 0.0, auto_pull: bool = false) -> void:
	spawn_velocity = initial_velocity
	drift_velocity = Vector2(-initial_velocity.y, initial_velocity.x) * randf_range(-0.08, 0.08)
	attract_delay = maxf(0.0, delay_before_attract)
	auto_pull_after_delay = auto_pull
	attraction_speed = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 20
	add_to_group("xp_orb")
	proximity_timer = randf_range(0.0, 0.07)
	bob_seed = randf_range(0.0, TAU)
	spark_seed = randf_range(0.0, TAU)

func force_collect() -> void:
	forced = true
	attracted = true
	auto_pull_after_delay = true
	attract_delay = 0.0

func _process(delta: float) -> void:
	if collected or not is_instance_valid(player):
		return
	t += delta
	proximity_timer -= delta

	if attract_delay > 0.0:
		attract_delay = maxf(0.0, attract_delay - delta)
		if attract_delay <= 0.0 and auto_pull_after_delay:
			attracted = true

	if forced and attract_delay <= 0.0:
		attracted = true

	if spawn_velocity.length_squared() > 1.0 or drift_velocity.length_squared() > 0.1:
		global_position += (spawn_velocity + drift_velocity) * delta
		spawn_velocity = spawn_velocity.move_toward(Vector2.ZERO, 420.0 * delta)
		drift_velocity = drift_velocity.move_toward(Vector2.ZERO, 110.0 * delta)

	if not attracted and attract_delay <= 0.0 and proximity_timer <= 0.0:
		proximity_timer = 0.07
		var check_delta: Vector2 = player.global_position - global_position
		var check_radius: float = pickup_radius * maxf(1.0, float(player.endless_pickup_radius_mul))
		attracted = check_delta.length_squared() <= check_radius * check_radius

	if attracted:
		var delta_pos: Vector2 = player.global_position - global_position
		var distance_sq: float = delta_pos.length_squared()
		var distance: float = maxf(0.001, sqrt(distance_sq))
		attraction_speed = move_toward(attraction_speed, 430.0 + minf(420.0, distance * 1.2), 1850.0 * delta)
		var target: Vector2 = player.global_position
		if distance > 24.0:
			var tangent: Vector2 = Vector2(-delta_pos.y, delta_pos.x)
			if tangent.length_squared() > 0.001:
				tangent = tangent.normalized() * minf(10.0, distance * 0.06)
				target += tangent * sin(t * 8.6 + spark_seed) * 0.35
		global_position = global_position.move_toward(target, attraction_speed * delta)
		if distance_sq <= 400.0:
			collected = true
			get_tree().call_group("endless_controller", "gain_xp", value)
			if is_rare:
				get_tree().call_group("endless_controller", "on_rare_xp_collected", value)
			queue_free()
			return

	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 24.0
		queue_redraw()

func _exit_tree() -> void:
	if is_instance_valid(controller) and controller.has_method("on_xp_orb_removed"):
		controller.on_xp_orb_removed()

func _draw() -> void:
	var base_r: float = 5.2 if value <= 1 else (6.0 if value <= 3 else 6.9)
	if is_rare:
		base_r += 1.3
	var pulse: float = 1.0 + sin(t * (6.6 if is_rare else 5.2) + bob_seed) * 0.10
	var outer_r: float = base_r * pulse
	var main_color: Color = Color("#ffd85d") if is_rare else (Color("#d6efe5") if value <= 1 else (Color("#c8d8ff") if value <= 3 else Color("#f2deb0")))
	var glow_color: Color = Color("#ffe79b") if is_rare else (Color("#aaf5d7") if value <= 1 else (Color("#adc8ff") if value <= 3 else Color("#ffdf9e")))
	var ink: Color = Color(0.08, 0.08, 0.08, 0.72)
	var halo_alpha: float = 0.12 + (0.04 if attracted else 0.0)
	draw_circle(Vector2.ZERO, outer_r + 7.4, Color(glow_color.r, glow_color.g, glow_color.b, halo_alpha * 0.45))
	draw_circle(Vector2.ZERO, outer_r + 4.1, Color(0.05, 0.05, 0.05, 0.12))
	draw_circle(Vector2.ZERO, outer_r + 2.0, Color(glow_color.r, glow_color.g, glow_color.b, halo_alpha))

	var move_hint: Vector2 = Vector2.ZERO
	if attracted and is_instance_valid(player):
		move_hint = global_position - player.global_position
	elif spawn_velocity.length_squared() > 6.0:
		move_hint = -spawn_velocity
	if move_hint.length_squared() > 0.01:
		var dir: Vector2 = move_hint.normalized()
		for i in range(3):
			var a: float = float(i) / 3.0
			var p0: Vector2 = dir * (outer_r + 1.8 + a * 5.0)
			var p1: Vector2 = dir * (outer_r + 6.6 + a * 7.0)
			draw_line(p0, p1, Color(glow_color.r, glow_color.g, glow_color.b, 0.18 - a * 0.04), 1.25 - a * 0.2)

	var poly: PackedVector2Array = PackedVector2Array([
		Vector2(0, -outer_r),
		Vector2(outer_r * 0.80, 0),
		Vector2(0, outer_r),
		Vector2(-outer_r * 0.80, 0)
	])
	draw_colored_polygon(poly, main_color)
	draw_polyline(PackedVector2Array([poly[0], poly[1], poly[2], poly[3], poly[0]]), ink, 1.0)
	var inner: float = outer_r * 0.45
	var inner_poly: PackedVector2Array = PackedVector2Array([
		Vector2(0, -inner),
		Vector2(inner * 0.82, 0),
		Vector2(0, inner),
		Vector2(-inner * 0.82, 0)
	])
	draw_colored_polygon(inner_poly, Color(1.0, 1.0, 1.0, 0.24 if is_rare else 0.16))

	for i in range(4):
		var a: float = t * 1.4 + spark_seed + TAU * float(i) / 4.0
		var p: Vector2 = Vector2(cos(a), sin(a)) * (outer_r + 3.8 + sin(t * 3.6 + float(i)) * 0.8)
		draw_circle(p, 0.9 if is_rare else 0.7, Color(1.0, 1.0, 1.0, 0.18 if is_rare else 0.12))

	if is_rare:
		draw_circle(Vector2.ZERO, 1.6, Color("#fff8c7"))
		for i in range(4):
			var ray_angle: float = t * 1.8 + TAU * float(i) / 4.0
			var ray: Vector2 = Vector2(cos(ray_angle), sin(ray_angle))
			draw_line(ray * (outer_r + 1.0), ray * (outer_r + 5.0), Color(1.0, 0.95, 0.67, 0.30), 1.0)
