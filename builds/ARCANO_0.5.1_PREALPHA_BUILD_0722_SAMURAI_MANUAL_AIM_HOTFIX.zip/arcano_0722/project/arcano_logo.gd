extends Control

signal tapped

const LOGO_TEXTURE: Texture2D = preload("res://arkano_logo.png")

var t: float = 0.0
var hover_t: float = 0.0
var click_t: float = 0.0
var frame_id: int = 0
var sparks: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		click_t = 1.0
		_spawn_sparks(get_local_mouse_position())
		tapped.emit()
		accept_event()

func _process(delta: float) -> void:
	t += delta
	frame_id += 1
	var hovered: bool = Rect2(Vector2.ZERO, size).has_point(get_local_mouse_position())
	hover_t = move_toward(hover_t, 1.0 if hovered else 0.0, delta * 6.0)
	click_t = move_toward(click_t, 0.0, delta * 3.8)
	var next_sparks: Array = []
	for item_value in sparks:
		var item: Dictionary = item_value
		item["ttl"] = float(item.get("ttl", 0.0)) - delta
		item["pos"] = Vector2(item.get("pos", Vector2.ZERO)) + Vector2(item.get("vel", Vector2.ZERO)) * delta
		item["vel"] = Vector2(item.get("vel", Vector2.ZERO)) * 0.92
		if float(item["ttl"]) > 0.0:
			next_sparks.append(item)
	sparks = next_sparks
	queue_redraw()

func _draw() -> void:
	if LOGO_TEXTURE == null:
		return
	var fit: Rect2 = _fit_logo_rect()
	var mouse: Vector2 = get_local_mouse_position()
	var m_t: Vector2 = (mouse / maxf(1.0, size.x)) - Vector2(0.5, 0.5)
	var drift: Vector2 = Vector2(m_t.x * 5.5, m_t.y * 2.6) * hover_t
	var pulse: float = sin(t * 1.65) * 0.012 + click_t * 0.035
	var pulse_size: Vector2 = fit.size * pulse
	var main_rect: Rect2 = Rect2(fit.position - pulse_size * 0.5 + drift, fit.size + pulse_size)

	# very subtle moving sketch aura around the word, modern and clean.
	_draw_sketch_motion(main_rect)

	# ghosted scribble passes to keep the hand-drawn logo alive.
	for i in range(3):
		var off: Vector2 = Vector2(_j(i * 7, 1.4 + hover_t * 0.6), _j(i * 7 + 2, 0.9 + hover_t * 0.4))
		var ghost_rect: Rect2 = Rect2(main_rect.position + off, main_rect.size)
		draw_texture_rect(LOGO_TEXTURE, ghost_rect, false, Color(0, 0, 0, 0.12 + 0.05 * float(i)))

	# main mark
	draw_texture_rect(LOGO_TEXTURE, main_rect, false, Color(0, 0, 0, 1.0))

	# tiny rough cuts give it that moving pencil/ink feeling without extra ornament.
	for i in range(6):
		var x: float = main_rect.position.x + main_rect.size.x * (0.08 + float(i) * 0.14)
		var y: float = main_rect.position.y + main_rect.size.y * (0.20 + 0.48 * absf(sin(t * 0.8 + float(i))))
		var cut_length: float = 9.0 + 8.0 * hover_t
		draw_line(Vector2(x, y), Vector2(x + cut_length, y + sin(t * 2.0 + float(i)) * 1.3), Color(0, 0, 0, 0.05 + hover_t * 0.04), 1.0)

	# click sparks
	for item_value in sparks:
		var item: Dictionary = item_value
		var alpha: float = clampf(float(item.get("ttl", 0.0)) / 0.52, 0.0, 1.0)
		var pos: Vector2 = item.get("pos", Vector2.ZERO)
		var vel: Vector2 = item.get("vel", Vector2.ZERO)
		draw_line(pos - vel.normalized() * 4.0, pos + vel.normalized() * 4.0, Color(0, 0, 0, 0.22 * alpha), 1.2)
		draw_circle(pos, 1.2 + (1.0 - alpha) * 1.8, Color(0, 0, 0, 0.10 * alpha))

func _draw_sketch_motion(rect: Rect2) -> void:
	var around_alpha: float = 0.035 + hover_t * 0.035
	for i in range(14):
		var px: float = rect.position.x + rect.size.x * float(i) / 13.0
		var py: float = rect.position.y + rect.size.y * (0.10 + 0.80 * absf(sin(t * 0.55 + float(i) * 0.41)))
		var dir: Vector2 = Vector2(1.0, sin(t * 2.3 + float(i)) * 0.2).normalized()
		var length_value: float = 10.0 + 8.0 * absf(sin(t * 1.7 + float(i))) + hover_t * 8.0
		draw_line(Vector2(px, py), Vector2(px, py) + dir * length_value, Color(0, 0, 0, around_alpha), 1.0)
	# thin cursor-reactive scratch near the mouse
	if hover_t > 0.01:
		var local_mouse: Vector2 = get_local_mouse_position()
		var scratch_from: Vector2 = Vector2(lerpf(rect.position.x + rect.size.x * 0.3, local_mouse.x, 0.45), rect.position.y + rect.size.y * 0.88)
		var scratch_to: Vector2 = local_mouse.lerp(Vector2(rect.position.x + rect.size.x * 0.7, rect.position.y + rect.size.y * 0.18), 0.18)
		for i in range(2):
			draw_line(scratch_from + Vector2(0, float(i)), scratch_to + Vector2(0, float(i) * 0.5), Color(0, 0, 0, 0.04 + hover_t * 0.04), 1.0)

func _fit_logo_rect() -> Rect2:
	var tex_size: Vector2 = LOGO_TEXTURE.get_size()
	var scale_amount: float = minf(size.x / tex_size.x, size.y / tex_size.y)
	scale_amount *= 0.92
	var final_size: Vector2 = tex_size * scale_amount
	var pos: Vector2 = Vector2((size.x - final_size.x) * 0.5, (size.y - final_size.y) * 0.5)
	return Rect2(pos, final_size)

func _spawn_sparks(origin: Vector2) -> void:
	for i in range(10):
		var angle: float = randf_range(-PI, PI)
		var speed: float = randf_range(24.0, 68.0)
		sparks.append({
			"pos": origin + Vector2(randf_range(-6.0, 6.0), randf_range(-4.0, 4.0)),
			"vel": Vector2(cos(angle), sin(angle)) * speed,
			"ttl": randf_range(0.28, 0.52)
		})

func _j(index: int, amount: float) -> float:
	return sin(float(frame_id) * 1.9 + float(index) * 3.1) * amount
