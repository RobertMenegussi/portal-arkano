# BUILD 0681 — ORBITAL VISUAL REWORK

Focused pass on the Orbital class only.

## Goals
- Slimmer and more readable mage silhouette.
- More premium-looking orbital crystals.
- Better sense of motion and casting.
- Match the updated look in gameplay and class previews.
- Improve the Orbital projectile visual so the whole class feels more finished.

## Files changed
- player.gd
- mage_preview.gd
- projectile.gd

## Highlights
- Reworked Orbital mage body silhouette with a cleaner robe, mantle, hat and slimmer proportions.
- Added a more active casting pose for the Orbital right arm and hand focus.
- Reworked orbiting stones with trails, orbit guides, connection lines and better crystal readability.
- Updated class preview art so menus reflect the new in-game Orbital identity.
- Refined Orbital projectile silhouette and trail to feel more premium and readable in motion.
