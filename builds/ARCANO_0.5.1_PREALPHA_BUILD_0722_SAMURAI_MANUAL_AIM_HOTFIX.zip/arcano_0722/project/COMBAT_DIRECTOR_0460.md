ARCANO 0.3.0-prealpha — Build 0460
Adaptive Director + Enemy Growth + Tome Arsenal

FOCO DESTA BUILD
- Corrigir defensivamente o crash do boss reportado como "Invalid call. Nonexistent 'bool' constructor".
- Fazer a pressão da run reagir à densidade de inimigos próxima ao jogador.
- Aumentar spawn quando a tela está vazia e quando o jogador fica parado.
- Fazer HP/velocidade dos inimigos crescerem com o tempo da run.
- Transformar elites em mini-bosses com HP e agressividade escalando por tempo.
- Introduzir novas ameaças e rework de comportamento.
- Adicionar Tomos mecânicos/visuais reais em vez de apenas porcentagens.

BOSS / ELITES
- Primeiro boss: 08:00.
- Elites: aproximadamente 02:00 / 04:00 / 06:00; retornam depois do boss.
- Boss recebe HP baseado no estágio temporal da run.
- boss_shockwave.gd não usa mais Array[bool] tipado para o tracking interno das ondas.

DIRETOR ADAPTATIVO
- Mede periodicamente quantos inimigos existem perto do player.
- Pouca densidade local aumenta a pressão de spawn.
- Ficar praticamente parado acumula pressão adicional.
- Pressão reduz intervalo entre spawns e aumenta temporariamente o cap.
- O sistema não depende apenas do nível do player.

ESCALONAMENTO DOS MOBS
- HP cresce continuamente com minutos sobrevividos.
- Velocidade também cresce suavemente, com teto.
- Spider permanece 1-hit no começo e passa a escalar depois.
- Slime começa simples/fraco e deixa de ser papel conforme a run avança.
- Warder/Brute recebem escala um pouco mais agressiva.

NOVOS / REWORKS
- Spider: rápida, contato direto causa dano e ela recua brevemente depois de bater.
- Brute: tanque terrestre com carga telegrafada.
- Stalker: agora aparece em bandos e faz rasantes rápidos no player.
- Skeleton: disparos são dessincronizados e existe orçamento global de projéteis para reduzir paredes de 500 flechas.

XP
- Curva de nível foi desacelerada novamente para evitar power spike precoce.

TOMOS MECÂNICOS — PRIMEIRA LEVA
Universais:
- Aura Residual
- Cometa Instável
- Chicote Etéreo
- Chuva de Cinza
- Poço Rúnico
- Familiar de Tinta
- Tempestade Menor
- Domo Guardião
- Satélite de Ferro
- Casca Prismática
- Espinhos Rúnicos
- Estilhaços de Sangue
- Colheita Explosiva
- Marca do Caçador
- Rastro da Esquiva

Orbital:
- Ricochete Orbital
- Pedra Partida
- Órbita Cortante

Tempestade:
- Corrente Viva
- Pós-Choque
- Raio Gêmeo

Fenda:
- Fenda Gravitacional
- Cruz do Abismo
- Fim Violento

OBSERVAÇÃO
Sem Godot executável no ambiente de geração. A build recebeu varredura estrutural/preloads e integridade do ZIP, mas o feeling e o runtime precisam ser validados no Godot do tester.
