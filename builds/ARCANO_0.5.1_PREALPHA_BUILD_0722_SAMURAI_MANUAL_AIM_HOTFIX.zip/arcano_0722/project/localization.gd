extends Node

signal language_changed(code: String)

const LANGUAGES: Array[String] = ["en","pt_BR","ja","es"]
const TEXT: Dictionary = {
  "menu.play": {
    "en": "PLAY",
    "pt_BR": "JOGAR",
    "ja": "プレイ",
    "es": "JUGAR"
  },
  "menu.play_sub": {
    "en": "choose a class and start a run",
    "pt_BR": "escolher classe e começar uma run",
    "ja": "クラスを選んでランを開始",
    "es": "elige una clase e inicia una run"
  },
  "menu.maps": {
    "en": "MAPS",
    "pt_BR": "MAPAS",
    "ja": "マップ",
    "es": "MAPAS"
  },
  "menu.maps_sub": {
    "en": "choose an unlocked map",
    "pt_BR": "escolher mapa desbloqueado",
    "ja": "解放済みマップを選ぶ",
    "es": "elige un mapa desbloqueado"
  },
  "menu.classes": {
    "en": "CLASSES",
    "pt_BR": "CLASSES",
    "ja": "クラス",
    "es": "CLASES"
  },
  "menu.classes_sub": {
    "en": "classes, quests and unlocks",
    "pt_BR": "classes, quests e desbloqueios",
    "ja": "クラス・クエスト・解放条件",
    "es": "clases, misiones y desbloqueos"
  },
  "menu.profile": {
    "en": "PROFILE",
    "pt_BR": "PERFIL",
    "ja": "プロフィール",
    "es": "PERFIL"
  },
  "menu.profile_sub": {
    "en": "records and run history",
    "pt_BR": "recordes e histórico de runs",
    "ja": "記録とラン履歴",
    "es": "récords e historial de runs"
  },
  "menu.runes": {
    "en": "ARCANE RUNES",
    "pt_BR": "RUNAS ARCANAS",
    "ja": "秘術ルーン",
    "es": "RUNAS ARCANAS"
  },
  "menu.runes_sub": {
    "en": "sigils, effects and combinations",
    "pt_BR": "sigilos, efeitos e combinações",
    "ja": "印・効果・組み合わせ",
    "es": "sellos, efectos y combinaciones"
  },
  "menu.config": {
    "en": "SETTINGS",
    "pt_BR": "CONFIGURAÇÕES",
    "ja": "設定",
    "es": "CONFIGURACIÓN"
  },
  "menu.config_sub": {
    "en": "gameplay, video and audio",
    "pt_BR": "jogabilidade, vídeo e áudio",
    "ja": "ゲーム・映像・音声",
    "es": "jugabilidad, vídeo y audio"
  },
  "menu.tutorial": {
    "en": "TUTORIAL",
    "pt_BR": "TUTORIAL",
    "ja": "チュートリアル",
    "es": "TUTORIAL"
  },
  "menu.tutorial_sub": {
    "en": "take your first lesson with the Sensei",
    "pt_BR": "receba sua primeira lição com o Sensei",
    "ja": "先生から最初の教えを受ける",
    "es": "recibe tu primera lección con el Sensei"
  },
  "menu.back": {
    "en": "BACK TO MENU",
    "pt_BR": "VOLTAR AO MENU",
    "ja": "メニューへ戻る",
    "es": "VOLVER AL MENÚ"
  },
  "menu.record": {
    "en": "RECORD   %s       •       %d KILLS",
    "pt_BR": "RECORDE   %s       •       %d ABATES",
    "ja": "記録   %s       •       %d 撃破",
    "es": "RÉCORD   %s       •       %d BAJAS"
  },
  "menu.selected": {
    "en": "SELECTED",
    "pt_BR": "SELECIONADO",
    "ja": "選択中",
    "es": "SELECCIONADO"
  },
  "menu.cancel": {
    "en": "CANCEL",
    "pt_BR": "CANCELAR",
    "ja": "キャンセル",
    "es": "CANCELAR"
  },
  "lang.title": {
    "en": "LANGUAGE",
    "pt_BR": "IDIOMA",
    "ja": "言語",
    "es": "IDIOMA"
  },
  "lang.hint": {
    "en": "Language",
    "pt_BR": "Idioma",
    "ja": "言語",
    "es": "Idioma"
  },
  "profile.info": {
    "en": "Every expedition leaves a mark. Your records gather here.",
    "pt_BR": "Toda expedição deixa uma marca. Seus recordes se encontram aqui.",
    "ja": "すべての遠征は痕跡を残す。記録はここに集まる。",
    "es": "Toda expedición deja una marca. Tus récords se reúnen aquí."
  },
  "profile.runs_started": {
    "en": "RUNS STARTED",
    "pt_BR": "RUNS INICIADAS",
    "ja": "開始ラン",
    "es": "RUNS INICIADAS"
  },
  "profile.runs_sub": {
    "en": "Every departure into the pale world counts.",
    "pt_BR": "Cada partida pelo mundo desbotado deixa sua marca.",
    "ja": "色褪せた世界へ踏み出すたび、記録が刻まれる。",
    "es": "Cada partida por el mundo descolorido deja su marca."
  },
  "profile.time_record": {
    "en": "TIME RECORD",
    "pt_BR": "RECORDE DE TEMPO",
    "ja": "最長時間",
    "es": "RÉCORD DE TIEMPO"
  },
  "profile.time_record_sub": {
    "en": "Longest recorded run.",
    "pt_BR": "Maior duração registrada.",
    "ja": "最長のラン時間。",
    "es": "Mayor duración registrada."
  },
  "profile.kill_record": {
    "en": "KILL RECORD",
    "pt_BR": "RECORDE DE ABATES",
    "ja": "最多撃破",
    "es": "RÉCORD DE BAJAS"
  },
  "profile.kill_record_sub": {
    "en": "Most kills in a single run.",
    "pt_BR": "Maior número em uma única run.",
    "ja": "1ランの最多撃破数。",
    "es": "Mayor número en una sola run."
  },
  "profile.best_level": {
    "en": "HIGHEST LEVEL",
    "pt_BR": "MAIOR NÍVEL",
    "ja": "最高レベル",
    "es": "MAYOR NIVEL"
  },
  "profile.best_level_sub": {
    "en": "Highest level reached.",
    "pt_BR": "Melhor nível alcançado.",
    "ja": "到達した最高レベル。",
    "es": "Mejor nivel alcanzado."
  },
  "profile.total_kills": {
    "en": "TOTAL KILLS",
    "pt_BR": "ABATES TOTAIS",
    "ja": "総撃破数",
    "es": "BAJAS TOTALES"
  },
  "profile.total_kills_sub": {
    "en": "Every fallen enemy remains written in your story.",
    "pt_BR": "Cada inimigo derrubado permanece escrito na sua história.",
    "ja": "倒した敵の数は、すべてお前の物語に刻まれる。",
    "es": "Cada enemigo derrotado queda escrito en tu historia."
  },
  "profile.elites": {
    "en": "ELITES DEFEATED",
    "pt_BR": "ELITES DERROTADOS",
    "ja": "エリート撃破",
    "es": "ÉLITES DERROTADOS"
  },
  "profile.elites_sub": {
    "en": "The strongest creatures that have fallen before you.",
    "pt_BR": "As criaturas mais fortes que já caíram diante de você.",
    "ja": "お前の前に倒れた、強敵たちの数。",
    "es": "Las criaturas más fuertes que ya han caído ante ti."
  },
  "profile.vases": {
    "en": "VASES BROKEN",
    "pt_BR": "VASOS QUEBRADOS",
    "ja": "壺破壊",
    "es": "VASOS ROTOS"
  },
  "profile.vases_sub": {
    "en": "Apparently, pottery has become your second enemy.",
    "pt_BR": "Aparentemente, cerâmica virou seu segundo maior inimigo.",
    "ja": "どうやら壺も、お前の立派な敵らしい。",
    "es": "Al parecer, la cerámica se convirtió en tu segundo enemigo."
  },
  "profile.avg_time": {
    "en": "AVERAGE TIME",
    "pt_BR": "MÉDIA DE TEMPO",
    "ja": "平均時間",
    "es": "TIEMPO MEDIO"
  },
  "profile.avg_kills": {
    "en": "AVERAGE KILLS",
    "pt_BR": "MÉDIA DE ABATES",
    "ja": "平均撃破",
    "es": "BAJAS MEDIAS"
  },
  "profile.avg_elites": {
    "en": "AVERAGE ELITES",
    "pt_BR": "MÉDIA DE ELITES",
    "ja": "平均エリート",
    "es": "ÉLITES MEDIOS"
  },
  "profile.closed_runs": {
    "en": "%d completed runs",
    "pt_BR": "%d runs encerradas",
    "ja": "%d ラン完了",
    "es": "%d runs terminadas"
  },
  "profile.per_run": {
    "en": "per completed run",
    "pt_BR": "por run encerrada",
    "ja": "完了ランあたり",
    "es": "por run terminada"
  },
  "maps.info": {
    "en": "Choose where the next hunt begins. Every land asks for a different rhythm.",
    "pt_BR": "Escolha onde começa a próxima caçada. Cada terra exige um ritmo diferente.",
    "ja": "次の狩りが始まる地を選べ。土地ごとに求められるリズムは違う。",
    "es": "Elige dónde comienza la próxima cacería. Cada tierra exige un ritmo distinto."
  },
  "maps.silent_fields": {
    "en": "SILENT FIELDS",
    "pt_BR": "CAMPOS SILENTES",
    "ja": "静寂の野",
    "es": "CAMPOS SILENTES"
  },
  "maps.silent_sub": {
    "en": "unlocked  •  wide grasslands, clear sightlines, high mobility",
    "pt_BR": "desbloqueado  •  pradarias amplas, leitura limpa e boa mobilidade",
    "ja": "解放済み • 広い草原・高い視認性・高機動",
    "es": "desbloqueado • praderas amplias, lectura limpia y buena movilidad"
  },
  "maps.silent_desc": {
    "en": "Old ruins sleep beneath a wide sky. There is room to run, room to see danger coming, and plenty of room for bad ideas to become powerful ones.",
    "pt_BR": "Ruínas antigas dormem sob um céu aberto. Há espaço para correr, enxergar o perigo chegando e transformar ideias ruins em poderes assustadoramente bons.",
    "ja": "古い遺跡が広い空の下で眠っている。走る余地も、迫る危険を見る余地も、妙な発想を恐ろしい力へ育てる余地も十分だ。",
    "es": "Viejas ruinas duermen bajo un cielo abierto. Hay espacio para correr, ver llegar el peligro y convertir malas ideas en poderes aterradoramente buenos."
  },
  "maps.ash_ruins": {
    "en": "ASH RUINS",
    "pt_BR": "RUÍNAS DE CINZA",
    "ja": "灰の遺跡",
    "es": "RUINAS DE CENIZA"
  },
  "maps.locked_soon": {
    "en": "locked  •  coming soon",
    "pt_BR": "bloqueado  •  em breve",
    "ja": "未解放 • 近日公開",
    "es": "bloqueado • próximamente"
  },
  "classes.available": {
    "en": "Available classes",
    "pt_BR": "Classes disponíveis",
    "ja": "使用可能クラス",
    "es": "Clases disponibles"
  },
  "classes.choose": {
    "en": "CHOOSE YOUR CLASS",
    "pt_BR": "ESCOLHA SUA CLASSE",
    "ja": "クラスを選択",
    "es": "ELIGE TU CLASE"
  },
  "classes.choose_sub": {
    "en": "Choose what kind of danger you want to become.",
    "pt_BR": "Escolha que tipo de perigo você quer se tornar.",
    "ja": "自分がどんな脅威になるか選べ。",
    "es": "Elige en qué clase de peligro quieres convertirte."
  },
  "class.orbit": {
    "en": "ORBITAL",
    "pt_BR": "ORBITAL",
    "ja": "オービタル",
    "es": "ORBITAL"
  },
  "class.orbit_desc": {
    "en": "Keep your distance and let the orbiting stones hunt. Calm feet, constant pressure.",
    "pt_BR": "Mantenha distância e deixe as pedras orbitais caçarem. Pés calmos, pressão constante.",
    "ja": "距離を保ち、軌道石に狩らせろ。足は静かに、圧力は絶やさず。",
    "es": "Mantén la distancia y deja que las piedras orbitales cacen. Pies tranquilos, presión constante."
  },
  "class.storm": {
    "en": "STORM",
    "pt_BR": "TEMPESTADE",
    "ja": "テンペスト",
    "es": "TORMENTA"
  },
  "class.storm_desc": {
    "en": "Call lightning until the sky starts choosing victims with you.",
    "pt_BR": "Chame relâmpagos até o céu começar a escolher vítimas junto com você.",
    "ja": "空そのものがお前と共に獲物を選び始めるまで、雷を呼び続けろ。",
    "es": "Llama rayos hasta que el cielo empiece a elegir víctimas contigo."
  },
  "class.rift": {
    "en": "RIFT",
    "pt_BR": "FENDA",
    "ja": "リフト",
    "es": "FISURA"
  },
  "class.rift_desc": {
    "en": "Scar the ground and make enemies regret stepping where you have already been.",
    "pt_BR": "Marque o chão e faça os inimigos se arrependerem de pisar onde você já passou.",
    "ja": "地面に傷を残し、お前が通った場所へ踏み込んだ敵を後悔させろ。",
    "es": "Marca el suelo y haz que los enemigos se arrepientan de pisar donde ya estuviste."
  },
  "class.samurai": {
    "en": "SAMURAI",
    "pt_BR": "SAMURAI",
    "ja": "侍",
    "es": "SAMURÁI"
  },
  "class.samurai_desc": {
    "en": "Live inside blade range. Short cuts, dangerous spacing, and a dash that passes through enemies like a verdict.",
    "pt_BR": "Viva no alcance da lâmina. Cortes curtos, distância perigosa e um dash que atravessa inimigos como uma sentença.",
    "ja": "刃の間合いで生きろ。短い斬撃、危険な距離、そして判決のように敵を貫くダッシュ。",
    "es": "Vive dentro del alcance de la hoja. Cortes cortos, distancia peligrosa y un dash que atraviesa enemigos como una sentencia."
  },
  "classes.unlocked": {
    "en": "UNLOCKED",
    "pt_BR": "DESBLOQUEADO",
    "ja": "解放済み",
    "es": "DESBLOQUEADO"
  },
  "classes.released": {
    "en": "AVAILABLE",
    "pt_BR": "LIBERADO",
    "ja": "使用可能",
    "es": "DISPONIBLE"
  },
  "classes.temporarily_removed": {
    "en": "TEMPORARILY REMOVED",
    "pt_BR": "TEMPORARIAMENTE REMOVIDO",
    "ja": "一時的に無効",
    "es": "RETIRADO TEMPORALMENTE"
  },
  "runes.title": {
    "en": "ARCANE RUNES",
    "pt_BR": "RUNAS ARCANAS",
    "ja": "秘術ルーン",
    "es": "RUNAS ARCANAS"
  },
  "runes.note": {
    "en": "Not every Rune is a number. Some change how your magic is born, travels, reacts and kills. Follow an affinity or mix strange ideas until the magic feels unmistakably yours.",
    "pt_BR": "Nem toda Runa é só número. Algumas mudam como sua magia nasce, viaja, reage e mata. Siga uma afinidade ou misture ideias estranhas até a magia ficar com a sua cara.",
    "ja": "ルーンは数字だけではない。魔法の生まれ方、飛び方、反応、倒し方そのものを変えるものもある。系統を追うもよし、妙な組み合わせを重ねて自分だけの魔法にするもよし。",
    "es": "No toda Runa es solo un número. Algunas cambian cómo nace, viaja, reacciona y mata tu magia. Sigue una afinidad o mezcla ideas extrañas hasta que la magia se sienta inconfundiblemente tuya."
  },
  "filter.all": {
    "en": "ALL",
    "pt_BR": "TODAS",
    "ja": "すべて",
    "es": "TODAS"
  },
  "filter.weapon": {
    "en": "WEAPON",
    "pt_BR": "ARMA",
    "ja": "武器",
    "es": "ARMA"
  },
  "filter.damage": {
    "en": "DAMAGE",
    "pt_BR": "DANO",
    "ja": "ダメージ",
    "es": "DAÑO"
  },
  "filter.movement": {
    "en": "MOVEMENT",
    "pt_BR": "MOVIMENTO",
    "ja": "移動",
    "es": "MOVIMIENTO"
  },
  "filter.survival": {
    "en": "SURVIVAL",
    "pt_BR": "SOBREVIVÊNCIA",
    "ja": "生存",
    "es": "SUPERVIVENCIA"
  },
  "filter.utility": {
    "en": "UTILITY",
    "pt_BR": "UTILIDADE",
    "ja": "ユーティリティ",
    "es": "UTILIDAD"
  },
  "filter.control": {
    "en": "CONTROL",
    "pt_BR": "CONTROLE",
    "ja": "制御",
    "es": "CONTROL"
  },
  "settings.gameplay": {
    "en": "GAMEPLAY",
    "pt_BR": "JOGABILIDADE",
    "ja": "ゲームプレイ",
    "es": "JUGABILIDAD"
  },
  "settings.attack_method": {
    "en": "TARGETING METHOD",
    "pt_BR": "MÉTODO DE TIRO",
    "ja": "ターゲット方式",
    "es": "MÉTODO DE DISPARO"
  },
  "settings.graphics": {
    "en": "GRAPHICS",
    "pt_BR": "GRÁFICOS",
    "ja": "グラフィック",
    "es": "GRÁFICOS"
  },
  "settings.resolution": {
    "en": "RESOLUTION",
    "pt_BR": "RESOLUÇÃO",
    "ja": "解像度",
    "es": "RESOLUCIÓN"
  },
  "settings.display": {
    "en": "DISPLAY",
    "pt_BR": "EXIBIÇÃO",
    "ja": "表示",
    "es": "PANTALLA"
  },
  "settings.shake": {
    "en": "SCREEN MOTION",
    "pt_BR": "MOVIMENTO DE TELA",
    "ja": "画面演出",
    "es": "MOVIMIENTO DE PANTALLA"
  },
  "settings.postfx": {
    "en": "VISUAL EFFECTS",
    "pt_BR": "EFEITOS VISUAIS",
    "ja": "視覚効果",
    "es": "EFECTOS VISUALES"
  },
  "settings.volume": {
    "en": "VOLUME",
    "pt_BR": "VOLUME",
    "ja": "音量",
    "es": "VOLUMEN"
  },
  "settings.master": {
    "en": "MASTER",
    "pt_BR": "GERAL",
    "ja": "全体",
    "es": "GENERAL"
  },
  "settings.music": {
    "en": "MUSIC",
    "pt_BR": "MÚSICA",
    "ja": "音楽",
    "es": "MÚSICA"
  },
  "settings.sfx": {
    "en": "EFFECTS",
    "pt_BR": "EFEITOS",
    "ja": "効果音",
    "es": "EFECTOS"
  },
  "settings.nearest": {
    "en": "NEAREST TARGET",
    "pt_BR": "ALVO MAIS PRÓXIMO",
    "ja": "最も近い敵",
    "es": "OBJETIVO MÁS CERCANO"
  },
  "settings.lowest": {
    "en": "LOWEST HEALTH",
    "pt_BR": "ALVO COM MENOS VIDA",
    "ja": "低HP優先",
    "es": "MENOR VIDA"
  },
  "settings.maxhealth": {
    "en": "HIGHEST MAX HEALTH",
    "pt_BR": "MAIOR VIDA MÁXIMA",
    "ja": "最大HP優先",
    "es": "MAYOR VIDA MÁXIMA"
  },
  "settings.mouse": {
    "en": "MOUSE / MANUAL",
    "pt_BR": "MOUSE / MANUAL",
    "ja": "マウス / 手動",
    "es": "RATÓN / MANUAL"
  },
  "settings.on": {
    "en": "ON",
    "pt_BR": "ATIVADO",
    "ja": "オン",
    "es": "ACTIVADO"
  },
  "settings.off": {
    "en": "OFF",
    "pt_BR": "DESATIVADO",
    "ja": "オフ",
    "es": "DESACTIVADO"
  },
  "settings.window": {
    "en": "WINDOWED",
    "pt_BR": "JANELA",
    "ja": "ウィンドウ",
    "es": "VENTANA"
  },
  "settings.borderless": {
    "en": "BORDERLESS",
    "pt_BR": "SEM BORDAS",
    "ja": "ボーダーレス",
    "es": "SIN BORDES"
  },
  "settings.fullscreen": {
    "en": "FULLSCREEN",
    "pt_BR": "TELA CHEIA",
    "ja": "フルスクリーン",
    "es": "PANTALLA COMPLETA"
  },
  "settings.fullscreen_borderless": {
    "en": "BORDERLESS FULLSCREEN",
    "pt_BR": "TELA CHEIA SEM BORDAS",
    "ja": "ボーダーレス全画面",
    "es": "PANTALLA COMPLETA SIN BORDES"
  },
  "settings.fullscreen_exclusive": {
    "en": "EXCLUSIVE FULLSCREEN",
    "pt_BR": "TELA CHEIA EXCLUSIVA",
    "ja": "排他フルスクリーン",
    "es": "PANTALLA COMPLETA EXCLUSIVA"
  },
  "settings.attack_desc": {
    "en": "Choose how the main attack selects targets.",
    "pt_BR": "Escolha como o ataque principal seleciona os alvos.",
    "ja": "メイン攻撃のターゲット選択方式。",
    "es": "Elige cómo el ataque principal selecciona objetivos."
  },
  "settings.shake_desc": {
    "en": "Keeps only soft cinematic motion. Regular kills no longer shake the camera.",
    "pt_BR": "Mantém apenas movimento cinematográfico suave. Abates comuns não tremem mais a câmera.",
    "ja": "強い揺れを抑え、通常撃破ではカメラを揺らしません。",
    "es": "Mantiene solo movimiento cinematográfico suave. Las bajas normales ya no sacuden la cámara."
  },
  "settings.postfx_desc": {
    "en": "Enable or disable extra visual effects and post-processing.",
    "pt_BR": "Liga ou desliga os efeitos visuais extras e o pós-processamento.",
    "ja": "追加視覚効果とポストプロセスを切替。",
    "es": "Activa o desactiva efectos visuales extra y postprocesado."
  },
  "settings.res_desc": {
    "en": "Window size used in Windowed mode.",
    "pt_BR": "Tamanho usado no modo Janela.",
    "ja": "ウィンドウモードのサイズ。",
    "es": "Tamaño usado en modo Ventana."
  },
  "settings.display_desc": {
    "en": "Choose Windowed, Borderless Fullscreen or Exclusive Fullscreen.",
    "pt_BR": "Escolha Janela, Tela Cheia sem borda ou Tela Cheia exclusiva.",
    "ja": "表示モードを選択。",
    "es": "Elige Ventana, Pantalla completa sin bordes o exclusiva."
  },
  "settings.master_desc": {
    "en": "Controls the overall game volume.",
    "pt_BR": "Controla o volume geral do jogo.",
    "ja": "ゲーム全体の音量。",
    "es": "Controla el volumen general del juego."
  },
  "settings.music_desc": {
    "en": "Controls soundtrack volume only.",
    "pt_BR": "Controla apenas a trilha sonora.",
    "ja": "BGMのみの音量。",
    "es": "Controla solo la música."
  },
  "settings.sfx_desc": {
    "en": "Controls sound effects only.",
    "pt_BR": "Controla apenas os efeitos sonoros.",
    "ja": "効果音のみの音量。",
    "es": "Controla solo los efectos de sonido."
  },
  "hud.level": {
    "en": "LEVEL %d  •  %s",
    "pt_BR": "NÍVEL %d  •  %s",
    "ja": "レベル %d  •  %s",
    "es": "NIVEL %d  •  %s"
  },
  "hud.kills": {
    "en": "%d KILLS",
    "pt_BR": "%d ABATES",
    "ja": "%d 撃破",
    "es": "%d BAJAS"
  },
  "hud.experience": {
    "en": "EXPERIENCE",
    "pt_BR": "EXPERIÊNCIA",
    "ja": "経験値",
    "es": "EXPERIENCIA"
  },
  "hud.boss": {
    "en": "BOSS",
    "pt_BR": "CHEFE",
    "ja": "ボス",
    "es": "JEFE"
  },
  "hud.elite": {
    "en": "ELITE",
    "pt_BR": "ELITE",
    "ja": "エリート",
    "es": "ÉLITE"
  },
  "hud.hp": {
    "en": "HP  %d / %d",
    "pt_BR": "VIDA  %d / %d",
    "ja": "HP  %d / %d",
    "es": "VIDA  %d / %d"
  },
  "hud.dash": {
    "en": "DASH",
    "pt_BR": "DASH",
    "ja": "ダッシュ",
    "es": "DASH"
  },
  "hud.attack_toggle": {
    "en": "R • aim: %s",
    "pt_BR": "R • mira: %s",
    "ja": "R • 照準: %s",
    "es": "R • apuntado: %s"
  },
  "hud.dash_in": {
    "en": "DASH  %.1fs",
    "pt_BR": "DASH  %.1fs",
    "ja": "ダッシュ  %.1f秒",
    "es": "DASH  %.1fs"
  },
  "hud.surge": {
    "en": "ARCANE SURGE",
    "pt_BR": "SURTO ARCANO",
    "ja": "秘術サージ",
    "es": "OLEADA ARCANA"
  },
  "hud.no_charges": {
    "en": "CHARGES ARE NOT CONSUMED",
    "pt_BR": "CARGAS NÃO SÃO CONSUMIDAS",
    "ja": "チャージ消費なし",
    "es": "LAS CARGAS NO SE CONSUMEN"
  },
  "hud.resonance": {
    "en": "RESONANCE",
    "pt_BR": "RESSONÂNCIA",
    "ja": "共鳴",
    "es": "RESONANCIA"
  },
  "hud.flow_in": {
    "en": "FLOW IN %ds",
    "pt_BR": "FLUXO EM %ds",
    "ja": "フローまで %d秒",
    "es": "FLUJO EN %ds"
  },
  "hud.flow": {
    "en": "FLOW",
    "pt_BR": "FLUXO",
    "ja": "フロー",
    "es": "FLUJO"
  },
  "hud.base_combat": {
    "en": "BASE COMBAT",
    "pt_BR": "COMBATE BASE",
    "ja": "基本戦闘",
    "es": "COMBATE BASE"
  },
  "hud.auto_attack": {
    "en": "AUTO ATTACK",
    "pt_BR": "AUTO-ATAQUE",
    "ja": "自動攻撃",
    "es": "AUTOATAQUE"
  },
  "banner.map_selected": {
    "en": "MAP SELECTED  •  %s",
    "pt_BR": "MAPA SELECIONADO  •  %s",
    "ja": "マップ選択 • %s",
    "es": "MAPA SELECCIONADO • %s"
  },
  "banner.endless": {
    "en": "ENDLESS  •  %s",
    "pt_BR": "ENDLESS  •  %s",
    "ja": "エンドレス • %s",
    "es": "ENDLESS • %s"
  },
  "banner.stalker_pack": {
    "en": "STALKER PACK",
    "pt_BR": "BANDO DE STALKERS",
    "ja": "ストーカー群",
    "es": "MANADA DE STALKERS"
  },
  "banner.elite_approach": {
    "en": "ELITE APPROACHING  •  %d HP",
    "pt_BR": "ELITE SE APROXIMANDO  •  %d HP",
    "ja": "エリート接近 • %d HP",
    "es": "ÉLITE ACERCÁNDOSE • %d HP"
  },
  "banner.boss_arrives": {
    "en": "BOSS  •  DISTANT WATCHER",
    "pt_BR": "CHEFE  •  OLHEIRO DISTANTE",
    "ja": "ボス • 遠見の監視者",
    "es": "JEFE • VIGÍA DISTANTE"
  },
  "banner.boss_defeated": {
    "en": "DISTANT WATCHER DEFEATED  •  +70 XP",
    "pt_BR": "OLHEIRO DERROTADO  •  +70 EXP",
    "ja": "遠見の監視者撃破 • +70 XP",
    "es": "VIGÍA DISTANTE DERROTADO • +70 EXP"
  },
  "banner.wave": {
    "en": "WAVE %d  •  PRESSURE RISES",
    "pt_BR": "ONDA %d  •  A PRESSÃO AUMENTOU",
    "ja": "ウェーブ %d • 圧力上昇",
    "es": "OLEADA %d • AUMENTA LA PRESIÓN"
  },
  "banner.gold_orb": {
    "en": "GOLD ORB  •  +%d XP",
    "pt_BR": "ORBE DOURADO  •  +%d EXP",
    "ja": "ゴールドオーブ • +%d XP",
    "es": "ORBE DORADO • +%d EXP"
  },
  "banner.vase": {
    "en": "RUNIC VASE  •  XP RELEASED",
    "pt_BR": "VASO RÚNICO  •  EXP LIBERADA",
    "ja": "ルーン壺 • XP解放",
    "es": "VASO RÚNICO • EXP LIBERADA"
  },
  "banner.level": {
    "en": "LEVEL %d",
    "pt_BR": "NÍVEL %d",
    "ja": "レベル %d",
    "es": "NIVEL %d"
  },
  "banner.heal2": {
    "en": "RECOVERED 2 HEALTH",
    "pt_BR": "RECUPEROU 2 DE VIDA",
    "ja": "HPを2回復",
    "es": "RECUPERASTE 2 DE VIDA"
  },
  "banner.magnet": {
    "en": "EXPERIENCE MAGNET",
    "pt_BR": "ÍMÃ DE EXPERIÊNCIA",
    "ja": "経験値マグネット",
    "es": "IMÁN DE EXPERIENCIA"
  },
  "banner.annihilation": {
    "en": "ANNIHILATION PULSE",
    "pt_BR": "PULSO DE ANIQUILAÇÃO",
    "ja": "殲滅パルス",
    "es": "PULSO DE ANIQUILACIÓN"
  },
  "banner.elite_chest": {
    "en": "ELITE CHEST • ARCANE GUARD SEALED",
    "pt_BR": "BAÚ DE ELITE • GUARDA ARCANA SELADA",
    "ja": "エリート宝箱 • 秘術の守りを封印",
    "es": "COFRE DE ÉLITE • GUARDIA ARCANA SELLADA"
  },
  "banner.unlock_storm": {
    "en": "STORM UNLOCKED  •  QUEST COMPLETE",
    "pt_BR": "TEMPESTADE DESBLOQUEADA  •  QUEST CONCLUÍDA",
    "ja": "テンペスト解放 • クエスト完了",
    "es": "TORMENTA DESBLOQUEADA • MISIÓN COMPLETA"
  },
  "banner.unlock_rift": {
    "en": "RIFT UNLOCKED  •  QUEST COMPLETE",
    "pt_BR": "FENDA DESBLOQUEADA  •  QUEST CONCLUÍDA",
    "ja": "リフト解放 • クエスト完了",
    "es": "FISURA DESBLOQUEADA • MISIÓN COMPLETA"
  },
  "banner.unlock_samurai": {
    "en": "SAMURAI UNLOCKED  •  QUEST COMPLETE",
    "pt_BR": "SAMURAI DESBLOQUEADO  •  QUEST CONCLUÍDA",
    "ja": "侍解放 • クエスト完了",
    "es": "SAMURÁI DESBLOQUEADO • MISIÓN COMPLETA"
  },
  "chest.gold_heal": {
    "en": "GOLD CHEST  •  MAJOR HEAL",
    "pt_BR": "BAÚ DOURADO  •  CURA MAIOR",
    "ja": "金の宝箱 • 大回復",
    "es": "COFRE DORADO • CURACIÓN MAYOR"
  },
  "chest.gold_xp": {
    "en": "GOLD CHEST  •  +%d XP",
    "pt_BR": "BAÚ DOURADO  •  +%d EXP",
    "ja": "金の宝箱 • +%d XP",
    "es": "COFRE DORADO • +%d EXP"
  },
  "chest.dragon": {
    "en": "GOLD CHEST  •  DRAGON BREATH",
    "pt_BR": "BAÚ DOURADO  •  SOPRO DRACÔNICO",
    "ja": "金の宝箱 • 竜の息吹",
    "es": "COFRE DORADO • ALIENTO DE DRAGÓN"
  },
  "chest.skyfire": {
    "en": "GOLD CHEST  •  SKYFIRE STORM",
    "pt_BR": "BAÚ DOURADO  •  TEMPESTADE CELESTE",
    "ja": "金の宝箱 • 天火の嵐",
    "es": "COFRE DORADO • TORMENTA CELESTE"
  },
  "chest.flux": {
    "en": "GOLD CHEST  •  FLOW RESERVE",
    "pt_BR": "BAÚ DOURADO  •  RESERVA DE FLUXO",
    "ja": "金の宝箱 • フロー貯蔵",
    "es": "COFRE DORADO • RESERVA DE FLUJO"
  },
  "chest.guard": {
    "en": "GOLD CHEST  •  ARCANE GUARD",
    "pt_BR": "BAÚ DOURADO  •  GUARDA ARCANA",
    "ja": "金の宝箱 • 秘術の守り",
    "es": "COFRE DORADO • GUARDIA ARCANA"
  },
  "chest.silver_heal": {
    "en": "SILVER CHEST  •  HEAL",
    "pt_BR": "BAÚ PRATEADO  •  CURA",
    "ja": "銀の宝箱 • 回復",
    "es": "COFRE PLATEADO • CURACIÓN"
  },
  "chest.silver_magnet": {
    "en": "SILVER CHEST  •  XP MAGNET",
    "pt_BR": "BAÚ PRATEADO  •  ÍMÃ DE EXP",
    "ja": "銀の宝箱 • XPマグネット",
    "es": "COFRE PLATEADO • IMÁN DE EXP"
  },
  "chest.silver_xp": {
    "en": "SILVER CHEST  •  +%d XP",
    "pt_BR": "BAÚ PRATEADO  •  +%d EXP",
    "ja": "銀の宝箱 • +%d XP",
    "es": "COFRE PLATEADO • +%d EXP"
  },
  "chest.cache": {
    "en": "SILVER CHEST  •  GOLD CACHE",
    "pt_BR": "BAÚ PRATEADO  •  CACHE DOURADO",
    "ja": "銀の宝箱 • ゴールドキャッシュ",
    "es": "COFRE PLATEADO • RESERVA DORADA"
  },
  "chest.spark": {
    "en": "SILVER CHEST  •  FLOW SPARK",
    "pt_BR": "BAÚ PRATEADO  •  CENTELHA DE FLUXO",
    "ja": "銀の宝箱 • フローの火花",
    "es": "COFRE PLATEADO • CHISPA DE FLUJO"
  },
  "chest.champion": {
    "en": "SILVER CHEST  •  CHAMPION IMPULSE",
    "pt_BR": "BAÚ PRATEADO  •  IMPULSO DO CAMPEÃO",
    "ja": "銀の宝箱 • 王者の衝動",
    "es": "COFRE PLATEADO • IMPULSO DEL CAMPEÓN"
  },
  "chest.shock": {
    "en": "SILVER CHEST  •  RUNIC SHOCK",
    "pt_BR": "BAÚ PRATEADO  •  CHOQUE RÚNICO",
    "ja": "銀の宝箱 • ルーンショック",
    "es": "COFRE PLATEADO • CHOQUE RÚNICO"
  },
  "levelup.rare": {
    "en": "ELITE CHEST",
    "pt_BR": "BAÚ DE ELITE",
    "ja": "エリート宝箱",
    "es": "COFRE DE ÉLITE"
  },
  "levelup.choose": {
    "en": "Choose 1 of 3 Runes. Some strengthen what you are; others rewrite what your magic can become.",
    "pt_BR": "Escolha 1 de 3 Runas. Algumas fortalecem o que você já é; outras reescrevem o que sua magia pode virar.",
    "ja": "3つからルーンを1つ選べ。今の力を磨くものもあれば、魔法の未来そのものを書き換えるものもある。",
    "es": "Elige 1 de 3 Runas. Algunas fortalecen lo que ya eres; otras reescriben en qué puede convertirse tu magia."
  },
  "levelup.rare_choose": {
    "en": "Choose a Rune reward.",
    "pt_BR": "Escolha uma Runa de recompensa.",
    "ja": "報酬ルーンを選択。",
    "es": "Elige una Runa de recompensa."
  },
  "death.title": {
    "en": "RUN ENDED",
    "pt_BR": "A RUN TERMINOU",
    "ja": "ラン終了",
    "es": "RUN TERMINADA"
  },
  "death.stats": {
    "en": "%s  •  LEVEL %d\n%d kills  •  %d elites\n%d runes acquired",
    "pt_BR": "%s  •  NÍVEL %d\n%d abates  •  %d elites\n%d runas adquiridas",
    "ja": "%s • レベル %d\n%d 撃破 • %d エリート\n%d ルーン獲得",
    "es": "%s • NIVEL %d\n%d bajas • %d élites\n%d runas adquiridas"
  },
  "death.retry": {
    "en": "TRY AGAIN",
    "pt_BR": "TENTAR DE NOVO",
    "ja": "再挑戦",
    "es": "INTENTAR DE NUEVO"
  },
  "pause.title": {
    "en": "PAUSED",
    "pt_BR": "PAUSADO",
    "ja": "ポーズ",
    "es": "PAUSA"
  },
  "pause.resume": {
    "en": "CONTINUE",
    "pt_BR": "CONTINUAR",
    "ja": "続ける",
    "es": "CONTINUAR"
  },
  "pause.stats_hint": {
    "en": "Run statistics live here now.",
    "pt_BR": "As estatísticas da run ficam aqui agora.",
    "ja": "ランの統計はここで確認できる。",
    "es": "Las estadísticas de la run están aquí ahora."
  },
  "pause.run_stats": {
    "en": "RUN STATISTICS",
    "pt_BR": "ESTATÍSTICAS DA RUN",
    "ja": "ラン統計",
    "es": "ESTADÍSTICAS DE LA RUN"
  },
  "pause.tab_hint": {
    "en": "During gameplay, hold TAB to check only your Runes and items [1–0].",
    "pt_BR": "Durante o jogo, segura TAB pra ver só suas Runas e os itens [1–0].",
    "ja": "プレイ中はTAB長押しで、ルーンと［1–0］のアイテムだけ確認できる。",
    "es": "Durante la partida, mantén TAB para ver solo tus Runas y objetos [1–0]."
  },
  "quest.storm": {
    "en": "QUEST • ORBITAL SPIDERS %d/80",
    "pt_BR": "QUEST • ARANHAS ORBITAL %d/80",
    "ja": "クエスト • オービタルでクモ %d/80",
    "es": "MISIÓN • ARAÑAS ORBITAL %d/80"
  },
  "quest.rift": {
    "en": "QUEST • ELITES %d/4",
    "pt_BR": "QUEST • ELITES %d/4",
    "ja": "クエスト • エリート %d/4",
    "es": "MISIÓN • ÉLITES %d/4"
  },
  "quest.samurai": {
    "en": "QUEST • VASES %d/4 • KILLS %d/100",
    "pt_BR": "QUEST • VASOS %d/4 • ABATES %d/100",
    "ja": "クエスト • 壺 %d/4 • 撃破 %d/100",
    "es": "MISIÓN • VASOS %d/4 • BAJAS %d/100"
  },
  "tab.build_title": {
    "en": "YOUR BUILD",
    "pt_BR": "SUA BUILD",
    "ja": "現在のビルド",
    "es": "TU BUILD"
  },
  "tab.build_sub": {
    "en": "Runes on the left. Your one-use belt on the right. Nothing else.",
    "pt_BR": "Runas à esquerda. Seu cinto de uso único à direita. Só isso.",
    "ja": "左にルーン、右に1回使い切りのベルト。それだけ。",
    "es": "Runas a la izquierda. Tu cinturón de un solo uso a la derecha. Nada más."
  },
  "tab.build_footer": {
    "en": "Hold TAB to check the build  •  ESC opens run statistics",
    "pt_BR": "Segure TAB pra conferir a build  •  ESC abre as estatísticas da run",
    "ja": "TAB長押しでビルド確認  •  ESCでラン統計",
    "es": "Mantén TAB para ver la build  •  ESC abre las estadísticas de la run"
  },
  "tab.more_runes": {
    "en": "+%d more Runes",
    "pt_BR": "+%d Runas a mais",
    "ja": "ほか%d個のルーン",
    "es": "+%d Runas más"
  },
  "stats.title": {
    "en": "TACTICAL RUN PANEL",
    "pt_BR": "PAINEL TÁTICO DA RUN",
    "ja": "ラン戦術パネル",
    "es": "PANEL TÁCTICO DE RUN"
  },
  "stats.summary": {
    "en": "SUMMARY",
    "pt_BR": "RESUMO",
    "ja": "概要",
    "es": "RESUMEN"
  },
  "stats.combat": {
    "en": "COMBAT",
    "pt_BR": "COMBATE",
    "ja": "戦闘",
    "es": "COMBATE"
  },
  "stats.survival": {
    "en": "SURVIVAL / INSTINCTS",
    "pt_BR": "SOBREVIVÊNCIA / INSTINTOS",
    "ja": "生存 / 本能",
    "es": "SUPERVIVENCIA / INSTINTOS"
  },
  "stats.state": {
    "en": "CURRENT STATE",
    "pt_BR": "ESTADO ATUAL",
    "ja": "現在状態",
    "es": "ESTADO ACTUAL"
  },
  "stats.quick": {
    "en": "QUICK VIEW",
    "pt_BR": "VISÃO RÁPIDA",
    "ja": "クイック表示",
    "es": "VISTA RÁPIDA"
  },
  "stats.runes": {
    "en": "ACTIVE RUNES  •  %d",
    "pt_BR": "RUNAS ATIVAS  •  %d",
    "ja": "有効ルーン • %d",
    "es": "RUNAS ACTIVAS • %d"
  },
  "stats.no_runes": {
    "en": "No Runes acquired yet.",
    "pt_BR": "Nenhuma Runa adquirida ainda.",
    "ja": "まだルーン未取得。",
    "es": "Aún no has adquirido Runas."
  },
  "stats.footer": {
    "en": "TAB closes the panel • the field does not pause to admire your numbers",
    "pt_BR": "TAB fecha o painel • o campo não para para admirar seus números",
    "ja": "TABで閉じる • 数字を眺めている間も野は待ってくれない",
    "es": "TAB cierra el panel • el campo no se detiene para admirar tus números"
  },
  "stats.label.class": {
    "en": "Class",
    "pt_BR": "Classe",
    "ja": "クラス",
    "es": "Clase"
  },
  "stats.label.health": {
    "en": "Health",
    "pt_BR": "Vida",
    "ja": "HP",
    "es": "Vida"
  },
  "stats.label.run_time": {
    "en": "Run time",
    "pt_BR": "Tempo de run",
    "ja": "ラン時間",
    "es": "Tiempo de run"
  },
  "stats.label.active_runes": {
    "en": "Active Runes",
    "pt_BR": "Runas ativas",
    "ja": "有効ルーン",
    "es": "Runas activas"
  },
  "stats.label.boss": {
    "en": "Boss",
    "pt_BR": "Chefe",
    "ja": "ボス",
    "es": "Jefe"
  },
  "stats.label.director": {
    "en": "Field pressure",
    "pt_BR": "Pressão do campo",
    "ja": "戦場の圧力",
    "es": "Presión del campo"
  },
  "stats.label.base_damage": {
    "en": "Base damage",
    "pt_BR": "Dano base",
    "ja": "基礎ダメージ",
    "es": "Daño base"
  },
  "stats.label.attack_rate": {
    "en": "Attack rate",
    "pt_BR": "Cadência",
    "ja": "攻撃速度",
    "es": "Cadencia"
  },
  "stats.label.accuracy": {
    "en": "Accuracy",
    "pt_BR": "Precisão",
    "ja": "精度",
    "es": "Precisión"
  },
  "stats.label.critical": {
    "en": "Critical",
    "pt_BR": "Crítico",
    "ja": "クリティカル",
    "es": "Crítico"
  },
  "stats.label.extra_attacks": {
    "en": "Extra attacks",
    "pt_BR": "Ataques extras",
    "ja": "追加攻撃",
    "es": "Ataques extra"
  },
  "stats.label.elite_damage": {
    "en": "Elite damage",
    "pt_BR": "Dano vs elite",
    "ja": "対エリートダメージ",
    "es": "Daño vs élite"
  },
  "stats.label.range": {
    "en": "Range",
    "pt_BR": "Alcance",
    "ja": "射程",
    "es": "Alcance"
  },
  "stats.label.area___resource": {
    "en": "Area / resource",
    "pt_BR": "Área / recurso",
    "ja": "範囲 / リソース",
    "es": "Área / recurso"
  },
  "stats.label.movement": {
    "en": "Movement",
    "pt_BR": "Movimento",
    "ja": "移動",
    "es": "Movimiento"
  },
  "stats.label.dash": {
    "en": "Dash",
    "pt_BR": "Dash",
    "ja": "ダッシュ",
    "es": "Dash"
  },
  "stats.label.regen": {
    "en": "Regen",
    "pt_BR": "Regen",
    "ja": "再生",
    "es": "Regen"
  },
  "stats.label.block": {
    "en": "Block",
    "pt_BR": "Bloqueio",
    "ja": "ブロック",
    "es": "Bloqueo"
  },
  "stats.label.xp": {
    "en": "XP",
    "pt_BR": "XP",
    "ja": "XP",
    "es": "XP"
  },
  "stats.label.pickup": {
    "en": "Pickup",
    "pt_BR": "Coleta",
    "ja": "回収範囲",
    "es": "Recogida"
  },
  "stats.label.luck": {
    "en": "Luck",
    "pt_BR": "Sorte",
    "ja": "運",
    "es": "Suerte"
  },
  "stats.label.gold_orb": {
    "en": "Gold orb",
    "pt_BR": "Orbe dourado",
    "ja": "ゴールドオーブ",
    "es": "Orbe dorado"
  },
  "stats.label.flow": {
    "en": "Flow",
    "pt_BR": "Fluxo",
    "ja": "フロー",
    "es": "Flujo"
  },
  "stats.label.flow_recharge": {
    "en": "Flow recharge",
    "pt_BR": "Recarga do fluxo",
    "ja": "フロー再充填",
    "es": "Recarga de flujo"
  },
  "stats.label.flow_activations": {
    "en": "Flow activations",
    "pt_BR": "Ativações de fluxo",
    "ja": "フロー発動回数",
    "es": "Activaciones de flujo"
  },
  "stats.label.auto_targeting": {
    "en": "Auto targeting",
    "pt_BR": "Mira automática",
    "ja": "自動照準",
    "es": "Apuntado automático"
  },
  "stats.label.current_stones": {
    "en": "Current stones",
    "pt_BR": "Pedras atuais",
    "ja": "現在の石",
    "es": "Piedras actuales"
  },
  "stats.label.rift_charges": {
    "en": "Rift charges",
    "pt_BR": "Cargas da fenda",
    "ja": "リフトチャージ",
    "es": "Cargas de fisura"
  },
  "stats.label.current_xp": {
    "en": "Current XP",
    "pt_BR": "XP atual",
    "ja": "現在XP",
    "es": "XP actual"
  },
  "stats.label.kills___elite": {
    "en": "Kills / elite",
    "pt_BR": "Abates / elite",
    "ja": "撃破 / エリート",
    "es": "Bajas / élite"
  },
  "stats.label.map": {
    "en": "Map",
    "pt_BR": "Mapa",
    "ja": "マップ",
    "es": "Mapa"
  },
  "stats.label.objective": {
    "en": "Objective",
    "pt_BR": "Objetivo",
    "ja": "目標",
    "es": "Objetivo"
  },
  "stats.label.survive_and_scale_the_build": {
    "en": "Survive. Let the Runes become stranger.",
    "pt_BR": "Sobreviva. Deixe as Runas ficarem mais estranhas.",
    "ja": "生き残れ。ルーンをもっと異様に育てろ。",
    "es": "Sobrevive. Deja que las Runas se vuelvan más extrañas."
  },
  "stats.enemy_scene": {
    "en": "%d enemies nearby",
    "pt_BR": "%d inimigos por perto",
    "ja": "周囲に敵 %d 体",
    "es": "%d enemigos cerca"
  },
  "stats.boss_active": {
    "en": "active",
    "pt_BR": "ativo",
    "ja": "出現中",
    "es": "activo"
  },
  "stats.boss_in": {
    "en": "in %.0fs",
    "pt_BR": "em %.0fs",
    "ja": "あと %.0f秒",
    "es": "en %.0fs"
  },
  "stats.flow_active": {
    "en": "ACTIVE • %.1fs",
    "pt_BR": "ATIVO • %.1fs",
    "ja": "発動中 • %.1f秒",
    "es": "ACTIVO • %.1fs"
  },
  "stats.flow_recharging": {
    "en": "recharging • %.1fs",
    "pt_BR": "recarregando • %.1fs",
    "ja": "再充填 • %.1f秒",
    "es": "recargando • %.1fs"
  },
  "stats.target_mouse": {
    "en": "mouse",
    "pt_BR": "mouse",
    "ja": "マウス",
    "es": "ratón"
  },
  "stats.target_low": {
    "en": "lowest health",
    "pt_BR": "menor vida",
    "ja": "低HP",
    "es": "menor vida"
  },
  "stats.target_max": {
    "en": "highest max health",
    "pt_BR": "maior vida máxima",
    "ja": "最大HP",
    "es": "mayor vida máxima"
  },
  "stats.target_near": {
    "en": "nearest",
    "pt_BR": "mais próximo",
    "ja": "最短距離",
    "es": "más cercano"
  },
  "rune.card": {
    "en": "RUNE",
    "pt_BR": "RUNA",
    "ja": "ルーン",
    "es": "RUNA"
  },
  "rune.rare": {
    "en": "RARE",
    "pt_BR": "RARA",
    "ja": "レア",
    "es": "RARA"
  },
  "rune.arcane": {
    "en": "ARCANE",
    "pt_BR": "ARCANA",
    "ja": "秘術",
    "es": "ARCANA"
  },
  "rune.choose": {
    "en": "CHOOSE",
    "pt_BR": "ESCOLHER",
    "ja": "選択",
    "es": "ELEGIR"
  },
  "rune.unknown": {
    "en": "Unknown Rune",
    "pt_BR": "Runa desconhecida",
    "ja": "未知のルーン",
    "es": "Runa desconocida"
  },
  "tutorial.prompt_title": {
    "en": "FIRST RUN?",
    "pt_BR": "PRIMEIRA RUN?",
    "ja": "初めてのラン？",
    "es": "¿PRIMERA RUN?"
  },
  "tutorial.prompt_body": {
    "en": "Before you face the field for real, the Sensei can show you the essentials: movement, combat styles, Runes, chests, and the instincts that keep a mage alive.",
    "pt_BR": "Antes de encarar o campo de verdade, o Sensei pode te mostrar o essencial: movimento, estilos de combate, Runas, baús e os instintos que mantêm um mago vivo.",
    "ja": "本番の野へ踏み込む前に、師匠が移動、戦い方、ルーン、宝箱、そして魔導士が生き残るための勘を教えてくれる。",
    "es": "Antes de enfrentarte al campo de verdad, el Sensei puede enseñarte lo esencial: movimiento, estilos de combate, Runas, cofres y los instintos que mantienen vivo a un mago."
  },
  "tutorial.start": {
    "en": "START TUTORIAL",
    "pt_BR": "INICIAR TUTORIAL",
    "ja": "チュートリアル開始",
    "es": "INICIAR TUTORIAL"
  },
  "tutorial.later": {
    "en": "NOT NOW",
    "pt_BR": "AGORA NÃO",
    "ja": "今はしない",
    "es": "AHORA NO"
  },
  "tutorial.sensei": {
    "en": "SENSEI",
    "pt_BR": "SENSEI",
    "ja": "師匠",
    "es": "SENSEI"
  },
  "tutorial.continue": {
    "en": "CLICK / SPACE TO CONTINUE",
    "pt_BR": "CLIQUE / ESPAÇO PARA CONTINUAR",
    "ja": "クリック / SPACE で続行",
    "es": "CLIC / ESPACIO PARA CONTINUAR"
  },
  "tutorial.skip": {
    "en": "ESC • leave tutorial",
    "pt_BR": "ESC • sair do tutorial",
    "ja": "ESC • 終了",
    "es": "ESC • salir del tutorial"
  },
  "tut.01": {
    "en": "Alright, you made it here in one piece. That is already a decent start. I am the Sensei. I will show you the basics, then you can go make questionable decisions on your own.",
    "pt_BR": "Beleza, chegou inteiro. Já é um ótimo começo. Eu sou o Sensei. Vou te mostrar o básico rapidinho e depois te solto pra fazer besteira sozinho.",
    "ja": "よし、ちゃんと無事に来たな。それだけでまずは合格だ。私は師匠。基本だけ教えるから、その後は自分で好きに無茶をしろ。",
    "es": "Bien, llegaste entero. Ya es un buen comienzo. Soy el Sensei. Te enseñaré lo básico y luego podrás ir a tomar malas decisiones por tu cuenta."
  },
  "tut.02": {
    "en": "Start simple: move with WASD or the arrow keys. I want to see you go a little in every direction. Standing still is a great way to become lunch.",
    "pt_BR": "Começa pelo básico: anda com WASD ou pelas setas. Quero ver você se mexendo um pouco pra cada lado. Parado você vira lanche.",
    "ja": "まずは基本。WASDか矢印キーで動け。上下左右、少しずつ見せてみろ。止まっていると普通に餌になるぞ。",
    "es": "Empecemos por lo básico: muévete con WASD o las flechas. Quiero verte ir un poco hacia cada lado. Quedarte quieto es una gran forma de convertirte en comida."
  },
  "tut.03": {
    "en": "There are different combat styles, but the rule is simple: learn what your class wants from you. Orbital likes distance. Samurai likes getting uncomfortably close.",
    "pt_BR": "Tem estilos bem diferentes de combate, mas a regra é simples: entende o que sua classe quer de você. Orbital gosta de distância. Samurai gosta de chegar perto até demais.",
    "ja": "戦い方はいろいろあるが、まず自分のクラスが何を求めているか覚えろ。オービタルは距離が好き。侍はちょっと近すぎるくらいが好きだ。",
    "es": "Hay estilos de combate muy distintos, pero la regla es simple: entiende qué quiere tu clase de ti. Orbital prefiere distancia. Samurai prefiere acercarse demasiado."
  },
  "tut.04": {
    "en": "Press SHIFT to Dash. Use it to get out of trouble, cross danger quickly, or close distance. With Samurai, the Dash can even become part of the attack.",
    "pt_BR": "Aperta SHIFT pra dar Dash. Serve pra sair de aperto, atravessar perigo rápido ou encurtar distância. Com Samurai, o Dash ainda pode virar parte do ataque.",
    "ja": "SHIFTでダッシュだ。危険から抜ける、素早く距離を詰める、逃げ道を作る。侍ならダッシュ自体が攻撃になることもある。",
    "es": "Pulsa SHIFT para hacer Dash. Sirve para salir de problemas, cruzar peligro rápido o acortar distancia. Con Samurai, el Dash incluso puede formar parte del ataque."
  },
  "tut.05": {
    "en": "These little orbs are XP. The normal ones give experience. The golden one is rare and fills 15% of your next level bar. Yes, grab the shiny one.",
    "pt_BR": "Essas bolinhas são EXP. As normais dão experiência. A dourada é rara e enche 15% da barra do próximo nível. Sim, pega a brilhante.",
    "ja": "この小さい玉がXPだ。普通のものは経験値。金色はレアで、次のレベルまでのゲージを15%埋める。そう、光ってる方は拾え。",
    "es": "Estas bolitas son EXP. Las normales dan experiencia. La dorada es rara y llena un 15% de la barra del siguiente nivel. Sí, recoge la brillante."
  },
  "tut.06": {
    "en": "Level up and you get three Rune paths: one tied to your class, one solid foundation upgrade, and one stranger option to bend the build. Ranked Runes go I, II, III — each level is stronger than the last, and the card tells you exactly what this pick adds.",
    "pt_BR": "Subiu de nível, aparecem três caminhos de Runa: uma ligada à sua classe, uma melhoria de fundamento e uma opção mais diferente pra entortar a build. Runas com nível vão de I, II e III — cada etapa é mais forte que a anterior, e a carta fala exatamente o que aquela escolha acrescenta.",
    "ja": "レベルが上がると3つの方向からルーンが出る。クラス向け、基礎強化、そしてビルドを変える変わり種だ。段階式ルーンはI・II・III。後の段階ほど強く、カードには今回増える効果がそのまま書いてある。",
    "es": "Al subir de nivel aparecen tres caminos de Runa: uno ligado a tu clase, una mejora de base y una opción más rara para torcer la build. Las Runas con nivel van I, II y III: cada etapa es más fuerte que la anterior y la carta dice exactamente qué añade esa elección."
  },
  "tut.07": {
    "en": "That is a Runic Vase. It does not break itself anymore: walk up to it and press E. They usually drop XP, so they are worth checking.",
    "pt_BR": "Aquilo é um Vaso Rúnico. Agora ele não quebra sozinho: chega perto e aperta E. Normalmente solta EXP, então vale a parada.",
    "ja": "あれがルーン壺だ。今は勝手に壊れない。近づいてEを押せ。だいたいXPが出るから、見かけたら寄る価値はある。",
    "es": "Eso es un Jarrón Rúnico. Ya no se rompe solo: acércate y pulsa E. Normalmente suelta EXP, así que suele valer la pena."
  },
  "tut.08": {
    "en": "Chests also use E. Their reward does not activate immediately: it goes into one of the numbered slots on your belt and waits there until you use it.",
    "pt_BR": "Baú também é no E. O item que sair não ativa na hora: ele vai pra um dos espaços numerados do seu cinto e fica lá até você usar.",
    "ja": "宝箱もEで開ける。報酬はその場で発動せず、ベルトの番号付きスロットに入り、自分で使うまで残る。",
    "es": "Los cofres también se abren con E. La recompensa no se activa al instante: va a uno de los espacios numerados de tu cinturón y se queda allí hasta que la uses."
  },
  "tut.09": {
    "en": "That bar is Flow. It fills while you fight. At 100%, Arcane Surge activates for a short time and your build speeds up. When it lights up, make the most of it.",
    "pt_BR": "Essa barra é o Fluxo. Ela enche enquanto você luta. Quando chega a 100%, ativa o Surto Arcano por um tempo e sua build acelera. Quando acender, aproveita.",
    "ja": "このゲージがフロー。戦っていると溜まり、100%でしばらく秘術サージが発動してビルドが加速する。光ったら遠慮なく使え。",
    "es": "Esa barra es el Flujo. Se llena mientras peleas. Al llegar al 100%, activa la Oleada Arcana durante un rato y tu build se acelera. Cuando se encienda, aprovéchala."
  },
  "tut.10": {
    "en": "Now an Elite. It has more health, hits harder, and generally makes the room less comfortable. When the warning appears, just get ready. No stopwatch required.",
    "pt_BR": "Agora um Elite. Ele tem mais vida, bate mais forte e deixa a sala bem menos confortável. Quando o aviso aparecer, só se prepara. Não precisa decorar cronômetro nenhum.",
    "ja": "次はエリート。体力が多く、攻撃も痛く、だいたい場の空気を悪くする。警告が出たら準備すればいい。秒数を暗記する必要はない。",
    "es": "Ahora un Élite. Tiene más vida, pega más fuerte y hace que todo sea bastante menos cómodo. Cuando aparezca el aviso, prepárate. No hace falta memorizar ningún cronómetro."
  },
  "tut.11": {
    "en": "When a run ends, the radial menu around the mage is your home base. From there you can play again, check classes, Runes, your Profile, maps and settings.",
    "pt_BR": "Quando uma run acabar, o menu radial em volta do mago é sua base. Por ali você joga de novo, vê classes, Runas, Perfil, mapas e configurações.",
    "ja": "ランが終わったら、魔導士の周りのラジアルメニューが拠点になる。そこから次のプレイ、クラス、ルーン、プロフィール、マップ、設定を開ける。",
    "es": "Cuando termina una run, el menú radial alrededor del mago es tu base. Desde ahí puedes volver a jugar, ver clases, Runas, Perfil, mapas y ajustes."
  },
  "tut.12": {
    "en": "If you want to change language later, use the language button. English, Brazilian Portuguese, Japanese and Spanish are available.",
    "pt_BR": "Se quiser trocar o idioma depois, usa o botão de língua. Inglês, PT-BR, japonês e espanhol estão disponíveis.",
    "ja": "あとで言語を変えたくなったら、言語ボタンを使え。英語、ブラジル・ポルトガル語、日本語、スペイン語に対応している。",
    "es": "Si quieres cambiar el idioma después, usa el botón de idioma. Están disponibles inglés, portugués de Brasil, japonés y español."
  },
  "tut.13": {
    "en": "That is it. Go play. Try weird Runes, open chests, make broken builds and learn the rest by actually playing. If you die... well, at least it will not be in my tutorial.",
    "pt_BR": "Pronto. Agora vai jogar. Testa Runa esquisita, abre baú, faz build quebrada e descobre o resto na prática. Se morrer... bom, pelo menos não foi no meu tutorial.",
    "ja": "以上。あとは遊べ。変なルーンを試して、宝箱を開けて、壊れたビルドを作って、残りは実戦で覚えろ。死んでも……まあ、少なくとも私のチュートリアルではない。",
    "es": "Listo. Ahora ve a jugar. Prueba Runas raras, abre cofres, crea builds rotas y aprende el resto jugando. Si mueres... bueno, al menos no será en mi tutorial."
  },
  "tut.14": {
    "en": "Now, items you find loose on the ground. These activate the moment you touch them. Chest items are different: those go to your belt and wait for you to use them.",
    "pt_BR": "Agora os itens que ficam soltos no chão. Esses ativam assim que você encosta. Os itens de baú são diferentes: eles vão pro seu cinto e esperam você usar.",
    "ja": "次は地面に落ちているアイテムだ。これは触れた瞬間に発動する。宝箱のアイテムは別で、ベルトに入って自分で使うまで残る。",
    "es": "Ahora, los objetos que aparecen sueltos en el suelo. Estos se activan en cuanto los tocas. Los de los cofres son distintos: van a tu cinturón y esperan a que los uses."
  },
  "tut.15": {
    "en": "For a quick build check, hold TAB. It is intentionally simple now: Runes on one side, your [1–0] items on the other. If you want kills, damage, speed and the rest of the run numbers, those are in ESC.",
    "pt_BR": "Pra conferir a build rapidinho, segura TAB. Agora ele é simples de propósito: Runas de um lado e seus itens [1–0] do outro. Se quiser abates, dano, velocidade e os outros números da run, eles ficam no ESC.",
    "ja": "ビルドをさっと確認したい時はTAB長押し。今はわざとシンプルで、片側にルーン、もう片側に［1–0］のアイテムだけ。キル数やダメージ、速度などのラン統計はESCにある。",
    "es": "Para revisar la build rápido, mantén TAB. Ahora es simple a propósito: Runas a un lado y tus objetos [1–0] al otro. Si quieres bajas, daño, velocidad y el resto de números de la run, están en ESC."
  },
  "tut.16": {
    "en": "New classes have their own challenges. Your Profile keeps track of the progress. And the tutorial stays here if you want to repeat it. I will only judge you a little.",
    "pt_BR": "Classes novas têm desafios próprios. O Perfil mostra seu progresso. E o tutorial fica aqui se quiser repetir. Eu vou julgar só um pouquinho.",
    "ja": "新しいクラスにはそれぞれ解放条件がある。進み具合はプロフィールで確認できる。チュートリアルも残しておく。やり直しても、少ししか笑わない。",
    "es": "Las clases nuevas tienen sus propios desafíos. El Perfil muestra tu progreso. Y el tutorial se queda aquí por si quieres repetirlo. Solo te juzgaré un poquito."
  },
  "tut.01b": {
    "en": "No multiple-choice test here. I ask for something, you do it, and we move on. Much easier.",
    "pt_BR": "Aqui não tem prova de marcar X. Eu peço, você faz e a gente segue. Bem mais fácil.",
    "ja": "選択問題なんてない。私が頼む、お前がやる、それで次へ進む。簡単だろ。",
    "es": "Aquí no hay examen de marcar casillas. Yo te pido algo, tú lo haces y seguimos. Mucho más fácil."
  },
  "tut.orbital": {
    "en": "This is Orbital. It attacks enemies in range automatically, so your job is to keep a good distance and choose where to move. Try it on that poor thing over there.",
    "pt_BR": "Esse é o Orbital. Ele ataca sozinho o que estiver no alcance, então seu trabalho é manter uma distância boa e escolher por onde andar. Faz o teste nesse coitado aí.",
    "ja": "これがオービタルだ。範囲内の敵を自動で攻撃する。だからお前は距離を保って、どこを歩くか考えればいい。あそこにいる気の毒なやつで試せ。",
    "es": "Este es Orbital. Ataca automáticamente a los enemigos que estén a alcance, así que tu trabajo es mantener una buena distancia y elegir por dónde moverte. Pruébalo con ese pobre de ahí."
  },
  "tut.aim_toggle": {
    "en": "Now press R once. NEAREST follows the closest enemy for you. MOUSE / MANUAL points attacks where your cursor is. Use whichever reads better for you.",
    "pt_BR": "Agora aperta R uma vez. ALVO MAIS PRÓXIMO acompanha o inimigo mais perto pra você. MOUSE / MANUAL aponta os ataques pra onde o cursor estiver. Usa o que ficar melhor pra você.",
    "ja": "次はRを1回押せ。『最も近い敵』は近い敵を自動で追う。『マウス / 手動』はカーソルの方向へ攻撃する。自分が読みやすい方を使え。",
    "es": "Ahora pulsa R una vez. OBJETIVO MÁS CERCANO sigue al enemigo más próximo por ti. RATÓN / MANUAL apunta los ataques donde esté tu cursor. Usa el que te resulte más cómodo."
  },
  "tut.samurai": {
    "en": "Now Samurai. Same automatic attack idea, except you have to get close. Stay too far away and he will heroically cut absolutely nothing. A little sad to watch.",
    "pt_BR": "Agora Samurai. Mesma ideia de ataque automático, só que você precisa chegar perto. Se ficar longe, ele vai cortar absolutamente nada. O que é meio triste de assistir.",
    "ja": "次は侍。自動攻撃なのは同じだが、今度は自分から近づく必要がある。遠すぎると格好よく空気だけ斬る。見ていて少し悲しい。",
    "es": "Ahora Samurai. La idea del ataque automático es la misma, pero tienes que acercarte. Si te quedas lejos, cortará heroicamente absolutamente nada. Es un poco triste de ver."
  },
  "tut.dash_reload": {
    "en": "Those little runners above your hat are your Dash charges. Spend one and the ring refills until it comes back. Quick read, quick decision.",
    "pt_BR": "Aqueles corredorezinhos acima do seu chapéu são suas cargas de Dash. Gastou uma? O anel enche até ela voltar. É leitura rápida pra decisão rápida.",
    "ja": "帽子の上にある小さな走る印がダッシュ回数だ。使うと輪が埋まり、満タンで1回戻る。見ればすぐ分かる。",
    "es": "Esos corredores pequeñitos sobre tu sombrero son tus cargas de Dash. Gasta una y el anillo se rellena hasta que vuelva. Lectura rápida, decisión rápida."
  },
  "tut.chest_silver": {
    "en": "Silver chests usually give smaller utility items: healing, magnets, XP, Flow, Dash recovery, things like that. Very useful for saving a run that is starting to look ugly.",
    "pt_BR": "Baús prateados costumam dar utilidades menores: cura, ímã, EXP, Fluxo, recuperação de Dash e coisas assim. Ótimos pra salvar uma run que começou a ficar feia.",
    "ja": "銀の宝箱は回復、磁石、XP、フロー、ダッシュ回復みたいな便利系が多い。ランが怪しくなってきた時にかなり助かる。",
    "es": "Los cofres plateados suelen dar utilidades menores: curación, imán, EXP, Flujo, recuperación de Dash y cosas así. Van genial para salvar una run que se está poniendo fea."
  },
  "tut.chest_gold": {
    "en": "Gold chests can hold stronger stuff: Dragon Breath, Skyfire, Arcane Guard and other big effects. Still one use only, so maybe do not panic-press the number.",
    "pt_BR": "Baús dourados podem vir com coisa mais forte: Sopro Dracônico, Tempestade Celeste, Guarda Arcana e outros efeitos grandes. Continua sendo uso único, então tenta não apertar o número no susto.",
    "ja": "金の宝箱には竜の息吹、天火、秘術の守りみたいな強いものが入る。とはいえ1回きりだ。焦って番号を押すなよ。",
    "es": "Los cofres dorados pueden traer cosas más fuertes: Aliento de Dragón, Tormenta Celeste, Guardia Arcana y otros efectos grandes. Sigue siendo de un solo uso, así que intenta no pulsar el número por pánico."
  },
  "hud.relic_belt": {
    "en": "ITEM BELT",
    "pt_BR": "CINTO DE ITENS",
    "ja": "アイテムベルト",
    "es": "CINTURÓN DE OBJETOS"
  },
  "hud.relic_details_hint": {
    "en": "[I] DETAILS",
    "pt_BR": "[I] DETALHES",
    "ja": "[I] 詳細",
    "es": "[I] DETALLES"
  },
  "hud.relic_details_title": {
    "en": "ITEMS ON YOUR BELT",
    "pt_BR": "ITENS NO SEU CINTO",
    "ja": "ベルトのアイテム",
    "es": "OBJETOS EN TU CINTURÓN"
  },
  "hud.relic_details_close": {
    "en": "[I] CLOSE",
    "pt_BR": "[I] FECHAR",
    "ja": "[I] 閉じる",
    "es": "[I] CERRAR"
  },
  "hud.relic_empty": {
    "en": "Empty",
    "pt_BR": "Vazio",
    "ja": "空き",
    "es": "Vacío"
  },
  "interact.vase": {
    "en": "[E] BREAK VASE",
    "pt_BR": "[E] QUEBRAR VASO",
    "ja": "[E] 壺を割る",
    "es": "[E] ROMPER JARRÓN"
  },
  "interact.chest": {
    "en": "[E] OPEN CHEST",
    "pt_BR": "[E] ABRIR BAÚ",
    "ja": "[E] 宝箱を開ける",
    "es": "[E] ABRIR COFRE"
  },
  "item.heal_minor": {
    "en": "Healing Seal",
    "pt_BR": "Selo de Cura",
    "ja": "癒しの印",
    "es": "Sello de Curación"
  },
  "item.xp_magnet": {
    "en": "XP Magnet",
    "pt_BR": "Ímã de EXP",
    "ja": "XP磁石",
    "es": "Imán de EXP"
  },
  "item.xp_burst_small": {
    "en": "XP Burst",
    "pt_BR": "Explosão de EXP",
    "ja": "XPバースト",
    "es": "Explosión de EXP"
  },
  "item.gold_cache": {
    "en": "Gold Cache",
    "pt_BR": "Cache Dourado",
    "ja": "ゴールドキャッシュ",
    "es": "Reserva Dorada"
  },
  "item.flux_spark": {
    "en": "Flow Spark",
    "pt_BR": "Centelha de Fluxo",
    "ja": "フローの火花",
    "es": "Chispa de Flujo"
  },
  "item.champion_impulse": {
    "en": "Champion Impulse",
    "pt_BR": "Impulso do Campeão",
    "ja": "王者の衝動",
    "es": "Impulso del Campeón"
  },
  "item.runic_shock": {
    "en": "Runic Shock",
    "pt_BR": "Choque Rúnico",
    "ja": "ルーンショック",
    "es": "Choque Rúnico"
  },
  "item.heal_major": {
    "en": "Major Healing",
    "pt_BR": "Cura Maior",
    "ja": "大回復",
    "es": "Curación Mayor"
  },
  "item.xp_burst_major": {
    "en": "Greater XP Burst",
    "pt_BR": "Grande Explosão de EXP",
    "ja": "大XPバースト",
    "es": "Gran Explosión de EXP"
  },
  "item.dragon_breath": {
    "en": "Dragon Breath",
    "pt_BR": "Sopro Dracônico",
    "ja": "竜の息吹",
    "es": "Aliento de Dragón"
  },
  "item.skyfire_storm": {
    "en": "Skyfire Storm",
    "pt_BR": "Tempestade Celeste",
    "ja": "天火の嵐",
    "es": "Tormenta Celeste"
  },
  "item.flux_reserve": {
    "en": "Flow Reserve",
    "pt_BR": "Reserva de Fluxo",
    "ja": "フロー貯蔵",
    "es": "Reserva de Flujo"
  },
  "item.arcane_guard": {
    "en": "Arcane Guard",
    "pt_BR": "Guarda Arcana",
    "ja": "秘術の守り",
    "es": "Guardia Arcana"
  },
  "itemdesc.heal_minor": {
    "en": "Restores 2 health.",
    "pt_BR": "Recupera 2 de vida.",
    "ja": "体力を2回復する。",
    "es": "Recupera 2 de vida."
  },
  "itemdesc.xp_magnet": {
    "en": "Pulls in and collects every XP orb currently on the field.",
    "pt_BR": "Puxa e coleta todos os orbes de EXP que estão no campo.",
    "ja": "フィールド上のXPオーブをすべて引き寄せて回収する。",
    "es": "Atrae y recoge todos los orbes de EXP que estén en el campo."
  },
  "itemdesc.xp_burst_small": {
    "en": "Grants 14% of your current XP bar.",
    "pt_BR": "Ganha 14% da barra atual de EXP.",
    "ja": "現在のXPゲージの14%を得る。",
    "es": "Obtienes un 14% de la barra actual de EXP."
  },
  "itemdesc.gold_cache": {
    "en": "Creates 4 golden XP orbs. Each is worth 15% of the current level bar.",
    "pt_BR": "Cria 4 orbes dourados de EXP. Cada um vale 15% da barra do nível atual.",
    "ja": "金色XPオーブを4個作る。1個につき現在のレベルゲージ15%分。",
    "es": "Crea 4 orbes dorados de EXP. Cada uno vale un 15% de la barra del nivel actual."
  },
  "itemdesc.flux_spark": {
    "en": "Adds 26 Flow.",
    "pt_BR": "Adiciona 26 de Fluxo.",
    "ja": "フローを26追加する。",
    "es": "Añade 26 de Flujo."
  },
  "itemdesc.champion_impulse": {
    "en": "Refills every Dash charge and gives +15% movement speed for 10s.",
    "pt_BR": "Recupera todas as cargas de Dash e dá +15% de velocidade por 10s.",
    "ja": "ダッシュを全回復し、10秒間移動速度+15%。",
    "es": "Recupera todas las cargas de Dash y da +15% de velocidad durante 10 s."
  },
  "itemdesc.runic_shock": {
    "en": "Calls 4 runic lightning strikes for 4 damage each.",
    "pt_BR": "Chama 4 raios rúnicos, causando 4 de dano cada.",
    "ja": "ルーン雷を4発落とし、1発につき4ダメージ。",
    "es": "Invoca 4 rayos rúnicos que hacen 4 de daño cada uno."
  },
  "itemdesc.heal_major": {
    "en": "Restores 3 health.",
    "pt_BR": "Recupera 3 de vida.",
    "ja": "体力を3回復する。",
    "es": "Recupera 3 de vida."
  },
  "itemdesc.xp_burst_major": {
    "en": "Grants 28% of your current XP bar.",
    "pt_BR": "Ganha 28% da barra atual de EXP.",
    "ja": "現在のXPゲージの28%を得る。",
    "es": "Obtienes un 28% de la barra actual de EXP."
  },
  "itemdesc.dragon_breath": {
    "en": "Blasts enemies in the direction you are aiming, with more damage up close.",
    "pt_BR": "Atinge inimigos na direção da mira e causa mais dano de perto.",
    "ja": "狙っている方向の敵を攻撃し、近いほど大きなダメージを与える。",
    "es": "Golpea a los enemigos en la dirección de la mira y hace más daño de cerca."
  },
  "itemdesc.skyfire_storm": {
    "en": "Calls 7 skyfire strikes for 6 damage each.",
    "pt_BR": "Chama 7 raios celestes, causando 6 de dano cada.",
    "ja": "天火を7発落とし、1発につき6ダメージ。",
    "es": "Invoca 7 rayos celestes que hacen 6 de daño cada uno."
  },
  "itemdesc.flux_reserve": {
    "en": "Adds 48 Flow.",
    "pt_BR": "Adiciona 48 de Fluxo.",
    "ja": "フローを48追加する。",
    "es": "Añade 48 de Flujo."
  },
  "itemdesc.arcane_guard": {
    "en": "2.6s invulnerability, full Dash, +1 health and a 10s speed boost.",
    "pt_BR": "2,6s de invulnerabilidade, Dash cheio, +1 de vida e velocidade extra por 10s.",
    "ja": "2.6秒無敵、ダッシュ全回復、体力+1、10秒間速度上昇。",
    "es": "2,6 s de invulnerabilidad, Dash completo, +1 de vida y velocidad extra durante 10 s."
  },
  "item.stored": {
    "en": "%s • STORED IN [%s]",
    "pt_BR": "%s • GUARDADO EM [%s]",
    "ja": "%s • ［%s］に保存",
    "es": "%s • GUARDADO EN [%s]"
  },
  "item.used": {
    "en": "%s • RELEASED",
    "pt_BR": "%s • LIBERADO",
    "ja": "%s • 解放",
    "es": "%s • LIBERADO"
  },
  "item.full": {
    "en": "All 10 item slots are occupied.",
    "pt_BR": "Os 10 espaços de item já estão ocupados.",
    "ja": "10個のアイテム枠がすべて埋まっている。",
    "es": "Los 10 espacios de objetos ya están ocupados."
  },
  "tut.item_heal": {
    "en": "This one heals you. I took a little health away just for the demonstration. Relax, I told you eventually.",
    "pt_BR": "Esse aqui cura. Eu tirei um pouquinho da sua vida só pra demonstração. Relaxa, eu avisei depois, mas avisei.",
    "ja": "これは回復だ。実演のために少しだけ体力を減らしておいた。安心しろ、今ちゃんと説明した。順番はともかくな。",
    "es": "Este cura. Te quité un poco de vida solo para la demostración. Tranquilo, te avisé... después, pero te avisé."
  },
  "tut.item_magnet": {
    "en": "This is the Magnet. Instead of running around collecting XP one orb at a time, it pulls everything to you. Strategic laziness.",
    "pt_BR": "Esse é o Ímã. Em vez de sair catando EXP uma por uma, ele puxa tudo pra você. Preguiça estratégica.",
    "ja": "これは磁石。XPを一個ずつ追いかける代わりに、全部こっちへ引き寄せる。戦略的な手抜きだ。",
    "es": "Este es el Imán. En vez de correr recogiendo EXP una por una, atrae todo hacia ti. Pereza estratégica."
  },
  "tut.item_bomb": {
    "en": "And this is Annihilation. It wipes out regular enemies around you. Officially, it is the I really cannot be bothered right now button.",
    "pt_BR": "E esse é Aniquilação. Ele apaga os inimigos comuns que estiverem por aí. É o botão oficial do “não tô com paciência agora”.",
    "ja": "そしてこれは殲滅。周りの普通の敵をまとめて消す。要するに「今は相手してられない」ボタンだ。",
    "es": "Y esto es Aniquilación. Borra a los enemigos normales que haya por ahí. Es el botón oficial de “ahora mismo no tengo paciencia”."
  },
  "tut.chest_slots": {
    "en": "Your belt has 10 slots: [1] through [9], plus [0]. Press the number to use that item once and free the slot. If you forget what something does, press [I] to open the item descriptions.",
    "pt_BR": "Seu cinto tem 10 espaços: [1] até [9], mais o [0]. Apertou o número, usa o item uma vez e libera o espaço. Se esquecer o que alguma coisa faz, aperta [I] pra abrir as descrições.",
    "ja": "ベルトには10枠ある。［1］から［9］、それと［0］だ。番号を押すと1回使って枠が空く。効果を忘れたら［I］で説明を開ける。",
    "es": "Tu cinturón tiene 10 espacios: del [1] al [9], más el [0]. Pulsas el número, usas el objeto una vez y liberas el espacio. Si olvidas qué hace algo, pulsa [I] para ver las descripciones."
  },
  "tut.dragon_use": {
    "en": "The gold chest gave you Dragon Breath in slot [%s]. Face that group and use it now. This one is much easier to understand when you actually see it.",
    "pt_BR": "O baú dourado te deu Sopro Dracônico no slot [%s]. Vira praquele grupo e usa agora. Esse é bem mais fácil de entender vendo.",
    "ja": "金の宝箱から［%s］に竜の息吹が入った。あの群れの方を向いて使ってみろ。これは見た方が早い。",
    "es": "El cofre dorado te dio Aliento de Dragón en el espacio [%s]. Mira hacia ese grupo y úsalo ahora. Este se entiende mucho mejor viéndolo."
  },
  "tut.boss_intro": {
    "en": "Last thing: as a run goes on, a Boss will show up. It is basically the game asking, alright, does this build actually work?",
    "pt_BR": "Última coisa: conforme a run avança, vai aparecer Boss. É basicamente o jogo perguntando “e aí, essa build presta mesmo?”.",
    "ja": "最後に一つ。ランが進むとボスが出てくる。要するにゲームから「で、そのビルド本当に強いの？」と聞かれる時間だ。",
    "es": "Última cosa: a medida que avanza la run, aparecerá un Boss. Es básicamente el juego preguntando “a ver, ¿esa build funciona de verdad?”."
  },
  "tut.boss_reveal": {
    "en": "And since we are talking about Bosses... later on, one of them is me. Yes. I teach you now and try to beat you up later. Excellent employment contract.",
    "pt_BR": "E já que estamos falando de Boss... mais pra frente, um deles sou eu. Pois é. Eu te ensino agora e tento te bater depois. Contrato ótimo.",
    "ja": "それでボスの話なんだが……そのうち一体は私だ。そう、今は教えて、後で殴りに行く。素晴らしい契約だろ。",
    "es": "Y ya que hablamos de Bosses... más adelante, uno de ellos soy yo. Sí. Te enseño ahora y luego intento golpearte. Excelente contrato laboral."
  },
  "tutorial.task_done": {
    "en": "Good. Got it.",
    "pt_BR": "Boa. Pegou a ideia.",
    "ja": "よし。分かったな。",
    "es": "Bien. Ya lo tienes."
  },
  "tutorial.task_move_progress": {
    "en": "LEFT %s   RIGHT %s   UP %s   DOWN %s",
    "pt_BR": "ESQ %s   DIR %s   CIMA %s   BAIXO %s",
    "ja": "左 %s   右 %s   上 %s   下 %s",
    "es": "IZQ %s   DER %s   ARRIBA %s   ABAJO %s"
  },
  "tutorial.task_heal": {
    "en": "Touch the healing item.",
    "pt_BR": "Encosta no item de Cura.",
    "ja": "回復アイテムに触れろ。",
    "es": "Toca el objeto de curación."
  },
  "tutorial.task_magnet": {
    "en": "Touch the Magnet and watch the XP come to you.",
    "pt_BR": "Encosta no Ímã e vê a EXP vir até você.",
    "ja": "磁石に触れて、XPが集まるのを見ろ。",
    "es": "Toca el Imán y mira cómo la EXP viene hacia ti."
  },
  "tutorial.task_bomb": {
    "en": "Grab Annihilation and clear the group.",
    "pt_BR": "Pega Aniquilação e limpa o grupo.",
    "ja": "殲滅を取って群れを消せ。",
    "es": "Recoge Aniquilación y limpia el grupo."
  },
  "tutorial.task_dragon": {
    "en": "Face the group and use Dragon Breath with [%s].",
    "pt_BR": "Mira pro grupo e usa Sopro Dracônico com [%s].",
    "ja": "群れを向いて［%s］で竜の息吹を使え。",
    "es": "Mira al grupo y usa Aliento de Dragón con [%s]."
  },
  "tutorial.task_samurai": {
    "en": "Get close enough for the Samurai to attack.",
    "pt_BR": "Chega perto o bastante pro Samurai atacar.",
    "ja": "侍が攻撃できる距離まで近づけ。",
    "es": "Acércate lo suficiente para que Samurai ataque."
  },
  "tutorial.task_pickups": {
    "en": "Try the three ground items.",
    "pt_BR": "Testa os três itens do chão.",
    "ja": "地面の3つのアイテムを試せ。",
    "es": "Prueba los tres objetos del suelo."
  },
  "tutorial.task_tab": {
    "en": "Hold [TAB] and check your Runes + items.",
    "pt_BR": "Segura [TAB] e confere suas Runas + itens.",
    "ja": "［TAB］を長押ししてルーン＋アイテムを確認しろ。",
    "es": "Mantén [TAB] y revisa tus Runas + objetos."
  },
  "tutorial.task_move": {
    "en": "Move a little in every direction.",
    "pt_BR": "Anda um pouco em cada direção.",
    "ja": "上下左右に少しずつ動け。",
    "es": "Muévete un poco en cada dirección."
  },
  "tutorial.task_kill": {
    "en": "Keep some distance and let Orbital attack.",
    "pt_BR": "Fica a uma distância boa e deixa o Orbital atacar.",
    "ja": "少し距離を取り、オービタルに攻撃させろ。",
    "es": "Mantén una buena distancia y deja que Orbital ataque."
  },
  "tutorial.task_aim_toggle": {
    "en": "Press [R] to switch to MOUSE / MANUAL aim.",
    "pt_BR": "Aperta [R] para trocar pra mira MOUSE / MANUAL.",
    "ja": "［R］を押してマウス / 手動照準に切り替えろ。",
    "es": "Pulsa [R] para cambiar al apuntado RATÓN / MANUAL."
  },
  "tutorial.task_dash": {
    "en": "Use DASH [SHIFT].",
    "pt_BR": "Usa o DASH [SHIFT].",
    "ja": "DASH［SHIFT］を使え。",
    "es": "Usa DASH [SHIFT]."
  },
  "tutorial.task_xp": {
    "en": "Collect the scattered XP orbs.",
    "pt_BR": "Pega os orbes de EXP espalhados.",
    "ja": "散らばったXPオーブを拾え。",
    "es": "Recoge los orbes de EXP dispersos."
  },
  "tutorial.task_rune": {
    "en": "Choose a Rune.",
    "pt_BR": "Escolhe uma Runa.",
    "ja": "ルーンを1つ選べ。",
    "es": "Elige una Runa."
  },
  "tutorial.task_vase": {
    "en": "Walk up to the vase and press [E].",
    "pt_BR": "Chega perto do vaso e aperta [E].",
    "ja": "壺に近づいて［E］を押せ。",
    "es": "Acércate al jarrón y pulsa [E]."
  },
  "tutorial.task_chest": {
    "en": "Open both chests with [E].",
    "pt_BR": "Abre os dois baús com [E].",
    "ja": "2つの宝箱を［E］で開け。",
    "es": "Abre los dos cofres con [E]."
  },
  "tutorial.task_flux": {
    "en": "Keep attacking until Flow reaches 100% and Arcane Surge activates.",
    "pt_BR": "Continua atacando até o Fluxo chegar a 100% e ativar o Surto Arcano.",
    "ja": "フローが100%になって秘術サージが発動するまで攻撃しろ。",
    "es": "Sigue atacando hasta que el Flujo llegue al 100% y se active la Oleada Arcana."
  },
  "tutorial.task_elite": {
    "en": "Defeat the Elite.",
    "pt_BR": "Derrota o Elite.",
    "ja": "エリートを倒せ。",
    "es": "Derrota al Élite."
  },
  "tutorial.stay_near": {
    "en": "Hey, come back. Class is not over yet.",
    "pt_BR": "Ei, volta aqui. A aula nem acabou ainda.",
    "ja": "おい、戻ってこい。まだ授業は終わってないぞ。",
    "es": "Eh, vuelve. La clase todavía no terminó."
  },
  "tutorial.complete": {
    "en": "TUTORIAL COMPLETE",
    "pt_BR": "TUTORIAL CONCLUÍDO",
    "ja": "チュートリアル完了",
    "es": "TUTORIAL COMPLETADO"
  },
  "cat.WEAPON": {
    "en": "WEAPON",
    "pt_BR": "ARMA",
    "ja": "武器",
    "es": "ARMA"
  },
  "cat.DAMAGE": {
    "en": "DAMAGE",
    "pt_BR": "DANO",
    "ja": "ダメージ",
    "es": "DAÑO"
  },
  "cat.MOVEMENT": {
    "en": "MOVEMENT",
    "pt_BR": "MOVIMENTO",
    "ja": "移動",
    "es": "MOVIMIENTO"
  },
  "cat.SURVIVAL": {
    "en": "SURVIVAL",
    "pt_BR": "SOBREVIVÊNCIA",
    "ja": "生存",
    "es": "SUPERVIVENCIA"
  },
  "cat.UTILITY": {
    "en": "UTILITY",
    "pt_BR": "UTILIDADE",
    "ja": "ユーティリティ",
    "es": "UTILIDAD"
  },
  "cat.CONTROL": {
    "en": "CONTROL",
    "pt_BR": "CONTROLE",
    "ja": "制御",
    "es": "CONTROL"
  },
  "cat.ARCANE": {
    "en": "ARCANE",
    "pt_BR": "ARCANO",
    "ja": "秘術",
    "es": "ARCANO"
  },
  "rstat.damage": {
    "en": "Damage",
    "pt_BR": "Dano",
    "ja": "ダメージ",
    "es": "Daño"
  },
  "rstat.rate": {
    "en": "Attack rate",
    "pt_BR": "Cadência",
    "ja": "攻撃速度",
    "es": "Cadencia"
  },
  "rstat.move": {
    "en": "Movement",
    "pt_BR": "Movimento",
    "ja": "移動",
    "es": "Movimiento"
  },
  "rstat.health": {
    "en": "Max health",
    "pt_BR": "Vida máxima",
    "ja": "最大HP",
    "es": "Vida máxima"
  },
  "rstat.pickup": {
    "en": "Pickup",
    "pt_BR": "Coleta",
    "ja": "回収範囲",
    "es": "Recogida"
  },
  "rstat.xp": {
    "en": "Experience",
    "pt_BR": "Experiência",
    "ja": "経験値",
    "es": "Experiencia"
  },
  "rstat.dash_recharge": {
    "en": "Dash recharge",
    "pt_BR": "Recarga do dash",
    "ja": "ダッシュ再充填",
    "es": "Recarga del dash"
  },
  "rstat.gold_chance": {
    "en": "Gold Orb chance",
    "pt_BR": "Chance de Orbe Dourado",
    "ja": "金オーブ確率",
    "es": "Prob. Orbe Dorado"
  },
  "rstat.elite_damage": {
    "en": "Elite/Boss damage",
    "pt_BR": "Dano vs Elite/Chefe",
    "ja": "対エリート/ボス",
    "es": "Daño vs Élite/Jefe"
  },
  "rstat.stones": {
    "en": "Stones",
    "pt_BR": "Pedras",
    "ja": "石",
    "es": "Piedras"
  },
  "rstat.reload": {
    "en": "Reload",
    "pt_BR": "Recarga",
    "ja": "再装填",
    "es": "Recarga"
  },
  "rstat.area": {
    "en": "Area",
    "pt_BR": "Área",
    "ja": "範囲",
    "es": "Área"
  },
  "rstat.duration": {
    "en": "Duration",
    "pt_BR": "Duração",
    "ja": "持続",
    "es": "Duración"
  },
  "rstat.charges": {
    "en": "Charges",
    "pt_BR": "Cargas",
    "ja": "チャージ",
    "es": "Cargas"
  },
  "rstat.rule": {
    "en": "RULE",
    "pt_BR": "REGRA",
    "ja": "ルール",
    "es": "REGLA"
  },
  "rstat.dash_speed": {
    "en": "Dash speed",
    "pt_BR": "Velocidade do dash",
    "ja": "ダッシュ速度",
    "es": "Velocidad de dash"
  },
  "rstat.flow_gain": {
    "en": "Flow gain",
    "pt_BR": "Ganho de Fluxo",
    "ja": "フロー獲得",
    "es": "Ganancia de Flujo"
  },
  "rstat.luck": {
    "en": "Luck",
    "pt_BR": "Sorte",
    "ja": "運",
    "es": "Suerte"
  },
  "menu.build": {"en":"BUILD","pt_BR":"BUILD","ja":"ビルド","es":"BUILD"},
  "menu.main": {
    "en": "MENU",
    "pt_BR": "MENU",
    "ja": "メニュー",
    "es": "MENÚ"
  },
  "stats.run_line": {
    "en": "%s • level %d • %s • %d kills • %d elites",
    "pt_BR": "%s • nível %d • %s • %d abates • %d elites",
    "ja": "%s • レベル %d • %s • %d 撃破 • %d エリート",
    "es": "%s • nivel %d • %s • %d bajas • %d élites"
  },
  "stats.melee_range": {
    "en": "%d melee",
    "pt_BR": "%d corpo a corpo",
    "ja": "%d 近接",
    "es": "%d cuerpo a cuerpo"
  },
  "stats.projectile_speed": {
    "en": "projectile %d",
    "pt_BR": "projétil %d",
    "ja": "投射速度 %d",
    "es": "proyectil %d"
  },
  "stats.stones": {
    "en": "%d stones",
    "pt_BR": "%d pedras",
    "ja": "%d 石",
    "es": "%d piedras"
  },
  "stats.arc": {
    "en": "arc %.0f°",
    "pt_BR": "arco %.0f°",
    "ja": "弧 %.0f°",
    "es": "arco %.0f°"
  },
  "stats.width_duration": {
    "en": "%d width • %.1fs",
    "pt_BR": "%d largura • %.1fs",
    "ja": "幅 %d • %.1f秒",
    "es": "%d ancho • %.1fs"
  },
  "boss.name": {
    "en": "DISTANT WATCHER",
    "pt_BR": "OLHEIRO DISTANTE",
    "ja": "遠見の監視者",
    "es": "VIGÍA DISTANTE"
  },
  "boss.phase": {
    "en": "PHASE %s • %s",
    "pt_BR": "FASE %s • %s",
    "ja": "フェーズ %s • %s",
    "es": "FASE %s • %s"
  },
  "boss.state.leap_windup": {"en":"LEAP","pt_BR":"SALTO","ja":"跳躍","es":"SALTO"},
  "boss.state.leap": {"en":"CHARGE","pt_BR":"INVESTIDA","ja":"突進","es":"EMBESTIDA"},
  "boss.state.parry": {"en":"COUNTERSPELL","pt_BR":"CONTRA-FEITIÇO","ja":"反呪文","es":"CONTRAHECHIZO"},
  "boss.state.cage_windup": {"en":"CAGE","pt_BR":"JAULA","ja":"檻","es":"JAULA"},
  "boss.state.shockwave_windup": {"en":"PULSE","pt_BR":"PULSO","ja":"衝撃波","es":"PULSO"},
  "boss.state.mark_windup": {"en":"MARK","pt_BR":"MARCA","ja":"印","es":"MARCA"},
  "boss.state.fan_windup": {"en":"VOLLEY","pt_BR":"SARAIVADA","ja":"連射","es":"SALVA"},
  "boss.state.lanes_windup": {"en":"BONE LANES","pt_BR":"LINHAS ÓSSEAS","ja":"骨の軌道","es":"LÍNEAS ÓSEAS"},
  "boss.state.observe": {"en":"WATCHING","pt_BR":"OBSERVANDO","ja":"観察中","es":"OBSERVANDO"},
  "player.surge_banner": {
    "en": "ARCANE SURGE  •  INFINITE CHARGES",
    "pt_BR": "SURTO ARCANO  •  CARGAS INFINITAS",
    "ja": "秘術サージ • チャージ無限",
    "es": "OLEADA ARCANA • CARGAS INFINITAS"
  }
}

var current_language: String = "en"

func _ready() -> void:
	load_language()
	TranslationServer.set_locale(current_language)

func load_language() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		var saved: String = str(cfg.get_value("language","code","en"))
		if LANGUAGES.has(saved):
			current_language = saved

func has_saved_language() -> bool:
	var cfg := ConfigFile.new()
	if cfg.load("user://settings.cfg") != OK:
		return false
	return cfg.has_section_key("language","code") and LANGUAGES.has(str(cfg.get_value("language","code","")))

func set_language(code: String) -> void:
	if not LANGUAGES.has(code):
		return
	var changed: bool = current_language != code
	current_language = code
	TranslationServer.set_locale(current_language)
	var cfg := ConfigFile.new()
	cfg.load("user://settings.cfg")
	cfg.set_value("language","code",current_language)
	cfg.save("user://settings.cfg")
	if changed:
		language_changed.emit(current_language)

func get_language() -> String:
	return current_language

func t(key: String) -> String:
	if not TEXT.has(key):
		return key
	var entry: Dictionary = TEXT[key]
	if entry.has(current_language):
		return str(entry[current_language])
	return str(entry.get("en",key))

func f(key: String,args: Array) -> String:
	# Missing formatted keys used to fall back to the raw key and then attempt
	# `% args`, which can flood the debugger every frame. Fail safely instead.
	if not TEXT.has(key):
		return key
	var value: String = t(key)
	if args.is_empty():
		return value
	if value.find("%") == -1:
		return value
	return value % args

func pick(values: Dictionary) -> String:
	if values.has(current_language):
		return str(values[current_language])
	return str(values.get("en",""))

func language_label(code: String) -> String:
	match code:
		"pt_BR": return "PT-BR"
		"ja": return "日本語"
		"es": return "ESPAÑOL"
		_: return "ENGLISH"
