# BUILD 0711 — Enemy visual rework + light Flux tuning

## Enemy visual changes
- Skeleton archer: layered waist cloth + mantle, quiver, visible arrows, bone hands, smooth skull tracking, real bow draw pose and release/recovery body language.
- Stalker: rebuilt silhouette with articulated wings, membrane ribs, horned head, tracking eyes, tail, claws, windup compression and stretched rush pose.
- Brute: stronger hunched armor silhouette, shoulder plates, chest straps, horned skull, wrapped fists, heavy walk, crouched windup and forward charge pose.
- Shaman: layered robe, front panel, hood/collar, sleeves, bone hands, crooked staff, skull lantern and animated ritual hand/runes.
- Warder: clearer knight silhouette, helmet, layered chest plate, actual spear grip, shield brace, shield emblem and attack/rush posing.
- Existing spider style preserved. Classic slime style preserved.
- All normal mobs reduced slightly in world scale without making them tiny.

## Performance
- Keeps the 0710 visual LOD/redraw throttling; the added details are concentrated in near-player detail levels.

## Flux
Very small difficulty easing:
- normal kill Flux: 0.65 -> 0.70
- idle grace before decay: 1.90s -> 2.15s
- idle decay: 5.5/s -> 5.1/s

## Files changed
- enemy.gd
- player.gd
- endless_main.gd
