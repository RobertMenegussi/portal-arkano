extends Control

const EndlessCatalog = preload("res://endless_catalog.gd")

var player
var controller
var t: float = 0.0

func configure(target, owner_controller) -> void:
	player = target
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if not is_instance_valid(player):
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var ink: Color = Color("#f2efe5")
	var faint: Color = Color(0.92, 0.91, 0.86, 0.52)
	var panel: Rect2 = Rect2(Vector2(40, 24), Vector2(880, 492))
	draw_rect(panel, Color(0.028, 0.034, 0.033, 0.962), true)
	for i in range(3):
		draw_rect(panel.grow(-float(i) * 2.0), Color(1, 1, 1, 0.046 - float(i) * 0.011), false, 1.0)
	for i in range(5):
		var a: float = t * 0.18 + float(i) * TAU / 5.0
		draw_circle(Vector2(panel.end.x - 44, panel.position.y + 34) + Vector2(cos(a), sin(a)) * 12.0, 1.6, Color(0.92, 0.91, 0.86, 0.14))
	draw_string(font, panel.position + Vector2(24, 30), Loc.t("stats.title"), HORIZONTAL_ALIGNMENT_LEFT, 400, 21, ink)
	var run_line: String = Loc.f("stats.run_line", [_class_name(), _level(), _time_text(), _kills(), _elite_kills()])
	draw_string(font, panel.position + Vector2(24, 50), run_line, HORIZONTAL_ALIGNMENT_LEFT, 780, 10, faint)
	_draw_card(font, Rect2(panel.position + Vector2(18, 68), Vector2(264, 126)), Loc.t("stats.summary"), ink, faint, _summary_rows())
	_draw_card(font, Rect2(panel.position + Vector2(300, 68), Vector2(270, 184)), Loc.t("stats.combat"), ink, faint, _combat_rows())
	_draw_card(font, Rect2(panel.position + Vector2(588, 68), Vector2(272, 184)), Loc.t("stats.survival"), ink, faint, _utility_rows())
	_draw_card(font, Rect2(panel.position + Vector2(18, 212), Vector2(264, 126)), Loc.t("stats.state"), ink, faint, _state_rows())
	_draw_traits_card(font, Rect2(panel.position + Vector2(18, 352), Vector2(842, 112)), ink, faint)
	_draw_card(font, Rect2(panel.position + Vector2(300, 268), Vector2(560, 70)), Loc.t("stats.quick"), ink, faint, _quick_rows(), true)
	draw_string(font, Vector2(panel.position.x + 20, panel.end.y - 10), Loc.t("stats.footer"), HORIZONTAL_ALIGNMENT_LEFT, 780, 9, faint)

func _draw_card(font, rect: Rect2, title: String, ink: Color, faint: Color, rows: Array, compact: bool = false) -> void:
	draw_rect(rect, Color(1, 1, 1, 0.03), true)
	draw_rect(rect, Color(1, 1, 1, 0.048), false, 1.0)
	draw_string(font, rect.position + Vector2(14, 22), title, HORIZONTAL_ALIGNMENT_LEFT, 220, 12, ink)
	draw_line(rect.position + Vector2(14, 30), Vector2(rect.end.x - 14, rect.position.y + 30), Color(1, 1, 1, 0.065), 1.0)
	var y: float = rect.position.y + 48.0
	for row_value in rows:
		var row: Array = row_value
		_draw_stat_row(font, rect.position.x + 14.0, y, str(row[0]), str(row[1]), ink, faint, rect.size.x - 28.0)
		y += 18.0 if compact else 20.0
		if y > rect.end.y - 8.0:
			break

func _draw_traits_card(font, rect: Rect2, ink: Color, faint: Color) -> void:
	draw_rect(rect, Color(1, 1, 1, 0.03), true)
	draw_rect(rect, Color(1, 1, 1, 0.048), false, 1.0)
	var ids: Array = []
	if is_instance_valid(controller):
		ids = controller.acquired_traits
	var count_value: int = ids.size()
	draw_string(font, rect.position + Vector2(14, 22), Loc.t("stats.runes") + "  •  %d" % count_value, HORIZONTAL_ALIGNMENT_LEFT, 280, 12, ink)
	draw_line(rect.position + Vector2(14, 30), Vector2(rect.end.x - 14, rect.position.y + 30), Color(1, 1, 1, 0.065), 1.0)
	if count_value == 0:
		draw_string(font, rect.position + Vector2(14, 58), Loc.t("stats.no_runes"), HORIZONTAL_ALIGNMENT_LEFT, 420, 10, faint)
		return
	var shown: int = mini(8, count_value)
	var start_index: int = maxi(0, count_value - shown)
	var chip_w: float = 401.0
	var chip_h: float = 32.0
	for idx in range(shown):
		var trait_id: String = str(ids[start_index + idx])
		var col: int = idx % 2
		var row: int = int(float(idx) / 2.0)
		var chip_rect: Rect2 = Rect2(rect.position + Vector2(14 + col * 413, 40 + row * 36), Vector2(chip_w, chip_h))
		_draw_trait_chip(font, chip_rect, trait_id, ink, faint)

func _draw_trait_chip(font, rect: Rect2, trait_id: String, ink: Color, faint: Color) -> void:
	draw_rect(rect, Color(0, 0, 0, 0.14), true)
	draw_rect(rect, Color(1, 1, 1, 0.045), false, 1.0)
	var category: String = EndlessCatalog.get_category_label(EndlessCatalog.get_category(trait_id))
	var title: String = EndlessCatalog.get_trait_name(trait_id)
	var summary: String = _trait_summary(trait_id)
	var icon_center: Vector2 = rect.position + Vector2(17, 16)
	draw_circle(icon_center, 10.0, Color(1, 1, 1, 0.05))
	_draw_chip_icon(icon_center, trait_id, ink)
	draw_string(font, rect.position + Vector2(34, 14), title, HORIZONTAL_ALIGNMENT_LEFT, 190, 10, ink)
	draw_string(font, rect.position + Vector2(34, 26), category, HORIZONTAL_ALIGNMENT_LEFT, 110, 8, Color(0.78, 0.82, 0.88, 0.55))
	draw_string(font, rect.position + Vector2(rect.size.x * 0.42, 20), summary, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x * 0.54, 9, faint)

func _draw_chip_icon(center: Vector2, trait_id: String, color: Color) -> void:
	var idx: int = 0
	for char_i in range(trait_id.length()):
		idx += trait_id.unicode_at(char_i) * (char_i + 1)
	match absi(idx) % 5:
		0:
			draw_line(center + Vector2(-5, 0), center + Vector2(5, 0), color, 1.5)
			draw_circle(center + Vector2(4, 0), 1.9, color)
		1:
			var poly := PackedVector2Array([center + Vector2(0, -4), center + Vector2(3.0, 0), center + Vector2(0, 4), center + Vector2(-3.0, 0)])
			draw_colored_polygon(poly, color)
		2:
			draw_arc(center, 5.0, 0.0, TAU, 16, color, 1.1)
			draw_circle(center, 1.7, color)
		3:
			draw_polyline(PackedVector2Array([center + Vector2(-4, 3), center + Vector2(-1, -2), center + Vector2(1, 1), center + Vector2(4, -4)]), color, 1.4)
		_:
			draw_line(center + Vector2(-4, -3), center + Vector2(4, 3), color, 1.2)
			draw_line(center + Vector2(-4, 3), center + Vector2(4, -3), color, 1.2)

func _summary_rows() -> Array:
	return [
		[Loc.t("stats.label.class"), _class_name()],
		[Loc.t("stats.label.health"), "%d / %d" % [int(player.health), int(player.max_health)]],
		[Loc.t("stats.label.run_time"), _time_text()],
		[Loc.t("stats.label.active_runes"), str(_trait_count())],
		[Loc.t("stats.label.boss"), _boss_status()],
		[Loc.t("stats.label.director"), Loc.f("stats.enemy_scene", [_enemy_count()])]
	]

func _combat_rows() -> Array:
	var damage: int = int(player.orbit_damage)
	var fire_rate: float = 1.0 / maxf(0.001, float(player.shot_cooldown))
	var range_text: String = "—"
	var area_text: String = "—"
	match str(player.mage_type):
		"samurai":
			damage = int(player.samurai_damage)
			fire_rate = 1.0 / maxf(0.001, float(player.shot_cooldown))
			range_text = Loc.f("stats.melee_range", [int(player.samurai_range)])
			area_text = Loc.f("stats.arc", [rad_to_deg(float(player.samurai_arc))])
		"storm":
			damage = int(player.storm_damage)
			fire_rate = 1.0 / maxf(0.001, float(player.storm_charge_duration) + 0.78 * float(player.storm_recovery_multiplier))
			range_text = "%d" % int(player.storm_range)
			area_text = "%d" % int(player.storm_radius)
		"rift":
			damage = int(player.rift_damage)
			fire_rate = 1.0 / maxf(0.001, float(player.shot_cooldown))
			range_text = "%d" % int(player.rift_wave_range)
			area_text = Loc.f("stats.width_duration", [int(player.rift_radius), float(player.rift_scar_duration)])
		_:
			range_text = Loc.f("stats.projectile_speed", [int(player.orbit_projectile_speed)])
			area_text = Loc.f("stats.stones", [int(player.max_magic_stones)])
	return [
		[Loc.t("stats.label.base_damage"), str(damage)],
		[Loc.t("stats.label.attack_rate"), "%.2f/s" % fire_rate],
		[Loc.t("stats.label.accuracy"), "%.2f°" % rad_to_deg(float(player.accuracy_spread))],
		[Loc.t("stats.label.critical"), "%d%%" % int(float(player.endless_crit_chance) * 100.0)],
		[Loc.t("stats.label.extra_attacks"), str(int(player.endless_extra_casts))],
		[Loc.t("stats.label.elite_damage"), "+%d%%" % int(float(player.endless_elite_damage_bonus) * 100.0)],
		[Loc.t("stats.label.range"), range_text],
		[Loc.t("stats.label.area___resource"), area_text]
	]

func _utility_rows() -> Array:
	return [
		[Loc.t("stats.label.movement"), "%d" % int(player.move_speed)],
		[Loc.t("stats.label.dash"), "%d/%d • %.2fs" % [int(player.dash_charges), int(player.max_dash_charges), float(player.dash_recharge)]],
		[Loc.t("stats.label.regen"), "%.2f HP/s" % float(player.endless_regen_per_second)],
		[Loc.t("stats.label.block"), "%d%%" % int(float(player.endless_guard_chance) * 100.0)],
		[Loc.t("stats.label.xp"), "x%.2f" % float(player.endless_xp_gain_mul)],
		[Loc.t("stats.label.pickup"), "x%.2f" % float(player.endless_pickup_radius_mul)],
		[Loc.t("stats.label.luck"), "+%d%%" % int(float(player.endless_luck) * 100.0)],
		[Loc.t("stats.label.gold_orb"), "+%d%%" % int(float(player.endless_rare_xp_chance_add) * 100.0)]
	]

func _state_rows() -> Array:
	return [
		[Loc.t("stats.label.flow"), _flux_status()],
		[Loc.t("stats.label.flow_recharge"), "%.1fs" % float(player.flux_recharge_delay)],
		[Loc.t("stats.label.flow_activations"), str(int(player.flux_activation_count))],
		[Loc.t("stats.label.auto_targeting"), _target_mode_text()],
		[Loc.t("stats.label.current_stones"), str(int(player.magic_stones)) if str(player.mage_type) == "orbit" else "—"],
		[Loc.t("stats.label.rift_charges"), str(int(player.rift_charges)) if str(player.mage_type) == "rift" else "—"]
	]

func _quick_rows() -> Array:
	return [
		[Loc.t("stats.label.current_xp"), "%d / %d" % [int(controller.xp), int(controller.xp_needed)] if is_instance_valid(controller) else "—"],
		[Loc.t("stats.label.kills___elite"), "%d / %d" % [_kills(), _elite_kills()]],
		[Loc.t("stats.label.map"), Loc.t("maps.silent_fields")],
		[Loc.t("stats.label.objective"), Loc.t("stats.label.survive_and_scale_the_build")]
	]

func _draw_stat_row(font, x: float, y: float, label: String, value: String, ink: Color, faint: Color, width: float = 450.0) -> void:
	draw_string(font, Vector2(x, y), label, HORIZONTAL_ALIGNMENT_LEFT, width * 0.54, 10, faint)
	draw_string(font, Vector2(x + width * 0.55, y), value, HORIZONTAL_ALIGNMENT_RIGHT, width * 0.42, 11, ink)

func _trait_summary(trait_id: String) -> String:
	var preview: Array = EndlessCatalog.get_stat_preview(trait_id, player)
	if preview.is_empty():
		return EndlessCatalog.get_description(trait_id, str(player.mage_type))
	var parts: Array[String] = []
	for entry in preview:
		if typeof(entry) != TYPE_DICTIONARY:
			continue
		var label: String = str(entry.get("label", ""))
		var delta: String = str(entry.get("delta", ""))
		var pct: String = str(entry.get("pct", ""))
		if label == Loc.t("rstat.rule"):
			parts.append(delta)
		else:
			parts.append(label + " " + delta + " " + pct)
		if parts.size() >= 1:
			break
	return parts[0].strip_edges() if not parts.is_empty() else EndlessCatalog.get_description(trait_id, str(player.mage_type))

func _trait_count() -> int:
	return int(controller.acquired_traits.size()) if is_instance_valid(controller) else 0

func _enemy_count() -> int:
	return get_tree().get_nodes_in_group("enemy").size()

func _boss_status() -> String:
	if not is_instance_valid(controller):
		return "—"
	if bool(controller.boss_spawned):
		return Loc.t("stats.boss_active")
	var remaining: float = maxf(0.0, float(controller.boss_spawn_time) - float(controller.elapsed))
	return Loc.f("stats.boss_in", [int(ceil(remaining))])

func _flux_status() -> String:
	if bool(player.flux_active):
		return Loc.f("stats.flow_active", [float(player.flux_timer)])
	if float(player.flux_recharge_timer) > 0.0:
		return Loc.f("stats.flow_recharging", [float(player.flux_recharge_timer)])
	return "%.0f / 100" % float(player.flux)

func _target_mode_text() -> String:
	var mode: String = player._get_attack_target_mode() if player.has_method("_get_attack_target_mode") else "nearest"
	match mode:
		"mouse": return Loc.t("stats.target_mouse")
		"lowest": return Loc.t("stats.target_low")
		"max_health": return Loc.t("stats.target_max")
		_: return Loc.t("stats.target_near")

func _class_name() -> String:
	match str(player.mage_type):
		"storm": return Loc.t("class.storm")
		"rift": return Loc.t("class.rift")
		"samurai": return Loc.t("class.samurai")
		_: return Loc.t("class.orbit")

func _level() -> int:
	return int(controller.level) if is_instance_valid(controller) else 1

func _kills() -> int:
	return int(controller.kill_count) if is_instance_valid(controller) else 0

func _elite_kills() -> int:
	return int(controller.elite_kills) if is_instance_valid(controller) else 0

func _time_text() -> String:
	if not is_instance_valid(controller):
		return "00:00"
	var total: int = maxi(0, int(controller.elapsed))
	var mins: int = int(total / 60)
	var secs: int = total % 60
	return "%02d:%02d" % [mins, secs]
