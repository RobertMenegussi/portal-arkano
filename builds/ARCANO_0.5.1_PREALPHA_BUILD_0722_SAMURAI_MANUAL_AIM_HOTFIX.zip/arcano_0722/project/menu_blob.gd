extends Control

signal clicked

var t: float = 0.0
var hover_t: float = 0.0
var click_t: float = 0.0
var blink_t: float = 0.0
var bubble_text: String = ""
var bubble_timer: float = 0.0
var click_count: int = 0
var frame_id: int = 0
var lines: Array[String] = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		click_count += 1
		click_t = 1.0
		blink_t = 0.11
		bubble_timer = 0.0
		bubble_text = ""
		clicked.emit()
		queue_redraw()
		accept_event()

func _process(delta: float) -> void:
	t += delta
	frame_id += 1
	var hovered: bool = Rect2(Vector2.ZERO, size).has_point(get_local_mouse_position())
	hover_t = move_toward(hover_t, 1.0 if hovered else 0.0, delta * 5.5)
	click_t = move_toward(click_t, 0.0, delta * 4.4)
	blink_t = maxf(0.0, blink_t - delta)
	bubble_timer = maxf(0.0, bubble_timer - delta)
	if randi() % 190 == 0:
		blink_t = 0.09
	queue_redraw()

func _draw_menu_stones(c: Vector2,paper: Color,back_pass: bool) -> void:
	var orbit_expand: float = ease(hover_t,0.75)
	for i in range(6):
		var a: float = -0.2 + float(i) * TAU / 6.0 + t * 0.52 + sin(t*0.8+float(i))*0.03
		var is_back: bool = sin(a) < 0.0
		if is_back != back_pass:
			continue
		var rr: float = 104.0 + sin(t*2.0+float(i))*4.0 + orbit_expand*26.0
		var stone: Vector2 = c + Vector2(cos(a)*rr, sin(a)*(34.0+orbit_expand*12.0) - 15.0)
		var depth_scale: float = 0.82 if is_back else 1.0
		var stone_alpha: float = 0.66 if is_back else 1.0
		var stone_color: Color = Color(paper.r,paper.g,paper.b,stone_alpha)
		_draw_diamond(stone,(4.5+sin(t*4.0+float(i))*0.40)*(1.0+orbit_expand*0.45)*depth_scale,stone_color)
		draw_arc(stone,(7.0+orbit_expand*1.4)*depth_scale,0.0,TAU,14,Color(0.08,0.08,0.08,(0.13 if is_back else 0.22)+orbit_expand*0.08),1.0)
		if hover_t > 0.02:
			var dir: Vector2 = (stone-c).normalized()
			draw_line(stone-dir*(8.0+orbit_expand*8.0),stone-dir*2.0,Color(0.08,0.08,0.08,(0.035 if is_back else 0.05)+orbit_expand*0.07),1.1)

func _draw() -> void:
	var c: Vector2 = Vector2(size.x * 0.5, size.y * 0.61)
	var mouse: Vector2 = get_local_mouse_position()
	var look: Vector2 = mouse - (c + Vector2(0,-34))
	if look.length_squared() > 0.001:
		look = look.normalized()
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var bob: float = sin(t * 2.35) * (1.8 + hover_t * 1.1)
	var recoil: float = sin(click_t * PI) * 14.0
	var tilt: float = sin(t * 0.75) * 1.6 + recoil * 0.55

	# ground shadow
	_draw_oval(c + Vector2(0,50), Vector2(42.0 + hover_t*3.0,9.0), Color(0.08,0.08,0.08,0.07))
	_draw_oval(c + Vector2(0,51), Vector2(31.0,6.0), Color(0.08,0.08,0.08,0.045))
	_draw_menu_stones(c,paper,true)

	# readable separated feet
	draw_line(c + Vector2(-8,20+bob), c + Vector2(-10-recoil*0.15,40), ink, 3.1)
	draw_line(c + Vector2(8,20+bob), c + Vector2(10+recoil*0.15,40), ink, 3.1)
	draw_line(c + Vector2(-15-recoil*0.15,40), c + Vector2(-5-recoil*0.15,40), ink, 2.3)
	draw_line(c + Vector2(5+recoil*0.15,40), c + Vector2(15+recoil*0.15,40), ink, 2.3)

	# reworked Orbital silhouette used by the class art
	var torso_shift: Vector2 = Vector2(sin(t * 1.1) * 0.8, 0.0)
	var robe: PackedVector2Array = PackedVector2Array([
		c + Vector2(-18,-6+bob), c + Vector2(18,-6+bob), c + Vector2(18,6+bob), c + Vector2(26,34+bob),
		c + Vector2(12,40+bob), c + Vector2(0,46+bob), c + Vector2(-12,40+bob), c + Vector2(-26,34+bob), c + Vector2(-18,6+bob)
	])
	draw_colored_polygon(robe, ink)
	var mantle: PackedVector2Array = PackedVector2Array([
		c + Vector2(-24,-9+bob), c + Vector2(24,-9+bob), c + Vector2(18,2+bob), c + Vector2(8,7+bob),
		c + Vector2(0,9+bob), c + Vector2(-8,7+bob), c + Vector2(-18,2+bob)
	])
	draw_colored_polygon(mantle, Color(0.07,0.07,0.07,0.97))
	var inner_panel: PackedVector2Array = PackedVector2Array([
		c + Vector2(-7,-1+bob), c + Vector2(7,-1+bob), c + Vector2(8,28+bob), c + Vector2(0,37+bob), c + Vector2(-8,28+bob)
	])
	draw_colored_polygon(inner_panel, Color(1.0,1.0,1.0,0.055))
	draw_line(c + Vector2(-16,12+bob), c + Vector2(16,12+bob), Color(1.0,1.0,1.0,0.10), 1.4)
	draw_line(c + Vector2(0,-2+bob), c + Vector2(0,38+bob), Color(1.0,1.0,1.0,0.10), 1.0)
	_draw_diamond(c + Vector2(0,14+bob), 4.0, paper)
	# arms + casting focus
	var arm_l: Vector2 = c + Vector2(-32-hover_t*3.0, 4+bob-recoil*0.20) + torso_shift
	var arm_r: Vector2 = c + Vector2(28+hover_t*4.0, 0+bob+recoil*0.18) + torso_shift
	draw_line(c + Vector2(-15,-2+bob) + torso_shift, arm_l, ink, 3.0)
	draw_line(c + Vector2(15,-2+bob) + torso_shift, arm_r, ink, 3.0)
	_draw_oval(arm_l,Vector2(4.4,3.0),ink)
	_draw_oval(arm_r,Vector2(4.4,3.0),ink)
	var focus: Vector2 = arm_r + Vector2(11.0 + sin(t*3.2)*2.0, -9.0 + cos(t*4.0)*1.4)
	draw_line(arm_r, focus, Color(0.08,0.08,0.08,0.30), 1.2)
	_draw_diamond(focus, 3.0 + hover_t*0.7, Color(1,1,1,0.42))
	# head + hat closer to the in-game rework
	var head: Vector2 = c + Vector2(0,-44+bob-recoil*0.08) + torso_shift
	_draw_oval(head, Vector2(13.8 + hover_t*0.4, 15.2), ink)
	var brim: PackedVector2Array = PackedVector2Array([
		head + Vector2(-30,-9), head + Vector2(30,-9), head + Vector2(19,-2), head + Vector2(-19,-2)
	])
	draw_colored_polygon(brim,ink)
	var hat: PackedVector2Array = PackedVector2Array([
		head + Vector2(-15,-8), head + Vector2(15,-8), head + Vector2(12,-24),
		head + Vector2(5+tilt,-54), head + Vector2(-4+tilt*0.4,-48), head + Vector2(-12,-24)
	])
	draw_colored_polygon(hat,ink)
	draw_line(head + Vector2(-10,-17),head + Vector2(10,-17),paper,1.2)
	_draw_diamond(head + Vector2(6,-24), 2.4, Color(1,1,1,0.36))
	# eyes track the cursor
	var eye_y: float = 0.15 if blink_t > 0.0 else 1.0
	_draw_eye(head + Vector2(-5,1), look, paper, ink, eye_y)
	_draw_eye(head + Vector2(5,1), look, paper, ink, eye_y)

	# front half is drawn after the mage, completing the depth illusion.
	_draw_menu_stones(c,paper,false)
	var orbit_expand: float = ease(hover_t,0.75)
	if orbit_expand > 0.02:
		draw_arc(c+Vector2(0,-14),118.0+orbit_expand*22.0,-0.32,PI+0.32,28,Color(0.08,0.08,0.08,0.04+orbit_expand*0.06),1.2)
		for i in range(3):
			var a_fx: float = t*0.22+float(i)*TAU/3.0
			var p_fx: Vector2 = c+Vector2(cos(a_fx)*(136.0+orbit_expand*12.0),sin(a_fx)*46.0-14.0)
			draw_circle(p_fx,1.4+orbit_expand*0.7,Color(1,1,1,0.04+orbit_expand*0.08))

func _draw_eye(base: Vector2, look: Vector2, paper: Color, ink: Color, y_scale: float) -> void:
	if y_scale < 0.25:
		draw_line(base+Vector2(-4,0),base+Vector2(4,0),paper,1.7)
		return
	_draw_oval(base,Vector2(4.0,3.0*y_scale),paper)
	draw_circle(base + look*1.3,1.15,ink)

func _draw_diamond(center: Vector2, radius_value: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center+Vector2(0,-radius_value), center+Vector2(radius_value*0.76,0),
		center+Vector2(0,radius_value), center+Vector2(-radius_value*0.76,0)
	])
	draw_colored_polygon(poly,color)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center+Vector2(cos(a)*radii.x,sin(a)*radii.y))
	draw_colored_polygon(points,color)
