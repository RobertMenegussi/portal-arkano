## Build 0721 — tutorial + HUD + menu class pass

- Tutorial pacing shortened and updated for current combat flow.
- Added an explicit R targeting-mode lesson (nearest <-> mouse/manual).
- Added a subtle in-run top-left reminder for the targeting toggle.
- Moved world dash charge icons higher so they sit above the hat/head silhouette.
- Locked Rift/Fenda as temporarily removed in menu/class panels.
- Updated the central radial Orbital menu art to better match the current rework.
