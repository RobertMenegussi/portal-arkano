extends Node2D

var t: float = 0.0
var sketch_frame: int = 0
var sketch_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	z_index = 2000

func _process(delta: float) -> void:
	t += delta
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.07
		sketch_frame += 1
	position = get_viewport().get_mouse_position()
	queue_redraw()

func jitter(index: int, amount: float) -> float:
	return sin(float(sketch_frame) * 2.9 + float(index) * 4.2) * amount

func _draw() -> void:
	var ink := Color("#111111")
	var r: float = 9.0 + sin(t * 4.0) * 0.7
	for i in range(3):
		var center := Vector2(jitter(i * 2, 0.8), jitter(i * 2 + 1, 0.8))
		draw_arc(center, r + jitter(10 + i, 0.9), 0.0, TAU, 24, Color(0.06, 0.06, 0.06, 0.52), 1.1)
	draw_circle(Vector2.ZERO, 1.7, ink)
	draw_line(Vector2(-16, 0), Vector2(-11, 0), ink, 1.3)
	draw_line(Vector2(16, 0), Vector2(11, 0), ink, 1.3)
	draw_line(Vector2(0, -16), Vector2(0, -11), ink, 1.3)
	draw_line(Vector2(0, 16), Vector2(0, 11), ink, 1.3)
