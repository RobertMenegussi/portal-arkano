# BUILD 0722 — Samurai manual aim hotfix

## Fixed
- Samurai manual/mouse aim no longer keeps attacking in the last automatic-target direction after pressing R.
- Mouse/manual mode now updates `aim_direction` directly from the live cursor every physics frame.
- Samurai slash also resolves its facing from the live mouse position on the exact attack frame as a safety net.
- `samurai_cached_focus` is refreshed from the cursor in manual mode so visual tracking and hit direction stay in sync.

## Files changed
- player.gd
- endless_main.gd
