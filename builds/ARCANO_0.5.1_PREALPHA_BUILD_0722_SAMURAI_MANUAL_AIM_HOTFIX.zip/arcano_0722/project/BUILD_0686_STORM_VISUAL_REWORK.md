# BUILD 0686 — STORM VISUAL REWORK

Focused pass only on the Storm class.

## Goals
- Move the Storm class away from the bulky/armored read.
- Push a slimmer mage silhouette with a more storm-driven identity.
- Increase richness of detail and polish in both gameplay and class preview art.

## Changes
- Reworked the Storm in-game body silhouette into a slimmer storm mage.
- Added layered rear cloak, main coat, inner panel, mantle, collar shapes, sash details and hanging tassels.
- Rebuilt the head/hood/crown to read more like an arcane storm caster instead of heavy armor.
- Improved fingertip lightning details and ambient storm hand effects.
- Refined the Storm class preview art to match the in-game update.
- Refined the Storm magic orbit effects for a richer presentation.

## Files changed
- player.gd
- mage_preview.gd
- endless_main.gd
