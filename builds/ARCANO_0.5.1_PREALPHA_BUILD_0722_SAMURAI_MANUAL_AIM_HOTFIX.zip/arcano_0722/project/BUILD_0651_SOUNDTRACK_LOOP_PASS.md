# ARCANO 0.5.1 PRE-ALPHA — BUILD 0651

## Soundtrack / Loop Pass

Build 0651 starts the 0.5.1 line with a focused soundtrack rewrite.

### Music engine
- Runtime soundtrack synthesis raised from 18 kHz to 22.05 kHz.
- `AudioStreamWAV` creation now accepts explicit loop begin/end sample points.
- Each song has a short one-time intro; only the main arrangement loops.
- Removed the old whole-track edge fade that made every restart sound like the song stopped and started again.
- Added a microscopic ~9 ms PCM seam guard strictly to prevent rounding/phase clicks. It is not an audible musical fade.
- Final harmony of each arrangement is deliberately written as a turnaround into its opening chord.

### Menu track
- 76 BPM.
- 2-bar intro + 16-bar / ~50.5 s main loop.
- D-minor-centered progression with two musical statements instead of one repeated eight-beat phrase.
- Three-note warm pad, soft low pulse, sparse bell motif and alternating shimmer/arpeggio sections.
- Intentionally no drum kit so the menu stays calm and premium.

### Gameplay track
- 106 BPM.
- 2-bar intro + 20-bar / ~45.3 s main loop.
- C-minor-centered progression with a middle lift and a G turnaround.
- Chord pad, grounded bass, plucked motif, soft kick/clap and later-section hats.
- Arrangement density changes over four-bar sections so a run does not feel like the same phrase firing forever.
- Percussion remains deliberately behind gameplay SFX.

### Boss track
- 132 BPM.
- 2-bar intro + 24-bar / ~43.6 s main loop.
- Low D-minor cycle with final A tension resolving into the first D-minor bar.
- Low ostinato, heartbeat pulse, restrained noise hits and periodic rising answers.
- More urgency without becoming a wall of generated noise.

### Version
- Active Endless build version: `0.5.1-prealpha`.
- Build number: `0651`.

## Validation note
Godot is not installed in this execution environment. This build received source/static checks and ZIP integrity validation, but not an engine runtime listening/playtest pass. Final musical balance and perceived seamlessness should be listened to in Godot/game output.
