extends Node2D

const PlayerScript = preload("res://player.gd")
const EnemyScript = preload("res://enemy.gd")
const EliteScript = preload("res://elite_reaver.gd")
const BossScript = preload("res://mini_boss_skeleton.gd")
const DummyScript = preload("res://training_dummy.gd")
const AudioManagerScript = preload("res://audio_manager.gd")
const ScreenFxScript = preload("res://screen_fx.gd")
const HudDisplayScript = preload("res://hud_display.gd")
const BossBarScript = preload("res://boss_bar.gd")
const CrosshairScript = preload("res://crosshair.gd")
const UpgradePanelScript = preload("res://upgrade_panel.gd")

const WORLD_SIZE: Vector2 = Vector2(2800.0,1800.0)
const CENTER: Vector2 = Vector2(1400.0,900.0)
const GAME_VERSION: String = "SANDBOX 0.2"
const BUILD_NUMBER: String = "0260"

var player
var audio_manager
var hud_widget
var boss_bar
var crosshair
var status_label: Label
var help_label: Label
var dev_layer: CanvasLayer
var panel_open: bool = false
var spawned: Array = []
var selected_mage_type: String = "orbit"
var current_boss
var upgrade_layer: CanvasLayer
var upgrade_panel
var inventory_open: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	RenderingServer.set_default_clear_color(Color("#e9e4d9"))
	_create_audio()
	_create_world_collision()
	_create_player()
	_create_screen_fx()
	_create_hud()
	_create_dev_panel()
	_create_upgrade_panel()
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	queue_redraw()

func _create_audio() -> void:
	audio_manager = AudioManagerScript.new()
	add_child(audio_manager)
	call_deferred("_silence_music")

func _silence_music() -> void:
	if is_instance_valid(audio_manager):
		audio_manager.stop_all_music()

func _create_player() -> void:
	player = PlayerScript.new()
	player.global_position = CENTER
	player.set_mage_type(selected_mage_type)
	player.died.connect(_on_player_died)
	add_child(player)
	player.visible = true
	player.active = true
	player.spawning = false
	player.modulate = Color.WHITE
	player.scale = Vector2.ONE
	player.health = player.max_health
	player.collision_layer = 2
	player.camera.limit_left = 0
	player.camera.limit_top = 0
	player.camera.limit_right = int(WORLD_SIZE.x)
	player.camera.limit_bottom = int(WORLD_SIZE.y)
	player.camera.position_smoothing_enabled = false
	player.camera.position_smoothing_speed = 0.0

func _create_world_collision() -> void:
	_add_wall(Vector2(WORLD_SIZE.x*0.5,18),Vector2(WORLD_SIZE.x,36))
	_add_wall(Vector2(WORLD_SIZE.x*0.5,WORLD_SIZE.y-18),Vector2(WORLD_SIZE.x,36))
	_add_wall(Vector2(18,WORLD_SIZE.y*0.5),Vector2(36,WORLD_SIZE.y))
	_add_wall(Vector2(WORLD_SIZE.x-18,WORLD_SIZE.y*0.5),Vector2(36,WORLD_SIZE.y))

func _add_wall(pos: Vector2,size: Vector2) -> void:
	var body: StaticBody2D = StaticBody2D.new()
	body.global_position = pos
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var shape_node: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = size
	shape_node.shape = shape
	body.add_child(shape_node)

func _create_screen_fx() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 15
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var fx = ScreenFxScript.new()
	fx.position = Vector2.ZERO
	fx.size = Vector2(960,540)
	fx.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(fx)

func _create_hud() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 30
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)

	hud_widget = HudDisplayScript.new()
	hud_widget.position = Vector2.ZERO
	hud_widget.size = Vector2(960,540)
	hud_widget.configure(player)
	layer.add_child(hud_widget)

	status_label = Label.new()
	status_label.position = Vector2(690,10)
	status_label.size = Vector2(254,42)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	status_label.add_theme_font_size_override("font_size",9)
	status_label.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.38))
	layer.add_child(status_label)

	help_label = Label.new()
	help_label.position = Vector2(12,8)
	help_label.size = Vector2(640,24)
	help_label.text = "F1 DEV  •  I inventário  •  U reroll  •  1–5 mobs  •  6 elite  •  7 Olheiro  •  V wave  •  C classe  •  H reset"
	help_label.add_theme_font_size_override("font_size",8)
	help_label.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.30))
	layer.add_child(help_label)

	boss_bar = BossBarScript.new()
	boss_bar.position = Vector2.ZERO
	boss_bar.size = Vector2(960,64)
	boss_bar.configure(null)
	layer.add_child(boss_bar)

	crosshair = CrosshairScript.new()
	layer.add_child(crosshair)

func _create_upgrade_panel() -> void:
	upgrade_layer = CanvasLayer.new()
	upgrade_layer.layer = 210
	upgrade_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	upgrade_layer.visible = false
	add_child(upgrade_layer)
	upgrade_panel = UpgradePanelScript.new()
	upgrade_panel.configure(player)
	upgrade_panel.close_requested.connect(_toggle_inventory)
	upgrade_layer.add_child(upgrade_panel)

func _create_dev_panel() -> void:
	dev_layer = CanvasLayer.new()
	dev_layer.layer = 220
	dev_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	dev_layer.visible = false
	add_child(dev_layer)

	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.06,0.06,0.06,0.36)
	dim.process_mode = Node.PROCESS_MODE_ALWAYS
	dev_layer.add_child(dim)

	var panel: ColorRect = ColorRect.new()
	panel.position = Vector2(155,62)
	panel.size = Vector2(650,416)
	panel.color = Color(0.96,0.94,0.89,0.98)
	panel.process_mode = Node.PROCESS_MODE_ALWAYS
	dev_layer.add_child(panel)

	var title: Label = Label.new()
	title.position = Vector2(24,18)
	title.size = Vector2(602,30)
	title.text = "ARCANO  •  GAMEPLAY SANDBOX"
	title.add_theme_font_size_override("font_size",20)
	panel.add_child(title)

	var sub: Label = Label.new()
	sub.position = Vector2(24,50)
	sub.size = Vector2(602,36)
	sub.text = "Sem campanha carregada. Inimigos, classes e inventário existem só para testar gameplay."
	sub.add_theme_font_size_override("font_size",10)
	sub.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.46))
	panel.add_child(sub)

	var x1: float = 24.0
	var x2: float = 226.0
	var x3: float = 428.0
	var y: float = 100.0
	_add_button(panel,"Slime [1]",Vector2(x1,y),_spawn_enemy.bind("slime"))
	_add_button(panel,"Esqueleto [2]",Vector2(x2,y),_spawn_enemy.bind("skeleton"))
	_add_button(panel,"Stalker [3]",Vector2(x3,y),_spawn_enemy.bind("stalker"))
	y += 46.0
	_add_button(panel,"Necromante [4]",Vector2(x1,y),_spawn_enemy.bind("shaman"))
	_add_button(panel,"Warder [5]",Vector2(x2,y),_spawn_enemy.bind("warder"))
	_add_button(panel,"Elite [6]",Vector2(x3,y),_spawn_elite)
	y += 46.0
	_add_button(panel,"OLHEIRO [7]",Vector2(x1,y),_spawn_boss)
	_add_button(panel,"Dummy DPS [8]",Vector2(x2,y),_spawn_dummy)
	_add_button(panel,"Wave mista [V]",Vector2(x3,y),_spawn_wave)
	y += 58.0
	_add_button(panel,"Orbital",Vector2(x1,y),_set_class.bind("orbit"))
	_add_button(panel,"Tempestade",Vector2(x2,y),_set_class.bind("storm"))
	_add_button(panel,"Fenda",Vector2(x3,y),_set_class.bind("rift"))
	y += 46.0
	_add_button(panel,"Reset build [H]",Vector2(x1,y),_reset_build)
	_add_button(panel,"Fluxo 100% [F]",Vector2(x2,y),_fill_flux)
	_add_button(panel,"Inventário [I]",Vector2(x3,y),_open_inventory_from_dev)
	y += 46.0
	_add_button(panel,"GOD MODE [G]",Vector2(x1,y),_toggle_god)
	_add_button(panel,"Limpar arena",Vector2(x2,y),_clear_arena)
	_add_button(panel,"Fechar [F1]",Vector2(x3,y),_toggle_panel)

func _add_button(parent: Control,text_value: String,pos: Vector2,callback: Callable) -> void:
	var button: Button = Button.new()
	button.position = pos
	button.size = Vector2(184,36)
	button.text = text_value
	button.process_mode = Node.PROCESS_MODE_ALWAYS
	button.pressed.connect(callback)
	parent.add_child(button)

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	if event.keycode == KEY_F1:
		if inventory_open:
			_toggle_inventory()
		_toggle_panel()
		get_viewport().set_input_as_handled()
		return
	if event.keycode == KEY_I:
		if panel_open:
			_toggle_panel()
		_toggle_inventory()
		get_viewport().set_input_as_handled()
		return
	if inventory_open:
		if event.keycode == KEY_U and is_instance_valid(upgrade_panel):
			upgrade_panel.call("_reroll")
		return
	if panel_open:
		return
	match event.keycode:
		KEY_1: _spawn_enemy("slime")
		KEY_2: _spawn_enemy("skeleton")
		KEY_3: _spawn_enemy("stalker")
		KEY_4: _spawn_enemy("shaman")
		KEY_5: _spawn_enemy("warder")
		KEY_6: _spawn_elite()
		KEY_7: _spawn_boss()
		KEY_8: _spawn_dummy()
		KEY_V: _spawn_wave()
		KEY_C: _cycle_class()
		KEY_H: _reset_build()
		KEY_G: _toggle_god()
		KEY_F: _fill_flux()
		KEY_U: _open_inventory_with_reroll()
		KEY_BACKSPACE: _clear_arena()

func _process(_delta: float) -> void:
	queue_redraw()
	if is_instance_valid(status_label) and is_instance_valid(player):
		var god_text: String = "ON" if player.admin_god_mode else "OFF"
		status_label.text = "BUILD "+BUILD_NUMBER+"  •  "+_class_name()+"\nGOD "+god_text+"  •  inimigos "+str(_enemy_count())
	if is_instance_valid(hud_widget):
		hud_widget.queue_redraw()
	if is_instance_valid(boss_bar):
		boss_bar.queue_redraw()

func _open_inventory_from_dev() -> void:
	if panel_open:
		_toggle_panel()
	if not inventory_open:
		_toggle_inventory()

func _toggle_inventory() -> void:
	inventory_open = not inventory_open
	upgrade_layer.visible = inventory_open
	get_tree().paused = inventory_open
	if inventory_open:
		upgrade_panel.refresh_for_player(player)
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		crosshair.visible = false
	else:
		Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
		crosshair.visible = true
		if is_instance_valid(player) and player.health > 0:
			player.active = true
			player.suppress_attack_until_release()

func _open_inventory_with_reroll() -> void:
	if not inventory_open:
		_toggle_inventory()
	if is_instance_valid(upgrade_panel):
		upgrade_panel.call("_reroll")

func _toggle_panel() -> void:
	panel_open = not panel_open
	dev_layer.visible = panel_open
	get_tree().paused = panel_open
	if panel_open:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		crosshair.visible = false
	else:
		Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
		crosshair.visible = true
		if is_instance_valid(player) and player.health > 0:
			player.active = true
			player.suppress_attack_until_release()

func _spawn_position(distance_min: float = 190.0,distance_max: float = 300.0) -> Vector2:
	var mouse_world: Vector2 = get_global_mouse_position()
	if mouse_world.x > 70.0 and mouse_world.x < WORLD_SIZE.x-70.0 and mouse_world.y > 70.0 and mouse_world.y < WORLD_SIZE.y-70.0:
		if mouse_world.distance_to(player.global_position) > 90.0:
			return mouse_world
	var angle: float = randf_range(0.0,TAU)
	return player.global_position + Vector2(cos(angle),sin(angle))*randf_range(distance_min,distance_max)

func _spawn_enemy(kind: String) -> void:
	if not is_instance_valid(player):
		return
	var enemy = EnemyScript.new()
	enemy.configure(kind,player)
	enemy.global_position = _spawn_position()
	add_child(enemy)
	enemy.add_to_group("sandbox_spawn")
	spawned.append(enemy)

func _spawn_elite() -> void:
	var elite = EliteScript.new()
	elite.configure(player)
	elite.global_position = _spawn_position(220.0,320.0)
	add_child(elite)
	elite.add_to_group("sandbox_spawn")
	spawned.append(elite)

func _spawn_boss() -> void:
	if is_instance_valid(current_boss):
		current_boss.queue_free()
	var boss = BossScript.new()
	boss.configure(player)
	boss.global_position = _spawn_position(300.0,390.0)
	boss.intro_requested = true
	boss.defeat_cutscene_requested.connect(_on_boss_defeat_requested.bind(boss))
	add_child(boss)
	boss.add_to_group("sandbox_spawn")
	boss.finish_intro_cutscene()
	current_boss = boss
	boss_bar.configure(boss)
	spawned.append(boss)
	get_tree().call_group("audio_bus","play_boss_reveal")

func _on_boss_defeat_requested(boss) -> void:
	if not is_instance_valid(boss):
		return
	boss.begin_defeat_cutscene()
	boss.finish_defeat_pose()

func _spawn_dummy() -> void:
	var dummy = DummyScript.new()
	dummy.global_position = _spawn_position(160.0,240.0)
	add_child(dummy)
	spawned.append(dummy)

func _spawn_wave() -> void:
	var kinds: Array = ["slime","skeleton","stalker","shaman","warder"]
	for i in range(kinds.size()):
		var enemy = EnemyScript.new()
		enemy.configure(str(kinds[i]),player)
		var angle: float = TAU*float(i)/float(kinds.size())
		enemy.global_position = player.global_position+Vector2(cos(angle),sin(angle))*310.0
		add_child(enemy)
		enemy.add_to_group("sandbox_spawn")
		spawned.append(enemy)

func _clear_arena() -> void:
	for node in get_tree().get_nodes_in_group("sandbox_spawn"):
		if is_instance_valid(node):
			node.queue_free()
	spawned.clear()
	current_boss = null
	boss_bar.configure(null)
	for node in get_tree().get_nodes_in_group("enemy"):
		if is_instance_valid(node) and node != player:
			if node.is_in_group("sandbox_spawn"):
				continue
			# Includes adds summoned by the Olheiro.
			node.queue_free()

func _restore_player() -> void:
	if not is_instance_valid(player):
		return
	player.health = player.max_health
	player.collision_layer = 2
	player.active = true
	player.invulnerability = 0.35
	player.refill_dash()
	player.refill_magic()
	player.global_position = CENTER
	player.velocity = Vector2.ZERO

func _reset_build() -> void:
	_clear_arena()
	var old_player = player
	if is_instance_valid(old_player):
		remove_child(old_player)
		old_player.free()
	_create_player()
	hud_widget.configure(player)
	if is_instance_valid(upgrade_panel):
		upgrade_panel.refresh_for_player(player)
	boss_bar.configure(null)
	get_tree().call_group("screen_fx","set_arcane_surge",false)
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN if not panel_open else Input.MOUSE_MODE_VISIBLE

func _toggle_god() -> void:
	if is_instance_valid(player):
		player.admin_god_mode = not player.admin_god_mode

func _fill_flux() -> void:
	if is_instance_valid(player):
		if player.flux_active:
			player.flux_timer = player.flux_duration
		else:
			player.add_flux(100.0)

func _cycle_class() -> void:
	match selected_mage_type:
		"orbit": _set_class("storm")
		"storm": _set_class("rift")
		_: _set_class("orbit")

func _set_class(kind: String) -> void:
	selected_mage_type = kind
	if is_instance_valid(player):
		player.set_mage_type(kind)
		player.refill_magic()
		player.suppress_attack_until_release()
		if is_instance_valid(upgrade_panel):
			upgrade_panel.refresh_for_player(player)

func _on_player_died() -> void:
	if is_instance_valid(status_label):
		status_label.text = "MORREU  •  H para resetar"

func _enemy_count() -> int:
	var count: int = 0
	for node in get_tree().get_nodes_in_group("enemy"):
		if is_instance_valid(node):
			count += 1
	return count

func _class_name() -> String:
	match selected_mage_type:
		"storm": return "TEMPESTADE"
		"rift": return "FENDA"
		_: return "ORBITAL"

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO,WORLD_SIZE),Color("#eee9df"),true)
	# Functional test grid only — intentionally no art/scenario pass.
	var grid: float = 128.0
	var x: float = 0.0
	while x <= WORLD_SIZE.x:
		draw_line(Vector2(x,0),Vector2(x,WORLD_SIZE.y),Color(0.08,0.08,0.08,0.035),1.0)
		x += grid
	var y: float = 0.0
	while y <= WORLD_SIZE.y:
		draw_line(Vector2(0,y),Vector2(WORLD_SIZE.x,y),Color(0.08,0.08,0.08,0.035),1.0)
		y += grid
	for r in [96.0,192.0,320.0,480.0]:
		draw_arc(CENTER,float(r),0.0,TAU,64,Color(0.08,0.08,0.08,0.055),1.0)
	draw_line(CENTER+Vector2(-560,0),CENTER+Vector2(560,0),Color(0.08,0.08,0.08,0.07),1.0)
	draw_line(CENTER+Vector2(0,-560),CENTER+Vector2(0,560),Color(0.08,0.08,0.08,0.07),1.0)
	if is_instance_valid(player) and bool(player.flux_active):
		var phase: float = Time.get_ticks_msec() * 0.001
		for i in range(4):
			var rr: float = 74.0 + float(i) * 58.0 + fmod(phase * 42.0,58.0)
			draw_arc(player.global_position,rr,0.0,TAU,64,Color(0.08,0.08,0.08,0.055-float(i)*0.008),1.2)
		for i in range(8):
			var a: float = phase*0.45+float(i)*TAU/8.0
			var p1: Vector2 = player.global_position+Vector2(cos(a),sin(a))*58.0
			var p2: Vector2 = player.global_position+Vector2(cos(a),sin(a))*105.0
			draw_line(p1,p2,Color(0.08,0.08,0.08,0.035),1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,CENTER+Vector2(-100,-510),"COMBAT TEST RANGE",HORIZONTAL_ALIGNMENT_CENTER,200,11,Color(0.08,0.08,0.08,0.18))
