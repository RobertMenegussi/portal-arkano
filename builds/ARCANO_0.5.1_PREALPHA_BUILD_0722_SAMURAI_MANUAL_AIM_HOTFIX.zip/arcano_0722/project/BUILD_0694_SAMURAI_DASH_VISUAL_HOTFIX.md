# BUILD 0694 — SAMURAI DASH VISUAL HOTFIX

## Fix
- Fixed parser error in `player.gd`: `Identifier "accent" not declared in the current scope`.
- Added the missing local accent color used by the Samurai dash/slash FX drawing routine.

## Files changed
- player.gd
- endless_main.gd
