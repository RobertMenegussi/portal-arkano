# BUILD 0697 — SPIDER STYLE REWORK

## Focus
Redesigned the spider enemy with a noticeably different silhouette and drawing style.

## What changed
- Replaced the previous rounded spider presentation with a more angular, predatory design.
- Gave the spider a clearer split between abdomen, armored thorax and aggressive head.
- Rebuilt the legs with a sharper, more creature-like layout and richer segmentation.
- Added a more deliberate eye cluster, mandibles, pedipalps and body markings for a stronger premium look.
- Kept the overall ARCANO sketch language while changing the spider to a more polished and interesting style.

## Files changed
- enemy.gd
- endless_main.gd
