extends CharacterBody2D

signal destroyed

const HitFxScript = preload("res://hit_fx.gd")

var health: int = 5
var max_health: int = 5
var dead: bool = false
var hit_flash: float = 0.0
var t: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy")
	collision_layer = 4
	collision_mask = 0
	z_index = 22
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 17.0
	collider.shape = shape
	add_child(collider)

func _process(delta: float) -> void:
	t += delta
	hit_flash = move_toward(hit_flash,0.0,delta*6.0)
	queue_redraw()

func take_damage(amount: int, hit_direction: Vector2) -> void:
	if dead:
		return
	health -= amount
	hit_flash = 1.0
	var fx = HitFxScript.new()
	fx.global_position = global_position
	fx.direction = hit_direction
	get_tree().current_scene.add_child(fx)
	get_tree().call_group("screen_fx","pulse_enemy_hit")
	if health <= 0:
		dead = true
		collision_layer = 0
		destroyed.emit()
		get_tree().call_group("screen_fx","pulse_kill")
		queue_free()

func _draw() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.6)
	var bob: float = sin(t*3.0)*1.5
	draw_circle(Vector2(0,19),Vector2(18,5).x,Color(0.08,0.08,0.08,0.05))
	var body: PackedVector2Array = PackedVector2Array([Vector2(-11,12+bob),Vector2(-7,-16+bob),Vector2(0,-25+bob),Vector2(8,-15+bob),Vector2(12,12+bob),Vector2(0,19+bob)])
	draw_colored_polygon(body,Color(0.96,0.94,0.88,0.95))
	draw_polyline(PackedVector2Array([body[0],body[1],body[2],body[3],body[4],body[5],body[0]]),ink,1.6)
	draw_circle(Vector2(0,-8+bob),4.0,ink)
	for i in range(3):
		var a: float = t*1.8+float(i)*TAU/3.0
		draw_circle(Vector2(cos(a),sin(a))*Vector2(20,10)+Vector2(0,-5+bob),1.8,Color(0.08,0.08,0.08,0.20))
