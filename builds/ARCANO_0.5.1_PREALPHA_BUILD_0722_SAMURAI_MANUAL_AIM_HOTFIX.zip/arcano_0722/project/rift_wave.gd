extends Node2D

const ArcaneBurstScript = preload("res://arcane_burst.gd")

var direction: Vector2 = Vector2.RIGHT
var speed: float = 470.0
var max_distance: float = 300.0
var radius: float = 38.0
var damage: int = 1
var distance_travelled: float = 0.0
var t: float = 0.0
var hit_ids: Dictionary = {}
var trail_points: Array[Vector2] = []
var cross_split: bool = false
var end_burst: bool = false
var pull_strength: float = 0.0
var owner_player
var split_done: bool = false
var cached_controller = null
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 68
	if direction.length_squared() < 0.001:
		direction = Vector2.RIGHT
	direction = direction.normalized()
	for i in range(8):
		trail_points.append(Vector2.ZERO)
	get_tree().call_group("audio_bus", "play_rift")
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	t += delta
	var step: float = speed * delta
	distance_travelled += step
	global_position += direction * step
	for i in range(trail_points.size() - 1, 0, -1):
		trail_points[i] = trail_points[i - 1]
	trail_points[0] = -direction * step
	_check_hits()
	if cross_split and not split_done and distance_travelled >= max_distance*0.56:
		split_done = true
		_spawn_cross()
	if distance_travelled >= max_distance:
		if end_burst:
			_spawn_end_burst()
		get_tree().call_group("screen_fx", "pulse_rift")
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _check_hits() -> void:
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(global_position,radius*1.9+16.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var id: int = enemy.get_instance_id()
		if hit_ids.has(id):
			continue
		var delta_pos: Vector2 = enemy.global_position - global_position
		var distance: float = delta_pos.length()
		if pull_strength > 0.0 and distance <= radius*1.7 and enemy.has_method("apply_external_force") and distance > 1.0:
			enemy.apply_external_force(-delta_pos.normalized()*pull_strength)
		if distance <= radius:
			hit_ids[id] = true
			enemy.take_damage(damage, direction)
			get_tree().call_group("screen_fx", "pulse_rift_hit")


func _spawn_cross() -> void:
	for sign_value in [-1.0,1.0]:
		var child = get_script().new()
		child.direction = direction.rotated(PI*0.5*sign_value)
		child.speed = speed*0.82
		child.max_distance = max_distance*0.38
		child.radius = maxf(24.0,radius*0.72)
		child.damage = maxi(1,damage-1)
		child.cross_split = false
		child.end_burst = false
		child.pull_strength = pull_strength*0.5
		child.owner_player = owner_player
		child.global_position = global_position
		get_tree().current_scene.add_child(child)

func _spawn_end_burst() -> void:
	var burst = ArcaneBurstScript.new()
	burst.radius = maxf(54.0,radius*1.55)
	burst.damage = maxi(1,damage)
	burst.pull_strength = pull_strength*0.35
	burst.global_position = global_position
	get_tree().current_scene.add_child(burst)

func _draw() -> void:
	var ink: Color = Color("#111111")
	var side: Vector2 = Vector2(-direction.y, direction.x)
	var fade: float = clampf(1.0 - distance_travelled / max_distance, 0.2, 1.0)
	# travelling crack head
	for branch in range(4):
		var branch_side: float = -1.0 if branch % 2 == 0 else 1.0
		var a: Vector2 = -direction * (8.0 + float(branch) * 3.0)
		var b: Vector2 = direction * (16.0 + float(branch) * 2.0) + side * branch_side * (6.0 + float(branch) * 3.0)
		draw_line(a, b, Color(ink.r, ink.g, ink.b, 0.42 * fade), 2.2)
		draw_line(b, b + direction * 8.0 + side * -branch_side * 5.0, Color(ink.r, ink.g, ink.b, 0.22 * fade), 1.2)
	# wake / fissure trail
	for i in range(6):
		var back: float = 18.0 + float(i) * 20.0
		var wobble: float = sin(t * 8.0 + float(i) * 1.7) * (4.0 + float(i))
		var p1: Vector2 = -direction * back + side * wobble
		var p2: Vector2 = p1 - direction * 14.0 + side * sin(float(i) * 2.2) * 6.0
		var alpha: float = maxf(0.04, 0.24 - float(i) * 0.03)
		draw_line(p1, p2, Color(ink.r, ink.g, ink.b, alpha), maxf(1.0, 2.0 - float(i) * 0.12))
	# hit width hint, not a giant target circle
	draw_arc(Vector2.ZERO, radius, direction.angle() - 0.55, direction.angle() + 0.55, 12, Color(0.08,0.08,0.08,0.10), 1.0)
