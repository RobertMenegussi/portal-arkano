# BUILD 0715 — Flux kill gain

- Normal kill Flow: 0.95 -> 1.25
- Elite kill Flow: 8.0 -> 11.0
- Flow gain runes/multipliers still apply normally.
