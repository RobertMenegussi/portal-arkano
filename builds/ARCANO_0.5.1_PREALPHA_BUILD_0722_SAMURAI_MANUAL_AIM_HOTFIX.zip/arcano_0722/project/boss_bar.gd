extends Control

var boss
var t: float = 0.0

func configure(target) -> void:
	boss = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if not is_instance_valid(boss):
		return
	if not boss.battle_started or boss.defeated:
		return
	var ink: Color = Color("#111111")
	var x: float = 252.0
	var y: float = 16.0
	var w: float = 456.0
	var ratio: float = clampf(float(boss.health) / float(boss.max_health), 0.0, 1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		var title: String = Loc.t("boss.name")
		var tw: float = font.get_string_size(title, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
		draw_string(font, Vector2(480.0 - tw * 0.5, y), title, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.08,0.08,0.08,0.74))
	var body: Rect2 = Rect2(Vector2(x, y + 10.0), Vector2(w, 15.0))
	draw_rect(body, Color(1,1,1,0.78), true)
	for i in range(2):
		draw_rect(body.grow(-float(i) * 1.2), Color(0.08,0.08,0.08,0.20 + float(i) * 0.13), false, 1.0)
	var fill: Rect2 = Rect2(body.position + Vector2(3,4), Vector2(maxf(0.0, (body.size.x - 6.0) * ratio), 7.0))
	draw_rect(fill, ink, true)
	# Phase cuts make the escalation readable without adding giant UI labels.
	for cut_ratio in [0.67,0.34]:
		var cut_x: float = body.position.x+body.size.x*float(cut_ratio)
		draw_line(Vector2(cut_x,body.position.y+1),Vector2(cut_x,body.end.y-1),Color(1,1,1,0.58),1.0)
	if font != null:
		var phase: int = boss._current_phase() if boss.has_method("_current_phase") else 1
		var info: String = Loc.f("boss.phase",[_roman(phase),_state_label(str(boss.state))])
		draw_string(font,Vector2(x,y+47),info,HORIZONTAL_ALIGNMENT_CENTER,w,9,Color(0.08,0.08,0.08,0.42))
	if ratio < 0.35:
		var pulse: float = 0.08 + absf(sin(t * 7.0)) * 0.07
		draw_rect(body.grow(3.0), Color(0.08,0.08,0.08,pulse), false, 1.0)

func _roman(value: int) -> String:
	if value >= 3:
		return "III"
	if value == 2:
		return "II"
	return "I"

func _state_label(value: String) -> String:
	match value:
		"leap_windup": return Loc.t("boss.state.leap_windup")
		"leap": return Loc.t("boss.state.leap")
		"parry": return Loc.t("boss.state.parry")
		"cage_windup": return Loc.t("boss.state.cage_windup")
		"shockwave_windup": return Loc.t("boss.state.shockwave_windup")
		"mark_windup": return Loc.t("boss.state.mark_windup")
		"fan_windup": return Loc.t("boss.state.fan_windup")
		"lanes_windup": return Loc.t("boss.state.lanes_windup")
		_: return Loc.t("boss.state.observe")
