# BUILD 0719 — Samurai slash area preview

## Main changes
- Added a visible slash-area preview for Samurai mouse/manual aim.
- The cursor now shows a soft wedge/arc from the Samurai toward the cut zone.
- The preview reflects melee direction and range more clearly so spacing reads better in combat.

## Files changed
- endless_aim_cursor.gd
- endless_main.gd
