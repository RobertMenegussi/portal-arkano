# ARCANO Build 0512 — Environment / Chests / FOV

- Endless map expanded from 5600x3600 to 7000x4400.
- Scenario art pass: layered ground patches, extra paths, ponds, ruins, groves, rocks, reeds, logs and shrubs.
- Post-processing pass: subtle ambient haze + light chromatic/lens treatment in screen shader.
- Wider endless FOV via lower camera zoom.
- Enemies reduced in visual/collision scale for a larger perceived play space.
- Rare world chests added:
  - Silver chest (rare, TTL 90s, active cap controlled)
  - Gold chest (very rare, TTL 105s, only one active at a time)
- World chests grant healing or single-use effects like Dragon Breath / Arcane Guard.
- World chest spawning is timer + chance based, with a cap of 2 active world chests to avoid map clutter.
