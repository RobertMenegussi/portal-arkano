# BUILD 0683 — ORBITAL DETAIL / RICHNESS PASS

Focused refinement of the Orbital class visual identity.

## Goals
- Remove the loose inertial back-piece feel that read as laggy.
- Push the Orbital silhouette into a richer, more premium-looking design.
- Add more detail layers without changing the whole class fantasy.
- Keep the overall sketchy magic-survival vibe while making the character feel more finished.

## Main changes
- Reworked the Orbital body to use a more stable rear drape instead of a floppy lagging back piece.
- Added more costume detail: layered robe, inner panel, mantle, collar shapes, shoulder accents, waist sash, belt gem, hanging cords and facial trim.
- Refined hat structure with under-brim, gem detail and cleaner silhouette.
- Added sleeve/cuff detail and slightly richer hand/arm presentation.
- Updated the menu preview art so the class card better matches the in-game look.

## Files changed
- player.gd
- mage_preview.gd
