extends Node2D

var delay: float = 0.26
var life: float = 0.48
var radius: float = 42.0
var damage: int = 1
var friendly: bool = true
var hit_done: bool = false
var t: float = 0.0
var chain_count: int = 0
var aftershock: bool = false
var owner_player
var cached_controller = null
var visual_timer: float = 0.0
var bolt_points: PackedVector2Array = PackedVector2Array()

func configure(is_friendly: bool = true) -> void:
	friendly = is_friendly

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 70
	cached_controller = get_tree().get_first_node_in_group("endless_controller")
	_build_bolt()

func _process(delta: float) -> void:
	t += delta
	if not hit_done and t >= delay:
		hit_done = true
		_impact()
	if t >= life:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 30.0
		queue_redraw()

func _impact() -> void:
	if friendly:
		var hit_targets: Array = []
		var targets: Array = get_tree().get_nodes_in_group("enemy")
		if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
			targets = cached_controller.get_nearby_enemies(global_position, radius + 24.0)
		targets.append_array(get_tree().get_nodes_in_group("basic_target"))
		for enemy in targets:
			if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
				continue
			var d2: float = global_position.distance_squared_to(enemy.global_position)
			if d2 <= radius * radius:
				var dir: Vector2 = (enemy.global_position - global_position).normalized()
				if dir.length_squared() < 0.001:
					dir = Vector2.RIGHT
				enemy.take_damage(damage, dir)
				hit_targets.append(enemy)
		if chain_count > 0:
			_spawn_chain(hit_targets)
		if aftershock:
			_spawn_aftershock()
		get_tree().call_group("screen_fx", "pulse_lightning")
		get_tree().call_group("audio_bus", "play_lightning")

func _spawn_chain(excluded: Array) -> void:
	var best = null
	var best_distance: float = 210.0
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(global_position, 220.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage") or excluded.has(enemy):
			continue
		var distance: float = global_position.distance_to(enemy.global_position)
		if distance < best_distance:
			best = enemy
			best_distance = distance
	if best == null:
		return
	var chain = get_script().new()
	chain.configure(true)
	chain.delay = 0.12
	chain.life = 0.34
	chain.radius = maxf(24.0, radius * 0.58)
	chain.damage = maxi(1, damage - 1)
	chain.chain_count = chain_count - 1
	chain.aftershock = false
	chain.owner_player = owner_player
	chain.global_position = best.global_position
	get_tree().current_scene.add_child(chain)

func _spawn_aftershock() -> void:
	var second = get_script().new()
	second.configure(true)
	second.delay = 0.34
	second.life = 0.58
	second.radius = maxf(28.0, radius * 0.76)
	second.damage = maxi(1, damage - 1)
	second.chain_count = 0
	second.aftershock = false
	second.owner_player = owner_player
	second.global_position = global_position
	get_tree().current_scene.add_child(second)

func _build_bolt() -> void:
	bolt_points.clear()
	var y: float = -206.0
	var x: float = randf_range(-4.0, 4.0)
	bolt_points.append(Vector2(x, y))
	for i in range(1, 8):
		y = lerpf(-206.0, 0.0, float(i) / 7.0)
		x += randf_range(-18.0, 18.0)
		bolt_points.append(Vector2(x, y))
	bolt_points.append(Vector2(0, 0))

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#f6f5ef")
	var sky: Color = Color(0.78, 0.90, 1.0, 0.30)
	if t < delay:
		var p: float = clampf(t / delay, 0.0, 1.0)
		for i in range(4):
			draw_arc(Vector2.ZERO, radius * (0.42 + float(i) * 0.17), 0.0, TAU, 28, Color(sky.r, sky.g, sky.b, 0.08 + p * 0.11), 1.0 + float(i == 0) * 0.3)
		for i in range(6):
			var a: float = t * 8.0 + float(i) * TAU / 6.0
			var r: float = 16.0 + p * 18.0 + float(i % 2) * 5.0
			draw_circle(Vector2(cos(a), sin(a)) * r, 1.5 + p * 0.5, Color(1, 1, 1, 0.14 + p * 0.12))
		draw_circle(Vector2.ZERO, 8.0 + p * 3.0, Color(1, 1, 1, 0.08 + p * 0.08))
	else:
		var q: float = clampf((t - delay) / maxf(0.001, life - delay), 0.0, 1.0)
		var alpha: float = 1.0 - q
		for i in range(bolt_points.size() - 1):
			var a0: Vector2 = bolt_points[i]
			var b0: Vector2 = bolt_points[i + 1]
			draw_line(a0, b0, Color(sky.r, sky.g, sky.b, 0.24 * alpha), 7.0)
			draw_line(a0, b0, Color(ink.r, ink.g, ink.b, 0.78 * alpha), 3.3)
			draw_line(a0, b0, Color(paper.r, paper.g, paper.b, 0.92 * alpha), 1.3)
			if i < bolt_points.size() - 2:
				var mid: Vector2 = a0.lerp(b0, 0.55)
				var branch: Vector2 = mid + Vector2(randf_range(-18.0, 18.0), randf_range(12.0, 28.0))
				draw_line(mid, branch, Color(ink.r, ink.g, ink.b, 0.36 * alpha), 1.5)
		var blast_r: float = radius * (0.46 + q * 0.78)
		draw_circle(Vector2.ZERO, blast_r, Color(sky.r, sky.g, sky.b, 0.09 * alpha))
		draw_arc(Vector2.ZERO, blast_r, 0.0, TAU, 32, Color(ink.r, ink.g, ink.b, 0.28 * alpha), 2.0)
		for i in range(8):
			var a2: float = float(i) * TAU / 8.0 + q * 0.5
			var p2: Vector2 = Vector2(cos(a2), sin(a2)) * (8.0 + blast_r * 0.82)
			draw_line(Vector2.ZERO, p2, Color(ink.r, ink.g, ink.b, 0.18 * alpha), 1.1)
