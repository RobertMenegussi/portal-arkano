extends Node

const SenseiScript = preload("res://tutorial_sensei.gd")
const DialoguePanelScript = preload("res://tutorial_dialogue_panel.gd")

var controller
var player
var sensei
var layer: CanvasLayer
var dialogue
var phase: int = 0
var line_queue: Array = []
var task: String = ""
var task_started: bool = false
var baseline_kills: int = 0
var baseline_runes: int = 0
var baseline_vases: int = 0
var baseline_health: int = 0
var baseline_consumable_uses: int = 0
var chest_spawned: bool = false
var elite_spawned: bool = false
var move_times: Array[float] = [0.0,0.0,0.0,0.0] # left, right, up, down
var move_ui_timer: float = 0.0
var transition_pending: bool = false
var transition_timer: float = 0.0
var camera_tween: Tween

const MOVE_HOLD_TIME: float = 0.48
const WARD_RADIUS: float = 335.0
const WARD_SPAWN_RADIUS: float = 285.0
var ward_notice_cooldown: float = 0.0

func configure(owner_controller,target) -> void:
	controller = owner_controller
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if not is_instance_valid(controller) or not is_instance_valid(player):
		queue_free()
		return
	sensei = SenseiScript.new()
	sensei.global_position = player.global_position+Vector2(135,-70)
	controller.add_child(sensei)
	layer = CanvasLayer.new()
	layer.layer = 245
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	controller.add_child(layer)
	dialogue = DialoguePanelScript.new()
	dialogue.position = Vector2.ZERO
	dialogue.size = Vector2(960,540)
	dialogue.advanced.connect(_on_dialogue_advanced)
	layer.add_child(dialogue)
	if player.has_method("set_tutorial_safe_mode"):
		player.set_tutorial_safe_mode(true)
	if controller.has_method("set_tutorial_consumables_locked"):
		controller.set_tutorial_consumables_locked(true)
	if controller.has_method("_tutorial_set_attack_target_mode"):
		controller._tutorial_set_attack_target_mode("nearest")
	_set_attack_locked(true)
	_show_phase()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		_finish(false)

func _process(delta: float) -> void:
	ward_notice_cooldown = maxf(0.0,ward_notice_cooldown-delta)
	_enforce_training_ward()
	if transition_pending:
		transition_timer -= delta
		if transition_timer <= 0.0:
			transition_pending = false
			_show_phase()
		return
	if not task_started or not is_instance_valid(player):
		return
	match task:
		"move":
			_update_move_task(delta)
		"kill":
			if int(controller.kill_count) > baseline_kills:
				_complete_task()
		"samurai":
			if int(controller.kill_count) > baseline_kills:
				_complete_task()
		"aim_toggle":
			if _current_attack_mode() == "mouse":
				_complete_task()
		"dash":
			if player.dash_active:
				_complete_task()
		"xp":
			if get_tree().get_nodes_in_group("tutorial_xp_cluster").is_empty():
				_complete_task()
		"pickup_heal":
			if player.health > baseline_health:
				_complete_task()
		"pickup_magnet":
			if get_tree().get_nodes_in_group("tutorial_magnet_xp").is_empty() and get_tree().get_nodes_in_group("tutorial_magnet_pickup").is_empty():
				_complete_task()
		"pickup_bomb":
			if get_tree().get_nodes_in_group("tutorial_bomb_target").is_empty() and get_tree().get_nodes_in_group("tutorial_bomb_pickup").is_empty():
				_complete_task()
		"rune":
			if int(controller.acquired_traits.size()) > baseline_runes and not controller.levelup_open:
				_complete_task()
		"vase":
			if int(controller.vases_broken_run) > baseline_vases:
				_complete_task()
		"chest":
			if chest_spawned and get_tree().get_nodes_in_group("world_chest").is_empty():
				_complete_task()
		"dragon":
			if int(controller.consumable_use_count) > baseline_consumable_uses and str(controller.last_consumable_used) == "dragon_breath":
				_complete_task()
		"flux":
			if player.flux_active:
				_complete_task()
		"elite":
			if elite_spawned and get_tree().get_nodes_in_group("elite").is_empty():
				_complete_task()
		"tab":
			if bool(controller.stats_visible):
				_complete_task()

func _update_move_task(delta: float) -> void:
	if not player.moving:
		return
	var d: Vector2 = player.move_direction
	# Count deliberate cardinal travel. Diagonal shortcuts do not tick two boxes
	# at once; the player has to actually feel each direction for a moment.
	if absf(d.x) > absf(d.y)*1.25:
		if d.x < -0.55:
			move_times[0] += delta
		elif d.x > 0.55:
			move_times[1] += delta
	elif absf(d.y) > absf(d.x)*1.25:
		if d.y < -0.55:
			move_times[2] += delta
		elif d.y > 0.55:
			move_times[3] += delta
	move_ui_timer -= delta
	if move_ui_timer <= 0.0:
		move_ui_timer = 0.09
		_refresh_move_task_text()
	for value in move_times:
		if value < MOVE_HOLD_TIME:
			return
	_complete_task()

func _refresh_move_task_text() -> void:
	var marks: Array[String] = []
	for value in move_times:
		marks.append("✓" if value >= MOVE_HOLD_TIME else "·")
	dialogue.set_task(Loc.f("tutorial.task_move_progress",[marks[0],marks[1],marks[2],marks[3]]))

func _show_phase() -> void:
	task_started = false
	task = ""
	dialogue.set_task("")
	dialogue.set_action_mode(false)
	_set_attack_locked(true)
	match phase:
		0: _queue_lines([["tut.01","happy"]])
		1: _queue_lines([["tut.02","serious"]])
		2: _queue_lines([["tut.orbital","calm"]])
		3: _queue_lines([["tut.aim_toggle","calm"]])
		4: _queue_lines([["tut.samurai","serious"]])
		5: _queue_lines([["tut.04","happy"]])
		6: _queue_lines([["tut.dash_reload","calm"]])
		7: _queue_lines([["tut.05","calm"]])
		8: _queue_lines([["tut.14","calm"],["tut.item_heal","calm"]])
		9: _queue_lines([["tut.item_magnet","happy"]])
		10: _queue_lines([["tut.item_bomb","serious"]])
		11: _queue_lines([["tut.06","serious"]])
		12: _queue_lines([["tut.07","surprised"]])
		13: _queue_lines([["tut.08","calm"],["tut.chest_silver","calm"],["tut.chest_gold","serious"]])
		14:
			var slot: int = controller.find_consumable_slot("dragon_breath") if controller.has_method("find_consumable_slot") else -1
			var key_label: String = controller.get_consumable_key_label(slot) if controller.has_method("get_consumable_key_label") and slot >= 0 else "1"
			_queue_lines([["tut.dragon_use","happy",[key_label]]])
		15: _queue_lines([["tut.09","serious"]])
		16: _queue_lines([["tut.10","serious"]])
		17: _queue_lines([["tut.15","calm"]])
		18: _queue_lines([["tut.11","calm"],["tut.12","happy"]])
		19: _queue_lines([["tut.13","happy"]])
		_: _finish(true)

func _queue_lines(values: Array) -> void:
	line_queue = values.duplicate(true)
	_show_next_line()

func _show_next_line() -> void:
	if line_queue.is_empty():
		_begin_task_for_phase()
		return
	var item: Array = line_queue.pop_front()
	var mood: String = str(item[1])
	if is_instance_valid(sensei):
		sensei.set_emotion(mood)
	_set_attack_locked(true)
	var text_value: String = Loc.t(str(item[0]))
	if item.size() >= 3:
		var format_args: Array = item[2]
		text_value = Loc.f(str(item[0]),format_args)
	dialogue.set_line(Loc.t("tutorial.sensei"),text_value,mood)

func _on_dialogue_advanced() -> void:
	if is_instance_valid(player) and player.has_method("suppress_attack_until_release"):
		player.suppress_attack_until_release()
	_show_next_line()

func _activate_task(task_id: String,task_key: String,args: Array = []) -> void:
	task = task_id
	var text_value: String = Loc.t(task_key) if args.is_empty() else Loc.f(task_key,args)
	dialogue.set_task(text_value)
	dialogue.set_action_mode(true)
	_set_attack_locked(false)
	task_started = true

func _begin_task_for_phase() -> void:
	match phase:
		0:
			phase += 1
			_show_phase()
		1:
			move_times = [0.0,0.0,0.0,0.0]
			move_ui_timer = 0.0
			_activate_task("move","tutorial.task_move")
			_refresh_move_task_text()
		2:
			controller._tutorial_set_class("orbit")
			if controller.has_method("_tutorial_set_attack_target_mode"):
				controller._tutorial_set_attack_target_mode("nearest")
			baseline_kills = int(controller.kill_count)
			var orbit_target: Vector2 = _ward_position(Vector2(205,0))
			controller._tutorial_spawn_enemy("slime",orbit_target,true,5,true)
			_activate_task("kill","tutorial.task_kill")
			_camera_glance(orbit_target)
		3:
			_activate_task("aim_toggle","tutorial.task_aim_toggle")
		4:
			if controller.has_method("_tutorial_set_attack_target_mode"):
				controller._tutorial_set_attack_target_mode("nearest")
			controller._tutorial_set_class("samurai")
			baseline_kills = int(controller.kill_count)
			var samurai_target: Vector2 = _ward_position(Vector2(185,0))
			controller._tutorial_spawn_enemy("slime",samurai_target,true,5,true)
			_activate_task("samurai","tutorial.task_samurai")
			_camera_glance(samurai_target)
		5:
			_activate_task("dash","tutorial.task_dash")
		6:
			controller._tutorial_set_class("orbit")
			phase += 1
			_show_phase()
		7:
			_spawn_spread_xp("tutorial_xp_cluster",true)
			_activate_task("xp","tutorial.task_xp")
			_camera_glance(sensei.global_position+Vector2(145,40))
		8:
			player.health = maxi(2,player.max_health-2)
			baseline_health = int(player.health)
			var heal_pos: Vector2 = _ward_position(Vector2(105,75))
			controller._tutorial_spawn_pickup("heal",heal_pos,"tutorial_heal_pickup")
			_activate_task("pickup_heal","tutorial.task_heal")
			_camera_glance(heal_pos)
		9:
			_spawn_spread_xp("tutorial_magnet_xp",false)
			var magnet_pos: Vector2 = _ward_position(Vector2(100,70))
			controller._tutorial_spawn_pickup("magnet",magnet_pos,"tutorial_magnet_pickup")
			_activate_task("pickup_magnet","tutorial.task_magnet")
			_camera_glance(magnet_pos)
		10:
			_spawn_bomb_targets()
			var bomb_pos: Vector2 = _ward_position(Vector2(105,70))
			controller._tutorial_spawn_pickup("bomb",bomb_pos,"tutorial_bomb_pickup")
			_activate_task("pickup_bomb","tutorial.task_bomb")
			_camera_glance(bomb_pos)
		11:
			baseline_runes = int(controller.acquired_traits.size())
			_activate_task("rune","tutorial.task_rune")
			controller._tutorial_force_levelup()
		12:
			baseline_vases = int(controller.vases_broken_run)
			var vase_pos: Vector2 = _ward_position(Vector2(120,35))
			controller._tutorial_spawn_vase(vase_pos)
			_activate_task("vase","tutorial.task_vase")
			_camera_glance(vase_pos)
		13:
			chest_spawned = true
			var silver_pos: Vector2 = _ward_position(Vector2(130,-50))
			var gold_pos: Vector2 = _ward_position(Vector2(-130,-50))
			controller._spawn_chest(silver_pos,"silver",180.0)
			controller._spawn_chest(gold_pos,"gold",180.0)
			_activate_task("chest","tutorial.task_chest")
			_camera_glance((silver_pos+gold_pos)*0.5)
		14:
			var dragon_slot: int = controller.find_consumable_slot("dragon_breath") if controller.has_method("find_consumable_slot") else 0
			var dragon_key: String = controller.get_consumable_key_label(dragon_slot) if controller.has_method("get_consumable_key_label") else str(dragon_slot+1)
			baseline_consumable_uses = int(controller.consumable_use_count)
			controller.set_tutorial_consumables_locked(false)
			_spawn_dragon_targets()
			_activate_task("dragon","tutorial.task_dragon",[dragon_key])
			_camera_glance(_ward_position(Vector2(205,0)))
			_set_attack_locked(true)
		15:
			player.flux = 99.1
			player.flux_recharge_timer = 0.0
			player.flux_idle_timer = 999.0
			if player.has_method("set_tutorial_flux_guard"):
				player.set_tutorial_flux_guard(true)
			var flux_target: Vector2 = _ward_position(Vector2(195,0))
			controller._tutorial_spawn_enemy("slime",flux_target,true,7,true,"tutorial_flux_target")
			_activate_task("flux","tutorial.task_flux")
			_camera_glance(flux_target)
		16:
			elite_spawned = true
			player.health = maxi(player.health,mini(player.max_health,4))
			var elite_pos: Vector2 = _ward_position(Vector2(215,0))
			controller._tutorial_spawn_elite(elite_pos)
			_activate_task("elite","tutorial.task_elite")
			_camera_glance(elite_pos)
		17:
			_activate_task("tab","tutorial.task_tab")
		18:
			phase += 1
			_show_phase()
		19:
			phase += 1
			_show_phase()
		_:
			_finish(true)

func _spawn_spread_xp(group_name: String,include_rare: bool) -> void:
	if not is_instance_valid(sensei):
		return
	var count: int = 6 if include_rare else 5
	var base_angle: float = 0.18
	for i in range(count):
		var angle: float = base_angle+TAU*float(i)/float(count)
		var radius: float = 205.0+float(i%2)*28.0
		var pos: Vector2 = sensei.global_position+Vector2(cos(angle),sin(angle))*radius
		controller._tutorial_spawn_xp_orb(pos,include_rare and i == count-1,group_name)

func _spawn_bomb_targets() -> void:
	if not is_instance_valid(sensei):
		return
	for i in range(4):
		var angle: float = TAU*float(i)/4.0+0.35
		var pos: Vector2 = sensei.global_position+Vector2(cos(angle),sin(angle))*220.0
		controller._tutorial_spawn_enemy("slime",pos,true,99,true,"tutorial_bomb_target")

func _spawn_dragon_targets() -> void:
	if not is_instance_valid(player) or not is_instance_valid(sensei):
		return
	var direction: Vector2 = sensei.global_position-player.global_position
	if direction.length_squared() < 0.001:
		direction = Vector2.RIGHT
	direction = direction.normalized()
	var side: Vector2 = Vector2(-direction.y,direction.x)
	var distances: Array[float] = [135.0,180.0,220.0,255.0]
	var offsets: Array[float] = [-34.0,26.0,-18.0,36.0]
	for i in range(distances.size()):
		var desired: Vector2 = player.global_position+direction*distances[i]+side*offsets[i]
		var from_sensei: Vector2 = desired-sensei.global_position
		if from_sensei.length() > WARD_SPAWN_RADIUS:
			desired = sensei.global_position+from_sensei.normalized()*WARD_SPAWN_RADIUS
		controller._tutorial_spawn_enemy("slime",desired,true,6,true,"tutorial_dragon_target")

func _ward_position(offset: Vector2) -> Vector2:
	var origin: Vector2 = player.global_position if is_instance_valid(player) else Vector2.ZERO
	var desired: Vector2 = origin+offset
	if not is_instance_valid(sensei):
		return desired
	var from_sensei: Vector2 = desired-sensei.global_position
	if from_sensei.length() > WARD_SPAWN_RADIUS:
		return sensei.global_position+from_sensei.normalized()*WARD_SPAWN_RADIUS
	return desired

func _enforce_training_ward() -> void:
	if not is_instance_valid(player) or not is_instance_valid(sensei):
		return
	var offset: Vector2 = player.global_position-sensei.global_position
	var distance: float = offset.length()
	if distance <= WARD_RADIUS:
		return
	var outward: Vector2 = offset.normalized() if distance > 0.001 else Vector2.RIGHT
	player.global_position = sensei.global_position+outward*WARD_RADIUS
	if player is CharacterBody2D:
		var body := player as CharacterBody2D
		var outward_speed: float = body.velocity.dot(outward)
		if outward_speed > 0.0:
			body.velocity -= outward*outward_speed
	if ward_notice_cooldown <= 0.0:
		ward_notice_cooldown = 1.8
		if is_instance_valid(controller) and controller.has_method("_show_banner"):
			controller._show_banner(Loc.t("tutorial.stay_near"),1.35)
		if sensei.has_method("set_emotion"):
			sensei.set_emotion("serious")

func _complete_task() -> void:
	if not task_started:
		return
	var completed_task: String = task
	task_started = false
	task = ""
	if completed_task == "flux" and is_instance_valid(player) and player.has_method("set_tutorial_flux_guard"):
		player.set_tutorial_flux_guard(false)
		_clear_group("tutorial_flux_target")
	elif completed_task == "dragon":
		_clear_group("tutorial_dragon_target")
	# Give the player's brain a beat to register "I did that" before a new lesson starts.
	dialogue.set_task(Loc.t("tutorial.task_done"))
	dialogue.set_action_mode(true)
	_set_attack_locked(true)
	phase += 1
	transition_pending = true
	transition_timer = 0.58 if completed_task in ["kill","samurai","rune","chest","dragon","flux","elite","aim_toggle"] else 0.42

func _current_attack_mode() -> String:
	if is_instance_valid(controller) and controller.has_method("_get_attack_target_mode"):
		return str(controller._get_attack_target_mode())
	return "nearest"

func _camera_glance(world_pos: Vector2) -> void:
	if not is_instance_valid(player) or not is_instance_valid(player.camera):
		return
	if camera_tween != null and camera_tween.is_valid():
		camera_tween.kill()
	var cam: Camera2D = player.camera
	var return_pos: Vector2 = cam.position
	var return_zoom: Vector2 = cam.zoom
	var focus_offset: Vector2 = (world_pos-player.global_position)*0.58
	if focus_offset.length() > 150.0:
		focus_offset = focus_offset.normalized()*150.0
	var focus_zoom: Vector2 = return_zoom*1.055
	_set_attack_locked(true)
	if player.has_method("set_cutscene_lock"):
		player.set_cutscene_lock(true)
	camera_tween = create_tween()
	camera_tween.set_trans(Tween.TRANS_QUAD)
	camera_tween.set_ease(Tween.EASE_OUT)
	camera_tween.tween_property(cam,"position",focus_offset,0.18)
	camera_tween.parallel().tween_property(cam,"zoom",focus_zoom,0.18)
	camera_tween.tween_interval(0.12)
	camera_tween.set_ease(Tween.EASE_IN_OUT)
	camera_tween.tween_property(cam,"position",return_pos,0.20)
	camera_tween.parallel().tween_property(cam,"zoom",return_zoom,0.20)
	camera_tween.tween_callback(_end_camera_glance)

func _end_camera_glance() -> void:
	if not is_instance_valid(player):
		return
	if player.has_method("set_cutscene_lock"):
		player.set_cutscene_lock(false)
	# Dragon Breath is meant to be the only damage source during its demonstration.
	_set_attack_locked(task_started and task == "dragon")

func _clear_group(group_name: String) -> void:
	for node in get_tree().get_nodes_in_group(group_name):
		if is_instance_valid(node):
			node.queue_free()

func _set_attack_locked(value: bool) -> void:
	if is_instance_valid(player) and player.has_method("set_tutorial_attack_locked"):
		player.set_tutorial_attack_locked(value)

func _finish(completed: bool) -> void:
	transition_pending = false
	if camera_tween != null and camera_tween.is_valid():
		camera_tween.kill()
	_set_attack_locked(false)
	if is_instance_valid(player):
		if player.has_method("set_cutscene_lock"):
			player.set_cutscene_lock(false)
		if is_instance_valid(player.camera):
			player.camera.position = Vector2.ZERO
			if player.has_method("_update_camera"):
				player.camera.offset = Vector2.ZERO
		if player.has_method("set_tutorial_safe_mode"):
			player.set_tutorial_safe_mode(false)
		if player.has_method("set_tutorial_flux_guard"):
			player.set_tutorial_flux_guard(false)
	if is_instance_valid(controller) and controller.has_method("set_tutorial_consumables_locked"):
		controller.set_tutorial_consumables_locked(false)
	if is_instance_valid(sensei):
		sensei.queue_free()
	if is_instance_valid(layer):
		layer.queue_free()
	if is_instance_valid(controller):
		controller._finish_tutorial(completed)
	queue_free()
