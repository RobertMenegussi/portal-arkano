# ARCANO 0.5.0 PRE-ALPHA — BUILD 0630
## Tutorial pacing + chest consumable belt

### Tutorial pacing
- Movement lesson now completes only after the player deliberately moves LEFT, RIGHT, UP and DOWN for a short amount of time in each direction.
- The objective card shows a live checkmark for each completed direction.
- Orbital's auto-attack target is now a harmless stationary slime with 5 HP, lasting roughly several baseline attacks instead of disappearing instantly.
- Tutorial XP is spread around the Sensei in a wide ring and each sample uses a reduced attraction radius, so the player collects the samples progressively.
- Tutorial Safe Mode prevents health from reaching zero during the entire lesson.
- The Arcane Surge lesson starts at 99.1 Flow, suspends idle Flow decay, guards Flow against damage loss, and uses a harmless target so the mechanic can be observed reliably.

### Common field relic lesson
- Floor relics are explicitly separated from chest relics: floor relics activate immediately on touch.
- Healing, Magnet and Annihilation are now taught one at a time with real controlled demonstrations.
- Healing starts with an intentional missing-health state.
- Magnet gets its own scattered XP field.
- Annihilation gets a dedicated durable target pack so its instant-clear behavior is obvious.

### Chest relic system
- Silver, Gold and Elite chest rewards are now single-use consumables instead of firing immediately when the chest opens.
- There are 9 consumable seals bound to keyboard keys 1 through 9.
- A chest reward occupies the first empty seal and stays there until manually released.
- The HUD now displays the 1–9 chest relic belt and filled-slot symbols.
- Tutorial chest rewards are deterministic for teaching: Silver gives a Healing Seal and Gold gives Dragon Breath.
- The tutorial explains Silver vs Gold reward families, then teaches Dragon Breath through the actual numbered slot it was stored in.
- During the Dragon Breath demonstration, normal attacks are locked so Orbital cannot quietly kill the demonstration pack first.
- Elite chests now store a one-use Arcane Guard.

### Dialogue polish
- Whole-dialogue-card motion was reduced substantially: 5 px entrance travel, very short/sub-pixel emotion reaction, no persistent large bobbing.
- The final lesson naturally introduces Bosses and reveals that the Sensei himself will eventually be one of them.

### Localization
All new/changed player-facing copy is present in:
- English (default)
- PT-BR
- Japanese
- Spanish

### Validation note
Godot is not installed in this execution environment, so this build received static source validation and ZIP integrity validation, not an engine runtime playtest.
