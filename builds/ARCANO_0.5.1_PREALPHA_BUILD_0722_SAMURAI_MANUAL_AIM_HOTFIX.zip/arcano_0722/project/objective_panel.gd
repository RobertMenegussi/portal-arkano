extends Control

var title_text: String = "OBJETIVO"
var body_text: String = ""
var area_text: String = ""
var t: float = 0.0
var changed_t: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_objective(value: String, area: String) -> void:
	if body_text == value and area_text == area:
		return
	body_text = value
	area_text = area
	changed_t = 1.0
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	changed_t = move_toward(changed_t,0.0,delta*2.5)
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var panel: Rect2 = Rect2(Vector2.ZERO,size)
	var y_off: float = -3.0 * sin(changed_t * PI)
	draw_rect(Rect2(panel.position+Vector2(0,y_off),panel.size),Color(1,1,1,0.80),true)
	draw_rect(Rect2(panel.position+Vector2(0,y_off),panel.size),Color(0.08,0.08,0.08,0.14),false,1.0)
	draw_line(Vector2(12,35+y_off),Vector2(size.x-12,35+y_off),Color(0.08,0.08,0.08,0.10),1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(14,22+y_off),area_text.to_upper(),HORIZONTAL_ALIGNMENT_LEFT,size.x-28,10,Color(0.08,0.08,0.08,0.42))
		var lines: Array[String] = _wrap_text(font,body_text,12,size.x-28.0,2)
		for i in range(lines.size()):
			draw_string(font,Vector2(14,51+y_off+float(i)*14.0),lines[i],HORIZONTAL_ALIGNMENT_LEFT,size.x-28,12,ink)
	# live corner pulse
	draw_circle(Vector2(size.x-17,18+y_off),2.0+sin(t*3.0)*0.35,Color(0.08,0.08,0.08,0.42))

func _wrap_text(font, value: String, font_size: int, width: float, max_lines: int) -> Array[String]:
	var out: Array[String] = []
	var words: PackedStringArray = value.split(" ")
	var current: String = ""
	for word in words:
		var candidate: String = word if current == "" else current + " " + word
		if font.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= width:
			current = candidate
		else:
			if current != "":
				out.append(current)
			if out.size() >= max_lines:
				break
			current = word
	if out.size() < max_lines and current != "":
		out.append(current)
	return out
