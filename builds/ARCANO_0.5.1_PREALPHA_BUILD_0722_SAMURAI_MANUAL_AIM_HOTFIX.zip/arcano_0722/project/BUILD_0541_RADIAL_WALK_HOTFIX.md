# ARCANO Build 0541 — Radial / Walk Hotfix

- Radial menu now closes when clicking anywhere outside its buttons.
- Invisible dismiss layer only exists while radial menu is open.
- Player locomotion reworked for all classes:
  - small hop per step
  - alternating foot lift
  - subtle arm counter-swing
  - reactive shadow scaling
  - slightly softer cadence
