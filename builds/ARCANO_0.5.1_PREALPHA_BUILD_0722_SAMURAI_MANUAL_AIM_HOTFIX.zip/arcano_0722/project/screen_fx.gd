extends ColorRect

var blur: float = 0.0
var blur_target: float = 0.0
var flash: float = 0.0
var flash_target: float = 0.0
var flash_color: Color = Color("#ffffff")
var zoom_fx: float = 0.0
var zoom_target: float = 0.0
var vignette: float = 0.18
var post_fx_enabled: bool = true
var time_value: float = 0.0
var surge_strength: float = 0.0
var surge_target: float = 0.0

func _ready() -> void:
	add_to_group("screen_fx")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var shader: Shader = Shader.new()
	shader.code = """
shader_type canvas_item;
uniform sampler2D screen_texture : hint_screen_texture, repeat_disable, filter_linear_mipmap;
uniform float blur_amount = 0.0;
uniform float flash_strength = 0.0;
uniform vec4 flash_color : source_color = vec4(1.0);
uniform float zoom_amount = 0.0;
uniform float vignette_strength = 0.18;
uniform float time_value = 0.0;
uniform float enabled = 1.0;
uniform float surge_strength = 0.0;

void fragment() {
	vec2 base_uv = SCREEN_UV;
	vec2 centered = base_uv - vec2(0.5);
	float surge_wave = sin(length(centered) * 42.0 - time_value * 7.0);
	vec2 surge_offset = centered * surge_wave * 0.0032 * surge_strength * enabled;
	vec2 uv = vec2(0.5) + centered * (1.0 - zoom_amount * enabled) + surge_offset;
	vec2 px = SCREEN_PIXEL_SIZE * blur_amount * enabled;
	vec4 c = texture(screen_texture, uv) * 0.44;
	c += texture(screen_texture, uv + vec2(px.x, 0.0)) * 0.14;
	c += texture(screen_texture, uv - vec2(px.x, 0.0)) * 0.14;
	c += texture(screen_texture, uv + vec2(0.0, px.y)) * 0.14;
	c += texture(screen_texture, uv - vec2(0.0, px.y)) * 0.14;
	float d = length(centered * vec2(1.0, 0.88));
	float vig = smoothstep(0.30, 0.76, d) * vignette_strength * enabled;
	c.rgb *= 1.0 - vig;
	float haze = 0.5 + 0.5 * sin(base_uv.x * 7.0 + base_uv.y * 16.0 + time_value * 0.12);
	c.rgb = mix(c.rgb, vec3(0.90, 0.91, 0.87), haze * 0.035 * enabled);
	vec2 chroma = SCREEN_PIXEL_SIZE * (0.40 + blur_amount * 0.22) * enabled;
	float r = texture(screen_texture, uv + chroma * vec2(1.0, -0.35)).r;
	float b = texture(screen_texture, uv - chroma * vec2(0.8, -0.15)).b;
	c.r = mix(c.r, r, 0.12 * enabled);
	c.b = mix(c.b, b, 0.12 * enabled);
	float grain = fract(sin(dot(base_uv * vec2(913.7, 731.3) + vec2(time_value), vec2(12.9898,78.233))) * 43758.5453);
	c.rgb += (grain - 0.5) * (0.010 + surge_strength * 0.012) * enabled;
	float ring = 1.0 - smoothstep(0.0, 0.49, abs(fract(d * 8.0 - time_value * 0.8) - 0.5));
	c.rgb *= 1.0 - surge_strength * 0.035 + ring * surge_strength * 0.018;
	c.rgb = mix(c.rgb, flash_color.rgb, clamp(flash_strength * enabled, 0.0, 1.0));
	COLOR = vec4(c.rgb, 1.0);
}
"""
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = shader
	material = mat

func set_post_fx_enabled(value: bool) -> void:
	post_fx_enabled = value
	if not value:
		blur = 0.0
		blur_target = 0.0
		zoom_fx = 0.0
		zoom_target = 0.0

func _process(delta: float) -> void:
	time_value += delta
	blur = move_toward(blur, blur_target, delta * 28.0)
	flash = move_toward(flash, flash_target, delta * 6.5)
	zoom_fx = move_toward(zoom_fx, zoom_target, delta * 5.5)
	surge_strength = move_toward(surge_strength,surge_target,delta*2.4)
	blur_target = move_toward(blur_target, 0.0, delta * 13.0)
	flash_target = move_toward(flash_target, 0.0, delta * 5.0)
	zoom_target = move_toward(zoom_target, 0.0, delta * 4.2)
	if material is ShaderMaterial:
		var mat: ShaderMaterial = material as ShaderMaterial
		mat.set_shader_parameter("blur_amount", blur)
		mat.set_shader_parameter("flash_strength", flash)
		mat.set_shader_parameter("flash_color", flash_color)
		mat.set_shader_parameter("zoom_amount", zoom_fx)
		mat.set_shader_parameter("vignette_strength", vignette)
		mat.set_shader_parameter("time_value", time_value)
		mat.set_shader_parameter("enabled", 1.0 if post_fx_enabled else 0.0)
		mat.set_shader_parameter("surge_strength",surge_strength)


func set_arcane_surge(enabled_value: bool) -> void:
	surge_target = 1.35 if enabled_value else 0.0
	if enabled_value:
		zoom_target = maxf(zoom_target,0.018)
		blur_target = maxf(blur_target,0.55)

func pulse_dash() -> void:
	blur_target = maxf(blur_target, 1.8)
	zoom_target = maxf(zoom_target, 0.015)
	flash_color = Color("#ffffff")
	flash_target = maxf(flash_target, 0.035)

func pulse_damage() -> void:
	blur_target = maxf(blur_target, 1.5)
	zoom_target = maxf(zoom_target, 0.022)
	flash_color = Color("#2b0000")
	flash_target = maxf(flash_target, 0.10)

func pulse_hit() -> void:
	blur_target = maxf(blur_target, 0.55)

func pulse_kill() -> void:
	# Kill feedback stays local/visual; no camera punch for repetitive kills.
	blur_target = maxf(blur_target, 0.28)
	flash_color = Color("#111111")
	flash_target = maxf(flash_target, 0.012)

func pulse_spawn() -> void:
	blur_target = maxf(blur_target, 1.2)
	zoom_target = maxf(zoom_target, 0.016)
	flash_color = Color("#ffffff")
	flash_target = maxf(flash_target, 0.06)

func pulse_magic() -> void:
	blur_target = maxf(blur_target, 0.35)

func pulse_lightning() -> void:
	blur_target = maxf(blur_target, 0.85)
	zoom_target = maxf(zoom_target, 0.018)
	flash_color = Color("#ffffff")
	flash_target = maxf(flash_target, 0.075)

func pulse_rift() -> void:
	blur_target = maxf(blur_target, 1.0)
	zoom_target = maxf(zoom_target, 0.025)
	flash_color = Color("#111111")
	flash_target = maxf(flash_target, 0.035)

func pulse_boss() -> void:
	blur_target = maxf(blur_target, 1.5)
	zoom_target = maxf(zoom_target, 0.035)
	flash_color = Color("#111111")
	flash_target = maxf(flash_target, 0.05)

func pulse_boss_mark() -> void:
	blur_target = maxf(blur_target, 1.2)
	zoom_target = maxf(zoom_target, 0.022)
	flash_color = Color("#ffffff")
	flash_target = maxf(flash_target, 0.065)

func pulse_enemy_hit() -> void:
	blur_target = maxf(blur_target, 0.72)
	zoom_target = maxf(zoom_target, 0.012)
	flash_color = Color("#ffffff")
	flash_target = maxf(flash_target, 0.025)

func pulse_enemy_land() -> void:
	blur_target = maxf(blur_target, 0.90)
	zoom_target = maxf(zoom_target, 0.018)

func pulse_storm_charge() -> void:
	blur_target = maxf(blur_target, 0.42)
	zoom_target = maxf(zoom_target, 0.010)

func pulse_rift_cast() -> void:
	blur_target = maxf(blur_target, 0.46)
	zoom_target = maxf(zoom_target, 0.012)

func pulse_rift_hit() -> void:
	blur_target = maxf(blur_target, 0.64)
	zoom_target = maxf(zoom_target, 0.014)
