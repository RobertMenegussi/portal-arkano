extends Control

var player
var refresh_timer: float = 0.0
var threats: Array = []
var redraw_timer: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	z_index = 30

func _process(delta: float) -> void:
	refresh_timer -= delta
	if refresh_timer <= 0.0:
		refresh_timer = 0.15
		_refresh_threats()
	redraw_timer -= delta
	if redraw_timer <= 0.0:
		redraw_timer = 1.0/24.0
		queue_redraw()

func _refresh_threats() -> void:
	threats.clear()
	for node in get_tree().get_nodes_in_group("mini_boss"):
		if _is_alive_threat(node, true):
			threats.append({"node":node,"kind":"boss"})
	for node in get_tree().get_nodes_in_group("elite"):
		if _is_alive_threat(node, false):
			threats.append({"node":node,"kind":"elite"})
			if threats.size() >= 4:
				break

func _is_alive_threat(node, is_boss: bool) -> bool:
	if not is_instance_valid(node) or not node.is_inside_tree():
		return false
	if is_boss:
		if node.get("defeated") == true:
			return false
		if node.get("battle_started") != null and node.get("battle_started") != true:
			return false
	else:
		if node.get("dead") == true:
			return false
	return true

func _draw() -> void:
	if not is_instance_valid(player):
		return
	var viewport_size: Vector2 = get_viewport_rect().size
	if viewport_size.x <= 1.0 or viewport_size.y <= 1.0:
		return
	var center: Vector2 = viewport_size * 0.5
	var safe_margin: float = 44.0
	var visible_rect: Rect2 = Rect2(Vector2(24.0,24.0),viewport_size-Vector2(48.0,48.0))
	var font = ThemeDB.fallback_font
	for data_value in threats:
		var data: Dictionary = data_value
		var target = data.get("node")
		if not is_instance_valid(target):
			continue
		var screen_pos: Vector2 = target.get_global_transform_with_canvas().origin
		if visible_rect.has_point(screen_pos):
			continue
		var direction: Vector2 = screen_pos-center
		if direction.length_squared() < 0.001:
			continue
		direction = direction.normalized()
		var half: Vector2 = viewport_size*0.5-Vector2(safe_margin,safe_margin)
		var tx: float = half.x/maxf(0.0001,absf(direction.x))
		var ty: float = half.y/maxf(0.0001,absf(direction.y))
		var distance_to_edge: float = minf(tx,ty)
		var anchor: Vector2 = center+direction*distance_to_edge
		_draw_threat_arrow(anchor,direction,str(data.get("kind","elite")),font)

func _draw_threat_arrow(anchor: Vector2,direction: Vector2,kind: String,font) -> void:
	var perp: Vector2 = Vector2(-direction.y,direction.x)
	var tip: Vector2 = anchor+direction*11.0
	var back: Vector2 = anchor-direction*10.0
	var poly: PackedVector2Array = PackedVector2Array([
		tip,
		back+perp*8.0,
		back-perp*8.0
	])
	var fill: Color = Color("#d4b36d") if kind == "boss" else Color("#ece8df")
	draw_colored_polygon(poly,Color(0.03,0.03,0.03,0.88))
	var inner: PackedVector2Array = PackedVector2Array([
		anchor+direction*7.0,
		anchor-direction*6.0+perp*4.8,
		anchor-direction*6.0-perp*4.8
	])
	draw_colored_polygon(inner,fill)
	draw_circle(anchor-direction*17.0,8.0,Color(0.03,0.03,0.03,0.82))
	draw_circle(anchor-direction*17.0,4.0,fill)
	if font != null:
		var label: String = Loc.t("hud.boss") if kind == "boss" else Loc.t("hud.elite")
		var text_pos: Vector2 = anchor-direction*31.0+Vector2(-22.0,4.0)
		draw_string(font,text_pos,label,HORIZONTAL_ALIGNMENT_CENTER,44.0,8,Color(0.05,0.05,0.05,0.82))
