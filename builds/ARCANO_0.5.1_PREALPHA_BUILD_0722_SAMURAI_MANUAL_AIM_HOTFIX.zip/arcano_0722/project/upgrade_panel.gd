extends Control

signal close_requested

const UpgradeCatalog = preload("res://upgrade_catalog.gd")

var player
var mage_type: String = "orbit"
var selected_slot: int = 0
var offers: Array = []
var slot_buttons: Array = []
var offer_buttons: Array = []
var description_label: Label
var class_label: Label

func configure(target) -> void:
	player = target
	mage_type = str(player.mage_type) if is_instance_valid(player) else "orbit"

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	_build_ui()
	_reroll()

func refresh_for_player(target) -> void:
	player = target
	mage_type = str(player.mage_type) if is_instance_valid(player) else "orbit"
	_refresh_slots()
	_refresh_offers()

func _build_ui() -> void:
	position = Vector2.ZERO
	size = Vector2(960,540)
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.03,0.03,0.03,0.58)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)

	var panel: ColorRect = ColorRect.new()
	panel.position = Vector2(96,54)
	panel.size = Vector2(768,432)
	panel.color = Color(0.945,0.925,0.88,0.985)
	add_child(panel)

	var title: Label = Label.new()
	title.position = Vector2(28,20)
	title.size = Vector2(500,30)
	title.text = "INVENTÁRIO ARCANO  •  3 SLOTS"
	title.add_theme_font_size_override("font_size",21)
	panel.add_child(title)

	class_label = Label.new()
	class_label.position = Vector2(530,24)
	class_label.size = Vector2(200,24)
	class_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	class_label.add_theme_font_size_override("font_size",10)
	class_label.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.48))
	panel.add_child(class_label)

	var hint: Label = Label.new()
	hint.position = Vector2(28,54)
	hint.size = Vector2(710,32)
	hint.text = "Escolha um slot e equipe um upgrade. O mesmo item se adapta à classe atual; a descrição mostra só o efeito que importa agora."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size",10)
	hint.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.46))
	panel.add_child(hint)

	for i in range(3):
		var b: Button = Button.new()
		b.position = Vector2(28 + float(i) * 238.0,98)
		b.size = Vector2(220,54)
		b.process_mode = Node.PROCESS_MODE_ALWAYS
		b.pressed.connect(_select_slot.bind(i))
		panel.add_child(b)
		slot_buttons.append(b)

	var choose: Label = Label.new()
	choose.position = Vector2(28,174)
	choose.size = Vector2(300,24)
	choose.text = "ESCOLHA UM UPGRADE"
	choose.add_theme_font_size_override("font_size",13)
	panel.add_child(choose)

	for i in range(3):
		var card: Button = Button.new()
		card.position = Vector2(28 + float(i) * 238.0,205)
		card.size = Vector2(220,102)
		card.process_mode = Node.PROCESS_MODE_ALWAYS
		card.alignment = HORIZONTAL_ALIGNMENT_LEFT
		card.pressed.connect(_equip_offer.bind(i))
		card.mouse_entered.connect(_show_offer_description.bind(i))
		panel.add_child(card)
		offer_buttons.append(card)

	description_label = Label.new()
	description_label.position = Vector2(28,322)
	description_label.size = Vector2(470,72)
	description_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description_label.add_theme_font_size_override("font_size",11)
	description_label.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.58))
	panel.add_child(description_label)

	var reroll: Button = Button.new()
	reroll.position = Vector2(510,332)
	reroll.size = Vector2(110,40)
	reroll.text = "REROLL [U]"
	reroll.process_mode = Node.PROCESS_MODE_ALWAYS
	reroll.pressed.connect(_reroll)
	panel.add_child(reroll)

	var close: Button = Button.new()
	close.position = Vector2(628,332)
	close.size = Vector2(110,40)
	close.text = "FECHAR [I]"
	close.process_mode = Node.PROCESS_MODE_ALWAYS
	close.pressed.connect(func(): close_requested.emit())
	panel.add_child(close)

	_refresh_slots()

func _select_slot(index: int) -> void:
	selected_slot = clampi(index,0,2)
	_refresh_slots()

func _reroll() -> void:
	var pool: Array = UpgradeCatalog.all_ids()
	var equipped: Array = player.get_equipped_upgrades() if is_instance_valid(player) else []
	var available: Array = []
	for id_value in pool:
		var id: String = str(id_value)
		if not equipped.has(id):
			available.append(id)
	available.shuffle()
	offers.clear()
	for i in range(mini(3,available.size())):
		offers.append(str(available[i]))
	_refresh_offers()

func _equip_offer(index: int) -> void:
	if not is_instance_valid(player) or index < 0 or index >= offers.size():
		return
	var id: String = str(offers[index])
	player.equip_upgrade(selected_slot,id)
	mage_type = str(player.mage_type)
	_refresh_slots()
	_reroll()
	description_label.text = UpgradeCatalog.get_upgrade_name(id)+" equipado no slot "+str(selected_slot+1)+"."

func _show_offer_description(index: int) -> void:
	if index < 0 or index >= offers.size():
		return
	var id: String = str(offers[index])
	description_label.text = UpgradeCatalog.get_upgrade_name(id)+"\n"+UpgradeCatalog.get_description(id,mage_type)

func _refresh_slots() -> void:
	if is_instance_valid(class_label):
		class_label.text = _class_name(mage_type)
	if not is_instance_valid(player):
		return
	var equipped: Array = player.get_equipped_upgrades()
	for i in range(slot_buttons.size()):
		var id: String = str(equipped[i]) if i < equipped.size() else ""
		var prefix: String = "▶ " if i == selected_slot else ""
		slot_buttons[i].text = prefix+"SLOT "+str(i+1)+"\n"+UpgradeCatalog.get_upgrade_name(id)

func _refresh_offers() -> void:
	mage_type = str(player.mage_type) if is_instance_valid(player) else mage_type
	for i in range(offer_buttons.size()):
		if i >= offers.size():
			offer_buttons[i].text = "-"
			offer_buttons[i].disabled = true
			continue
		var id: String = str(offers[i])
		offer_buttons[i].disabled = false
		offer_buttons[i].text = UpgradeCatalog.get_upgrade_name(id)
	if not offers.is_empty():
		_show_offer_description(0)

func _class_name(kind: String) -> String:
	match kind:
		"storm": return "TEMPESTADE"
		"rift": return "FENDA"
		_: return "ORBITAL"
