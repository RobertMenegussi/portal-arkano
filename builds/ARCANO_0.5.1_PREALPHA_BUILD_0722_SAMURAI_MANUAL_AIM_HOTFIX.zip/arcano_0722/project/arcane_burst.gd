extends Node2D

var radius: float = 72.0
var damage: int = 1
var duration: float = 0.34
var elapsed: float = 0.0
var hit_ids: Dictionary = {}
var pull_strength: float = 0.0
var cached_controller = null
var visual_timer: float = 0.0
var hit_scan_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 69
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	elapsed += delta
	var progress: float = clampf(elapsed / maxf(duration, 0.001), 0.0, 1.0)
	var current_radius: float = lerpf(12.0, radius, progress)
	hit_scan_timer -= delta
	if hit_scan_timer <= 0.0:
		hit_scan_timer = 1.0 / 30.0
		var candidates: Array = get_tree().get_nodes_in_group("enemy")
		if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
			candidates = cached_controller.get_nearby_enemies(global_position, radius * 1.25)
		for enemy in candidates:
			if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
				continue
			var id: int = enemy.get_instance_id()
			var delta_pos: Vector2 = enemy.global_position - global_position
			var d2: float = delta_pos.length_squared()
			if absf(pull_strength) > 0.001 and d2 > 1.0 and d2 < radius * radius * 1.44 and enemy.has_method("apply_external_force"):
				var distance: float = sqrt(d2)
				enemy.apply_external_force(-delta_pos / distance * pull_strength * (1.0 - progress))
			if hit_ids.has(id):
				continue
			if d2 <= current_radius * current_radius:
				hit_ids[id] = true
				var dir: Vector2 = delta_pos.normalized() if d2 > 0.001 else Vector2.RIGHT
				enemy.take_damage(damage, dir)
	if elapsed >= duration:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 30.0
		queue_redraw()

func _draw() -> void:
	var p: float = clampf(elapsed / maxf(duration, 0.001), 0.0, 1.0)
	var r: float = lerpf(12.0, radius, p)
	var alpha: float = (1.0 - p) * 0.34
	var glow: Color = Color(0.80, 0.91, 1.0, 0.12 * (1.0 - p))
	draw_circle(Vector2.ZERO, r * 0.64, glow)
	for i in range(4):
		draw_arc(Vector2.ZERO, maxf(2.0, r - float(i) * 7.0), 0.0, TAU, 40, Color(0.06, 0.06, 0.06, alpha * (1.0 - float(i) * 0.16)), 2.1 - float(i) * 0.32)
	for i in range(10):
		var a: float = TAU * float(i) / 10.0 + elapsed * 2.3
		var start: Vector2 = Vector2(cos(a), sin(a)) * r * 0.28
		var finish: Vector2 = Vector2(cos(a + 0.13), sin(a + 0.13)) * r * 0.92
		draw_line(start, finish, Color(0.08, 0.08, 0.08, alpha * 0.75), 1.4)
		if i % 2 == 0:
			draw_circle(finish, 1.2 + alpha * 2.0, Color(1, 1, 1, 0.16 * alpha * 3.0))
