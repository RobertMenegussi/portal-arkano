# ARCANO Build 0504 — Horde / Elite / Targeting Balance

- Auto-target now ignores enemies outside the visible viewport.
- First elite HP reduced substantially while maintaining time scaling.
- Enemy density increased at every stage.
- Spawn Director adds extra slime/spider bodies to keep a weak-mob backbone.
- Advanced enemies remain in the composition instead of being replaced.
- XP requirement curve increased moderately to compensate for higher mob density.
- New core Tome: Tomo do Caçador (3 ranks, +12% expected damage vs Elite/Boss per rank).
- New mechanic Tome: Espólio do Campeão (Elite/Boss kill restores 1 dash and gives +15% movement for 10s).
