extends Area2D

const HitFxScript = preload("res://hit_fx.gd")
const ArcaneBurstScript = preload("res://arcane_burst.gd")

@export var speed: float = 660.0
@export var lifetime: float = 1.60
@export var damage: int = 1

var direction: Vector2 = Vector2.RIGHT
var age: float = 0.0
var split_on_hit: bool = false
var ricochet_count: int = 0
var explode_on_hit: bool = false
var hit_ids: Dictionary = {}
var visual_timer: float = 0.0
var cached_controller = null
var expire_at_msec: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	collision_layer = 8
	collision_mask = 1 | 4
	monitoring = true
	z_index = 28
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 5.5
	collider.shape = shape
	add_child(collider)
	body_entered.connect(_on_body_entered)
	cached_controller = get_tree().get_first_node_in_group("endless_controller")
	expire_at_msec = Time.get_ticks_msec() + int(lifetime * 1000.0)

func _physics_process(delta: float) -> void:
	age += delta
	if Time.get_ticks_msec() >= expire_at_msec:
		queue_free()
		return
	global_position += direction * speed * delta
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 30.0
		queue_redraw()

func _on_body_entered(body: Node) -> void:
	if (body.is_in_group("enemy") or body.is_in_group("basic_target")) and body.has_method("take_damage"):
		var body_id: int = body.get_instance_id()
		if hit_ids.has(body_id):
			return
		hit_ids[body_id] = true
		body.take_damage(damage, direction)
		_spawn_impact()
		if explode_on_hit:
			_spawn_burst()
		if split_on_hit:
			_spawn_split_projectiles()
		if ricochet_count > 0 and _try_ricochet(body):
			return
		queue_free()
	elif body is StaticBody2D:
		_spawn_impact()
		if explode_on_hit:
			_spawn_burst()
		queue_free()

func _try_ricochet(previous_body: Node) -> bool:
	var best = null
	var best_distance_sq: float = 190.0 * 190.0
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	var controller = cached_controller if is_instance_valid(cached_controller) else get_tree().get_first_node_in_group("endless_controller")
	if is_instance_valid(controller) and controller.has_method("get_nearby_enemies"):
		candidates = controller.get_nearby_enemies(global_position, 210.0)
	for enemy in candidates:
		if enemy == previous_body or not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var id: int = enemy.get_instance_id()
		if hit_ids.has(id):
			continue
		var distance_sq: float = global_position.distance_squared_to(enemy.global_position)
		if distance_sq < best_distance_sq:
			best = enemy
			best_distance_sq = distance_sq
	if best == null:
		return false
	var next_dir: Vector2 = (best.global_position - global_position).normalized()
	if next_dir.length_squared() < 0.001:
		return false
	ricochet_count -= 1
	direction = next_dir
	global_position += direction * 7.0
	queue_redraw()
	get_tree().call_group("screen_fx", "pulse_hit")
	return true

func _spawn_split_projectiles() -> void:
	for sign_value in [-1.0, 1.0]:
		var child = get_script().new()
		child.direction = direction.rotated(0.34 * sign_value)
		child.damage = maxi(1, damage - 1)
		child.speed = speed * 0.88
		child.lifetime = 0.62
		child.split_on_hit = false
		child.ricochet_count = 0
		child.explode_on_hit = false
		child.global_position = global_position + child.direction * 8.0
		get_tree().current_scene.add_child(child)

func _spawn_burst() -> void:
	var burst = ArcaneBurstScript.new()
	burst.radius = 62.0
	burst.damage = maxi(1, damage)
	burst.global_position = global_position
	get_tree().current_scene.add_child(burst)
	get_tree().call_group("screen_fx", "pulse_rift_hit")

func _spawn_impact() -> void:
	var controller = cached_controller if is_instance_valid(cached_controller) else get_tree().get_first_node_in_group("endless_controller")
	if is_instance_valid(controller) and controller.has_method("allow_cosmetic_fx") and not bool(controller.allow_cosmetic_fx()):
		return
	var fx = HitFxScript.new()
	fx.global_position = global_position
	fx.direction = direction
	fx.tint = Color("#111111")
	get_tree().current_scene.add_child(fx)

func _draw() -> void:
	var dir_n: Vector2 = direction.normalized()
	if dir_n.length_squared() < 0.001:
		dir_n = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir_n.y, dir_n.x)
	var core_color: Color = Color("#f6f4ee")
	var edge_color: Color = Color("#111111")
	var accent: Color = Color(0.80, 0.90, 1.0, 0.52)
	for i in range(6, 0, -1):
		var trail_t: float = float(i)
		var p: Vector2 = -dir_n * trail_t * 9.0
		var sway: Vector2 = side * sin(age * 30.0 + trail_t * 0.85) * (1.4 + trail_t * 0.18)
		var alpha: float = 0.03 + trail_t * 0.018
		var r: float = 1.2 + trail_t * 0.42
		draw_circle(p + sway, r * 1.7, Color(accent.r, accent.g, accent.b, alpha * 0.20))
		_draw_diamond(p + sway, r, Color(accent.r, accent.g, accent.b, alpha))
		if i <= 4:
			draw_line(p + sway + side * 0.7, p + sway - dir_n * 10.0, Color(edge_color.r, edge_color.g, edge_color.b, alpha * 0.34), 1.0)
	var back_tip: Vector2 = -dir_n * 10.5
	var front_tip: Vector2 = dir_n * 13.0
	var crystal: PackedVector2Array = PackedVector2Array([
		front_tip,
		side * 6.6 + dir_n * 1.0,
		back_tip + side * 2.3,
		-dir_n * 3.0,
		back_tip - side * 2.3,
		-side * 6.6 + dir_n * 1.0
	])
	draw_circle(Vector2.ZERO, 11.0, Color(accent.r, accent.g, accent.b, 0.14))
	draw_colored_polygon(crystal, core_color)
	draw_polyline(PackedVector2Array([crystal[0], crystal[1], crystal[2], crystal[3], crystal[4], crystal[5], crystal[0]]), edge_color, 1.25)
	draw_line(back_tip + dir_n * 1.5, front_tip - dir_n * 4.0, Color(0.08, 0.08, 0.08, 0.46), 1.1)
	draw_line(side * 3.2, front_tip - side * 0.5, Color(1, 1, 1, 0.24), 1.0)
	for i in range(3):
		var angle: float = age * 11.0 + float(i) * TAU / 3.0
		var spark: Vector2 = Vector2(cos(angle), sin(angle)) * (7.2 + sin(age * 14.0 + float(i)) * 1.3)
		draw_circle(spark, 1.1, Color(0.08, 0.08, 0.08, 0.16))

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(0, -radius), center + Vector2(radius * 0.72, 0), center + Vector2(0, radius), center + Vector2(-radius * 0.72, 0)
	])
	draw_colored_polygon(poly, color)
