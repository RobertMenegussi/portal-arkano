# Build 0468 — Orbital / Flux pacing

- Orbital base shot cooldown: 0.48s -> 0.82s (~2.08/s -> ~1.22/s).
- Orbital Flux cadence: fixed 0.29s -> max(0.52s, base cooldown * 0.72).
- Flux gains reduced heavily: normal kill 0.65, elite kill 7.0, enemy hit 0.18x strength, perfect dodge 4.0.
- After Surto ends, Flux has 22s of Resonance lockout before it can charge again.
- Tome da Celeridade on Orbital: 0.88x -> 0.92x cooldown per rank.
- Enxame Arcano: 0.62x -> 0.78x cooldown and reload penalty 45% -> 35%.
- HUD now displays Resonance lockout.
