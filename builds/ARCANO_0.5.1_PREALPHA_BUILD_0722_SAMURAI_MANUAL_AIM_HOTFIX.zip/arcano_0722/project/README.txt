ARCANO — GAMEPLAY SANDBOX
Build 0260

This project boots directly into a combat sandbox. Campaign/world content is intentionally not loaded while visual production is pending.

Main test keys:
F1 DEV panel | I inventory | U reroll | 1-5 enemies | 6 elite | 7 boss | 8 dummy | V wave | C class | H reset | G god | F flux | Backspace clear

See BUILD_0260_GAMEPLAY_REWORK.txt for the complete change list.
