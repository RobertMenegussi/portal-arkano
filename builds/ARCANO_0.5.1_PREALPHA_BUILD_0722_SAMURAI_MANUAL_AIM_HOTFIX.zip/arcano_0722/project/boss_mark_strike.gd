extends Node2D

var player
var follow_time: float = 0.52
var lock_time: float = 0.36
var t: float = 0.0
var locked: bool = false
var hit_done: bool = false
var radius: float = 56.0

func configure(target) -> void:
	player = target
	if is_instance_valid(player):
		global_position = player.global_position

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 72

func _process(delta: float) -> void:
	t += delta
	if not locked and t < follow_time and is_instance_valid(player):
		global_position = global_position.lerp(player.global_position, 0.28)
	elif not locked:
		locked = true
	if not hit_done and t >= follow_time + lock_time:
		hit_done = true
		_impact()
	if t >= follow_time + lock_time + 0.28:
		queue_free()
		return
	queue_redraw()

func _impact() -> void:
	if is_instance_valid(player) and player.active and global_position.distance_to(player.global_position) <= radius:
		var dir: Vector2 = (player.global_position-global_position).normalized()
		if dir.length_squared() < 0.001:
			dir = Vector2.DOWN
		player.take_damage(1, dir)
	get_tree().call_group("screen_fx", "pulse_boss_mark")
	get_tree().call_group("audio_bus", "play_boss_mark")

func _draw() -> void:
	var ink: Color = Color("#111111")
	var impact_at: float = follow_time + lock_time
	if t < impact_at:
		var p: float = clampf(t/impact_at,0.0,1.0)
		var eye: PackedVector2Array = PackedVector2Array()
		for i in range(28):
			var a: float = TAU*float(i)/28.0
			eye.append(Vector2(cos(a)*34.0, sin(a)*16.0))
		draw_polyline(eye, Color(0.08,0.08,0.08,0.16+p*0.18), 1.5)
		draw_circle(Vector2.ZERO, 5.0+p*2.0, Color(0.08,0.08,0.08,0.18+p*0.18))
		draw_arc(Vector2.ZERO, radius, -PI*0.5, -PI*0.5+TAU*p, 34, Color(0.08,0.08,0.08,0.24), 1.6)
	else:
		var q: float = clampf((t-impact_at)/0.28,0.0,1.0)
		var alpha: float = 1.0-q
		for i in range(5):
			var x: float = -20.0 + float(i)*10.0
			draw_line(Vector2(x,-210), Vector2(x*0.2,0), Color(ink.r,ink.g,ink.b,0.42*alpha), 2.2)
		draw_circle(Vector2.ZERO, radius*(0.4+q*0.7), Color(0.08,0.08,0.08,0.11*alpha))
