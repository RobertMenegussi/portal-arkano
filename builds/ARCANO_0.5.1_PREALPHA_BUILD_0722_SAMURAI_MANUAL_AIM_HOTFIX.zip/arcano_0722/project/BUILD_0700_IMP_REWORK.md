# BUILD 0700 — IMP / DIABRETE REWORK

## Focus
Replaced the old slime-slot creature with a richer diabrete / imp enemy.

## What changed
- `_draw_slime()` no longer draws a slime or the previous hopper critter concept.
- The enemy now appears as a small imp / diabrete with:
  - separate head and torso silhouette
  - animated horns, tail and cloth shapes
  - expressive eyes, nose and fangs
  - springy arms and hind legs that better match the jump behavior
  - richer layered body rendering to feel less static and more premium
- Kept the same underlying gameplay / attack logic so no spawn or balance logic needed to change.

## Files changed
- enemy.gd
- endless_main.gd
