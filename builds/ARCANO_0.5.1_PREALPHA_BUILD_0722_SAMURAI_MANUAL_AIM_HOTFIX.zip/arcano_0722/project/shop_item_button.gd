extends Button

@export var item_title: String = "Melhoria"
@export var item_description: String = "Descrição"
@export var status_text: String = "PERMANENTE"
@export var price: int = 0
@export var accent_kind: String = "orbit"
@export var maxed: bool = false

var hover_t: float = 0.0
var pressed_t: float = 0.0
var hovered_local: bool = false
var pressed_local: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	focus_mode = Control.FOCUS_NONE
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_ARROW if maxed else Control.CURSOR_POINTING_HAND
	clip_contents = true
	disabled = maxed
	mouse_entered.connect(_on_enter)
	mouse_exited.connect(_on_exit)
	button_down.connect(_on_down)
	button_up.connect(_on_up)
	var clear: StyleBoxFlat = StyleBoxFlat.new()
	clear.bg_color = Color(0,0,0,0)
	add_theme_stylebox_override("normal",clear)
	add_theme_stylebox_override("hover",clear)
	add_theme_stylebox_override("pressed",clear)
	add_theme_stylebox_override("disabled",clear)
	add_theme_stylebox_override("focus",clear)

func _on_enter() -> void:
	if not maxed:
		hovered_local = true

func _on_exit() -> void:
	hovered_local = false
	pressed_local = false

func _on_down() -> void:
	if not maxed:
		pressed_local = true

func _on_up() -> void:
	pressed_local = false

func _process(delta: float) -> void:
	hover_t = move_toward(hover_t,1.0 if hovered_local else 0.0,delta*9.0)
	pressed_t = move_toward(pressed_t,1.0 if pressed_local else 0.0,delta*16.0)
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var alpha: float = 0.48 if maxed else 0.86 + hover_t*0.09
	var rect: Rect2 = Rect2(Vector2(2,2 + pressed_t*1.2 - hover_t*1.5),size-Vector2(4,4))
	draw_rect(Rect2(rect.position+Vector2(0,4),rect.size-Vector2(0,4)),Color(0.08,0.08,0.08,0.045),true)
	draw_rect(rect,Color(1,1,1,alpha),true)
	draw_rect(rect,Color(0.08,0.08,0.08,0.16),false,1.0)
	draw_line(Vector2(rect.position.x+10,rect.position.y+38),Vector2(rect.end.x-10,rect.position.y+38),Color(0.08,0.08,0.08,0.08),1.0)

	var crest: Vector2 = rect.position+Vector2(22,21)
	_draw_crest(crest,ink,paper)
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var left: float = rect.position.x+42.0
	var right_pad: float = 68.0
	var usable: float = rect.size.x-42.0-right_pad
	var title_size: int = 14
	while title_size > 11 and font.get_string_size(item_title,HORIZONTAL_ALIGNMENT_LEFT,-1,title_size).x > usable:
		title_size -= 1
	draw_string(font,Vector2(left,rect.position.y+25),item_title,HORIZONTAL_ALIGNMENT_LEFT,usable,title_size,ink)

	var badge: Rect2 = Rect2(rect.end.x-61.0,rect.position.y+9.0,50.0,24.0)
	draw_rect(badge,Color(0.08,0.08,0.08,0.065),true)
	draw_rect(badge,Color(0.08,0.08,0.08,0.18),false,1.0)
	draw_string(font,Vector2(badge.position.x+8,badge.position.y+17),"◆ "+str(price),HORIZONTAL_ALIGNMENT_LEFT,40,11,ink)

	var lines: Array[String] = _wrap_text(font,item_description,11,rect.size.x-24.0,2)
	for i in range(lines.size()):
		draw_string(font,Vector2(rect.position.x+12,rect.position.y+57+float(i)*15.0),lines[i],HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-24.0,11,Color(0.08,0.08,0.08,0.58))

	var status_color: Color = Color(0.08,0.08,0.08,0.36)
	if maxed:
		status_color = Color(0.08,0.08,0.08,0.62)
	draw_string(font,Vector2(rect.position.x+12,rect.end.y-10),status_text,HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-24.0,9,status_color)
	if hover_t > 0.02:
		draw_line(Vector2(rect.position.x+12,rect.end.y-4),Vector2(rect.position.x+12+94.0*hover_t,rect.end.y-4),Color(0.08,0.08,0.08,0.18),1.0)

func _draw_crest(center: Vector2, ink: Color, paper: Color) -> void:
	match accent_kind:
		"storm":
			draw_polyline(PackedVector2Array([center+Vector2(-4,-8),center+Vector2(2,-2),center+Vector2(-1,2),center+Vector2(6,8)]),ink,1.8)
		"rift":
			draw_arc(center,8.0,-1.3,1.3,12,ink,1.5)
			draw_arc(center+Vector2(3,0),5.0,PI-1.1,PI+1.1,10,Color(0.08,0.08,0.08,0.28),1.0)
		_:
			var d: PackedVector2Array = PackedVector2Array([center+Vector2(0,-8),center+Vector2(6,0),center+Vector2(0,8),center+Vector2(-6,0)])
			draw_colored_polygon(d,paper)
			draw_polyline(PackedVector2Array([d[0],d[1],d[2],d[3],d[0]]),ink,1.1)

func _wrap_text(font, value: String, font_size: int, width: float, max_lines: int) -> Array[String]:
	var out: Array[String] = []
	var words: PackedStringArray = value.split(" ")
	var current: String = ""
	for word in words:
		var candidate: String = word if current == "" else current+" "+word
		if font.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= width:
			current = candidate
		else:
			if current != "":
				out.append(current)
			if out.size() >= max_lines:
				break
			current = word
	if out.size() < max_lines and current != "":
		out.append(current)
	if out.size() == max_lines:
		var consumed: int = 0
		for line in out:
			consumed += line.split(" ").size()
		if consumed < words.size():
			var last: String = out[max_lines-1]
			while last.length() > 3 and font.get_string_size(last+"…",HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x > width:
				last = last.left(last.length()-1)
			out[max_lines-1] = last+"…"
	return out
