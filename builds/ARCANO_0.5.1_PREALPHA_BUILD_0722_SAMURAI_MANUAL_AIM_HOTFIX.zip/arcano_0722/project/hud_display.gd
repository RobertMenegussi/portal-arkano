extends Control

const UpgradeCatalog = preload("res://upgrade_catalog.gd")

var player
var controller
var t: float = 0.0
var redraw_timer: float = 0.0

func configure(target, owner_controller = null) -> void:
	player = target
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	redraw_timer -= delta
	if redraw_timer <= 0.0:
		redraw_timer = 1.0 / 30.0
		queue_redraw()

func _draw() -> void:
	if not is_instance_valid(player):
		return
	var ink: Color = Color("#111111")
	var soft: Color = Color(0.08, 0.08, 0.08, 0.34)
	var font = ThemeDB.fallback_font
	_draw_left_status(ink, soft, font)
	_draw_flux(ink, soft, font)
	_draw_right_status(ink, soft, font)
	_draw_soft_hints(font)

func _draw_left_status(ink: Color, soft: Color, font) -> void:
	var anchor: Vector2 = Vector2(36, 500)
	var hurt: float = clampf(float(player.hurt_flash), 0.0, 1.0)
	var impact_pulse: float = absf(sin(t * 46.0)) * hurt
	draw_arc(anchor, 24.0, PI * 0.72, PI * 2.28, 28, Color(0.08, 0.08, 0.08, 0.20 + impact_pulse * 0.18), 2.2 + impact_pulse * 1.0)
	draw_arc(anchor, 29.0, PI * 0.84, PI * 2.16, 22, Color(0.94, 0.93, 0.89, 0.12 + impact_pulse * 0.10), 1.0)
	_draw_hud_portrait(anchor, ink)
	if font != null:
		draw_string(font, Vector2(68, 482), _class_name(), HORIZONTAL_ALIGNMENT_LEFT, 136, 10, Color(0.08, 0.08, 0.08, 0.66))
		draw_string(font, Vector2(68, 497), Loc.f("hud.hp", [int(player.health), int(player.max_health)]), HORIZONTAL_ALIGNMENT_LEFT, 130, 11, ink)
	var bar := Rect2(Vector2(68, 506), Vector2(148, 10))
	draw_rect(bar, Color(0.08, 0.08, 0.08, 0.08), true)
	draw_rect(bar, Color(0.08, 0.08, 0.08, 0.18), false, 1.0)
	var hp_ratio: float = clampf(player.health / maxf(1.0, player.max_health), 0.0, 1.0)
	if hp_ratio > 0.0:
		var pulse_h: float = sin(t * 8.0) * 0.12 if hurt > 0.02 else 0.0
		draw_rect(Rect2(bar.position + Vector2(1, 1), Vector2((bar.size.x - 2.0) * hp_ratio, (bar.size.y - 2.0) + pulse_h)), Color(0.10, 0.10, 0.10, 0.82), true)
	if font != null:
		draw_string(font, Vector2(152, 527), Loc.t("hud.dash"), HORIZONTAL_ALIGNMENT_LEFT, 96, 8, soft)

func _draw_flux(ink: Color, _soft: Color, font) -> void:
	var center: Vector2 = Vector2(480, 516)
	var ratio: float = clampf(player.flux / 100.0, 0.0, 1.0)
	var radius: float = 74.0
	var start_angle: float = PI * 1.08
	var total_angle: float = PI * 0.84
	draw_arc(center, radius, start_angle, start_angle + total_angle, 40, Color(0.08, 0.08, 0.08, 0.09), 2.0)
	if player.flux_active:
		var pulse: float = 0.72 + sin(t * 10.0) * 0.16
		draw_arc(center, radius, start_angle, start_angle + total_angle, 40, Color(0.04, 0.04, 0.04, pulse), 3.0)
		for i in range(6):
			var a: float = start_angle + fmod(t * 1.4 + float(i) * 0.15, total_angle)
			var p: Vector2 = center + Vector2(cos(a), sin(a)) * radius
			draw_circle(p, 1.8, Color(0.08, 0.08, 0.08, 0.36))
	else:
		draw_arc(center, radius, start_angle, start_angle + total_angle * ratio, 40, ink, 2.8)
	if font != null:
		if player.flux_active:
			draw_string(font, Vector2(390, 508), Loc.t("hud.surge"), HORIZONTAL_ALIGNMENT_CENTER, 180, 10, Color(0.05, 0.05, 0.05, 0.72))
			draw_string(font, Vector2(380, 531), Loc.t("hud.no_charges"), HORIZONTAL_ALIGNMENT_CENTER, 200, 8, Color(0.05, 0.05, 0.05, 0.48))
		elif float(player.flux_recharge_timer) > 0.0:
			draw_string(font, Vector2(402, 508), Loc.t("hud.resonance"), HORIZONTAL_ALIGNMENT_CENTER, 156, 9, Color(0.05, 0.05, 0.05, 0.56))
			draw_string(font, Vector2(420, 531), Loc.f("hud.flow_in", [int(ceil(float(player.flux_recharge_timer)))]), HORIZONTAL_ALIGNMENT_CENTER, 120, 8, Color(0.08, 0.08, 0.08, 0.40))
		else:
			draw_string(font, Vector2(420, 531), Loc.t("hud.flow") + "  " + str(int(player.flux)) + "%", HORIZONTAL_ALIGNMENT_CENTER, 120, 9, Color(0.08, 0.08, 0.08, 0.46))

func _draw_soft_hints(font) -> void:
	if font == null or not is_instance_valid(controller) or not controller.has_method("_get_attack_target_mode"):
		return
	var mode_value: String = str(controller._get_attack_target_mode())
	var mode_label: String = Loc.t("settings.mouse") if mode_value == "mouse" else Loc.t("settings.nearest")
	var hint_color: Color = Color(0.08, 0.08, 0.08, 0.24)
	draw_string(font, Vector2(14.0, 18.0), Loc.f("hud.attack_toggle", [mode_label]), HORIZONTAL_ALIGNMENT_LEFT, 260, 7, hint_color)

func _draw_right_status(ink: Color, soft: Color, font) -> void:
	var anchor: Vector2 = Vector2(926, 503)
	match player.mage_type:
		"rift":
			for i in range(player.rift_max_charges):
				var p: Vector2 = anchor + Vector2(-float(i) * 24.0 - 8.0, -24.0)
				var filled: bool = i < player.rift_charges and not player.rift_reloading
				draw_arc(p, 8.2, -1.2, 1.2, 14, ink if filled else Color(0.08, 0.08, 0.08, 0.09), 1.8)
			if player.rift_reloading:
				var rr: float = player.get_rift_reload_ratio()
				draw_arc(anchor + Vector2(-60, -24), 10.0, -PI * 0.5, -PI * 0.5 + TAU * rr, 18, soft, 1.6)
		"storm":
			if player.storm_charging:
				var r: float = clampf(player.storm_charge / maxf(0.001, player.storm_charge_duration), 0.0, 1.0)
				draw_arc(anchor + Vector2(-24, -24), 15.0, -PI * 0.5, -PI * 0.5 + TAU * r, 22, ink, 2.1)
		_:
			if player.magic_reloading:
				var r2: float = player.get_magic_reload_ratio()
				draw_arc(anchor + Vector2(-24, -24), 15.0, -PI * 0.5, -PI * 0.5 + TAU * r2, 22, ink, 2.1)
	if player.endless_mode:
		_draw_consumable_belt(ink, soft, font)
	else:
		var equipped: Array = player.get_equipped_upgrades()
		for i in range(3):
			var x: float = 706.0 + float(i) * 80.0
			var id: String = str(equipped[i]) if i < equipped.size() else ""
			var active: bool = id != ""
			var center: Vector2 = Vector2(x, 512)
			draw_arc(center, 14.0, PI * 0.1, PI * 1.9, 20, ink if active else Color(0.08, 0.08, 0.08, 0.10), 1.4)
			_draw_slot_symbol(center, i, ink if active else Color(0.08, 0.08, 0.08, 0.12))
			if font != null:
				var upgrade_name: String = UpgradeCatalog.get_upgrade_name(id)
				if upgrade_name.length() > 11:
					upgrade_name = upgrade_name.substr(0, 10) + "…"
				draw_string(font, Vector2(x - 36, 536), upgrade_name, HORIZONTAL_ALIGNMENT_CENTER, 72, 7, Color(0.08, 0.08, 0.08, 0.36 if active else 0.18))

func _draw_consumable_belt(ink: Color, _soft: Color, font) -> void:
	if not is_instance_valid(controller) or not controller.has_method("get_consumable_slots"):
		return
	var slots: Array = controller.get_consumable_slots()
	var start_x: float = 618.0
	var y: float = 509.0
	if font != null:
		draw_string(font, Vector2(start_x - 2.0, 481.0), Loc.t("hud.relic_belt"), HORIZONTAL_ALIGNMENT_LEFT, 190, 7, Color(0.08, 0.08, 0.08, 0.32))
		draw_string(font, Vector2(818.0, 481.0), Loc.t("hud.relic_details_hint"), HORIZONTAL_ALIGNMENT_RIGHT, 118, 7, Color(0.08, 0.08, 0.08, 0.38))
	for i in range(10):
		var center := Vector2(start_x + float(i) * 32.0, y)
		var item_id: String = str(slots[i]) if i < slots.size() else ""
		var active: bool = item_id != ""
		var ring: Color = Color(0.08, 0.08, 0.08, 0.42) if active else Color(0.08, 0.08, 0.08, 0.09)
		draw_circle(center, 13.8, Color(1, 1, 1, 0.04 if active else 0.02))
		draw_arc(center, 12.2, -PI * 0.42, PI * 1.42, 20, ring, 1.25)
		if active:
			_draw_consumable_symbol(center, item_id, ink)
		if font != null:
			var key_label: String = "0" if i == 9 else str(i + 1)
			draw_string(font, center + Vector2(-6.0, 22.0), key_label, HORIZONTAL_ALIGNMENT_CENTER, 12, 7, Color(0.08, 0.08, 0.08, 0.46 if active else 0.18))
	if controller.has_method("are_consumable_details_visible") and bool(controller.are_consumable_details_visible()):
		_draw_consumable_details(slots, font, ink)

func _draw_consumable_details(slots: Array, font, _ink: Color) -> void:
	if font == null or not is_instance_valid(controller):
		return
	var panel := Rect2(Vector2(384, 226), Vector2(544, 244))
	draw_rect(panel, Color(0.965, 0.955, 0.925, 0.95), true)
	draw_rect(panel, Color(0.08, 0.08, 0.08, 0.20), false, 1.0)
	draw_string(font, panel.position + Vector2(18, 24), Loc.t("hud.relic_details_title"), HORIZONTAL_ALIGNMENT_LEFT, 330, 11, Color(0.07, 0.07, 0.07, 0.80))
	draw_string(font, panel.position + Vector2(396, 23), Loc.t("hud.relic_details_close"), HORIZONTAL_ALIGNMENT_RIGHT, 126, 7, Color(0.07, 0.07, 0.07, 0.40))
	for i in range(10):
		var col: int = floori(float(i) / 5.0)
		var row: int = i % 5
		var x: float = panel.position.x + 18.0 + float(col) * 262.0
		var y: float = panel.position.y + 50.0 + float(row) * 36.0
		var item_id: String = str(slots[i]) if i < slots.size() else ""
		var key_label: String = "0" if i == 9 else str(i + 1)
		var key_rect := Rect2(Vector2(x, y - 13), Vector2(24, 24))
		draw_rect(key_rect, Color(0.08, 0.08, 0.08, 0.055), true)
		draw_rect(key_rect, Color(0.08, 0.08, 0.08, 0.16), false, 1.0)
		draw_string(font, key_rect.position + Vector2(0, 16), key_label, HORIZONTAL_ALIGNMENT_CENTER, 24, 8, Color(0.07, 0.07, 0.07, 0.62))
		if item_id == "":
			draw_string(font, Vector2(x + 34, y + 2), Loc.t("hud.relic_empty"), HORIZONTAL_ALIGNMENT_LEFT, 210, 8, Color(0.08, 0.08, 0.08, 0.20))
			continue
		_draw_consumable_symbol(Vector2(x + 36, y - 2), item_id, Color("#111111"))
		var item_name: String = controller.get_consumable_name(item_id) if controller.has_method("get_consumable_name") else item_id
		var desc: String = controller.get_consumable_description(item_id) if controller.has_method("get_consumable_description") else ""
		draw_string(font, Vector2(x + 50, y - 3), item_name, HORIZONTAL_ALIGNMENT_LEFT, 210, 8, Color(0.06, 0.06, 0.06, 0.72))
		var lines: Array[String] = _wrap_hud_text(desc, 41, 2)
		for line_index in range(lines.size()):
			draw_string(font, Vector2(x + 50, y + 9 + float(line_index) * 9.0), lines[line_index], HORIZONTAL_ALIGNMENT_LEFT, 204, 7, Color(0.07, 0.07, 0.07, 0.44))

func _wrap_hud_text(text: String, max_chars: int, max_lines: int) -> Array[String]:
	var result: Array[String] = []
	var current: String = ""
	var truncated: bool = false
	for word_value in text.split(" ", false):
		var word: String = str(word_value)
		var candidate: String = word if current == "" else current + " " + word
		if candidate.length() <= max_chars:
			current = candidate
		else:
			if current != "":
				result.append(current)
			current = word
			if result.size() >= max_lines:
				truncated = true
				break
	if result.size() < max_lines and current != "":
		result.append(current)
	elif current != "":
		truncated = true
	if truncated and not result.is_empty():
		result[result.size() - 1] = result[result.size() - 1].left(maxi(1, max_chars - 1)).strip_edges() + "…"
	return result

func _draw_consumable_symbol(center: Vector2, item_id: String, color: Color) -> void:
	match item_id:
		"heal_minor", "heal_major":
			draw_line(center + Vector2(-4, 0), center + Vector2(4, 0), color, 1.9)
			draw_line(center + Vector2(0, -4), center + Vector2(0, 4), color, 1.9)
		"xp_magnet":
			draw_arc(center + Vector2(0, 1), 5.8, PI * 0.16, PI * 0.84, 16, color, 1.8)
			draw_arc(center + Vector2(0, 1), 5.8, PI * 1.16, PI * 1.84, 16, color, 1.8)
			draw_line(center + Vector2(-5.6, -1.0), center + Vector2(-5.6, 3.0), color, 1.8)
			draw_line(center + Vector2(5.6, -1.0), center + Vector2(5.6, 3.0), color, 1.8)
		"xp_burst_small", "xp_burst_major":
			_draw_diamond(center, 5.2, color)
			draw_circle(center, 1.2, Color(1, 1, 1, 0.62))
		"gold_cache":
			for a in [0.0, PI * 0.5]:
				draw_line(center + Vector2(cos(a), sin(a)) * -5.0, center + Vector2(cos(a), sin(a)) * 5.0, color, 1.4)
			_draw_diamond(center, 3.4, color)
		"flux_spark", "flux_reserve":
			draw_arc(center, 5.2, -PI * 0.5, PI * 1.35, 16, color, 1.7)
			draw_circle(center, 1.5, color)
		"champion_impulse":
			_draw_diamond(center + Vector2(-2, 0), 4.3, color)
			draw_line(center + Vector2(2, -4), center + Vector2(6, 0), color, 1.4)
			draw_line(center + Vector2(6, 0), center + Vector2(2, 4), color, 1.4)
		"runic_shock", "skyfire_storm":
			draw_polyline(PackedVector2Array([center + Vector2(-2, -6), center + Vector2(2, -1), center + Vector2(-1, 1), center + Vector2(3, 6)]), color, 1.7)
		"dragon_breath":
			draw_line(center + Vector2(-5, 0), center + Vector2(5, -4), color, 1.4)
			draw_line(center + Vector2(-5, 0), center + Vector2(6, 0), color, 1.8)
			draw_line(center + Vector2(-5, 0), center + Vector2(5, 4), color, 1.4)
		"arcane_guard":
			draw_arc(center, 5.3, 0.15, PI - 0.15, 14, color, 1.7)
			draw_line(center + Vector2(-5, 0), center + Vector2(0, 6), color, 1.4)
			draw_line(center + Vector2(5, 0), center + Vector2(0, 6), color, 1.4)
		_:
			draw_circle(center, 2.5, color)

func _draw_class_glyph(center: Vector2, ink: Color) -> void:
	match player.mage_type:
		"storm":
			draw_polyline(PackedVector2Array([center + Vector2(-5, -11), center + Vector2(2, -3), center + Vector2(-2, 3), center + Vector2(6, 11)]), ink, 2.2)
		"rift":
			draw_arc(center + Vector2(-2, 0), 10.0, -1.2, 1.2, 16, ink, 1.8)
			draw_arc(center + Vector2(3, 0), 7.0, PI - 1.0, PI + 1.0, 14, Color(0.08, 0.08, 0.08, 0.28), 1.0)
		_: 
			_draw_diamond(center, 7.8, ink)

func _draw_slot_symbol(center: Vector2, index: int, color: Color) -> void:
	match index:
		0: _draw_diamond(center, 4.0, color)
		1: draw_circle(center, 3.4, color)
		_: draw_arc(center, 4.5, 0.0, TAU, 14, color, 1.4)

func _class_name() -> String:
	match player.mage_type:
		"storm": return Loc.t("class.storm")
		"rift": return Loc.t("class.rift")
		"samurai": return Loc.t("class.samurai")
		_: return Loc.t("class.orbit")


func _draw_hud_dash_bolts(center: Vector2, ink: Color, soft: Color) -> void:
	var count: int = maxi(1, int(player.max_dash_charges))
	var spacing: float = 18.0 if count <= 3 else 16.0 if count <= 5 else 14.0
	var start_x: float = center.x - (float(count - 1) * spacing) * 0.5
	for i in range(count):
		var bolt_center: Vector2 = Vector2(start_x + float(i) * spacing, center.y)
		var fill_ratio: float = 0.0
		if i < int(player.dash_charges):
			fill_ratio = 1.0
		elif i == int(player.dash_charges) and player.dash_charges < player.max_dash_charges and player.has_method("get_dash_recharge_ratio"):
			fill_ratio = clampf(player.get_dash_recharge_ratio(), 0.0, 1.0)
		_draw_dash_bolt_container(bolt_center, fill_ratio, ink, soft, i < int(player.dash_charges), i)

func _draw_dash_bolt_container(center: Vector2, fill_ratio: float, ink: Color, soft: Color, ready: bool, index: int) -> void:
	var pulse: float = (0.10 + maxf(0.0, sin(t * 7.2 + float(index) * 0.9)) * 0.10) if ready else 0.0
	draw_circle(center, 8.8, Color(1.0, 1.0, 1.0, 0.03 + pulse * 0.40))
	draw_arc(center, 7.8, -PI * 0.30, PI * 1.30, 16, Color(0.08, 0.08, 0.08, 0.10), 1.2)
	var outer: PackedVector2Array = _dash_bolt_points(center, 1.0)
	draw_polyline(outer, Color(0.08, 0.08, 0.08, 0.22 if fill_ratio > 0.0 else 0.12), 1.2)
	if fill_ratio > 0.0:
		var fill_poly: PackedVector2Array = _dash_bolt_points(center + Vector2(0, (1.0 - fill_ratio) * 2.6), 0.42 + fill_ratio * 0.58)
		draw_colored_polygon(fill_poly, Color(0.10, 0.10, 0.10, 0.62 + fill_ratio * 0.18))
		if ready:
			draw_polyline(fill_poly, Color(1.0, 1.0, 1.0, 0.08 + pulse * 0.35), 0.9)

func _dash_bolt_points(center: Vector2, scale: float) -> PackedVector2Array:
	return PackedVector2Array([
		center + Vector2(-3.8, -6.0) * scale,
		center + Vector2(0.2, -1.2) * scale,
		center + Vector2(-1.6, -1.0) * scale,
		center + Vector2(2.8, 5.8) * scale,
		center + Vector2(-0.3, 1.3) * scale,
		center + Vector2(1.4, 1.0) * scale,
		center + Vector2(-2.5, -5.8) * scale,
		center + Vector2(-3.8, -6.0) * scale
	])

func _draw_hud_portrait(center: Vector2, ink: Color) -> void:
	if player.mage_type == "rift":
		_draw_class_glyph(center, ink)
		return
	var dir: Vector2 = _hud_focus_direction()
	var eye_shift: Vector2 = Vector2(clampf(dir.x, -1.0, 1.0) * 1.8, clampf(dir.y, -1.0, 1.0) * 1.2)
	var hurt: float = clampf(float(player.hurt_flash), 0.0, 1.0)
	var blink: float = 1.0
	if fmod(t, 4.6) < 0.10:
		blink = 0.15
	var powered: bool = bool(player.flux_active)
	var impact_offset: Vector2 = Vector2.ZERO
	if hurt > 0.02:
		impact_offset = Vector2(sin(t * 62.0) * hurt * 2.5, -absf(sin(t * 34.0)) * hurt * 1.4)
	var c: Vector2 = center + impact_offset
	match player.mage_type:
		"storm":
			_draw_storm_hud_face(c, ink, eye_shift, blink, hurt, powered)
		"samurai":
			_draw_samurai_hud_face(c, ink, eye_shift, blink, hurt, powered)
		_:
			_draw_orbit_hud_face(c, ink, eye_shift, blink, hurt, powered)
	if hurt > 0.02:
		var shock_alpha: float = hurt * (0.16 + absf(sin(t * 30.0)) * 0.22)
		for i in range(4):
			var ang: float = -PI * 0.7 + float(i) * 0.46
			var inner: Vector2 = center + Vector2(cos(ang), sin(ang)) * 24.0
			var outer: Vector2 = center + Vector2(cos(ang), sin(ang)) * (30.0 + float(i % 2) * 4.0)
			draw_line(inner, outer, Color(0.08, 0.08, 0.08, shock_alpha), 1.3)
		var mark: Vector2 = center + Vector2(12.0, -12.0)
		draw_line(mark + Vector2(0, -2), mark + Vector2(0, 5), ink, 1.2)
		draw_line(mark + Vector2(2, -1), mark + Vector2(2, 4), ink, 1.0)

func _hud_focus_direction() -> Vector2:
	if not is_instance_valid(player):
		return Vector2.RIGHT
	if player.aim_direction.length_squared() > 0.001:
		return player.aim_direction.normalized()
	return Vector2.RIGHT

func _draw_orbit_hud_face(center: Vector2, ink: Color, eye_shift: Vector2, blink: float, hurt: float, powered: bool) -> void:
	# Orbit: broad wizard hat, deeper hood, floating stones, broad robe collar.
	var hat: PackedVector2Array = PackedVector2Array([
		center + Vector2(-15, -3), center + Vector2(-10, -15), center + Vector2(-2, -21), center + Vector2(6, -17), center + Vector2(10, -8), center + Vector2(12, -3), center + Vector2(4, -5), center + Vector2(-7, -5)
	])
	draw_colored_polygon(hat, Color(0.08, 0.08, 0.08, 0.98))
	var brim: PackedVector2Array = PackedVector2Array([
		center + Vector2(-17, -2), center + Vector2(-9, -5), center + Vector2(2, -5), center + Vector2(14, -2), center + Vector2(6, 0), center + Vector2(-10, 0)
	])
	draw_colored_polygon(brim, Color(0.10, 0.10, 0.10, 0.93))
	var hood: PackedVector2Array = PackedVector2Array([
		center + Vector2(-14, 10), center + Vector2(-15, -1), center + Vector2(-11, -10), center + Vector2(-4, -14), center + Vector2(5, -14), center + Vector2(12, -10), center + Vector2(15, -1), center + Vector2(14, 10), center + Vector2(0, 17)
	])
	draw_colored_polygon(hood, Color(0.08, 0.08, 0.08, 0.97))
	var face: PackedVector2Array = PackedVector2Array([
		center + Vector2(-6, -1), center + Vector2(-5, -8), center + Vector2(4, -8), center + Vector2(7, -1), center + Vector2(5, 7), center + Vector2(-3, 8)
	])
	draw_colored_polygon(face, Color(0.16, 0.16, 0.16, 0.92))
	# broad orbit robe collar so the class reads as a mage, not a generic head.
	var collar: PackedVector2Array = PackedVector2Array([
		center + Vector2(-15, 12), center + Vector2(-9, 9), center + Vector2(-3, 12), center + Vector2(0, 17), center + Vector2(4, 12), center + Vector2(10, 9), center + Vector2(15, 12), center + Vector2(9, 18), center + Vector2(-9, 18)
	])
	draw_colored_polygon(collar, Color(0.10, 0.10, 0.10, 0.88))
	draw_line(center + Vector2(-7, 10), center + Vector2(-1, 16), Color(1,1,1,0.08), 0.9)
	draw_line(center + Vector2(1, 16), center + Vector2(7, 10), Color(1,1,1,0.08), 0.9)
	# floating orbit stones, stronger read.
	for side in [-1.0, 1.0]:
		var stone_center := center + Vector2(side * 18.5, -1.5 + sin(t * 3.0 + side) * 0.9)
		_draw_diamond(stone_center, 4.3, Color(0.10, 0.10, 0.10, 0.84))
		draw_line(stone_center + Vector2(0, -3.6), stone_center + Vector2(0, 3.6), Color(1,1,1,0.06), 0.8)
	if powered:
		draw_arc(center, 19.0, -PI * 0.78, PI * 0.16, 16, Color(0.08, 0.08, 0.08, 0.26), 1.0)
	_draw_common_hud_face(center, ink, eye_shift, blink, hurt, powered, false, Vector2(-4.8, -1.0), Vector2(4.8, -1.0), 6.6)

func _draw_storm_hud_face(center: Vector2, ink: Color, eye_shift: Vector2, blink: float, hurt: float, powered: bool) -> void:
	# Storm: clear pointed hat, angled face, blue-dark mantle with bright lightning accents.
	var storm_cloth: Color = Color(0.11, 0.17, 0.28, 0.92)
	var storm_cloth_dark: Color = Color(0.08, 0.12, 0.20, 0.96)
	var storm_glow: Color = Color(0.56, 0.78, 1.0, 0.56)
	var hat: PackedVector2Array = PackedVector2Array([
		center + Vector2(-12, -3), center + Vector2(-7, -17), center + Vector2(-1, -21), center + Vector2(4, -18), center + Vector2(8, -8), center + Vector2(10, -2), center + Vector2(2, -4), center + Vector2(-5, -5)
	])
	draw_colored_polygon(hat, Color(0.08, 0.08, 0.08, 0.98))
	var brim: PackedVector2Array = PackedVector2Array([
		center + Vector2(-15, -2), center + Vector2(-7, -5), center + Vector2(4, -5), center + Vector2(13, -2), center + Vector2(5, 0), center + Vector2(-8, 0)
	])
	draw_colored_polygon(brim, Color(0.10, 0.10, 0.10, 0.92))
	var face: PackedVector2Array = PackedVector2Array([
		center + Vector2(-6, 0), center + Vector2(-4, -7), center + Vector2(5, -7), center + Vector2(8, 1), center + Vector2(5, 9), center + Vector2(-3, 9)
	])
	draw_colored_polygon(face, Color(0.16, 0.16, 0.16, 0.92))
	var shoulders: PackedVector2Array = PackedVector2Array([
		center + Vector2(-14, 11), center + Vector2(-9, 7), center + Vector2(-4, 10), center + Vector2(0, 17), center + Vector2(5, 10), center + Vector2(10, 7), center + Vector2(16, 11), center + Vector2(8, 18), center + Vector2(-9, 18)
	])
	draw_colored_polygon(shoulders, storm_cloth)
	var mantle_inner: PackedVector2Array = PackedVector2Array([
		center + Vector2(-10, 11), center + Vector2(-5, 9), center + Vector2(-1, 12), center + Vector2(0, 16), center + Vector2(3, 12), center + Vector2(7, 9), center + Vector2(12, 11), center + Vector2(6, 16), center + Vector2(-6, 16)
	])
	draw_colored_polygon(mantle_inner, storm_cloth_dark)
	# lightning crest + cheek rune + tiny storm spark near shoulder.
	draw_polyline(PackedVector2Array([center + Vector2(-1, -18), center + Vector2(3, -12), center + Vector2(0, -10), center + Vector2(5, -4)]), storm_glow, 1.6)
	draw_polyline(PackedVector2Array([center + Vector2(9, -2), center + Vector2(11, 1), center + Vector2(8, 4)]), storm_glow, 1.1)
	draw_polyline(PackedVector2Array([center + Vector2(-16, 7), center + Vector2(-13, 11), center + Vector2(-16, 14)]), Color(0.40,0.68,1.0,0.34), 1.0)
	# small cloth lightning marks to distinguish from the others.
	draw_polyline(PackedVector2Array([center + Vector2(-8, 12), center + Vector2(-5, 10), center + Vector2(-7, 15)]), Color(0.60, 0.82, 1.0, 0.34), 0.9)
	draw_polyline(PackedVector2Array([center + Vector2(8, 11), center + Vector2(10, 14), center + Vector2(6, 15)]), Color(0.60, 0.82, 1.0, 0.34), 0.9)
	if powered:
		for i in range(2):
			var o: float = -10.0 + float(i) * 20.0
			draw_polyline(PackedVector2Array([center + Vector2(o, -14), center + Vector2(o + 4, -9), center + Vector2(o + 1, -7)]), Color(0.60, 0.82, 1.0, 0.30), 1.1)
	_draw_common_hud_face(center, ink, eye_shift, blink, hurt, powered, true, Vector2(-4.4, -1.4), Vector2(4.7, -0.9), 6.1)

func _draw_samurai_hud_face(center: Vector2, ink: Color, eye_shift: Vector2, blink: float, hurt: float, powered: bool) -> void:
	# Samurai: headband, side tie, kimono collar / chest plate silhouette.
	var hair_cap: PackedVector2Array = PackedVector2Array([
		center + Vector2(-13, 9), center + Vector2(-11, -7), center + Vector2(-3, -13), center + Vector2(8, -12), center + Vector2(13, -2), center + Vector2(12, 10), center + Vector2(0, 16)
	])
	draw_colored_polygon(hair_cap, Color(0.08, 0.08, 0.08, 0.97))
	var headband: PackedVector2Array = PackedVector2Array([
		center + Vector2(-12, -7), center + Vector2(11, -7), center + Vector2(11, -4), center + Vector2(-12, -4)
	])
	draw_colored_polygon(headband, Color(1.0, 1.0, 1.0, 0.09))
	var head_tie: PackedVector2Array = PackedVector2Array([
		center + Vector2(10, -7), center + Vector2(15, -12 + sin(t * 4.0) * 0.8), center + Vector2(14, -5)
	])
	draw_colored_polygon(head_tie, Color(0.08, 0.08, 0.08, 0.90))
	var face: PackedVector2Array = PackedVector2Array([
		center + Vector2(-6, -1), center + Vector2(-4, -8), center + Vector2(5, -8), center + Vector2(7, 0), center + Vector2(5, 9), center + Vector2(-2, 10)
	])
	draw_colored_polygon(face, Color(0.16, 0.16, 0.16, 0.92))
	var kimono: PackedVector2Array = PackedVector2Array([
		center + Vector2(-15, 12), center + Vector2(-10, 8), center + Vector2(-2, 12), center + Vector2(0, 17), center + Vector2(4, 12), center + Vector2(10, 8), center + Vector2(15, 12), center + Vector2(9, 18), center + Vector2(-8, 18)
	])
	draw_colored_polygon(kimono, Color(0.10, 0.10, 0.10, 0.88))
	draw_line(center + Vector2(-6, 9), center + Vector2(-1, 16), Color(1,1,1,0.07), 0.9)
	draw_line(center + Vector2(0, 16), center + Vector2(5, 10), Color(1,1,1,0.07), 0.9)
	# sharper identity: cheek scar and jaw line.
	draw_line(center + Vector2(3, -2), center + Vector2(5, 3), Color(0.08, 0.08, 0.08, 0.34), 0.8)
	draw_line(center + Vector2(-5, 9), center + Vector2(5, 9), Color(0.08, 0.08, 0.08, 0.16), 0.9)
	if powered:
		draw_line(center + Vector2(-16, -1), center + Vector2(-22, -5), Color(0.08, 0.08, 0.08, 0.18), 1.0)
		draw_line(center + Vector2(16, 2), center + Vector2(22, -2), Color(0.08, 0.08, 0.08, 0.18), 1.0)
	_draw_common_hud_face(center, ink, eye_shift, blink, hurt, powered, false, Vector2(-5.1, -1.3), Vector2(4.3, -1.3), 6.8)

func _draw_common_hud_face(center: Vector2, ink: Color, eye_shift: Vector2, blink: float, hurt: float, powered: bool, angular: bool = false, left_eye_offset: Vector2 = Vector2(-4.8, -1.0), right_eye_offset: Vector2 = Vector2(4.8, -1.0), mouth_y: float = 6.6) -> void:
	var eye_white: Color = Color("#fffdf7")
	var left_eye: Vector2 = center + left_eye_offset
	var right_eye: Vector2 = center + right_eye_offset
	if hurt > 0.02:
		draw_line(left_eye + Vector2(-3.0, -2.0), left_eye + Vector2(2.8, -3.0), ink, 1.0)
		draw_line(right_eye + Vector2(-2.8, -3.0), right_eye + Vector2(3.0, -2.0), ink, 1.0)
	elif powered:
		draw_line(left_eye + Vector2(-2.5, -2.0), left_eye + Vector2(2.2, -3.0), ink, 0.9)
		draw_line(right_eye + Vector2(-2.2, -3.0), right_eye + Vector2(2.5, -2.0), ink, 0.9)
	var eye_h: float = 2.0 * blink
	if eye_h < 0.4:
		draw_line(left_eye + Vector2(-2.6, 0), left_eye + Vector2(2.6, 0), ink, 1.1)
		draw_line(right_eye + Vector2(-2.6, 0), right_eye + Vector2(2.6, 0), ink, 1.1)
	else:
		if angular:
			var lp: PackedVector2Array = PackedVector2Array([left_eye + Vector2(-2.7, 0), left_eye + Vector2(0, -eye_h), left_eye + Vector2(2.7, 0), left_eye + Vector2(0, eye_h)])
			var rp: PackedVector2Array = PackedVector2Array([right_eye + Vector2(-2.7, 0), right_eye + Vector2(0, -eye_h), right_eye + Vector2(2.7, 0), right_eye + Vector2(0, eye_h)])
			draw_colored_polygon(lp, eye_white)
			draw_colored_polygon(rp, eye_white)
		else:
			draw_circle(left_eye, 2.5, eye_white)
			draw_circle(right_eye, 2.5, eye_white)
		var pupil_l: Vector2 = left_eye + eye_shift
		var pupil_r: Vector2 = right_eye + eye_shift
		draw_circle(pupil_l, 0.8, ink)
		draw_circle(pupil_r, 0.8, ink)
	if hurt > 0.02:
		draw_polyline(PackedVector2Array([center + Vector2(-2.7, mouth_y), center + Vector2(0, mouth_y - 1.2), center + Vector2(2.7, mouth_y)]), ink, 1.0)
	elif powered:
		draw_polyline(PackedVector2Array([center + Vector2(-2.7, mouth_y), center + Vector2(0, mouth_y + 1.3), center + Vector2(2.7, mouth_y)]), ink, 1.0)
	else:
		draw_polyline(PackedVector2Array([center + Vector2(-2.7, mouth_y), center + Vector2(0, mouth_y + 0.6), center + Vector2(2.7, mouth_y)]), ink, 0.95)

func _draw_dash_head_icons(center: Vector2, ink: Color) -> void:
	var count: int = maxi(1, int(player.max_dash_charges))
	var spacing: float = 18.0
	var total_width: float = float(count - 1) * spacing
	var available: int = int(player.dash_charges)
	var progress_index: int = available
	var progress_ratio: float = 0.0
	if player.dash_charges < player.max_dash_charges and player.has_method("get_dash_recharge_ratio"):
		progress_ratio = clampf(float(player.get_dash_recharge_ratio()), 0.0, 1.0)
	for i in range(count):
		var slot_center: Vector2 = center + Vector2(float(i) * spacing - total_width * 0.5, 0)
		var fill_ratio: float = 0.0
		if i < available:
			fill_ratio = 1.0
		elif i == progress_index:
			fill_ratio = progress_ratio
		var pulse: float = (0.10 + maxf(0.0, sin(t * 7.0 + float(i) * 0.9)) * 0.10) if fill_ratio >= 1.0 else 0.0
		draw_circle(slot_center, 8.8, Color(0.98, 0.97, 0.94, 0.05 + pulse * 0.4))
		draw_arc(slot_center, 7.0, 0.0, TAU, 18, Color(0.08, 0.08, 0.08, 0.14), 1.0)
		_draw_dash_lightning_icon(slot_center, ink, fill_ratio)

func _draw_dash_lightning_icon(center: Vector2, ink: Color, fill_ratio: float) -> void:
	# container body
	var glass: PackedVector2Array = PackedVector2Array([
		center + Vector2(-4.6, -6.0), center + Vector2(1.0, -6.0), center + Vector2(4.0, -2.4), center + Vector2(0.8, 1.4), center + Vector2(3.0, 1.4), center + Vector2(-1.4, 6.2), center + Vector2(-0.2, 2.0), center + Vector2(-4.2, 2.0)
	])
	draw_colored_polygon(glass, Color(1.0, 1.0, 1.0, 0.03))
	# staged fill to simulate filling the lightning container from bottom to top.
	var fill: Color = Color(0.08, 0.08, 0.08, 0.70)
	if fill_ratio > 0.02:
		if fill_ratio >= 0.18:
			draw_colored_polygon(PackedVector2Array([center + Vector2(-2.7, 2.0), center + Vector2(1.2, 2.0), center + Vector2(-1.1, 4.9)]), fill)
		elif fill_ratio > 0.0:
			var rr0: float = fill_ratio / 0.18
			draw_colored_polygon(PackedVector2Array([center + Vector2(-2.7, 2.0), center + Vector2(-2.7 + 3.9 * rr0, 2.0), center + Vector2(-1.1, 2.0 + 2.9 * rr0)]), fill)
		if fill_ratio >= 0.42:
			draw_colored_polygon(PackedVector2Array([center + Vector2(-3.7, 0.7), center + Vector2(0.2, 0.7), center + Vector2(1.6, -1.2), center + Vector2(-2.1, -1.2)]), fill)
		elif fill_ratio > 0.18:
			var rr1: float = (fill_ratio - 0.18) / 0.24
			draw_colored_polygon(PackedVector2Array([center + Vector2(-3.7, 0.7), center + Vector2(-3.7 + 3.9 * rr1, 0.7), center + Vector2(-2.1 + 3.7 * rr1, -1.2), center + Vector2(-2.1, -1.2)]), fill)
		if fill_ratio >= 0.72:
			draw_colored_polygon(PackedVector2Array([center + Vector2(-0.7, -4.9), center + Vector2(1.7, -4.9), center + Vector2(2.8, -3.1), center + Vector2(0.9, -1.2), center + Vector2(-1.0, -1.2)]), fill)
		elif fill_ratio > 0.42:
			var rr2: float = (fill_ratio - 0.42) / 0.30
			draw_colored_polygon(PackedVector2Array([center + Vector2(-0.7, -1.2 - 3.7 * rr2), center + Vector2(-0.7 + 2.4 * rr2, -1.2 - 3.7 * rr2), center + Vector2(-1.0 + 1.9 * rr2, -1.2), center + Vector2(-1.0, -1.2)]), fill)
		if fill_ratio >= 1.0:
			draw_colored_polygon(PackedVector2Array([center + Vector2(-4.1, -6.0), center + Vector2(-0.1, -6.0), center + Vector2(0.8, -4.9), center + Vector2(-0.7, -4.9), center + Vector2(-1.5, -3.6)]), fill)
		elif fill_ratio > 0.72:
			var rr3: float = (fill_ratio - 0.72) / 0.28
			draw_colored_polygon(PackedVector2Array([center + Vector2(-4.1, -6.0 + (1.1 * (1.0 - rr3))), center + Vector2(-4.1 + 4.0 * rr3, -6.0 + (1.1 * (1.0 - rr3))), center + Vector2(-1.5 + 2.3 * rr3, -3.6 + (-1.3 * rr3)), center + Vector2(-1.5, -3.6)]), fill)
	# outline and lightning contour
	var outline: PackedVector2Array = PackedVector2Array([
		center + Vector2(-4.6, -6.0), center + Vector2(1.0, -6.0), center + Vector2(4.0, -2.4), center + Vector2(0.8, 1.4), center + Vector2(3.0, 1.4), center + Vector2(-1.4, 6.2), center + Vector2(-0.2, 2.0), center + Vector2(-4.2, 2.0), center + Vector2(-4.6, -6.0)
	])
	draw_polyline(outline, ink if fill_ratio > 0.98 else Color(0.08, 0.08, 0.08, 0.44), 1.1)
	if fill_ratio > 0.02:
		draw_line(center + Vector2(-1.6, 2.3), center + Vector2(0.8, 0.4), Color(1, 1, 1, 0.08 + fill_ratio * 0.08), 0.8)

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([center + Vector2(0, -radius), center + Vector2(radius * 0.75, 0), center + Vector2(0, radius), center + Vector2(-radius * 0.75, 0)])
	draw_colored_polygon(poly, color)
