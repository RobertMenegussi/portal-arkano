# BUILD 0695 — SAMURAI STUN TIMER HOTFIX

## Fix
- Fixed the Samurai post-dash stun becoming permanent.
- The timer was not being reduced every frame.
- The post-dash recovery stun now correctly expires after 0.4 seconds.

## Files changed
- player.gd
- endless_main.gd
