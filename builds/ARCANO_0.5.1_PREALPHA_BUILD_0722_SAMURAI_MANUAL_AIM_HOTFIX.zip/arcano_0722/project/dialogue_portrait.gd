extends Control

var speaker: String = ""
var tone: String = "normal"
var t: float = 0.0
var frame_id: int = 0
var arrival: float = 1.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_speaker(value: String, value_tone: String) -> void:
	speaker = value
	tone = value_tone
	arrival = 0.0
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	frame_id += 1
	arrival = move_toward(arrival, 1.0, delta * 7.0)
	queue_redraw()

func _draw() -> void:
	var center: Vector2 = size * 0.5
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var bob: float = sin(t * 2.8) * 0.65
	if tone == "nervous":
		bob += sin(t * 28.0) * 0.55
	elif tone == "shout":
		bob += sin(t * 34.0) * 1.0
	elif tone == "hurt":
		bob += sin(t * 15.0) * 0.65
	var pop: float = 1.0 - pow(1.0 - arrival, 3.0)
	var draw_center: Vector2 = center + Vector2((1.0 - pop) * -10.0, bob)

	_draw_oval(center + Vector2(0, 35), Vector2(38, 7), Color(0.08,0.08,0.08,0.07))

	if speaker == "Olheiro Distante":
		_draw_skeleton(draw_center, ink, paper)
	elif speaker == "Mercante":
		_draw_merchant(draw_center, ink, paper)
	elif speaker == "Vigia":
		_draw_guard(draw_center, ink, paper)
	elif speaker == "Mago":
		_draw_mage(draw_center, ink, paper)
	elif speaker == "Velho":
		_draw_elder(draw_center, ink, paper)
	elif speaker == "Moradora":
		_draw_parent(draw_center, ink, paper)
	elif speaker == "Aldeão":
		_draw_skeptic(draw_center, ink, paper)
	elif speaker == "Aprendiz":
		_draw_apprentice(draw_center, ink, paper)
	else:
		_draw_mentor(draw_center, ink, paper)

func _draw_mage(c: Vector2, ink: Color, paper: Color) -> void:
	var body: PackedVector2Array = PackedVector2Array([
		c + Vector2(-17,24), c + Vector2(17,24), c + Vector2(13,3), c + Vector2(7,-8), c + Vector2(-9,-8), c + Vector2(-14,2)
	])
	draw_colored_polygon(body, ink)
	draw_circle(c + Vector2(0,-11), 16, ink)
	var hat: PackedVector2Array = PackedVector2Array([
		c + Vector2(-28,-20), c + Vector2(28,-20), c + Vector2(17,-34), c + Vector2(6,-60), c + Vector2(-10,-39)
	])
	draw_colored_polygon(hat, ink)
	draw_circle(c + Vector2(-6,-11), 3.2, paper)
	draw_circle(c + Vector2(6,-11), 3.2, paper)

func _draw_mentor(c: Vector2, ink: Color, paper: Color) -> void:
	var mantle: PackedVector2Array = PackedVector2Array([
		c + Vector2(-20,27), c + Vector2(20,27), c + Vector2(14,1), c + Vector2(9,-10), c + Vector2(-10,-10), c + Vector2(-16,0)
	])
	draw_colored_polygon(mantle, ink)
	draw_circle(c + Vector2(0,-13), 17, ink)
	var hood: PackedVector2Array = PackedVector2Array([
		c + Vector2(-25,-24), c + Vector2(25,-24), c + Vector2(13,-42), c + Vector2(-2,-55), c + Vector2(-18,-39)
	])
	draw_colored_polygon(hood, ink)
	draw_circle(c + Vector2(-6,-13), 3.0, paper)
	draw_circle(c + Vector2(6,-13), 3.0, paper)
	var beard: PackedVector2Array = PackedVector2Array([
		c + Vector2(-10,-3), c + Vector2(10,-3), c + Vector2(6,14), c + Vector2(0,23), c + Vector2(-7,14)
	])
	draw_colored_polygon(beard, Color(0.22,0.22,0.22,0.38))
	draw_line(c + Vector2(22,5), c + Vector2(30,31), Color(0.10,0.10,0.10,0.32), 2.0)

func _draw_merchant(c: Vector2, ink: Color, paper: Color) -> void:
	var pack: PackedVector2Array = PackedVector2Array([
		c + Vector2(-31,-3), c + Vector2(-13,-23), c + Vector2(-5,24), c + Vector2(-29,27), c + Vector2(-37,10)
	])
	draw_colored_polygon(pack, Color(0.14,0.14,0.14,0.94))
	var coat: PackedVector2Array = PackedVector2Array([
		c + Vector2(-17,27), c + Vector2(21,27), c + Vector2(16,1), c + Vector2(8,-13), c + Vector2(-12,-12), c + Vector2(-18,0)
	])
	draw_colored_polygon(coat, ink)
	draw_circle(c + Vector2(2,-13), 15, ink)
	var hood: PackedVector2Array = PackedVector2Array([
		c + Vector2(-17,-25), c + Vector2(20,-25), c + Vector2(13,-40), c + Vector2(1,-47), c + Vector2(-16,-38)
	])
	draw_colored_polygon(hood, ink)
	draw_circle(c + Vector2(-4,-13), 3.0, paper)
	draw_circle(c + Vector2(7,-13), 3.0, paper)
	for i in range(3):
		var charm: Vector2 = c + Vector2(24 + float(i) * 6.0, 2 + float(i % 2) * 10.0)
		_draw_diamond(charm, 4.2, paper)
		draw_line(c + Vector2(16,-1), charm, Color(0.08,0.08,0.08,0.18), 1.0)

func _draw_guard(c: Vector2, ink: Color, paper: Color) -> void:
	var jacket: PackedVector2Array = PackedVector2Array([
		c + Vector2(-19,27), c + Vector2(19,27), c + Vector2(14,1), c + Vector2(7,-9), c + Vector2(-9,-9), c + Vector2(-15,0)
	])
	draw_colored_polygon(jacket, ink)
	draw_circle(c + Vector2(0,-14), 16, ink)
	# no hat: messy hair + headband
	var hair: PackedVector2Array = PackedVector2Array([
		c + Vector2(-16,-21), c + Vector2(-11,-36), c + Vector2(-4,-29), c + Vector2(2,-40), c + Vector2(8,-30), c + Vector2(16,-35), c + Vector2(14,-21)
	])
	draw_colored_polygon(hair, ink)
	draw_line(c + Vector2(-12,-18), c + Vector2(12,-19), paper, 1.3)
	draw_circle(c + Vector2(-6,-13), 3.0, paper)
	draw_circle(c + Vector2(6,-13), 3.0, paper)
	draw_line(c + Vector2(22,25), c + Vector2(30,-44), Color(0.10,0.10,0.10,0.42), 2.2)
	var spear: PackedVector2Array = PackedVector2Array([
		c + Vector2(30,-53), c + Vector2(26,-43), c + Vector2(34,-43)
	])
	draw_colored_polygon(spear, ink)

func _draw_skeleton(c: Vector2, ink: Color, paper: Color) -> void:
	for y in [-1.0, 5.0, 11.0, 17.0]:
		draw_arc(c + Vector2(0,y), 14.0, 0.25, PI - 0.25, 16, ink, 2.0)
	draw_line(c + Vector2(0,-6), c + Vector2(0,23), ink, 2.5)
	draw_circle(c + Vector2(0,-19), 21, paper)
	draw_arc(c + Vector2(0,-19), 21, 0, TAU, 28, ink, 2.0)
	draw_circle(c + Vector2(-8,-22), 4.6, ink)
	draw_circle(c + Vector2(8,-22), 4.6, ink)
	draw_line(c + Vector2(-9,-8), c + Vector2(9,-8), ink, 1.6)
	for x in [-7.0,-2.5,2.5,7.0]:
		draw_line(c + Vector2(x,-8), c + Vector2(x,-2), ink, 1.0)
	draw_arc(c + Vector2(0,-44), 18.0, PI * 0.08, PI * 0.92, 18, Color(0.10,0.10,0.10,0.20), 1.2)


func _draw_elder(c: Vector2, ink: Color, paper: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c+Vector2(-18,27),c+Vector2(18,27),c+Vector2(12,-4),c+Vector2(-11,-5)]),ink)
	draw_circle(c+Vector2(0,-15),16.0,ink)
	draw_circle(c+Vector2(-6,-15),3.0,paper)
	draw_circle(c+Vector2(6,-15),3.0,paper)
	draw_colored_polygon(PackedVector2Array([c+Vector2(-10,-5),c+Vector2(10,-5),c+Vector2(4,15),c+Vector2(-2,22),c+Vector2(-8,14)]),Color(0.22,0.22,0.22,0.38))
	draw_line(c+Vector2(20,2),c+Vector2(28,30),Color(0.08,0.08,0.08,0.34),2.0)

func _draw_parent(c: Vector2, ink: Color, paper: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c+Vector2(-20,28),c+Vector2(20,28),c+Vector2(12,-5),c+Vector2(-10,-6)]),ink)
	draw_circle(c+Vector2(0,-15),16.0,ink)
	draw_circle(c+Vector2(12,-28),7.0,ink)
	draw_circle(c+Vector2(-6,-15),3.0,paper)
	draw_circle(c+Vector2(6,-15),3.0,paper)
	draw_circle(c+Vector2(27,10),7.0,Color(0.12,0.12,0.12,0.70))

func _draw_skeptic(c: Vector2, ink: Color, paper: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c+Vector2(-20,27),c+Vector2(20,27),c+Vector2(14,-5),c+Vector2(-14,-5)]),ink)
	draw_circle(c+Vector2(0,-15),16.0,ink)
	draw_rect(Rect2(c+Vector2(-17,-31),Vector2(32,7)),ink,true)
	draw_line(c+Vector2(10,-27),c+Vector2(23,-24),ink,3.0)
	draw_circle(c+Vector2(-6,-15),3.0,paper)
	draw_circle(c+Vector2(6,-15),3.0,paper)
	draw_line(c+Vector2(-17,4),c+Vector2(14,14),paper,1.3)
	draw_line(c+Vector2(17,4),c+Vector2(-14,14),paper,1.3)

func _draw_apprentice(c: Vector2, ink: Color, paper: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c+Vector2(-17,27),c+Vector2(17,27),c+Vector2(12,-4),c+Vector2(-12,-4)]),ink)
	draw_circle(c+Vector2(0,-15),15.0,ink)
	draw_colored_polygon(PackedVector2Array([c+Vector2(-14,-22),c+Vector2(-7,-37),c+Vector2(0,-29),c+Vector2(6,-40),c+Vector2(15,-22)]),ink)
	draw_circle(c+Vector2(-5,-15),3.0,paper)
	draw_circle(c+Vector2(5,-15),3.0,paper)
	draw_line(c+Vector2(16,5),c+Vector2(31,25),Color(0.08,0.08,0.08,0.30),2.0)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	draw_colored_polygon(PackedVector2Array([
		center + Vector2(0,-radius), center + Vector2(radius*0.75,0), center + Vector2(0,radius), center + Vector2(-radius*0.75,0)
	]), color)
