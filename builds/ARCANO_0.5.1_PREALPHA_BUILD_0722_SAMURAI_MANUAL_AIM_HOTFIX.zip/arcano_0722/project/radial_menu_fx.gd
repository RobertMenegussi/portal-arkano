extends Control

var t: float = 0.0
var open_amount: float = 0.0
var center_point: Vector2 = Vector2(480, 308)
var button_points: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if open_amount <= 0.001:
		return
	var eased: float = 1.0-pow(1.0-open_amount,2.4)
	# Soft veil and a quiet breathing focus around the mage. The menu should feel
	# deliberate rather than explosive.
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.01,0.012,0.011,0.145*eased),true)
	var breathe: float = 0.5+sin(t*1.6)*0.5
	for i in range(3):
		var radius := Vector2(112.0+float(i)*47.0,68.0+float(i)*27.0)
		_draw_oval_outline(center_point,radius,Color(0.86,0.86,0.81,(0.026-float(i)*0.005+0.004*breathe)*eased),1.0)
	for idx in range(button_points.size()):
		var point: Vector2 = button_points[idx]
		var reveal: float = clampf((open_amount-float(idx)*0.045)/0.76,0.0,1.0)
		if reveal <= 0.001:
			continue
		_draw_calm_link(point,idx,reveal)

func _draw_calm_link(point: Vector2,idx: int,reveal: float) -> void:
	var dir: Vector2 = (point-center_point).normalized()
	var side: Vector2 = Vector2(-dir.y,dir.x)
	var control: Vector2 = center_point.lerp(point,0.53)+side*(8.0+float(idx%2)*4.0)
	# A single hairline grows toward each card.
	for s in range(14):
		var f0: float = float(s)/14.0
		var f1: float = float(s+1)/14.0
		if f0 > reveal:
			break
		f1 = minf(f1,reveal)
		var p0: Vector2 = _bezier(center_point,control,point,f0)
		var p1: Vector2 = _bezier(center_point,control,point,f1)
		var fade: float = sin(PI*clampf(f0,0.0,1.0))
		draw_line(p0,p1,Color(0.84,0.84,0.79,0.035*fade*reveal),1.0)
	# One restrained mote rides the line instead of the old splash/droplet burst.
	var mote_f: float = clampf(reveal*1.08,0.0,1.0)
	var mote: Vector2 = _bezier(center_point,control,point,mote_f)
	draw_circle(mote,1.3,Color(0.88,0.87,0.81,0.20*sin(PI*mote_f)))
	if reveal > 0.72:
		var settle: float = (reveal-0.72)/0.28
		var ring_radius: float = lerpf(10.0,16.0,settle)
		draw_arc(point,ring_radius,-PI*0.9,PI*0.82,20,Color(0.86,0.85,0.80,0.055*(1.0-settle)),1.0)

func _bezier(a: Vector2,b: Vector2,c: Vector2,t_value: float) -> Vector2:
	var inv: float = 1.0-t_value
	return inv*inv*a+2.0*inv*t_value*b+t_value*t_value*c

func _draw_oval_outline(center: Vector2,radius: Vector2,color: Color,width: float) -> void:
	var previous: Vector2 = center+Vector2(radius.x,0)
	for i in range(1,33):
		var a: float = TAU*float(i)/32.0
		var current: Vector2 = center+Vector2(cos(a)*radius.x,sin(a)*radius.y)
		draw_line(previous,current,color,width)
		previous = current
