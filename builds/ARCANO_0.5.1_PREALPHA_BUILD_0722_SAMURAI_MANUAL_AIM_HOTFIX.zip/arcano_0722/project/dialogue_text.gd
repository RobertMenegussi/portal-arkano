extends RichTextLabel

signal line_finished

var raw_text: String = ""
var tone: String = "normal"
var speaker: String = ""
var typing: bool = false
var char_timer: float = 0.0
var char_interval: float = 0.025
var punctuation_pause: float = 0.0
var sound_stride: int = 2
var sound_counter: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	bbcode_enabled = true
	fit_content = false
	scroll_active = false
	autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_theme_font_size_override("normal_font_size", 17)
	add_theme_color_override("default_color", Color("#111111"))
	add_theme_constant_override("line_separation", 4)

func start_line(value: String, line_tone: String, speaker_name: String) -> void:
	raw_text = value
	tone = line_tone
	speaker = speaker_name
	char_interval = _speed_for_tone(tone)
	sound_stride = _stride_for_tone(tone)
	char_timer = char_interval
	punctuation_pause = 0.0
	sound_counter = 0
	text = _format_for_tone(raw_text, tone)
	visible_characters = 0
	typing = true

func is_typing() -> bool:
	return typing

func finish_line() -> void:
	visible_characters = -1
	typing = false
	line_finished.emit()

func _process(delta: float) -> void:
	if not typing:
		return
	if punctuation_pause > 0.0:
		punctuation_pause = maxf(0.0, punctuation_pause - delta)
		return

	char_timer -= delta
	while char_timer <= 0.0 and typing:
		char_timer += char_interval
		var next_index: int = visible_characters
		if next_index >= raw_text.length():
			visible_characters = -1
			typing = false
			line_finished.emit()
			break

		visible_characters += 1
		var ch: String = raw_text.substr(next_index, 1)
		_apply_character_feedback(ch)
		if ch == "." or ch == "!" or ch == "?":
			punctuation_pause = 0.085 if tone != "rapid" else 0.035
		elif ch == "," or ch == ";" or ch == ":":
			punctuation_pause = 0.035
		elif ch == "…":
			punctuation_pause = 0.11

func _apply_character_feedback(ch: String) -> void:
	if ch == " " or ch == "\n" or ch == "." or ch == "," or ch == "!" or ch == "?" or ch == ":" or ch == ";":
		return
	sound_counter += 1
	if sound_counter % sound_stride == 0:
		get_tree().call_group("audio_bus", "play_dialogue_tick", speaker, tone)

func _speed_for_tone(value: String) -> float:
	match value:
		"nervous":
			return 0.019
		"rapid":
			return 0.014
		"shout":
			return 0.017
		"grave":
			return 0.034
		"soft":
			return 0.032
		"hurt":
			return 0.036
		"mocking":
			return 0.027
		_:
			return 0.024

func _stride_for_tone(value: String) -> int:
	if value == "rapid" or value == "nervous":
		return 3
	return 2

func _format_for_tone(value: String, value_tone: String) -> String:
	var escaped: String = value.replace("[", "[").replace("]", "]")
	match value_tone:
		"nervous":
			return "[shake rate=11.0 level=2 connected=1]" + escaped + "[/shake]"
		"shout":
			return "[shake rate=20.0 level=5 connected=1]" + escaped + "[/shake]"
		"hurt":
			return "[shake rate=8.0 level=2 connected=1]" + escaped + "[/shake]"
		"mocking":
			return "[wave amp=3.0 freq=2.2 connected=1]" + escaped + "[/wave]"
		_:
			return escaped
