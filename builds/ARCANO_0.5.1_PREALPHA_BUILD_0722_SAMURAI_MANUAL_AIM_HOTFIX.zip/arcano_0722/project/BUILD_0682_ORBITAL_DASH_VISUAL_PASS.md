# BUILD 0682 — ORBITAL DASH VISUAL PASS

Focused pass on Orbital movement feel and dash identity.

## Goals
- Make the Orbital body feel more alive beyond idle/walk.
- Add robe/body reaction to motion, casting and dash.
- Give Orbital a distinct dash animation and stronger gameplay feel.
- Keep changes focused on Orbital so iteration stays clean.

## Changes
- Added Orbital-specific dash pose blending.
- Added start/landing dash flash layers and a dedicated Orbital dash effect drawing pass.
- Reworked Orbital body pose so robe, cape, hat and body lean react to movement, attack casting and dash.
- Reworked Orbital arm pose so the casting hand extends more clearly during attacks.
- Reworked Orbital stones during dash: they collapse into a fast comet-tail formation while dashing.
- Added a small Orbital landing burst at the end of dash to make the class feel more expressive and satisfying.

## Files changed
- player.gd
