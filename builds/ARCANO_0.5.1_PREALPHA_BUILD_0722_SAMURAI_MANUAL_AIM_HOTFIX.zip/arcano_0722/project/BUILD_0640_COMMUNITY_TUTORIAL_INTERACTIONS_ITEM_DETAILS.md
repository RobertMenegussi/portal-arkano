# ARCANO 0.5.0 PRE-ALPHA — BUILD 0640
## Community tutorial tone + deliberate world interactions + item details

### Tutorial dialogue tone
- Rewrote the full playable Sensei tutorial pass in EN / PT-BR / Japanese / Spanish.
- Removed overly poetic / abstract wording from the tutorial (crossroads, seals-as-metaphor, mysterious HUD descriptions, etc.).
- Sensei now speaks like an experienced player teaching a newcomer: clear first, relaxed second, with occasional light jokes instead of constant dramatic prose.
- Objective cards were also simplified so the requested action is immediately obvious.
- The Boss reveal remains, but is now delivered as a casual joke: Sensei teaches the player now and eventually fights them later.

### Vase interaction
- Runic Vases are no longer auto-attack targets.
- Player projectiles/automatic attacks no longer break them accidentally.
- Walk into interaction range and press [E] to break the vase.
- A localized world prompt appears only while the player is close enough.
- Existing vase break animation, XP reward, audio, profile progress and tutorial tracking are preserved.

### Chest interaction
- Silver, Gold and Elite chests no longer open merely because the player walked near them.
- Walk into interaction range and press [E] to open a chest.
- A localized [E] prompt appears while in range.
- Opening animation and delayed reward delivery are preserved.
- The tutorial now explicitly teaches this interaction.

### Consumable belt — 1 2 3 4 5 6 7 8 9 0
- Expanded the chest consumable belt from 9 to 10 slots.
- Slot keys are now [1] through [9] plus [0].
- Storage banners display the actual key, including [0] for the tenth slot.
- Full-belt messaging now refers to 10 item slots.

### Item descriptions — [I]
- Added a persistent HUD hint: [I] DETAILS.
- Press [I] during a run to toggle a clean item-information overlay.
- Overlay shows all ten slots in two columns with slot key, localized item name and a concise description of the actual gameplay effect.
- Press [I] again to close it.
- Added descriptions for all current chest consumables:
  - Healing Seal
  - XP Magnet
  - XP Burst
  - Gold Cache
  - Flow Spark
  - Champion Impulse
  - Runic Shock
  - Major Healing
  - Greater XP Burst
  - Dragon Breath
  - Skyfire Storm
  - Flow Reserve
  - Arcane Guard

### Localization
All new and rewritten player-facing text is present in:
- English (default)
- PT-BR
- Japanese
- Spanish

### Validation note
Godot is not installed in this execution environment. Build 0640 received static source validation, localization completeness checks and ZIP integrity validation, but not an engine runtime playtest.
