extends Node2D

const ChunkScript = preload("res://death_decal_chunk.gd")
var chunks: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 10
	add_to_group("death_decal_batch")
	add_to_group("run_decal")
	_ensure_chunk()

func _ensure_chunk():
	if not chunks.is_empty():
		var last = chunks[chunks.size()-1]
		if is_instance_valid(last) and not last.is_full():
			return last
	var chunk = ChunkScript.new()
	chunk.z_index = 0
	add_child(chunk)
	chunks.append(chunk)
	return chunk

func add_slime(world_pos: Vector2) -> void:
	_ensure_chunk().add_slime(world_pos)

func add_skeleton(world_pos: Vector2,pieces: Array) -> void:
	_ensure_chunk().add_skeleton(world_pos,pieces)
