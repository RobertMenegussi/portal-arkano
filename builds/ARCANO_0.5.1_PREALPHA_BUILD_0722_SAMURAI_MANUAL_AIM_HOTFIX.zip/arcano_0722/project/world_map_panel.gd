extends Control

var t: float = 0.0
var hover_index: int = -1
var points: Array = [
	{"name":"Vila Desbotada","pos":Vector2(164,324),"note":"onde a jornada começa"},
	{"name":"Ponte do Vigia","pos":Vector2(292,270),"note":"fronteira do vale"},
	{"name":"Ruínas dos Espadachins","pos":Vector2(404,348),"note":"ordem destruída"},
	{"name":"Refúgio dos Ladinos","pos":Vector2(518,220),"note":"últimos relatos são antigos"},
	{"name":"Santuário das Cores","pos":Vector2(630,318),"note":"quatro rotas, quatro guardiões"},
	{"name":"Terras Cinzentas","pos":Vector2(712,190),"note":"a cor quase não existe aqui"},
	{"name":"Castelo de Dracaris","pos":Vector2(792,112),"note":"destino final"}
]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if not event is InputEventMouseMotion:
		return
	var motion: InputEventMouseMotion = event as InputEventMouseMotion
	hover_index = -1
	for i in range(points.size()):
		var point: Dictionary = points[i]
		var p: Vector2 = point["pos"]
		if motion.position.distance_to(p) <= 18.0:
			hover_index = i
			break
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#faf6ed")
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.94,0.91,0.84,0.98),true)
	var map_rect: Rect2 = Rect2(Vector2(70,58),Vector2(size.x-140,size.y-116))
	draw_rect(map_rect,paper,true)
	for i in range(3):
		draw_rect(map_rect.grow(-float(i)*2.0),Color(0.08,0.08,0.08,0.20-float(i)*0.04),false,1.2)
	# terrain scribbles
	for i in range(11):
		var x: float = map_rect.position.x + 42.0 + float(i) * 66.0
		var y: float = map_rect.position.y + 84.0 + sin(float(i) * 1.6) * 56.0
		draw_arc(Vector2(x,y),24.0+float(i%3)*7.0,0.2,2.7,18,Color(0.08,0.08,0.08,0.055),1.0)
	# routes
	for i in range(points.size()-1):
		var a: Vector2 = points[i]["pos"]
		var b: Vector2 = points[i+1]["pos"]
		_draw_dashed_line(a,b,Color(0.08,0.08,0.08,0.24),9.0,5.0)
	# guard branches
	_draw_dashed_line(Vector2(630,318),Vector2(650,390),Color(0.08,0.08,0.08,0.15),7.0,5.0)
	_draw_dashed_line(Vector2(630,318),Vector2(574,398),Color(0.08,0.08,0.08,0.15),7.0,5.0)
	_draw_dashed_line(Vector2(630,318),Vector2(712,382),Color(0.08,0.08,0.08,0.15),7.0,5.0)
	_draw_dashed_line(Vector2(630,318),Vector2(766,338),Color(0.08,0.08,0.08,0.15),7.0,5.0)
	for i in range(points.size()):
		var entry: Dictionary = points[i]
		var p: Vector2 = entry["pos"]
		var pulse: float = 5.0 + sin(t * 3.0 + float(i)) * 0.5
		if i == hover_index:
			pulse += 2.5
		draw_circle(p,pulse,paper)
		draw_arc(p,pulse,0.0,TAU,18,Color(0.08,0.08,0.08,0.52),1.2)
		if i == points.size()-1:
			draw_circle(p,2.2,ink)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(94,96),"AS TERRAS CINZENTAS",HORIZONTAL_ALIGNMENT_LEFT,-1,22,ink)
		draw_string(font,Vector2(94,121),"Um mapa incompleto. Rotas riscadas por quem ainda tinha coragem de viajar.",HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color(0.08,0.08,0.08,0.52))
		for i in range(points.size()):
			var entry2: Dictionary = points[i]
			var p2: Vector2 = entry2["pos"]
			var offset: Vector2 = Vector2(12,-8)
			draw_string(font,p2+offset,str(entry2["name"]),HORIZONTAL_ALIGNMENT_LEFT,-1,10,Color(0.08,0.08,0.08,0.64 if i != hover_index else 0.95))
		if hover_index >= 0:
			var selected: Dictionary = points[hover_index]
			var info_rect: Rect2 = Rect2(Vector2(96,size.y-94),Vector2(size.x-192,52))
			draw_rect(info_rect,Color(1,1,1,0.46),true)
			draw_rect(info_rect,Color(0.08,0.08,0.08,0.13),false,1.0)
			draw_string(font,info_rect.position+Vector2(14,20),str(selected["name"]),HORIZONTAL_ALIGNMENT_LEFT,-1,13,ink)
			draw_string(font,info_rect.position+Vector2(14,39),str(selected["note"]),HORIZONTAL_ALIGNMENT_LEFT,-1,11,Color(0.08,0.08,0.08,0.52))

func _draw_dashed_line(a: Vector2,b: Vector2,color: Color,dash: float,gap: float) -> void:
	var delta: Vector2 = b-a
	var length: float = delta.length()
	if length <= 0.001:
		return
	var dir: Vector2 = delta/length
	var cursor: float = 0.0
	while cursor < length:
		var end_pos: float = minf(cursor+dash,length)
		draw_line(a+dir*cursor,a+dir*end_pos,color,1.2)
		cursor += dash+gap
