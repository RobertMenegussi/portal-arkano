extends Control

var fragments: int = 0
var t: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_fragments(value: int) -> void:
	fragments = value
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var center: Vector2 = Vector2(17, 16)
	var r: float = 8.0 + sin(t * 3.0) * 0.45
	var gem: PackedVector2Array = PackedVector2Array([
		center + Vector2(0, -r),
		center + Vector2(r * 0.72, 0),
		center + Vector2(0, r),
		center + Vector2(-r * 0.72, 0)
	])
	draw_colored_polygon(gem, paper)
	draw_polyline(PackedVector2Array([gem[0], gem[1], gem[2], gem[3], gem[0]]), Color(0.08,0.08,0.08,0.58), 1.3)
	draw_line(center + Vector2(-3,0), center + Vector2(3,0), Color(0.08,0.08,0.08,0.22), 1.0)
	draw_circle(center, 2.0, ink)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font, Vector2(34, 21), str(fragments), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, ink)
