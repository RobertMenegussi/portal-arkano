extends Node2D

var player
var life: float = 1.28
var elapsed: float = 0.0
var locked_center: Vector2 = Vector2.ZERO
var hit: bool = false
var spike_count: int = 12
var start_radius: float = 126.0
var end_radius: float = 54.0

func configure(target, center: Vector2) -> void:
	player = target
	locked_center = center
	global_position = center

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 27
	get_tree().call_group("audio_bus", "play_boss_mark")

func _process(delta: float) -> void:
	elapsed += delta
	if elapsed >= life:
		queue_free()
		return

	var progress: float = clampf(elapsed / life, 0.0, 1.0)
	if progress >= 0.54 and not hit and is_instance_valid(player):
		var radius_now: float = lerpf(start_radius, end_radius, _ease_close(progress))
		var distance: float = player.global_position.distance_to(global_position)
		# The cage snaps inward: getting caught near the contracting ring hurts once.
		if absf(distance - radius_now) <= 24.0 or (progress > 0.80 and distance <= end_radius + 12.0):
			hit = true
			var push: Vector2 = player.global_position - global_position
			if push.length_squared() < 0.001:
				push = Vector2.RIGHT
			player.take_damage(1, push.normalized())
			get_tree().call_group("screen_fx", "pulse_boss_mark")
	queue_redraw()

func _ease_close(progress: float) -> float:
	var t: float = clampf((progress - 0.24) / 0.62, 0.0, 1.0)
	return 1.0 - pow(1.0 - t, 3.0)

func _draw() -> void:
	var progress: float = clampf(elapsed / life, 0.0, 1.0)
	var telegraph: float = clampf(progress / 0.30, 0.0, 1.0)
	var close_t: float = _ease_close(progress)
	var radius_now: float = lerpf(start_radius, end_radius, close_t)
	# Faint locked circle before the bones slam inward.
	draw_arc(Vector2.ZERO, radius_now, 0.0, TAU, 48, Color(0.08,0.08,0.08,0.10 + telegraph * 0.12), 1.2)
	draw_arc(Vector2.ZERO, maxf(8.0, radius_now - 8.0), 0.0, TAU, 48, Color(0.08,0.08,0.08,0.06), 1.0)

	for i in range(spike_count):
		var angle: float = TAU * float(i) / float(spike_count) + sin(elapsed * 2.2) * 0.03
		var outward: Vector2 = Vector2(cos(angle), sin(angle))
		var side: Vector2 = Vector2(-outward.y, outward.x)
		var base: Vector2 = outward * radius_now
		var length: float = 24.0 + sin(float(i) * 1.9) * 3.0
		var tip: Vector2 = base - outward * length
		var half_width: float = 4.0
		var bone: PackedVector2Array = PackedVector2Array([
			base + side * half_width,
			base - side * half_width,
			tip
		])
		draw_colored_polygon(bone, Color(0.96,0.94,0.88,0.86))
		draw_polyline(PackedVector2Array([bone[0],bone[1],bone[2],bone[0]]), Color(0.08,0.08,0.08,0.42), 1.0)
		# joint scratch near each root
		draw_line(base + side * 6.0, base - side * 6.0, Color(0.08,0.08,0.08,0.15), 1.0)

	if progress > 0.78:
		var pulse: float = (progress - 0.78) / 0.22
		draw_circle(Vector2.ZERO, 14.0 + pulse * 16.0, Color(0.08,0.08,0.08,0.04 * (1.0-pulse)))
