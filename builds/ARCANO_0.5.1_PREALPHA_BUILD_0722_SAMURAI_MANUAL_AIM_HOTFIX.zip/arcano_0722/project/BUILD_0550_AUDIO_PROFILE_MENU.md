# ARCANO Build 0550 — Audio Comfort / Profile / Menu

- Music kept from 0526/0541 (user-approved).
- Repetitive combat SFX comfort pass:
  - 4 softer Orbital basic attack variants
  - 3 softer hit variants
  - 3 softer footstep variants
  - lower pitch / lower gain Lightning, Rift and Samurai basic SFX
  - reduced repetitive enemy attack SFX density
- Removed the menu slogan.
- Added PROFILE to the radial menu with persistent run statistics, averages and records.
- Build/version moved to the upper-right corner of the menu.
