extends Control

const EndlessCatalog = preload("res://endless_catalog.gd")

var player
var controller
var t: float = 0.0

func configure(target, owner_controller) -> void:
	player = target
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	t += delta
	queue_redraw()

func _draw() -> void:
	if not is_instance_valid(player) or not is_instance_valid(controller):
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var ink: Color = Color("#f2efe5")
	var faint: Color = Color(0.92, 0.91, 0.86, 0.56)
	var panel := Rect2(Vector2(40, 24), Vector2(880, 492))
	draw_rect(panel, Color(0.026, 0.032, 0.031, 0.972), true)
	for i in range(3):
		draw_rect(panel.grow(-float(i) * 2.0), Color(1, 1, 1, 0.05 - float(i) * 0.012), false, 1.0)
	for i in range(6):
		var x: float = panel.position.x + 24.0 + float(i) * 146.0
		draw_line(Vector2(x, panel.position.y + 56.0), Vector2(x + 22.0, panel.position.y + 53.0 + sin(t * 2.0 + float(i)) * 1.5), Color(1, 1, 1, 0.04), 1.0)
	draw_string(font, panel.position + Vector2(24, 32), Loc.t("tab.build_title"), HORIZONTAL_ALIGNMENT_LEFT, 500, 21, ink)
	draw_string(font, panel.position + Vector2(24, 52), Loc.t("tab.build_sub"), HORIZONTAL_ALIGNMENT_LEFT, 680, 10, faint)

	var rune_rect := Rect2(panel.position + Vector2(18, 72), Vector2(548, 392))
	var item_rect := Rect2(panel.position + Vector2(580, 72), Vector2(282, 392))
	_draw_section(font, rune_rect, Loc.f("stats.runes", [_compact_rune_ids().size()]), ink, faint)
	_draw_section(font, item_rect, Loc.t("hud.relic_details_title"), ink, faint)
	_draw_runes(font, rune_rect, ink, faint)
	_draw_items(font, item_rect, ink, faint)
	draw_string(font, Vector2(panel.position.x + 20, panel.end.y - 10), Loc.t("tab.build_footer"), HORIZONTAL_ALIGNMENT_LEFT, 840, 9, faint)

func _draw_section(font, rect: Rect2, title: String, ink: Color, faint: Color) -> void:
	draw_rect(rect, Color(1, 1, 1, 0.03), true)
	draw_rect(rect, Color(1, 1, 1, 0.055), false, 1.0)
	draw_string(font, rect.position + Vector2(14, 22), title, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 28, 12, ink)
	draw_string(font, Vector2(rect.end.x - 14, rect.position.y + 22), "◆", HORIZONTAL_ALIGNMENT_RIGHT, 16, 10, Color(faint.r, faint.g, faint.b, 0.36))
	draw_line(rect.position + Vector2(14, 31), Vector2(rect.end.x - 14, rect.position.y + 31), Color(1, 1, 1, 0.065), 1.0)

func _compact_rune_ids() -> Array:
	var source: Array = controller.acquired_traits if is_instance_valid(controller) else []
	var result: Array = []
	var family_slot: Dictionary = {}
	for value in source:
		var id: String = str(value)
		var key: String = EndlessCatalog.get_offer_key(id)
		if EndlessCatalog.is_foundation_rune(id):
			if family_slot.has(key):
				result[int(family_slot[key])] = id
			else:
				family_slot[key] = result.size()
				result.append(id)
		else:
			result.append(id)
	return result

func _draw_runes(font, rect: Rect2, ink: Color, faint: Color) -> void:
	var ids: Array = _compact_rune_ids()
	if ids.is_empty():
		draw_string(font, rect.position + Vector2(14, 58), Loc.t("stats.no_runes"), HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 28, 10, faint)
		return
	var shown: int = mini(12, ids.size())
	var start: int = maxi(0, ids.size() - shown)
	for i in range(shown):
		var col: int = i % 2
		var row: int = floori(float(i) / 2.0)
		var chip := Rect2(rect.position + Vector2(12 + col * 266, 42 + row * 56), Vector2(254, 49))
		_draw_rune_chip(font, chip, str(ids[start + i]), ink, faint)
	if ids.size() > shown:
		draw_string(font, Vector2(rect.position.x + 14, rect.end.y - 12), Loc.f("tab.more_runes", [ids.size() - shown]), HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 28, 8, faint)

func _draw_rune_chip(font, rect: Rect2, id: String, ink: Color, faint: Color) -> void:
	draw_rect(rect, Color(0, 0, 0, 0.16), true)
	draw_rect(rect, Color(1, 1, 1, 0.05), false, 1.0)
	var icon_center: Vector2 = rect.position + Vector2(20, 24)
	draw_circle(icon_center, 11.0, Color(1, 1, 1, 0.05))
	_draw_rune_icon(icon_center, id, ink)
	var rune_name: String = EndlessCatalog.get_trait_name(id)
	var desc: String = EndlessCatalog.get_description(id, str(player.mage_type))
	var cat: String = EndlessCatalog.get_category_label(EndlessCatalog.get_category(id))
	draw_string(font, rect.position + Vector2(38, 16), rune_name, HORIZONTAL_ALIGNMENT_LEFT, 150, 9, ink)
	draw_string(font, rect.position + Vector2(180, 16), cat, HORIZONTAL_ALIGNMENT_RIGHT, 64, 7, Color(0.78, 0.84, 0.90, 0.58))
	var summary: String = _shorten(desc, 80)
	draw_string(font, rect.position + Vector2(38, 34), summary, HORIZONTAL_ALIGNMENT_LEFT, 205, 8, faint)

func _draw_items(font, rect: Rect2, ink: Color, faint: Color) -> void:
	var slots: Array = controller.get_consumable_slots() if controller.has_method("get_consumable_slots") else []
	for i in range(10):
		var y: float = rect.position.y + 49.0 + float(i) * 33.0
		var key: String = controller.get_consumable_key_label(i) if controller.has_method("get_consumable_key_label") else str(i + 1)
		var item_id: String = str(slots[i]) if i < slots.size() else ""
		var row_rect := Rect2(Vector2(rect.position.x + 10, y - 16), Vector2(rect.size.x - 20, 28))
		draw_rect(row_rect, Color(0, 0, 0, 0.12), true)
		draw_rect(row_rect, Color(1, 1, 1, 0.03), false, 1.0)
		draw_rect(Rect2(Vector2(rect.position.x + 13, y - 13), Vector2(24, 22)), Color(1, 1, 1, 0.04), true)
		draw_string(font, Vector2(rect.position.x + 13, y + 3), key, HORIZONTAL_ALIGNMENT_CENTER, 24, 8, ink)
		if item_id == "":
			draw_string(font, Vector2(rect.position.x + 46, y + 3), Loc.t("hud.relic_empty"), HORIZONTAL_ALIGNMENT_LEFT, 206, 8, Color(faint.r, faint.g, faint.b, 0.34))
			continue
		var item_name: String = controller.get_consumable_name(item_id) if controller.has_method("get_consumable_name") else item_id
		var desc: String = controller.get_consumable_description(item_id) if controller.has_method("get_consumable_description") else ""
		_draw_item_icon(Vector2(rect.position.x + 50, y - 2), item_id, ink)
		draw_string(font, Vector2(rect.position.x + 64, y - 1), item_name, HORIZONTAL_ALIGNMENT_LEFT, 180, 9, ink)
		draw_string(font, Vector2(rect.position.x + 64, y + 9), _shorten(desc, 52), HORIZONTAL_ALIGNMENT_LEFT, 180, 7, faint)

func _draw_rune_icon(center: Vector2, id: String, color: Color) -> void:
	var idx: int = 0
	for char_i in range(id.length()):
		idx += id.unicode_at(char_i) * (char_i + 1)
	match absi(idx) % 6:
		0:
			draw_line(center + Vector2(-6, 0), center + Vector2(6, 0), color, 1.7)
			draw_circle(center + Vector2(4, 0), 2.2, color)
		1:
			_draw_diamond(center, 5.0, color)
		2:
			draw_arc(center, 6.0, -1.0, 1.0, 14, color, 1.4)
		3:
			draw_polyline(PackedVector2Array([center + Vector2(-5, 4), center + Vector2(-1, -3), center + Vector2(2, 2), center + Vector2(6, -5)]), color, 1.7)
		4:
			draw_arc(center, 6.4, 0.0, TAU, 18, color, 1.2)
			draw_circle(center, 2.0, color)
		_:
			draw_line(center + Vector2(-5, -4), center + Vector2(5, 4), color, 1.5)
			draw_line(center + Vector2(-5, 4), center + Vector2(5, -4), color, 1.5)

func _draw_item_icon(center: Vector2, item_id: String, color: Color) -> void:
	match item_id:
		"magnet":
			draw_arc(center + Vector2(0, 1), 5.0, PI * 0.12, PI * 0.88, 16, color, 1.8)
			draw_line(center + Vector2(-5, -1), center + Vector2(-5, 4), color, 1.8)
			draw_line(center + Vector2(5, -1), center + Vector2(5, 4), color, 1.8)
		"heal":
			draw_line(center + Vector2(-4, 0), center + Vector2(4, 0), color, 1.8)
			draw_line(center + Vector2(0, -4), center + Vector2(0, 4), color, 1.8)
		_:
			draw_circle(center, 2.1, color)

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([center + Vector2(0, -radius), center + Vector2(radius * 0.75, 0), center + Vector2(0, radius), center + Vector2(-radius * 0.75, 0)])
	draw_colored_polygon(poly, color)

func _shorten(value: String, limit: int) -> String:
	var clean: String = value.replace("
", " ").strip_edges()
	if clean.length() <= limit:
		return clean
	return clean.substr(0, maxi(1, limit - 1)).strip_edges() + "…"
