# BUILD 0713 — 200-enemy performance pass

Goal: keep the large-horde look while removing expensive work that scales badly toward ~200 simultaneous enemies.

Main changes:
- Added adaptive horde performance tiers (90+ and 150+ enemies).
- Idle enemy AI is staggered; attack states remain full-rate so combat timing stays responsive.
- Enemy movement still integrates every physics frame, keeping motion smooth.
- Spatial hash rebuild is now timer-based/adaptive and uses the controller's enemy registry instead of SceneTree-wide scans.
- Local separation recalculates less often in large hordes and caps the number of neighbors processed.
- Enemy redraw frequency adapts to distance, combat state and horde size.
- Distant idle enemies use cheaper direct movement.
- Hit/death/landing feedback is budgeted during extreme hordes to stop audio/screen-FX spam.
- Samurai's full-time nearest-enemy look now caches its target and no longer scans all enemies every physics frame.
- XP orbs merge earlier only during large hordes so hundreds of mobs + hundreds of loose XP objects do not compound.
- Existing detailed enemy drawings/animations are preserved; optimization targets update frequency and duplicated work rather than removing the art.

Runtime note:
Godot executable is not available in this environment, so this pass was statically validated only.
