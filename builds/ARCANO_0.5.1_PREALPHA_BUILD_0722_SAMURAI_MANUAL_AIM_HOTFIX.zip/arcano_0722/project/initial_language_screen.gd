extends Control

signal language_selected(code: String)

var t: float = 0.0
var hovered_index: int = -1
var option_rects: Array[Rect2] = []
var option_codes: Array[String] = ["en", "pt_BR", "ja", "es"]
var option_names: Array[String] = ["ENGLISH", "PORTUGUÊS (BR)", "日本語", "ESPAÑOL"]
var option_welcome: Array[String] = ["Enter the faded world", "Entre no mundo desbotado", "色を失った世界へ", "Entra al mundo descolorido"]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	set_process_input(true)
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	var mouse: Vector2 = get_local_mouse_position()
	var next_hover: int = -1
	for i in range(option_rects.size()):
		if option_rects[i].has_point(mouse):
			next_hover = i
			break
	if next_hover != hovered_index:
		hovered_index = next_hover
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		for i in range(option_rects.size()):
			if option_rects[i].has_point(event.position):
				language_selected.emit(option_codes[i])
				accept_event()
				return

func _draw() -> void:
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var size_now: Vector2 = size
	if size_now.x <= 1.0 or size_now.y <= 1.0:
		size_now = Vector2(960, 540)
	draw_rect(Rect2(Vector2.ZERO, size_now), Color("#121615"), true)
	for i in range(8):
		var radius: float = 82.0 + float(i) * 52.0 + sin(t * 0.42 + float(i)) * 5.0
		draw_arc(Vector2(size_now.x * 0.5, 248), radius, PI * 1.05, PI * 1.95, 56, Color(0.92, 0.91, 0.86, 0.020), 1.0)
	for i in range(12):
		var a: float = t * 0.28 + float(i) * TAU / 12.0
		var p: Vector2 = Vector2(size_now.x * 0.5, 248) + Vector2(cos(a) * 166.0, sin(a) * 68.0)
		draw_circle(p, 1.1, Color(0.92, 0.91, 0.86, 0.08))
	var crest: Vector2 = Vector2(size_now.x * 0.5, 72)
	draw_circle(crest, 31.0, Color(0.96, 0.95, 0.90, 0.04))
	draw_arc(crest, 19.0, 0.0, TAU, 36, Color(0.96, 0.95, 0.90, 0.62), 1.6)
	draw_arc(crest, 8.5, -PI * 0.5, PI * 0.5, 20, Color(0.96, 0.95, 0.90, 0.42), 1.0)
	draw_arc(crest, 8.5, PI * 0.5, PI * 1.5, 20, Color(0.96, 0.95, 0.90, 0.42), 1.0)
	draw_line(crest + Vector2(-18, 0), crest + Vector2(18, 0), Color(0.96, 0.95, 0.90, 0.38), 1.0)
	draw_string(font, Vector2(0, 124), "LANGUAGE  •  IDIOMA  •  言語  •  IDIOMA", HORIZONTAL_ALIGNMENT_CENTER, int(size_now.x), 24, Color(0.96, 0.95, 0.91, 0.96))
	draw_string(font, Vector2(0, 153), "CHOOSE  •  ESCOLHA  •  選択  •  ELIGE", HORIZONTAL_ALIGNMENT_CENTER, int(size_now.x), 11, Color(0.92, 0.91, 0.87, 0.56))
	draw_string(font, Vector2(0, 178), "hand-drawn onboarding", HORIZONTAL_ALIGNMENT_CENTER, int(size_now.x), 9, Color(0.92, 0.91, 0.87, 0.28))
	option_rects.clear()
	var card_size := Vector2(304, 108)
	var gap := Vector2(22, 18)
	var total_width: float = card_size.x * 2.0 + gap.x
	var start := Vector2((size_now.x - total_width) * 0.5, 214)
	for i in range(option_codes.size()):
		var col: int = i % 2
		var row: int = floori(float(i) / 2.0)
		var rect := Rect2(start + Vector2(float(col) * (card_size.x + gap.x), float(row) * (card_size.y + gap.y)), card_size)
		option_rects.append(rect)
		var hovered: bool = i == hovered_index
		var pulse: float = 0.5 + sin(t * 3.2 + float(i)) * 0.5
		var bg_alpha: float = 0.10 if hovered else 0.05
		draw_rect(rect, Color(0.96, 0.95, 0.90, bg_alpha), true)
		for ring in range(2):
			draw_rect(rect.grow(-float(ring) * 2.0), Color(0.96, 0.95, 0.90, (0.25 if hovered else 0.10) - float(ring) * 0.08), false, 1.0)
		if hovered:
			draw_line(rect.position + Vector2(14, rect.size.y - 10), rect.position + Vector2(rect.size.x - 14, rect.size.y - 10), Color(0.96, 0.95, 0.90, 0.20 + 0.10 * pulse), 1.0)
		var code_label: String = "%02d" % [i + 1]
		draw_string(font, rect.position + Vector2(18, 24), code_label, HORIZONTAL_ALIGNMENT_LEFT, 44, 8, Color(0.96, 0.95, 0.90, 0.30))
		draw_string(font, rect.position + Vector2(18, 54), option_names[i], HORIZONTAL_ALIGNMENT_LEFT, int(rect.size.x - 36), 16, Color(0.98, 0.97, 0.93, 0.95 if hovered else 0.82))
		draw_string(font, rect.position + Vector2(18, 81), option_welcome[i], HORIZONTAL_ALIGNMENT_LEFT, int(rect.size.x - 36), 9, Color(0.96, 0.95, 0.90, 0.50 if hovered else 0.32))
	draw_string(font, Vector2(0, 492), "ARCANO  •  onboarding  •  01/04", HORIZONTAL_ALIGNMENT_CENTER, int(size_now.x), 8, Color(0.96, 0.95, 0.90, 0.22))
