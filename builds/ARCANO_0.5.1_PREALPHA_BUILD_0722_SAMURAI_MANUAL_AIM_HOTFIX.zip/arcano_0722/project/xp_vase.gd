extends StaticBody2D

var player
var controller
var health: int = 1
var max_health: int = 1
var dead: bool = false
var t: float = 0.0
var ttl: float = 100.0
var break_t: float = 0.0
var shards: Array = []
const INTERACTION_RANGE: float = 58.0

func configure(target, owner_controller, life_time: float = 100.0) -> void:
	player = target
	controller = owner_controller
	ttl = life_time

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	collision_layer = 0
	collision_mask = 0
	z_index = 19
	add_to_group("xp_vase")
	add_to_group("world_interactable")
	add_to_group("endless_drop")
	var collider := CollisionShape2D.new()
	var shape := CircleShape2D.new()
	shape.radius = 12.0
	collider.shape = shape
	collider.position = Vector2(0, 4)
	add_child(collider)

func _process(delta: float) -> void:
	t += delta
	if dead:
		break_t += delta
		for shard_value in shards:
			var shard: Dictionary = shard_value
			var vel: Vector2 = shard["vel"]
			var pos: Vector2 = shard["pos"]
			var rot: float = float(shard["rot"])
			vel.y += 250.0 * delta
			pos += vel * delta
			rot += float(shard["spin"]) * delta
			shard["vel"] = vel
			shard["pos"] = pos
			shard["rot"] = rot
		queue_redraw()
		if break_t >= 0.58:
			queue_free()
		return
	ttl -= delta
	if ttl <= 0.0:
		queue_free()
		return
	queue_redraw()

func get_interaction_range() -> float:
	return INTERACTION_RANGE

func can_interact(target) -> bool:
	return not dead and is_instance_valid(target) and global_position.distance_to(target.global_position) <= INTERACTION_RANGE

func interact(target = null) -> bool:
	var actor = target if is_instance_valid(target) else player
	if not can_interact(actor):
		return false
	var direction: Vector2 = global_position - actor.global_position
	if direction.length_squared() < 0.001:
		direction = Vector2.RIGHT
	take_damage(1, direction.normalized())
	return true

func take_damage(_amount: int, hit_direction: Vector2) -> void:
	if dead:
		return
	dead = true
	health = 0
	collision_layer = 0
	collision_mask = 0
	var knock: Vector2 = hit_direction.normalized()
	if knock.length_squared() < 0.001:
		knock = Vector2.RIGHT
	for i in range(8):
		var a: float = -1.9 + float(i) * 0.56 + randf_range(-0.14, 0.14)
		var speed: float = randf_range(76.0, 145.0)
		shards.append({
			"pos": Vector2(randf_range(-6.0, 6.0), randf_range(-9.0, 5.0)),
			"vel": Vector2(cos(a), sin(a)) * speed + knock * 38.0,
			"rot": randf_range(-1.0, 1.0),
			"spin": randf_range(-7.0, 7.0),
			"size": randf_range(4.0, 8.0)
		})
	if is_instance_valid(controller) and controller.has_method("on_xp_vase_broken"):
		controller.on_xp_vase_broken(global_position)
	get_tree().call_group("audio_bus", "play_vase_break")
	get_tree().call_group("screen_fx", "pulse_hit")
	queue_redraw()

func _draw() -> void:
	if dead:
		_draw_broken()
		return
	var pulse: float = 0.5 + 0.5 * sin(t * 2.0)
	var ink := Color("#191816")
	var clay := Color("#8d6c51")
	var clay_light := Color("#b0906d")
	var rune := Color(0.76, 0.92, 0.90, 0.32 + 0.12 * pulse)
	draw_circle(Vector2.ZERO, 24.0 + pulse * 1.2, Color(0.76, 0.92, 0.90, 0.06))
	_draw_oval(Vector2(0, 17), Vector2(18, 5), Color(0.05, 0.05, 0.04, 0.08))
	var body := PackedVector2Array([
		Vector2(-9, -10), Vector2(-14, -2), Vector2(-16, 9), Vector2(-11, 18),
		Vector2(0, 22), Vector2(11, 18), Vector2(16, 9), Vector2(14, -2), Vector2(9, -10)
	])
	draw_colored_polygon(body, clay)
	draw_polyline(PackedVector2Array([body[0], body[1], body[2], body[3], body[4], body[5], body[6], body[7], body[8], body[0]]), ink, 1.5)
	draw_rect(Rect2(Vector2(-8, -17), Vector2(16, 8)), clay_light, true)
	draw_rect(Rect2(Vector2(-8, -17), Vector2(16, 8)), ink, false, 1.4)
	_draw_oval(Vector2(0, -17), Vector2(10, 3.7), clay_light)
	draw_arc(Vector2(0, -17), 10.0, 0.0, PI, 18, ink, 1.4)
	draw_arc(Vector2(0, 4), 14.0, 0.18, PI - 0.18, 20, Color(0.15, 0.13, 0.10, 0.26), 1.3)
	draw_arc(Vector2(0, 9), 12.0, PI + 0.18, TAU - 0.18, 20, Color(0.15, 0.13, 0.10, 0.20), 1.0)
	var diamond := PackedVector2Array([Vector2(0, -3), Vector2(4, 2), Vector2(0, 7), Vector2(-4, 2)])
	draw_circle(Vector2.ZERO, 8.0 + pulse * 0.5, Color(rune.r, rune.g, rune.b, 0.10))
	draw_colored_polygon(diamond, rune)
	draw_polyline(PackedVector2Array([diamond[0], diamond[1], diamond[2], diamond[3], diamond[0]]), Color(0.10, 0.10, 0.09, 0.30), 1.0)
	draw_line(Vector2(-11, 3), Vector2(-6, 7), Color(0.13, 0.11, 0.09, 0.18), 1.0)
	draw_line(Vector2(10, -1), Vector2(7, 5), Color(0.13, 0.11, 0.09, 0.16), 1.0)
	for i in range(4):
		var a: float = t * 0.6 + TAU * float(i) / 4.0
		var p: Vector2 = Vector2(cos(a) * 17.0, sin(a) * 9.0 - 6.0)
		draw_circle(p, 1.2, Color(0.82, 0.93, 0.87, 0.10 + 0.08 * pulse))
	_draw_interaction_prompt()

func _draw_interaction_prompt() -> void:
	if dead or not is_instance_valid(player) or global_position.distance_to(player.global_position) > INTERACTION_RANGE:
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var text: String = Loc.t("interact.vase")
	var width: float = 132.0
	var rect := Rect2(Vector2(-width * 0.5, -52), Vector2(width, 24))
	draw_rect(rect, Color(0.025, 0.032, 0.030, 0.92), true)
	draw_rect(rect, Color(0.92, 0.90, 0.84, 0.20), false, 1.0)
	draw_string(font, rect.position + Vector2(0, 16), text, HORIZONTAL_ALIGNMENT_CENTER, width, 9, Color(0.95, 0.94, 0.90, 0.92))

func _draw_broken() -> void:
	var fade: float = clampf(1.0 - break_t / 0.58, 0.0, 1.0)
	for shard in shards:
		var p: Vector2 = shard["pos"]
		var rot: float = shard["rot"]
		var s: float = shard["size"]
		var dir := Vector2(cos(rot), sin(rot)) * s
		var side := Vector2(-dir.y, dir.x) * 0.55
		var poly := PackedVector2Array([p + dir, p - dir + side, p - dir - side])
		draw_colored_polygon(poly, Color(0.58, 0.43, 0.31, 0.75 * fade))
		draw_polyline(PackedVector2Array([poly[0], poly[1], poly[2], poly[0]]), Color(0.10, 0.09, 0.08, 0.40 * fade), 0.9)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts := PackedVector2Array()
	for i in range(22):
		var a: float = TAU * float(i) / 22.0
		pts.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(pts, color)
