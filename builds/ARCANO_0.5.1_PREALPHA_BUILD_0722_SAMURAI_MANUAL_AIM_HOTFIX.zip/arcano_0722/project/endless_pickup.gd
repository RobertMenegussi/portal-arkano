extends Node2D

var player
var kind: String = "heal"
var t: float = 0.0
var collected: bool = false

func configure(target, pickup_kind: String) -> void:
	player = target
	kind = pickup_kind

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 21

func _process(delta: float) -> void:
	if collected or not is_instance_valid(player):
		return
	t += delta
	if global_position.distance_to(player.global_position) <= 28.0:
		collected = true
		get_tree().call_group("endless_controller", "collect_pickup", kind)
		queue_free()
	queue_redraw()

func _draw() -> void:
	var pulse: float = 1.0 + sin(t * 5.0) * 0.08
	var aura: Color = Color(1, 1, 1, 0.08)
	match kind:
		"heal": aura = Color(0.82, 0.94, 0.82, 0.12)
		"magnet": aura = Color(0.80, 0.90, 1.0, 0.12)
		_: aura = Color(1.0, 0.86, 0.78, 0.12)
	draw_circle(Vector2.ZERO, 14.0 * pulse, aura)
	draw_circle(Vector2(0, 8), 10.0, Color(0, 0, 0, 0.06))
	if kind == "heal":
		draw_circle(Vector2.ZERO, 10.2 * pulse, Color("#d9ebcf"))
		draw_arc(Vector2.ZERO, 10.2 * pulse, 0.0, TAU, 24, Color("#243024"), 1.2)
		draw_line(Vector2(-5.5, 0), Vector2(5.5, 0), Color("#263326"), 2.4)
		draw_line(Vector2(0, -5.5), Vector2(0, 5.5), Color("#263326"), 2.4)
	elif kind == "magnet":
		draw_arc(Vector2.ZERO, 10.6 * pulse, PI * 0.18, PI * 0.82, 20, Color("#1b2230"), 2.4)
		draw_arc(Vector2.ZERO, 10.6 * pulse, PI * 1.18, PI * 1.82, 20, Color("#1b2230"), 2.4)
		draw_line(Vector2(-8.0, -5.5), Vector2(-8.0, 4.2), Color("#d6e8ff"), 3.4)
		draw_line(Vector2(8.0, -5.5), Vector2(8.0, 4.2), Color("#d6e8ff"), 3.4)
		draw_line(Vector2(-8.0, 4.2), Vector2(8.0, 4.2), Color("#d6e8ff"), 3.0)
		draw_line(Vector2(-8.0, -5.5), Vector2(-3.0, -5.5), Color("#ffb2b2"), 2.1)
		draw_line(Vector2(3.0, -5.5), Vector2(8.0, -5.5), Color("#b2c6ff"), 2.1)
	else:
		draw_circle(Vector2.ZERO, 9.4 * pulse, Color("#f0d2c6"))
		draw_arc(Vector2.ZERO, 9.4 * pulse, 0.0, TAU, 24, Color(0.12, 0.08, 0.06, 0.58), 1.2)
		for i in range(8):
			var a: float = TAU * float(i) / 8.0
			draw_line(Vector2(cos(a), sin(a)) * 4.8, Vector2(cos(a), sin(a)) * 12.8, Color(0.12, 0.08, 0.06, 0.72), 1.5)
		draw_circle(Vector2.ZERO, 2.3, Color(1, 1, 1, 0.42))
