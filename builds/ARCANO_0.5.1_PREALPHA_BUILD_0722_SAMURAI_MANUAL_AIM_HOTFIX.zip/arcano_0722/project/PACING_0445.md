# ARCANO Endless pacing 0445

- XP curve slowed (~40% more XP required around levels 6-9).
- Enemy roster staged by time.
- Early slimes: 2 HP during first minute.
- Elites: ~01:30, 03:00, 04:30; next one after boss window.
- First boss: 06:00, with HUD countdown.
- First Endless boss uses Olheiro Distante combat kit, scaled for the run.
- Regular enemy cap and spawn cadence ramp in phases instead of near-linearly.
