# ARCANO 0.5.0 Pre-Alpha — Build 0620

## Radial menu
- Fixed the bottom collision between PROFILE and ARCANE RUNES.
- Radial layout now opens on a wider ellipse, leaving ~38 px of horizontal breathing room between those two cards at rest.
- Replaced the busier splash-like radial FX with a quieter staged reveal: soft veil, breathing elliptical rings, thin links and a restrained traveling mote.
- Added smoother staggered card entry, subtle settle, scale and micro-rotation.

## Premium UI audio
- Added original runtime-generated PCM sounds for radial open/close and panel open/close.
- Retuned hover/click sounds toward a softer glass/chime/body character.
- No external/copyrighted console audio is used; the sounds are synthesized by the game.

## Tutorial boundary
- Added a Sensei-centered ink ward (~335 px radius).
- The player is gently hard-limited at the ward edge and outward velocity is removed, preventing the lesson from being abandoned by simply walking away.
- Tutorial enemies, vases, chests and Elite examples are clamped to safe positions inside the lesson area.
- Crossing the edge shows a localized in-world warning and makes the Sensei react seriously.
- Sensei now draws a subtle broken ink-circle ward in world space.

## Tutorial dialogue presentation
- Dialogue cards now enter with a short eased motion instead of appearing flat.
- Objective cards also slide in cleanly without intercepting Rune-card clicks.
- Added typewriter dialogue ticks and a soft dialogue-open sound.
- Sensei voice pitch reacts to happy / serious / surprised moods.
- Existing portrait expressions received matching micro-motion/glyph reactions.

## Player-facing writing polish
- Audited the current playable build's localization/menu/tutorial/stats/Rune copy for dev-note or implementation-facing language.
- Rewrote Tutorial, Profile, Maps, class descriptions, Rune catalog guidance and tactical-panel copy where text sounded like documentation instead of game writing.
- Removed implementation-facing terms such as Profile-system bookkeeping, enemies “in scene”, the internal “Director” label, and tutorial prose about systems/build plumbing.
- Rune of Tempo/Celeridade no longer mentions avoiding a “machine gun”; it now describes the sensation and actual benefit naturally.
- All 100 style Rune descriptions remain present and were rewritten in player-facing language based on their real trigger/pattern/effect behavior.
- All changed visible text remains aligned in EN / PT-BR / 日本語 / ES.

## Validation
- Static structural validation passed for changed GDScript files.
- Localization dictionary parses with 297 keys and every localized entry has all four languages.
- Rune catalog structured validation: 9 core + 10 stat families + 25 mechanic + 100 unique style Runes; localized names/descriptions complete.
- Radial PROFILE/RUNES rest-state gap validated at ~38 px.
- Godot executable is not available in this environment, so runtime gameplay/audio rendering still needs an in-engine test.
