extends Node

const SFX_RATE: int = 44100
const MUSIC_RATE: int = 22050

var master_volume: float = 0.85
var music_volume: float = 0.55
var sfx_volume: float = 0.85

var menu_music_player: AudioStreamPlayer
var game_music_player: AudioStreamPlayer
var boss_music_player: AudioStreamPlayer
var sfx_pool: Array[AudioStreamPlayer] = []
var sfx_index: int = 0
var hover_gate: float = 0.0
var last_sfx_ms: Dictionary = {}

var streams: Dictionary = {}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("audio_bus")
	_load_settings()
	_generate_streams()
	_create_players()
	_apply_music_volumes()
	play_menu_music()

func _process(delta: float) -> void:
	hover_gate = maxf(0.0, hover_gate - delta)

func _generate_streams() -> void:
	# Nenhum arquivo externo: tudo é PCM gerado pelo Godot em runtime.
	streams["player_shot"] = _make_player_shot()
	streams["player_shot_0"] = _make_soft_player_shot(0)
	streams["player_shot_1"] = _make_soft_player_shot(1)
	streams["player_shot_2"] = _make_soft_player_shot(2)
	streams["player_shot_3"] = _make_soft_player_shot(3)
	streams["dash"] = _make_dash()
	streams["enemy_shot"] = _make_enemy_shot()
	streams["slime_attack"] = _make_slime_attack()
	streams["player_hurt"] = _make_player_hurt()
	streams["enemy_die"] = _make_enemy_die()
	streams["enemy_hit"] = _make_enemy_hit()
	streams["enemy_hit_0"] = _make_soft_hit(0)
	streams["enemy_hit_1"] = _make_soft_hit(1)
	streams["enemy_hit_2"] = _make_soft_hit(2)
	streams["ui_hover"] = _make_ui_hover()
	streams["ui_click"] = _make_ui_click()
	streams["ui_radial_open"] = _make_ui_radial_open()
	streams["ui_radial_close"] = _make_ui_radial_close()
	streams["ui_panel_open"] = _make_ui_panel_open()
	streams["ui_panel_close"] = _make_ui_panel_close()
	streams["blob_tap"] = _make_blob_tap()
	streams["dialogue_tick"] = _make_dialogue_tick()
	streams["dialogue_open"] = _make_dialogue_open()
	streams["magic_reload"] = _make_magic_reload()
	streams["magic_reload_finish"] = _make_magic_reload_finish()
	streams["boss_reveal"] = _make_boss_reveal()
	streams["boss_fall"] = _make_boss_fall()
	streams["lightning"] = _make_lightning()
	streams["rift"] = _make_rift()
	streams["boss_mark"] = _make_boss_mark()
	streams["footstep"] = _make_footstep()
	streams["footstep_0"] = _make_soft_footstep(0)
	streams["footstep_1"] = _make_soft_footstep(1)
	streams["footstep_2"] = _make_soft_footstep(2)
	streams["wind_gust"] = _make_wind_gust()
	streams["shield_break"] = _make_shield_break()
	streams["necro_summon"] = _make_necro_summon()
	streams["arcane_surge"] = _make_arcane_surge()
	streams["samurai_slash"] = _make_samurai_slash()
	streams["samurai_dash_hit"] = _make_samurai_dash_hit()
	streams["vase_break"] = _make_vase_break()
	streams["rune_proc_0"] = _make_rune_proc(0)
	streams["rune_proc_1"] = _make_rune_proc(1)
	streams["rune_proc_2"] = _make_rune_proc(2)
	streams["menu_music"] = _make_new_music("menu")
	streams["game_music"] = _make_new_music("game")
	streams["boss_music"] = _make_new_music("boss")

func _create_players() -> void:
	menu_music_player = AudioStreamPlayer.new()
	menu_music_player.process_mode = Node.PROCESS_MODE_ALWAYS
	menu_music_player.stream = streams["menu_music"]
	add_child(menu_music_player)

	game_music_player = AudioStreamPlayer.new()
	game_music_player.process_mode = Node.PROCESS_MODE_ALWAYS
	game_music_player.stream = streams["game_music"]
	add_child(game_music_player)

	boss_music_player = AudioStreamPlayer.new()
	boss_music_player.process_mode = Node.PROCESS_MODE_ALWAYS
	boss_music_player.stream = streams["boss_music"]
	add_child(boss_music_player)

	for i in range(14):
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		p.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(p)
		sfx_pool.append(p)

func _next_sfx_player() -> AudioStreamPlayer:
	var p: AudioStreamPlayer = sfx_pool[sfx_index]
	sfx_index = (sfx_index + 1) % sfx_pool.size()
	return p

func _db_from_ratio(value: float) -> float:
	if value <= 0.001:
		return -80.0
	return linear_to_db(value)

func _scaled_sfx(gain: float) -> float:
	return master_volume * sfx_volume * gain

func _apply_music_volumes() -> void:
	if is_instance_valid(menu_music_player):
		menu_music_player.volume_db = _db_from_ratio(master_volume * music_volume)
	if is_instance_valid(game_music_player):
		game_music_player.volume_db = _db_from_ratio(master_volume * music_volume * 0.90)
	if is_instance_valid(boss_music_player):
		boss_music_player.volume_db = _db_from_ratio(master_volume * music_volume * 0.96)

func play_menu_music() -> void:
	if not is_instance_valid(menu_music_player):
		return
	if is_instance_valid(game_music_player):
		game_music_player.stop()
	if is_instance_valid(boss_music_player):
		boss_music_player.stop()
	if not menu_music_player.playing:
		menu_music_player.play()

func play_game_music() -> void:
	if not is_instance_valid(game_music_player):
		return
	if is_instance_valid(menu_music_player):
		menu_music_player.stop()
	if is_instance_valid(boss_music_player):
		boss_music_player.stop()
	if not game_music_player.playing:
		game_music_player.play()

func play_boss_music() -> void:
	if not is_instance_valid(boss_music_player):
		return
	if is_instance_valid(menu_music_player):
		menu_music_player.stop()
	if is_instance_valid(game_music_player):
		game_music_player.stop()
	if not boss_music_player.playing:
		boss_music_player.play()

func stop_all_music() -> void:
	if is_instance_valid(menu_music_player):
		menu_music_player.stop()
	if is_instance_valid(game_music_player):
		game_music_player.stop()
	if is_instance_valid(boss_music_player):
		boss_music_player.stop()

func _play_sfx(key: String, gain: float = 1.0, pitch: float = 1.0) -> void:
	if not streams.has(key):
		return
	var p: AudioStreamPlayer = _next_sfx_player()
	p.stream = streams[key]
	p.pitch_scale = pitch
	p.volume_db = _db_from_ratio(_scaled_sfx(gain))
	p.play()


func _play_sfx_limited(key: String,gain: float,pitch: float,min_interval_ms: int,probability: float = 1.0) -> void:
	if probability < 1.0 and randf() > probability:
		return
	var now_ms: int = Time.get_ticks_msec()
	var last_ms: int = int(last_sfx_ms.get(key,-100000))
	if now_ms-last_ms < min_interval_ms:
		return
	last_sfx_ms[key] = now_ms
	_play_sfx(key,gain,pitch)

func play_player_shot() -> void:
	var key: String = "player_shot_"+str(randi()%4)
	_play_sfx_limited(key,0.20,randf_range(0.97,1.035),74,0.92)

func play_dash() -> void:
	_play_sfx("dash", 0.82, randf_range(0.98, 1.02))

func play_enemy_shot() -> void:
	_play_sfx_limited("enemy_shot",0.22,randf_range(0.95,1.06),88,0.64)

func play_slime_attack() -> void:
	_play_sfx_limited("slime_attack",0.24,randf_range(0.95,1.05),105,0.62)

func play_player_hurt() -> void:
	_play_sfx("player_hurt", 0.92, randf_range(0.98, 1.02))

func play_enemy_die() -> void:
	_play_sfx_limited("enemy_die",0.28,randf_range(0.86,1.14),58,0.72)

func play_enemy_hit() -> void:
	var key: String = "enemy_hit_"+str(randi()%3)
	_play_sfx_limited(key,0.12,randf_range(0.96,1.04),68,0.52)

func play_ui_hover() -> void:
	if hover_gate > 0.0:
		return
	hover_gate = 0.055
	_play_sfx("ui_hover", 0.31, randf_range(0.985, 1.02))

func play_ui_click() -> void:
	_play_sfx("ui_click", 0.48, randf_range(0.99, 1.015))

func play_ui_radial_open() -> void:
	_play_sfx("ui_radial_open",0.52,randf_range(0.995,1.008))

func play_ui_radial_close() -> void:
	_play_sfx("ui_radial_close",0.42,randf_range(0.995,1.008))

func play_ui_panel_open() -> void:
	_play_sfx("ui_panel_open",0.43,randf_range(0.995,1.01))

func play_ui_panel_close() -> void:
	_play_sfx("ui_panel_close",0.36,randf_range(0.995,1.01))

func play_blob_tap() -> void:
	_play_sfx("blob_tap", 0.72, randf_range(0.97, 1.04))

func play_dialogue_open() -> void:
	_play_sfx("dialogue_open", 0.30, randf_range(0.98, 1.02))

func play_magic_reload() -> void:
	_play_sfx("magic_reload", 0.70, randf_range(0.98, 1.02))

func play_magic_reload_finish() -> void:
	_play_sfx("magic_reload_finish", 0.78, randf_range(0.99, 1.03))

func play_boss_reveal() -> void:
	_play_sfx("boss_reveal", 0.82, 1.0)

func play_boss_fall() -> void:
	_play_sfx("boss_fall", 0.86, 1.0)

func play_lightning() -> void:
	_play_sfx_limited("lightning",0.31,randf_range(0.96,1.04),112,0.84)

func play_rift() -> void:
	_play_sfx_limited("rift",0.30,randf_range(0.96,1.04),105,0.82)

func play_boss_mark() -> void:
	_play_sfx("boss_mark", 0.82, 1.0)

func play_footstep() -> void:
	var key: String = "footstep_"+str(randi()%3)
	_play_sfx_limited(key,0.105,randf_range(0.97,1.03),125,0.82)

func play_wind_gust() -> void:
	_play_sfx("wind_gust", 0.24, randf_range(0.96, 1.03))

func play_shield_break() -> void:
	_play_sfx("shield_break",0.82,randf_range(0.98,1.03))

func play_necro_summon() -> void:
	_play_sfx("necro_summon",0.56,randf_range(0.97,1.03))

func play_arcane_surge() -> void:
	_play_sfx("arcane_surge",0.72,1.0)

func play_samurai_slash() -> void:
	_play_sfx_limited("samurai_slash",0.34,randf_range(0.97,1.03),92,0.92)

func play_samurai_dash_hit() -> void:
	_play_sfx_limited("samurai_dash_hit",0.48,randf_range(0.94,1.06),52,0.86)

func play_vase_break() -> void:
	_play_sfx("vase_break",0.58,randf_range(0.96,1.05))

func play_rune_proc() -> void:
	var idx: int = randi()%3
	_play_sfx_limited("rune_proc_"+str(idx),0.24,randf_range(0.94,1.06),88,0.82)

func play_dialogue_tick(speaker_name: String, line_tone: String = "normal") -> void:
	var pitch: float = 1.0
	match speaker_name:
		"Mago":
			pitch = 1.08
		"Mentor":
			pitch = 0.83
		"Mercante":
			pitch = 1.16
		"Vigia":
			pitch = 1.24
		"Olheiro Distante":
			pitch = 0.68
		"SENSEI", "師匠":
			pitch = 0.82
	if line_tone == "nervous":
		pitch += randf_range(-0.10, 0.10)
	elif line_tone == "grave" or line_tone == "hurt" or line_tone == "serious":
		pitch *= 0.92
	elif line_tone == "surprised":
		pitch *= 1.08
	elif line_tone == "happy":
		pitch *= 1.03
	_play_sfx("dialogue_tick", 0.19, pitch * randf_range(0.97, 1.03))

func set_master_volume(value: float) -> void:
	master_volume = clampf(value, 0.0, 1.0)
	_apply_music_volumes()
	save_settings()

func set_music_volume(value: float) -> void:
	music_volume = clampf(value, 0.0, 1.0)
	_apply_music_volumes()
	save_settings()

func set_sfx_volume(value: float) -> void:
	sfx_volume = clampf(value, 0.0, 1.0)
	save_settings()

func save_settings() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.load("user://settings.cfg")
	cfg.set_value("audio", "master", master_volume)
	cfg.set_value("audio", "music", music_volume)
	cfg.set_value("audio", "sfx", sfx_volume)
	cfg.save("user://settings.cfg")

func _load_settings() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		master_volume = float(cfg.get_value("audio", "master", master_volume))
		music_volume = float(cfg.get_value("audio", "music", music_volume))
		sfx_volume = float(cfg.get_value("audio", "sfx", sfx_volume))

# ------------------------------------------------------------------
# PCM synthesis
# ------------------------------------------------------------------

func _pcm_stream(samples: PackedFloat32Array, rate: int, looped: bool = false, loop_begin_sample: int = 0, loop_end_sample: int = -1) -> AudioStreamWAV:
	var bytes: PackedByteArray = PackedByteArray()
	bytes.resize(samples.size() * 2)

	for i in range(samples.size()):
		var sample: float = clampf(samples[i], -1.0, 1.0)
		var signed_value: int = int(round(sample * 32767.0))
		var unsigned_value: int = signed_value
		if unsigned_value < 0:
			unsigned_value += 65536
		bytes[i * 2] = unsigned_value & 0xFF
		bytes[i * 2 + 1] = (unsigned_value >> 8) & 0xFF

	var stream: AudioStreamWAV = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = bytes

	if looped:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = clampi(loop_begin_sample, 0, maxi(0, samples.size() - 1))
		stream.loop_end = samples.size() if loop_end_sample < 0 else clampi(loop_end_sample, stream.loop_begin + 1, samples.size())

	return stream

func _add_sample(samples: PackedFloat32Array, index: int, value: float) -> void:
	if index >= 0 and index < samples.size():
		samples[index] = clampf(samples[index] + value, -1.0, 1.0)

func _envelope(t: float, duration: float, attack: float, release: float) -> float:
	if t < attack:
		return clampf(t / maxf(attack, 0.0001), 0.0, 1.0)
	if t > duration - release:
		return clampf((duration - t) / maxf(release, 0.0001), 0.0, 1.0)
	return 1.0

func _noise_value(index: int, seed_value: float) -> float:
	# Deterministic pseudo-noise. No RandomNumberGenerator allocation per sample.
	var n: float = sin(float(index) * 12.9898 + seed_value * 78.233) * 43758.5453
	return (n - floor(n)) * 2.0 - 1.0

func _make_player_shot() -> AudioStreamWAV:
	return _make_soft_player_shot(0)

func _make_soft_player_shot(variant: int) -> AudioStreamWAV:
	var duration: float = 0.13+float(variant%2)*0.015
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	var base: float = 245.0+float(variant)*24.0
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.004,0.075)
		var body: float = sin(TAU*lerpf(base+45.0,base-50.0,p)*tt)*0.135
		var low: float = sin(TAU*(base*0.48)*tt)*0.085
		var air: float = _noise_value(i,13.0+float(variant)*8.0)*0.025*(1.0-p)
		samples[i] = (body+low+air)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_dash() -> AudioStreamWAV:
	var duration: float = 0.20
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.002, 0.085)
		var f: float = lerpf(520.0, 110.0, p)
		var s: float = sin(TAU * f * t) * 0.30
		s += _noise_value(i, 4.2) * (0.20 * (1.0 - p))
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_enemy_shot() -> AudioStreamWAV:
	var duration: float = 0.18
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.002, 0.07)
		var s: float = sin(TAU * 340.0 * t) * 0.24
		s += signf(sin(TAU * 510.0 * t)) * 0.08
		s += _noise_value(i, 7.7) * 0.04
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_slime_attack() -> AudioStreamWAV:
	var duration: float = 0.24
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.006, 0.09)
		var f: float = lerpf(155.0, 72.0, p)
		var s: float = sin(TAU * f * t) * 0.28
		s += sin(TAU * f * 0.52 * t) * 0.12
		s += _noise_value(i, 12.0) * 0.07
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_player_hurt() -> AudioStreamWAV:
	var duration: float = 0.16
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.001, 0.09)
		var s: float = signf(sin(TAU * 175.0 * t)) * 0.20
		s += _noise_value(i, 19.2) * 0.20
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_enemy_die() -> AudioStreamWAV:
	var duration: float = 0.28
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.002, 0.12)
		var f: float = lerpf(250.0, 78.0, p)
		var s: float = sin(TAU * f * t) * 0.26
		s += _noise_value(i, 29.0) * (0.13 * (1.0 - p))
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_enemy_hit() -> AudioStreamWAV:
	var duration: float = 0.105
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.001, 0.055)
		var click: float = sin(TAU * lerpf(760.0, 210.0, p) * t) * 0.18
		var body: float = sin(TAU * 120.0 * t) * 0.10
		var scratch: float = _noise_value(i, 24.7) * 0.11 * (1.0 - p)
		samples[i] = (click + body + scratch) * env
	return _pcm_stream(samples, SFX_RATE)

func _make_soft_hit(variant: int) -> AudioStreamWAV:
	var duration: float = 0.075+float(variant)*0.008
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.0015,0.045)
		var body: float = sin(TAU*(135.0+float(variant)*18.0)*tt)*0.10
		var tap: float = sin(TAU*lerpf(360.0,190.0,p)*tt)*0.07
		var texture: float = _noise_value(i,61.0+float(variant)*9.0)*0.045*(1.0-p)
		samples[i] = (body+tap+texture)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_hover() -> AudioStreamWAV:
	var duration: float = 0.13
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.006,0.070)
		var glass: float = sin(TAU * lerpf(610.0,760.0,p) * t) * 0.075
		var overtone: float = sin(TAU * 1220.0 * t) * 0.024 * (1.0-p)
		var air: float = _noise_value(i,141.0) * 0.008 * (1.0-p)
		samples[i] = (glass+overtone+air)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_click() -> AudioStreamWAV:
	var duration: float = 0.17
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.003,0.090)
		var body: float = sin(TAU * lerpf(205.0,168.0,p) * t) * 0.105
		var bell: float = sin(TAU * 520.0 * t) * 0.058
		var shine: float = sin(TAU * 780.0 * t) * 0.026 * (1.0-p)
		samples[i] = (body+bell+shine)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_radial_open() -> AudioStreamWAV:
	var duration: float = 0.46
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.012,0.16)
		var low: float = sin(TAU * lerpf(155.0,205.0,p) * t) * 0.075
		var mid_gate: float = clampf((t-0.055)/0.10,0.0,1.0)
		var high_gate: float = clampf((t-0.120)/0.10,0.0,1.0)
		var mid: float = sin(TAU * 330.0 * t) * 0.050 * mid_gate
		var high: float = sin(TAU * 495.0 * t) * 0.032 * high_gate
		var air: float = _noise_value(i,163.0) * 0.011 * sin(PI*p)
		samples[i] = (low+mid+high+air)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_radial_close() -> AudioStreamWAV:
	var duration: float = 0.31
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.006,0.13)
		var hush: float = sin(TAU * lerpf(420.0,190.0,p) * t) * 0.060
		var low: float = sin(TAU * 128.0 * t) * 0.070 * p
		var air: float = _noise_value(i,177.0) * 0.008 * (1.0-p)
		samples[i] = (hush+low+air)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_panel_open() -> AudioStreamWAV:
	var duration: float = 0.27
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.008,0.11)
		var warm: float = sin(TAU * 245.0 * t) * 0.068
		var chime: float = sin(TAU * lerpf(510.0,660.0,p) * t) * 0.040
		var sparkle: float = sin(TAU * 990.0 * t) * 0.015 * (1.0-p)
		samples[i] = (warm+chime+sparkle)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_ui_panel_close() -> AudioStreamWAV:
	var duration: float = 0.23
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t,duration,0.004,0.10)
		var tone: float = sin(TAU * lerpf(390.0,225.0,p) * t) * 0.052
		var soft: float = sin(TAU * 150.0 * t) * 0.040 * p
		samples[i] = (tone+soft)*env
	return _pcm_stream(samples,SFX_RATE)


func _make_dialogue_tick() -> AudioStreamWAV:
	var duration: float = 0.032
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.001, 0.018)
		var s: float = sin(TAU * 520.0 * t) * 0.10
		s += sin(TAU * 820.0 * t) * 0.035
		s += _noise_value(i, 93.0) * 0.015
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_dialogue_open() -> AudioStreamWAV:
	var duration: float = 0.085
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.002, 0.040)
		var s: float = sin(TAU * 420.0 * t) * 0.08
		s += sin(TAU * 760.0 * t) * 0.045
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_magic_reload() -> AudioStreamWAV:
	var duration: float = 0.42
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.01, 0.10)
		var f: float = lerpf(260.0, 760.0, p)
		var s: float = sin(TAU * f * t) * 0.14
		s += sin(TAU * f * 1.51 * t) * 0.06
		s += _noise_value(i, 72.0) * 0.018
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_magic_reload_finish() -> AudioStreamWAV:
	var duration: float = 0.16
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.002, 0.07)
		var s: float = sin(TAU * 880.0 * t) * 0.13
		s += sin(TAU * 1320.0 * t) * 0.07
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_boss_reveal() -> AudioStreamWAV:
	var duration: float = 0.55
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.005, 0.16)
		var f: float = lerpf(92.0, 210.0, p)
		var s: float = sin(TAU * f * t) * 0.20
		s += _noise_value(i, 84.0) * 0.055 * (1.0 - p)
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_boss_fall() -> AudioStreamWAV:
	var duration: float = 0.38
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.002, 0.15)
		var f: float = lerpf(150.0, 54.0, p)
		var s: float = sin(TAU * f * t) * 0.22
		s += _noise_value(i, 91.0) * 0.09 * (1.0 - p)
		samples[i] = s * env
	return _pcm_stream(samples, SFX_RATE)

func _make_blob_tap() -> AudioStreamWAV:
	var duration: float = 0.18
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var env: float = _envelope(t, duration, 0.003, 0.08)
		var sweep: float = lerpf(480.0, 860.0, t / duration)
		var s: float = sin(TAU * sweep * t) * 0.18
		s += sin(TAU * (sweep * 1.62) * t) * 0.10
		s += _noise_value(i, 31.4) * 0.035
		samples[i] = s * env

	return _pcm_stream(samples, SFX_RATE)

func _make_lightning() -> AudioStreamWAV:
	var duration: float = 0.20
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.001,0.095)
		var crack: float = _noise_value(i,112.0)*0.12*(1.0-p)
		var body: float = sin(TAU*lerpf(420.0,125.0,p)*tt)*0.12
		var low: float = sin(TAU*86.0*tt)*0.07
		samples[i] = (crack+body+low)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_rift() -> AudioStreamWAV:
	var duration: float = 0.28
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.006,0.12)
		var body: float = sin(TAU*lerpf(92.0,210.0,p)*tt)*0.15
		var sub: float = sin(TAU*54.0*tt)*0.075
		var grit: float = _noise_value(i,121.0)*0.032*(1.0-p)
		samples[i] = (body+sub+grit)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_boss_mark() -> AudioStreamWAV:
	var duration: float = 0.25
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i)/float(SFX_RATE)
		var env: float = _envelope(t,duration,0.002,0.10)
		var s: float = sin(TAU*180.0*t)*0.18 + sin(TAU*540.0*t)*0.07
		s += _noise_value(i,144.0)*0.06
		samples[i] = s*env
	return _pcm_stream(samples,SFX_RATE)

func _make_samurai_slash() -> AudioStreamWAV:
	var duration: float = 0.17
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = exp(-tt*16.0)
		var cut: float = _noise_value(i,37.0)*0.085*env*(1.0-p)
		var body: float = sin(TAU*lerpf(460.0,180.0,p)*tt)*0.095*env
		var low: float = sin(TAU*105.0*tt)*0.045*env
		samples[i] = cut+body+low
	return _pcm_stream(samples,SFX_RATE,false)

func _make_samurai_dash_hit() -> AudioStreamWAV:
	var duration: float = 0.12
	var count: int = int(float(SFX_RATE)*duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var env: float = exp(-tt*23.0)
		var s: float = sin(TAU*180.0*tt)*0.15*env + _noise_value(i,58.0)*0.08*env
		samples[i]=s
	return _pcm_stream(samples,SFX_RATE,false)

func _make_vase_break() -> AudioStreamWAV:
	var duration: float = 0.24
	var count: int = int(float(SFX_RATE)*duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var env: float = exp(-tt*14.0)
		var s: float = _noise_value(i,91.0)*0.15*env
		s += sin(TAU*(620.0-tt*900.0)*tt)*0.07*env
		samples[i]=s
	return _pcm_stream(samples,SFX_RATE,false)


func _make_rune_proc(variant: int) -> AudioStreamWAV:
	var duration: float = 0.18+float(variant)*0.02
	var count: int = int(float(SFX_RATE)*duration)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = exp(-tt*(14.0+float(variant)*2.0))
		var base: float = 138.0+float(variant)*34.0
		var s: float = sin(TAU*(base+32.0*sin(tt*9.0))*tt)*0.055*env
		s += sin(TAU*(base*0.5)*tt)*0.035*env
		s += _noise_value(i,47.0+float(variant)*9.0)*0.018*(1.0-p)*env
		samples[i] = s
	return _pcm_stream(samples,SFX_RATE,false)

func _music_note(base: float, semitones: float) -> float:
	return base * pow(2.0, semitones / 12.0)

func _music_bar_envelope(local_t: float, bar_length: float) -> float:
	# Every chord breathes at its own boundary. That makes the musical turnaround
	# seamless without fading the whole soundtrack out every time it loops.
	return _envelope(local_t, bar_length, 0.085, 0.12)

func _seal_music_loop(samples: PackedFloat32Array, loop_begin_sample: int) -> void:
	# Microscopic seam safety only (about 9 ms). This is intentionally NOT a
	# musical fade; it just guarantees the last PCM samples meet the first loop
	# sample without a click caused by rounding/phase residue.
	var seam: int = mini(int(float(MUSIC_RATE) * 0.009), samples.size() - loop_begin_sample - 1)
	if seam <= 1:
		return
	var target: float = samples[loop_begin_sample]
	var first: int = samples.size() - seam
	var source: float = samples[first]
	for j in range(seam):
		var x: float = float(j) / float(seam - 1)
		var smooth: float = x * x * (3.0 - 2.0 * x)
		samples[first + j] = lerpf(source, target, smooth)

func _make_new_music(kind: String) -> AudioStreamWAV:
	# 0.5.1 soundtrack pass.
	# Each track has a short one-time intro plus a longer cyclic arrangement.
	# The loop begins AFTER the intro and the final chord is a deliberate
	# turnaround back into the first one, so repetition feels like another pass
	# through the piece instead of the file simply restarting.
	var bpm: float = 106.0
	var loop_bars: int = 20
	if kind == "menu":
		bpm = 76.0
		loop_bars = 16
	elif kind == "boss":
		bpm = 132.0
		loop_bars = 24

	var beat_length: float = 60.0 / bpm
	var bar_length: float = beat_length * 4.0
	var intro_bars: int = 2
	var intro_samples: int = int(round(float(MUSIC_RATE) * bar_length * float(intro_bars)))
	var loop_samples: int = int(round(float(MUSIC_RATE) * bar_length * float(loop_bars)))
	var count: int = intro_samples + loop_samples
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)

	# Roots are written as frequencies so this remains completely asset-free.
	# 0 = minor third, 1 = major third. Every final bar wants to resolve to bar 0.
	var roots: Array = []
	var major: Array = []
	if kind == "menu":
		# Dm — Bb — F — C / Dm — Gm — Bb — A, with a calmer second statement.
		roots = [146.83,116.54,174.61,130.81, 146.83,98.00,116.54,110.00, 146.83,116.54,174.61,130.81, 98.00,116.54,110.00,110.00]
		major = [false,true,true,true, false,false,true,true, false,true,true,true, false,true,true,true]
	elif kind == "boss":
		# Low D minor cycle. The last two A bars are the tension that throws us
		# naturally back into D when the loop wraps.
		roots = [73.42,65.41,58.27,55.00, 73.42,58.27,65.41,55.00, 73.42,77.78,58.27,55.00, 65.41,58.27,73.42,55.00, 73.42,65.41,58.27,55.00, 58.27,65.41,55.00,55.00]
		major = [false,true,true,true, false,true,true,true, false,true,true,true, true,true,false,true, false,true,true,true, true,true,true,true]
	else:
		# Cm with a little lift in the middle, then G holds the turnaround.
		roots = [130.81,103.83,155.56,116.54, 130.81,87.31,103.83,98.00, 130.81,103.83,155.56,116.54, 87.31,103.83,98.00,98.00, 130.81,103.83,116.54,98.00]
		major = [false,true,true,true, false,false,true,true, false,true,true,true, false,true,true,true, false,true,true,true]

	var menu_motif: Array = [12.0,7.0,3.0,-99.0, 7.0,10.0,12.0,-99.0, 15.0,12.0,10.0,7.0, 3.0,7.0,10.0,-99.0]
	var game_motif: Array = [0.0,-99.0,7.0,10.0, 12.0,10.0,7.0,-99.0, 3.0,7.0,10.0,7.0, 0.0,-99.0,3.0,7.0]
	var boss_ostinato: Array = [0.0,0.0,3.0,0.0, 7.0,6.0,3.0,0.0]

	for i in range(count):
		var in_intro: bool = i < intro_samples
		var body_index: int = i if in_intro else i - intro_samples
		var body_t: float = float(body_index) / float(MUSIC_RATE)
		var bar_index: int = int(body_t / bar_length)
		if in_intro:
			bar_index = mini(bar_index, intro_bars - 1)
		else:
			bar_index %= loop_bars
		var chord_index: int = bar_index % roots.size()
		var root: float = float(roots[chord_index])
		var third_semitones: float = 4.0 if bool(major[chord_index]) else 3.0
		var third: float = _music_note(root, third_semitones)
		var fifth: float = _music_note(root, 7.0)
		var octave: float = root * 2.0
		var bar_local: float = fmod(body_t, bar_length)
		var beat_index: int = int(body_t / beat_length)
		var beat_in_bar: int = beat_index % 4
		var beat_local: float = fmod(body_t, beat_length)
		var eighth_length: float = beat_length * 0.5
		var eighth_index: int = int(body_t / eighth_length)
		var eighth_local: float = fmod(body_t, eighth_length)
		var section: int = int(float(bar_index) / 4.0)
		var pad_env: float = _music_bar_envelope(bar_local, bar_length)
		var s: float = 0.0

		# Warm three-note pad. Starting each chord at zero phase + tiny attack
		# avoids clicks at every progression change and at the loop point.
		var pad_time: float = bar_local
		var pad_gain: float = 0.020 if kind == "menu" else (0.014 if kind == "game" else 0.012)
		s += sin(TAU * root * 0.5 * pad_time) * pad_gain * pad_env
		s += sin(TAU * third * 0.5 * pad_time) * pad_gain * 0.72 * pad_env
		s += sin(TAU * fifth * 0.5 * pad_time) * pad_gain * 0.58 * pad_env
		# A barely detuned upper voice makes the generated PCM feel less sterile.
		s += sin(TAU * octave * 0.5015 * pad_time) * pad_gain * 0.18 * pad_env

		if kind == "menu":
			# Soft pulse underneath; no drums. Sections 2/3 answer the first motif
			# an octave lower so a full loop has an actual A/B shape.
			var pulse_env: float = exp(-beat_local * 3.8) * _envelope(beat_local, beat_length, 0.008, 0.08)
			s += sin(TAU * root * 0.5 * beat_local) * 0.009 * pulse_env

			if not in_intro:
				var motif_pos: int = beat_index % menu_motif.size()
				var semis: float = float(menu_motif[motif_pos])
				if semis > -90.0 and (section % 4 != 1 or beat_in_bar % 2 == 0):
					if section >= 2:
						semis -= 12.0
					var freq: float = _music_note(root, semis)
					var bell_env: float = exp(-beat_local * 4.5) * _envelope(beat_local, beat_length, 0.006, 0.10)
					s += sin(TAU * freq * beat_local) * 0.015 * bell_env
					s += sin(TAU * freq * 2.01 * beat_local) * 0.0045 * bell_env

			# Sparse eighth-note shimmer, deliberately absent in the first section.
			if not in_intro and section % 4 in [1,3] and eighth_index % 2 == 0:
				var arp_notes: Array = [0.0,7.0,12.0,third_semitones + 12.0]
				var arp_freq: float = _music_note(root, float(arp_notes[eighth_index % arp_notes.size()]))
				var arp_env: float = exp(-eighth_local * 7.0) * _envelope(eighth_local, eighth_length, 0.004, 0.055)
				s += sin(TAU * arp_freq * eighth_local) * 0.007 * arp_env

		elif kind == "game":
			# Grounded bass on beats 1/3, then a lighter off-beat response. The
			# arrangement gradually fills over each 4-bar section.
			var bass_env: float = exp(-beat_local * 7.5) * _envelope(beat_local, beat_length, 0.004, 0.055)
			if beat_in_bar in [0,2]:
				s += sin(TAU * root * 0.5 * beat_local) * 0.026 * bass_env
			else:
				s += sin(TAU * fifth * 0.5 * beat_local) * 0.011 * bass_env

			if not in_intro:
				var gpos: int = beat_index % game_motif.size()
				var gsemis: float = float(game_motif[gpos])
				if gsemis > -90.0 and (section % 5 != 1 or beat_in_bar in [0,3]):
					var gfreq: float = _music_note(root, gsemis + (12.0 if section == 3 else 0.0))
					var pluck_env: float = exp(-beat_local * 6.0) * _envelope(beat_local, beat_length, 0.004, 0.07)
					s += sin(TAU * gfreq * beat_local) * 0.013 * pluck_env
					s += sin(TAU * gfreq * 1.997 * beat_local) * 0.0035 * pluck_env

			# Percussion is intentionally soft: enough motion for combat, but the
			# frequent game SFX still own the foreground.
			if not in_intro:
				if beat_in_bar in [0,2]:
					var kick_env: float = exp(-beat_local * 15.0) * _envelope(beat_local, beat_length, 0.002, 0.04)
					var kick_freq: float = lerpf(64.0, 43.0, clampf(beat_local / 0.14, 0.0, 1.0))
					s += sin(TAU * kick_freq * beat_local) * 0.018 * kick_env
				if beat_in_bar in [1,3]:
					var clap_env: float = exp(-beat_local * 17.0) * _envelope(beat_local, beat_length, 0.003, 0.035)
					s += _noise_value(i, 61.0 + float(bar_index % 7)) * 0.007 * clap_env
				if section >= 2 and eighth_index % 2 == 1:
					var hat_env: float = exp(-eighth_local * 24.0) * _envelope(eighth_local, eighth_length, 0.002, 0.025)
					s += _noise_value(i, 31.0) * 0.0038 * hat_env

		else:
			# Boss: low ostinato, heavier heartbeat and a rising answer every few
			# bars. Still tonal enough that looping the fight for minutes is sane.
			var half_beat: float = beat_length * 0.5
			var half_local: float = fmod(body_t, half_beat)
			var half_index: int = int(body_t / half_beat)
			var opos: int = half_index % boss_ostinato.size()
			var ofreq: float = _music_note(root, float(boss_ostinato[opos]))
			var oenv: float = exp(-half_local * 9.5) * _envelope(half_local, half_beat, 0.003, 0.04)
			if not in_intro:
				s += sin(TAU * ofreq * half_local) * 0.020 * oenv
				s += sin(TAU * ofreq * 0.5 * half_local) * 0.013 * oenv

			var heart_env: float = exp(-beat_local * 16.0) * _envelope(beat_local, beat_length, 0.002, 0.035)
			if beat_in_bar in [0,2]:
				s += sin(TAU * 47.0 * beat_local) * 0.029 * heart_env
			if not in_intro and beat_in_bar in [1,3]:
				s += _noise_value(i, 93.0 + float(bar_index % 5)) * 0.010 * heart_env

			if not in_intro and bar_index % 4 == 3 and beat_in_bar >= 2:
				var rise_semis: float = 12.0 + float(beat_in_bar - 2) * 3.0
				var rise_freq: float = _music_note(root, rise_semis)
				var rise_env: float = exp(-beat_local * 3.8) * _envelope(beat_local, beat_length, 0.008, 0.07)
				s += sin(TAU * rise_freq * beat_local) * 0.011 * rise_env

		# The intro itself eases in once. The LOOP never fades globally.
		if in_intro:
			var intro_gain: float = clampf(float(i) / float(maxi(1, int(float(MUSIC_RATE) * 0.75))), 0.0, 1.0)
			s *= intro_gain * (0.72 if kind == "menu" else 0.78)

		samples[i] = clampf(s, -0.32, 0.32)

	_seal_music_loop(samples, intro_samples)
	return _pcm_stream(samples, MUSIC_RATE, true, intro_samples, samples.size())


func _make_footstep() -> AudioStreamWAV:
	var duration: float = 0.085
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.002, 0.045)
		var body: float = sin(TAU * lerpf(135.0, 88.0, p) * t) * 0.10
		var grit: float = _noise_value(i, 52.1) * 0.11 * (1.0 - p)
		samples[i] = (body + grit) * env
	return _pcm_stream(samples, SFX_RATE)

func _make_soft_footstep(variant: int) -> AudioStreamWAV:
	var duration: float = 0.068+float(variant)*0.006
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.001,0.040)
		var thump: float = sin(TAU*(82.0+float(variant)*8.0)*tt)*0.075
		var dirt: float = _noise_value(i,72.0+float(variant)*13.0)*0.042*(1.0-p)
		samples[i] = (thump+dirt)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_wind_gust() -> AudioStreamWAV:
	var duration: float = 1.05
	var count: int = int(float(SFX_RATE) * duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var t: float = float(i) / float(SFX_RATE)
		var p: float = t / duration
		var env: float = _envelope(t, duration, 0.08, 0.30)
		var airy: float = _noise_value(i, 111.4) * 0.12
		var tone: float = sin(TAU * lerpf(180.0, 96.0, p) * t) * 0.035
		samples[i] = (airy + tone) * env * (0.25 + sin(p * PI))
	return _pcm_stream(samples, SFX_RATE)


func _make_shield_break() -> AudioStreamWAV:
	var duration: float = 0.24
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.001,0.12)
		var clang: float = sin(TAU*lerpf(760.0,210.0,p)*tt)*0.22
		var crack: float = _noise_value(i,144.0)*0.24*(1.0-p)
		samples[i] = (clang+crack)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_necro_summon() -> AudioStreamWAV:
	var duration: float = 0.42
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.02,0.16)
		var low: float = sin(TAU*lerpf(110.0,220.0,p)*tt)*0.14
		var grit: float = _noise_value(i,155.0)*0.045
		samples[i] = (low+grit)*env
	return _pcm_stream(samples,SFX_RATE)

func _make_arcane_surge() -> AudioStreamWAV:
	var duration: float = 0.52
	var count: int = int(float(SFX_RATE)*duration)
	var samples: PackedFloat32Array = PackedFloat32Array()
	samples.resize(count)
	for i in range(count):
		var tt: float = float(i)/float(SFX_RATE)
		var p: float = tt/duration
		var env: float = _envelope(tt,duration,0.01,0.18)
		var f: float = lerpf(180.0,920.0,p)
		var tone: float = sin(TAU*f*tt)*0.13 + sin(TAU*f*1.5*tt)*0.05
		var air: float = _noise_value(i,166.0)*0.035
		samples[i] = (tone+air)*env
	return _pcm_stream(samples,SFX_RATE)
