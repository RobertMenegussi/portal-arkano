# ARCANO 0.5.0-prealpha — Build 0600

## Runas
- User-facing Tome naming replaced by Rune / Runa / ルーン across the active Endless game.
- 100 gameplay/style Runes added:
  - 20 universal
  - 20 Orbital
  - 20 Storm
  - 20 Rift
  - 20 Samurai
- Style Runes can trigger on basic attack, dash, kill, damage taken or periodic cadence.
- Runtime patterns include nova, bolt, rain, cone, line, orbit, burst, aura, mark and spiral, with procedural visual effects.
- 50 percentage-stat Runes added as 10 five-rank families.
- Existing mechanic/mutation Rune content remains available and localized.

## Languages
- English is the default language.
- Language globe added to the main menu with English, PT-BR, Japanese and Spanish.
- Language choice persists in user://settings.cfg.
- Active Endless menu, HUD, Rune catalog/cards, Profile, Classes/quests, settings, pause/death, boss UI, TAB panel, banners and tutorial are localized in all four languages.

## Tutorial
- First launch suggests a guided tutorial.
- Tutorial can be replayed from the radial menu.
- Sensei NPC + emotional dialogue panel with typewriter text, portrait reactions and subtle box motion.
- Guided tasks cover movement, auto-attack, Samurai melee rules, dash, XP/Gold XP, common pickups, Runes, Runic Vases, silver/gold chests, Flow/Arcane Surge, Elite/Boss timing, TAB panel, class quests, radial menu, Profile, settings and language selection.
- Tutorial run is isolated from Profile/class-quest progression.

## Comfort / Boss HUD
- Repetitive basic attacks and enemy hits no longer shake the camera.
- Dash, player damage and major states retain much softer optional shake.
- Kill feedback is primarily local/visual instead of camera jerk.
- Normal boss arrival is randomized around 10 minutes (9:30–10:30).
- Top HUD uses a horned boss icon + countdown instead of a textual “boss in” label.

## Menu
- Removed the static “click the mage to open the arcane menu” hint.
- Existing radial outside-click dismissal remains.
- Build/version remains top-right.

## Validation
Static checks only: no Godot executable is available in this environment, so runtime validation was not claimed.
