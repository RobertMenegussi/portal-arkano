extends Node2D

const ProjectileScript = preload("res://projectile.gd")
const ArcaneBurstScript = preload("res://arcane_burst.gd")
const LightningStrikeScript = preload("res://lightning_strike.gd")
const RiftScarScript = preload("res://rift_scar.gd")
const TomeMeteorScript = preload("res://tome_meteor.gd")

var player
var timers: Dictionary = {}
var blade_angle: float = 0.0
var blade_hit_timer: float = 0.0
var blade_cooldowns: Dictionary = {}
var shield_cooldown: float = 0.0
var kill_counter: int = 0
var chain_counter: int = 0
var whip_flash: float = 0.0
var whip_direction: Vector2 = Vector2.RIGHT
var retaliate_flash: float = 0.0
var familiar_angle: float = 0.0
var cached_controller = null
var visual_timer: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 33
	add_to_group("tome_arsenal")
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	if not is_instance_valid(player):
		return
	blade_angle += delta*2.25
	familiar_angle -= delta*1.35
	whip_flash = maxf(0.0,whip_flash-delta*3.8)
	retaliate_flash = maxf(0.0,retaliate_flash-delta*3.0)
	shield_cooldown = maxf(0.0,shield_cooldown-delta)
	if not player.active:
		visual_timer -= delta
		if visual_timer <= 0.0:
			visual_timer = 1.0/15.0
			queue_redraw()
		return
	_tick_trait("aux_aura",delta,1.00,_pulse_aura)
	_tick_trait("aux_fireball",delta,3.00,_fire_explosive_orb)
	_tick_trait("aux_whip",delta,2.50,_swing_whip)
	_tick_trait("aux_meteor",delta,4.00,_drop_meteor)
	_tick_trait("aux_voidwell",delta,6.00,_spawn_voidwell)
	_tick_trait("aux_familiar",delta,1.50,_familiar_shot)
	_tick_trait("aux_minor_storm",delta,3.50,_minor_storm)
	_tick_trait("aux_guardian_nova",delta,8.00,_guardian_nova)
	blade_hit_timer -= delta
	if player.has_trait("aux_orbit_blade") and blade_hit_timer <= 0.0:
		blade_hit_timer = 0.16
		_damage_orbit_blade()
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _tick_trait(trait_id: String,delta: float,interval: float,callback: Callable) -> void:
	if not player.has_trait(trait_id):
		return
	var left: float = float(timers.get(trait_id,randf_range(0.12,interval)))
	left -= delta
	if left <= 0.0:
		left += interval
		callback.call()
	timers[trait_id] = left

func _nearest_enemy(max_distance: float = 9999.0):
	var best = null
	var best_d2: float = max_distance*max_distance
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(player.global_position,max_distance)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var d2: float = player.global_position.distance_squared_to(enemy.global_position)
		if d2 < best_d2:
			best_d2 = d2
			best = enemy
	return best

func _densest_target():
	var best = _nearest_enemy(680.0)
	if best == null:
		return null
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(player.global_position,680.0)
	var best_score: int = -1
	for candidate in candidates:
		if not is_instance_valid(candidate) or player.global_position.distance_squared_to(candidate.global_position) > 680.0*680.0:
			continue
		var score: int = 0
		var neighbors: Array = candidates
		if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
			neighbors = cached_controller.get_nearby_enemies(candidate.global_position,100.0)
		for other in neighbors:
			if is_instance_valid(other) and candidate.global_position.distance_squared_to(other.global_position) <= 92.0*92.0:
				score += 1
		if score > best_score:
			best_score = score
			best = candidate
	return best

func _pulse_aura() -> void:
	var burst = ArcaneBurstScript.new()
	burst.radius = 78.0
	burst.damage = 1
	burst.global_position = player.global_position
	get_tree().current_scene.add_child(burst)

func _fire_explosive_orb() -> void:
	var target = _nearest_enemy(760.0)
	if target == null:
		return
	var dir: Vector2 = (target.global_position-player.global_position).normalized()
	var shot = ProjectileScript.new()
	shot.direction = dir
	shot.damage = 1
	shot.speed = 520.0
	shot.lifetime = 1.65
	shot.explode_on_hit = true
	shot.global_position = player.global_position+dir*24.0
	get_tree().current_scene.add_child(shot)

func _swing_whip() -> void:
	var target = _nearest_enemy(150.0)
	whip_direction = player.aim_direction
	if target != null:
		whip_direction = (target.global_position-player.global_position).normalized()
	whip_flash = 1.0
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(player.global_position,140.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var delta_pos: Vector2 = enemy.global_position-player.global_position
		var dist: float = delta_pos.length()
		if dist <= 122.0 and dist > 0.001 and delta_pos.normalized().dot(whip_direction) >= -0.08:
			enemy.take_damage(1,whip_direction)
	get_tree().call_group("screen_fx","pulse_hit")

func _drop_meteor() -> void:
	var target = _densest_target()
	if target == null:
		return
	var meteor = TomeMeteorScript.new()
	meteor.damage = 2
	meteor.radius = 62.0
	meteor.global_position = target.global_position
	get_tree().current_scene.add_child(meteor)

func _spawn_voidwell() -> void:
	var target = _densest_target()
	if target == null:
		return
	var burst = ArcaneBurstScript.new()
	burst.radius = 105.0
	burst.damage = 1
	burst.pull_strength = 290.0
	burst.duration = 0.58
	burst.global_position = target.global_position
	get_tree().current_scene.add_child(burst)

func _familiar_shot() -> void:
	var target = _nearest_enemy(720.0)
	if target == null:
		return
	var familiar_pos: Vector2 = player.global_position+Vector2(cos(familiar_angle)*74.0,sin(familiar_angle)*44.0-8.0)
	var dir: Vector2 = (target.global_position-familiar_pos).normalized()
	var shot = ProjectileScript.new()
	shot.direction = dir
	shot.damage = 1
	shot.speed = 690.0
	shot.lifetime = 1.2
	shot.global_position = familiar_pos
	get_tree().current_scene.add_child(shot)

func _minor_storm() -> void:
	var target = _nearest_enemy(640.0)
	if target == null:
		return
	var strike = LightningStrikeScript.new()
	strike.configure(true)
	strike.radius = 34.0
	strike.damage = 1
	strike.delay = 0.26
	strike.chain_count = 1
	strike.global_position = target.global_position
	get_tree().current_scene.add_child(strike)

func _guardian_nova() -> void:
	# Clears a small breathing space without becoming a screen wipe.
	var burst = ArcaneBurstScript.new()
	burst.radius = 108.0
	burst.damage = 1
	burst.pull_strength = -180.0
	burst.global_position = player.global_position
	get_tree().current_scene.add_child(burst)

func _damage_orbit_blade() -> void:
	var blade_pos: Vector2 = player.global_position+Vector2(cos(blade_angle)*86.0,sin(blade_angle)*54.0-4.0)
	var now_ms: int = Time.get_ticks_msec()
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(blade_pos,30.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var id: int = enemy.get_instance_id()
		if now_ms-int(blade_cooldowns.get(id,0)) < 620:
			continue
		if blade_pos.distance_squared_to(enemy.global_position) <= 23.0*23.0:
			blade_cooldowns[id] = now_ms
			var dir: Vector2 = (enemy.global_position-blade_pos).normalized()
			enemy.take_damage(1,dir)

func try_block_hit() -> bool:
	if not is_instance_valid(player) or not player.has_trait("aux_prism_shield"):
		return false
	if shield_cooldown > 0.0:
		return false
	shield_cooldown = 18.0
	get_tree().call_group("screen_fx","pulse_dash")
	get_tree().call_group("audio_bus","play_shield_break")
	queue_redraw()
	return true

func on_player_damaged() -> void:
	if not is_instance_valid(player):
		return
	if player.has_trait("aux_retaliation"):
		retaliate_flash = 1.0
		var burst = ArcaneBurstScript.new()
		burst.radius = 102.0
		burst.damage = 2
		burst.global_position = player.global_position
		get_tree().current_scene.add_child(burst)
	if player.has_trait("aux_blood_shards"):
		for i in range(8):
			var dir: Vector2 = Vector2.RIGHT.rotated(TAU*float(i)/8.0)
			var shot = ProjectileScript.new()
			shot.direction = dir
			shot.damage = 1
			shot.speed = 590.0
			shot.lifetime = 0.72
			shot.global_position = player.global_position+dir*18.0
			get_tree().current_scene.add_child(shot)

func on_enemy_killed(_elite: bool = false) -> void:
	if not is_instance_valid(player):
		return
	kill_counter += 1
	chain_counter += 1
	if player.has_trait("aux_kill_nova") and kill_counter >= 14:
		kill_counter = 0
		var burst = ArcaneBurstScript.new()
		burst.radius = 126.0
		burst.damage = 2
		burst.global_position = player.global_position
		get_tree().current_scene.add_child(burst)
	if player.has_trait("aux_hunter_chain") and chain_counter >= 8:
		chain_counter = 0
		_minor_storm()

func on_dash_started(start_pos: Vector2,direction: Vector2) -> void:
	if not is_instance_valid(player) or not player.has_trait("aux_dash_scar"):
		return
	var scar = RiftScarScript.new()
	scar.direction = direction.normalized()
	scar.length = 128.0
	scar.width = 20.0
	scar.damage = 1
	scar.duration = 1.7
	scar.tick_interval = 0.55
	scar.global_position = start_pos-direction.normalized()*24.0
	get_tree().current_scene.add_child(scar)

func _draw() -> void:
	if not is_instance_valid(player):
		return
	var ink: Color = Color("#111111")
	if player.has_trait("aux_orbit_blade"):
		var blade: Vector2 = Vector2(cos(blade_angle)*86.0,sin(blade_angle)*54.0-4.0)
		var tangent: Vector2 = Vector2(-sin(blade_angle),cos(blade_angle)).normalized()
		draw_line(blade-tangent*9.0,blade+tangent*9.0,ink,3.0)
		draw_line(blade-tangent*6.0+Vector2(2,1),blade+tangent*6.0+Vector2(2,1),Color(1,1,1,0.36),1.0)
	if player.has_trait("aux_familiar"):
		var fp: Vector2 = Vector2(cos(familiar_angle)*74.0,sin(familiar_angle)*44.0-8.0)
		draw_circle(fp,6.0,Color(0.08,0.08,0.08,0.82))
		draw_circle(fp+Vector2(-2,-1),1.2,Color("#fffdf7"))
		draw_circle(fp+Vector2(2,-1),1.2,Color("#fffdf7"))
	if player.has_trait("aux_prism_shield"):
		var ready_alpha: float = 0.28 if shield_cooldown <= 0.0 else 0.06
		draw_arc(Vector2.ZERO,34.0,0.0,TAU,32,Color(0.08,0.08,0.08,ready_alpha),2.0)
		if shield_cooldown > 0.0:
			var p: float = clampf(1.0-shield_cooldown/18.0,0.0,1.0)
			draw_arc(Vector2.ZERO,38.0,-PI*0.5,-PI*0.5+TAU*p,32,Color(0.08,0.08,0.08,0.12),1.2)
	if whip_flash > 0.0:
		var a0: float = whip_direction.angle()-0.78
		var a1: float = whip_direction.angle()+0.78
		draw_arc(Vector2.ZERO,104.0,a0,a1,28,Color(0.08,0.08,0.08,0.38*whip_flash),3.2)
		draw_arc(Vector2.ZERO,91.0,a0+0.05,a1-0.05,28,Color(1,1,1,0.24*whip_flash),1.0)
	if retaliate_flash > 0.0:
		draw_arc(Vector2.ZERO,54.0+retaliate_flash*26.0,0.0,TAU,28,Color(0.08,0.08,0.08,0.24*retaliate_flash),2.0)
