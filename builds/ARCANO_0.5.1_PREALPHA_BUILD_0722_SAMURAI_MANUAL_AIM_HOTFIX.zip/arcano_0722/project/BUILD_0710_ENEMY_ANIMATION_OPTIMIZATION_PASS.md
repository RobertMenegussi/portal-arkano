# BUILD 0710 — Enemy animation + optimization pass

## Goal
Bring regular enemies closer to the player classes in animation quality while lowering the CPU / draw cost that had started to rise in recent builds.

## Enemy animation work
- Added smoothed visual facing and motion state shared by enemy drawings.
- Skeleton now walks with a more readable gait, smoothly tracks the player, and physically presents its bow/arrow toward the target.
- Stalker now has smoother body lean, wing movement, eye focus and rush motion.
- Spider keeps the detailed rework but now uses smoother target focus and LOD-based detail so close spiders look rich without every distant spider paying the same draw cost.
- Brute now has animated heavy arms/fists, body lean and a stronger charge silhouette.
- Shaman now has a staff hand that follows its focus, animated robe/hood movement and a more alive free-hand casting pose.
- Warder now tracks smoothly, carries a visible spear, and integrates shield/weapon posing with movement.
- Classic slime silhouette preserved, but its eyes now track the player and movement/attack deformation is smoother.
- Enemy final scale reduced slightly (roughly 4–7% depending on type).

## Performance work
- Enemy redraw frequency is now adaptive: high during close combat/action, lower at mid/far distance.
- Far enemies use lower visual detail and cheaper update frequencies.
- Spider/skeleton decorative draw work scales down with distance.
- Soft separation refresh reduced from ~20 Hz to ~15 Hz.
- Spatial hash rebuild reduced from ~15 Hz to ~12 Hz.
- Enemy oval geometry reduced from 24 to 20 points.
- Offscreen cleanup radius reduced to prevent unnecessary distant buildup.
- Horde caps trimmed modestly, especially late-run, while preserving Survivor-style density.
- Cosmetic hit/death FX budget becomes stricter at high enemy counts.

## Files changed
- enemy.gd
- endless_main.gd
