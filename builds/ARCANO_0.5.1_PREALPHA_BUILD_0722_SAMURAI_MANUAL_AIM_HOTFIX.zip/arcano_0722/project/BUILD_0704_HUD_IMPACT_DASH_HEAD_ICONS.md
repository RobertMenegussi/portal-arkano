# BUILD 0704 — HUD impact reactions + head dash icons

## Main changes
- Added a stronger impact animation to the HUD portrait when the player takes damage.
- Reworked dash display: charges now appear as small lightning containers above the portrait/head instead of the old seconds-focused readout.
- Each dash icon fills back up visually during recharge.
- The number of lightning containers scales with max dash charges, including rune-based increases.
- Further personalized the HUD faces so Orbit, Storm and Samurai read more distinctly.

## Files changed
- hud_display.gd
- endless_main.gd
