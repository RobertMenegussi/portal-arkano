extends Node2D

var p: float = 0.0
var settled: bool = false
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("run_decal")
	z_index = 10

func _process(delta: float) -> void:
	if settled:
		return
	p = minf(1.0,p+delta/0.55)
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()
	if p >= 1.0:
		var batch = get_tree().get_first_node_in_group("death_decal_batch")
		if is_instance_valid(batch) and batch.has_method("add_slime"):
			batch.add_slime(global_position)
			queue_free()
			return
		settled = true
		set_process(false)

func _draw() -> void:
	var e: float = 1.0 - pow(1.0 - p, 3.0)
	var width: float = lerpf(18.0, 30.0, e)
	var height: float = lerpf(14.0, 2.8, e)
	var y: float = lerpf(2.0, 14.0, e)
	var alpha: float = lerpf(0.85, 0.30, e)

	_draw_oval(Vector2(0, y), Vector2(width, height), Color(0.05, 0.05, 0.05, alpha))
	if p < 0.82:
		for i in range(6):
			var a: float = float(i) * 1.3 + p * 5.0
			var pos := Vector2(cos(a) * (7.0 + float(i)), -6.0 - p * 16.0 - float(i % 2) * 3.0)
			draw_circle(pos, 1.7, Color(0.05, 0.05, 0.05, (1.0 - p) * 0.45))

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(26):
		var a: float = TAU * float(i) / 26.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)
