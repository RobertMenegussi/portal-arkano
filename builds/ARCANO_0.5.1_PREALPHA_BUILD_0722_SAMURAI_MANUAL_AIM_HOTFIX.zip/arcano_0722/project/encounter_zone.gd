extends Node2D

signal started(encounter_id: String)
signal completed(encounter_id: String, reward_tier: String)

const EnemyScript = preload("res://enemy.gd")
const TotemScript = preload("res://encounter_totem.gd")

var encounter_id: String = "encounter"
var encounter_type: String = "ambush"
var reward_tier: String = "normal"
var player
var trigger_radius: float = 125.0
var started_once: bool = false
var completed_once: bool = false
var members: Array = []
var totems: Array = []
var elapsed: float = 0.0
var wave_timer: float = 0.0
var wave_index: int = 0
var gauntlet_wave: int = 0
var t: float = 0.0
var title_text: String = "ENCONTRO"

func configure(id_value: String, kind: String, target, tier: String = "normal", title: String = "ENCONTRO") -> void:
	encounter_id = id_value
	encounter_type = kind
	player = target
	reward_tier = tier
	title_text = title

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 10

func _process(delta: float) -> void:
	t += delta
	if completed_once or not is_instance_valid(player):
		queue_redraw()
		return
	if not started_once:
		if player.active and global_position.distance_to(player.global_position) <= trigger_radius:
			_start_encounter()
		queue_redraw()
		return
	elapsed += delta
	_prune_members()
	_prune_totems()
	match encounter_type:
		"survival":
			wave_timer -= delta
			if wave_timer <= 0.0 and elapsed < 15.0:
				wave_timer = 3.6
				_spawn_survival_wave()
			if elapsed >= 16.0:
				_complete()
		"totems":
			if totems.is_empty():
				_complete()
		"gauntlet":
			if members.is_empty():
				if gauntlet_wave == 0:
					gauntlet_wave = 1
					_spawn_pack(["warder","skeleton","stalker"],92.0)
				elif gauntlet_wave == 1:
					gauntlet_wave = 2
					_spawn_pack(["shaman","slime","slime","stalker"],112.0)
				else:
					_complete()
		_:
			if members.is_empty():
				_complete()
	queue_redraw()


func _prune_members() -> void:
	var alive: Array = []
	for member in members:
		if is_instance_valid(member) and member.get("dead") != true:
			alive.append(member)
	members = alive

func _prune_totems() -> void:
	var alive: Array = []
	for totem in totems:
		if is_instance_valid(totem):
			alive.append(totem)
	totems = alive

func _start_encounter() -> void:
	started_once = true
	elapsed = 0.0
	started.emit(encounter_id)
	get_tree().call_group("screen_fx","pulse_spawn")
	match encounter_type:
		"ambush":
			_spawn_pack(["slime","skeleton","stalker"],92.0)
		"survival":
			wave_timer = 0.05
		"totems":
			_spawn_totems()
			_spawn_pack(["shaman","stalker"],108.0)
		"gauntlet":
			gauntlet_wave = 0
			_spawn_pack(["slime","slime","skeleton"],86.0)

func _spawn_pack(kinds: Array, radius: float) -> void:
	for i in range(kinds.size()):
		var angle: float = TAU*float(i)/maxf(1.0,float(kinds.size()))+0.38
		var enemy = EnemyScript.new()
		enemy.configure(str(kinds[i]),player)
		enemy.global_position = global_position+Vector2(cos(angle),sin(angle))*radius
		enemy.set_meta("encounter_id",encounter_id)
		get_tree().current_scene.add_child(enemy)
		members.append(enemy)

func _spawn_survival_wave() -> void:
	wave_index += 1
	var kinds: Array = ["slime","stalker"]
	if wave_index >= 2:
		kinds.append("skeleton")
	if wave_index >= 3:
		kinds.append("shaman")
	_spawn_pack(kinds,118.0+float(wave_index%2)*22.0)

func _spawn_totems() -> void:
	for i in range(3):
		var a: float = TAU*float(i)/3.0-0.4
		var totem = TotemScript.new()
		totem.global_position = global_position+Vector2(cos(a),sin(a))*92.0
		totem.destroyed.connect(_on_totem_destroyed)
		get_tree().current_scene.add_child(totem)
		totems.append(totem)

func _on_totem_destroyed() -> void:
	get_tree().call_group("audio_bus","play_enemy_die")

func _complete() -> void:
	if completed_once:
		return
	completed_once = true
	for member in members:
		if is_instance_valid(member):
			member.queue_free()
	members.clear()
	get_tree().call_group("screen_fx","pulse_kill")
	completed.emit(encounter_id,reward_tier)

func _draw() -> void:
	if completed_once:
		return
	var font = ThemeDB.fallback_font
	if not started_once:
		var alpha: float = 0.08+absf(sin(t*2.0))*0.04
		draw_arc(Vector2.ZERO,trigger_radius*0.55,0.0,TAU,38,Color(0.08,0.08,0.08,alpha),1.0)
		if font != null and is_instance_valid(player) and global_position.distance_to(player.global_position) < trigger_radius*1.45:
			draw_string(font,Vector2(-68,-trigger_radius*0.55-12),title_text,HORIZONTAL_ALIGNMENT_CENTER,136,9,Color(0.08,0.08,0.08,0.34))
	else:
		if encounter_type == "survival" and font != null:
			var left: int = maxi(0,int(ceil(16.0-elapsed)))
			draw_string(font,Vector2(-60,-68),"SOBREVIVA  "+str(left)+"s",HORIZONTAL_ALIGNMENT_CENTER,120,10,Color(0.08,0.08,0.08,0.48))
		elif encounter_type == "totems" and font != null:
			draw_string(font,Vector2(-60,-68),"TOTENS  "+str(totems.size()),HORIZONTAL_ALIGNMENT_CENTER,120,10,Color(0.08,0.08,0.08,0.48))
