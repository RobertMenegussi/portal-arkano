extends Control

var tone: String = "normal"
var speaker: String = ""
var t: float = 0.0
var intro_t: float = 1.0
var line_flash: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_line(value_speaker: String, value_tone: String) -> void:
	speaker = value_speaker
	tone = value_tone
	intro_t = 0.0
	line_flash = 1.0
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	intro_t = move_toward(intro_t, 1.0, delta * 5.5)
	line_flash = move_toward(line_flash, 0.0, delta * 3.8)
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fbf7ee")
	var box: Rect2 = Rect2(Vector2.ZERO, size)
	var pop: float = 1.0 - pow(1.0 - intro_t, 3.0)
	var inner: Rect2 = box.grow(-3.0)

	draw_rect(inner, Color(paper.r, paper.g, paper.b, 0.98), true)
	for i in range(3):
		var frame: Rect2 = inner.grow(-float(i) * 1.7)
		var alpha: float = 0.12 + float(i) * 0.08
		draw_rect(frame, Color(ink.r, ink.g, ink.b, alpha), false, 1.0)

	# portrait divider and speaker-name rail.
	var divider_x: float = 130.0
	draw_line(Vector2(divider_x, 15), Vector2(divider_x, size.y - 15), Color(0.08,0.08,0.08,0.18), 1.2)
	draw_line(Vector2(divider_x + 12, 47), Vector2(size.x - 18, 47), Color(0.08,0.08,0.08,0.13), 1.0)

	# Corner ornaments, animated subtly with the line arrival.
	var corner_len: float = 17.0 + pop * 9.0
	_draw_corner(Vector2(12, 12), Vector2.RIGHT, Vector2.DOWN, corner_len, ink)
	_draw_corner(Vector2(size.x - 12, 12), Vector2.LEFT, Vector2.DOWN, corner_len, ink)
	_draw_corner(Vector2(12, size.y - 12), Vector2.RIGHT, Vector2.UP, corner_len, ink)
	_draw_corner(Vector2(size.x - 12, size.y - 12), Vector2.LEFT, Vector2.UP, corner_len, ink)

	# Moving ink marks at the bottom keep the box alive without shaking the readable text.
	for i in range(7):
		var x: float = 160.0 + float(i) * 72.0
		var y: float = size.y - 12.0 + sin(t * 2.0 + float(i)) * 0.8
		draw_line(Vector2(x, y), Vector2(x + 14.0, y - 2.0), Color(0.08,0.08,0.08,0.055), 1.0)

	# Tone-specific visual feedback stays in the frame, not over every glyph.
	if tone == "shout":
		for i in range(3):
			var p: Vector2 = Vector2(size.x - 42.0 - float(i) * 11.0, 22.0 + sin(t * 16.0 + float(i)) * 2.0)
			draw_line(p, p + Vector2(5.0, -8.0), Color(0.08,0.08,0.08,0.20), 1.5)
	elif tone == "nervous" or tone == "hurt":
		for i in range(4):
			var p2: Vector2 = Vector2(size.x - 48.0 - float(i) * 10.0, 24.0 + sin(t * 12.0 + float(i)) * 1.4)
			draw_circle(p2, 1.2, Color(0.08,0.08,0.08,0.16))
	elif tone == "grave":
		draw_line(Vector2(size.x - 104.0, 27), Vector2(size.x - 30.0, 27), Color(0.08,0.08,0.08,0.14), 2.0)

	if line_flash > 0.01:
		draw_rect(inner.grow(-5.0), Color(1,1,1,line_flash * 0.08), false, 2.0)

func _draw_corner(origin: Vector2, horizontal: Vector2, vertical: Vector2, length: float, color: Color) -> void:
	draw_line(origin, origin + horizontal * length, Color(color.r,color.g,color.b,0.28), 1.2)
	draw_line(origin, origin + vertical * length, Color(color.r,color.g,color.b,0.28), 1.2)
	var rune_center: Vector2 = origin + (horizontal + vertical) * 7.0
	draw_circle(rune_center, 1.8, Color(color.r,color.g,color.b,0.18))
