ARCANO 0.5.1 PREALPHA BUILD 0680 – VISUAL OVERHAUL / COMBAT READABILITY PASS

Goal:
- Push the entire presentation toward a darker, hand-drawn, high-readability action look inspired by survival spell games, without copying exact copyrighted assets.

Major changes in this build:
- Stronger combat VFX for projectile, hit, lightning, arcane burst, rift burst, and rift scar.
- Larger, clearer pickup icons and better world readability for the vase interaction object.
- Stronger run / stats tab presentation with bigger glyphs and cleaner card framing.
- Punchier menu button treatment and a stronger first language-select screen.
- Tutorial dialogue card visual refresh.
- Mage preview updated to better match the in-game visual style.
- Player combat pass: stronger flux aura, stronger samurai slash, improved orbit / storm / rift magic readability.

Key intent:
- Make attacks feel more alive.
- Make icons easier to read.
- Reduce the "dead / apagado" look.
- Keep the sketchy ARCANO identity while increasing motion and contrast.
