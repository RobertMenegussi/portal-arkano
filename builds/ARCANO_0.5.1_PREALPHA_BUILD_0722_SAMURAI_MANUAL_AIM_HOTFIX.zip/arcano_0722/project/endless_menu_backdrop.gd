extends Control

var t: float = 0.0
var hover_energy: float = 0.0
var particles: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in range(34):
		particles.append({
			"seed": float(i) * 7.71,
			"x": fmod(float(i) * 137.0, 960.0),
			"y": fmod(float(i) * 83.0, 540.0),
			"r": 1.0 + fmod(float(i), 3.0)
		})

func _process(delta: float) -> void:
	t += delta
	var mouse: Vector2 = get_local_mouse_position()
	var focus_center: Vector2 = Vector2(size.x * 0.5, size.y * 0.57)
	var near_center: float = 1.0 - clampf(mouse.distance_to(focus_center) / 420.0, 0.0, 1.0)
	hover_energy = move_toward(hover_energy, near_center, delta * 2.8)
	queue_redraw()

func _draw() -> void:
	var w: float = size.x
	var h: float = size.y
	var mage_center: Vector2 = Vector2(w * 0.5, h * 0.57)
	var mouse: Vector2 = get_local_mouse_position()
	var parallax: Vector2 = (mouse-Vector2(w*0.5,h*0.5))*0.012
	draw_rect(Rect2(Vector2.ZERO,size),Color("#232a26"),true)
	for i in range(9):
		var rr: float = 300.0 - float(i) * 24.0
		draw_circle(mage_center + Vector2(0, 8), rr, Color(0.95,0.94,0.88,0.032 - float(i) * 0.0028))
	for ring in range(4):
		var radius: float = 72.0 + float(ring) * 34.0
		var alpha: float = 0.028 + float(ring) * 0.007
		var ring_center: Vector2 = mage_center+parallax*(0.35+float(ring)*0.18)
		draw_arc(ring_center,radius,-PI * 0.94 + sin(t * 0.35 + float(ring))*0.08,PI * 0.84 + sin(t * 0.35 + float(ring))*0.08,56,Color(0.97,0.96,0.90,alpha),1.0)
		for mark in range(4):
			var a: float = t * (0.22 + float(ring)*0.015) + float(mark) * TAU / 4.0 + float(ring) * 0.31
			var p: Vector2 = ring_center + Vector2(cos(a),sin(a))*radius
			draw_circle(p,1.2 + hover_energy*0.6,Color(1,1,1,0.08 + hover_energy*0.03))
	for item_value in particles:
		var item: Dictionary = item_value
		var particle_seed: float = float(item.get("seed",0.0))
		var px: float = fmod(float(item.get("x",0.0)) + t * (6.0 + fmod(particle_seed,8.0)),w + 30.0) - 15.0
		var py: float = float(item.get("y",0.0)) + sin(t*0.55 + particle_seed)*16.0
		var alpha: float = 0.02 + absf(sin(t*0.8+particle_seed))*0.04
		draw_circle(Vector2(px,py),float(item.get("r",1.0)),Color(0.94,0.93,0.86,alpha))
	var cursor_dir: Vector2 = mouse-mage_center
	if cursor_dir.length_squared() > 1.0:
		var cursor_angle: float = cursor_dir.angle()
		draw_arc(mage_center+parallax*0.4,188.0,cursor_angle-0.32,cursor_angle+0.32,18,Color(0.96,0.95,0.90,0.025+hover_energy*0.025),1.0)
	_draw_oval(mage_center + Vector2(0,96), Vector2(95.0, 20.0), Color(0.05,0.05,0.05,0.07))

func _draw_oval(center: Vector2,radius: Vector2,color: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(32):
		var a: float = TAU * float(i) / 32.0
		pts.append(center + Vector2(cos(a) * radius.x, sin(a) * radius.y))
	draw_colored_polygon(pts, color)
