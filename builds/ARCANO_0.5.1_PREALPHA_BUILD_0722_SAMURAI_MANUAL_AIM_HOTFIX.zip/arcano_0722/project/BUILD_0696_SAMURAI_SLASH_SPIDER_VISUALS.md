# BUILD 0696 — SAMURAI SLASH + SPIDER VISUALS

## Focus
Visual punch pass for the Samurai attack and the spider enemy.

## Samurai
- Reworked the Samurai slash visuals to be much flashier and more attention-grabbing.
- Added more layered crescents, brighter core trails, cross-cut accent arcs, burst rings, shards and extra spark detail.
- The dash slash and the normal sword slash should now read much more strongly in combat.

## Spider
- Reworked the spider enemy drawing to feel richer and more creature-like.
- Added layered body shells, segmented markings, more readable eye cluster, visible fangs with venom accents, joint detail, tiny body hairs and more nuanced legs.
- Overall silhouette should feel more premium and alive while staying in the game's sketchy style.

## Files changed
- player.gd
- enemy.gd
- endless_main.gd
