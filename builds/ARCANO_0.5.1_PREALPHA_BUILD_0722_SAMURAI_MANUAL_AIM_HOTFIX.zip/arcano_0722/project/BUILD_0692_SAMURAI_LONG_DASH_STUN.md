# BUILD 0692 — SAMURAI LONG DASH + RECOVERY STUN

## Requested change
- Removed the failed 2-step Samurai dash behavior.
- Replaced it with a single longer Samurai dash.
- Added a short 0.4 second recovery stun after the Samurai dash.

## Details
- Samurai dash distance/duration is now clearly longer than the default dash.
- Samurai dash remains visually unique via the custom Samurai dash pose.
- Samurai cannot move, attack, or start another dash during the 0.4s recovery window after the dash ends.
- Samurai dash recharge remains 4 seconds.

## Files changed
- player.gd
- endless_main.gd
