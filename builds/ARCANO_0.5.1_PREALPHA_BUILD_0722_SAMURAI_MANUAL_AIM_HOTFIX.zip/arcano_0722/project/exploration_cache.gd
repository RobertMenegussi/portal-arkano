extends Node2D

signal opened(reward: int)

var player
var reward: int = 5
var opened_once: bool = false
var e_was_down: bool = false
var t: float = 0.0
var label_text: String = "ACHADO ARCANO"

func configure(target, amount: int = 5) -> void:
	player = target
	reward = amount

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 20

func _process(delta: float) -> void:
	t += delta
	if opened_once or not is_instance_valid(player) or not player.active:
		queue_redraw()
		return
	var near: bool = global_position.distance_to(player.global_position) < 78.0
	var down: bool = Input.is_key_pressed(KEY_E)
	if near and down and not e_was_down:
		opened_once = true
		opened.emit(reward)
		get_tree().call_group("screen_fx","pulse_spawn")
		get_tree().call_group("audio_bus","play_magic_reload_finish")
	e_was_down = down
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var open_amount: float = 1.0 if opened_once else 0.0
	draw_rect(Rect2(-24,2,48,25),Color(1,1,1,0.78),true)
	draw_rect(Rect2(-24,2,48,25),Color(0.08,0.08,0.08,0.28),false,1.2)
	draw_line(Vector2(-20,3),Vector2(-14,-13-open_amount*9.0),ink,1.5)
	draw_line(Vector2(20,3),Vector2(14,-13-open_amount*9.0),ink,1.5)
	draw_line(Vector2(-14,-13-open_amount*9.0),Vector2(14,-13-open_amount*9.0),ink,1.5)
	for i in range(3):
		var a: float = t*2.2+float(i)*TAU/3.0
		var p: Vector2 = Vector2(cos(a)*12.0,-3+sin(a)*5.0)
		draw_circle(p,2.1,Color(0.08,0.08,0.08,0.18 if not opened_once else 0.05))
	if not opened_once and is_instance_valid(player) and global_position.distance_to(player.global_position) < 78.0:
		var font = ThemeDB.fallback_font
		if font != null:
			draw_rect(Rect2(-34,-48,68,24),Color(1,1,1,0.90),true)
			draw_rect(Rect2(-34,-48,68,24),Color(0.08,0.08,0.08,0.20),false,1.0)
			draw_string(font,Vector2(-24,-31),"E  ABRIR",HORIZONTAL_ALIGNMENT_LEFT,52,10,ink)
