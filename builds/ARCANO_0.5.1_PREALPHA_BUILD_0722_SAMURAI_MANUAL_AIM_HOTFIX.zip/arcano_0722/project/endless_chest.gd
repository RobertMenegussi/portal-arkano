extends Node2D

var player
var t: float = 0.0
var chest_tier: String = "elite"
var life_time: float = -1.0
var flash_t: float = 0.0
var opening: bool = false
var open_t: float = 0.0
var reward_sent: bool = false
var opened: bool = false
const INTERACTION_RANGE: float = 62.0

func configure(target, tier: String = "elite", ttl: float = -1.0) -> void:
	player = target
	chest_tier = tier
	life_time = ttl

func get_chest_tier() -> String:
	return chest_tier

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 22
	add_to_group("endless_drop")
	add_to_group("world_interactable")
	if chest_tier != "elite":
		add_to_group("world_chest")

func _process(delta: float) -> void:
	t += delta
	flash_t += delta
	if opened:
		return
	if opening:
		open_t += delta * 3.8
		if not reward_sent and open_t >= 0.34:
			reward_sent = true
			if chest_tier == "elite":
				get_tree().call_group("endless_controller","open_elite_chest")
			else:
				get_tree().call_group("endless_controller","open_world_chest",chest_tier)
		if open_t >= 1.0:
			opened = true
			queue_free()
		queue_redraw()
		return
	if not is_instance_valid(player):
		return
	if life_time > 0.0:
		life_time -= delta
		if life_time <= 0.0:
			queue_free()
			return
	queue_redraw()

func get_interaction_range() -> float:
	return INTERACTION_RANGE

func can_interact(target) -> bool:
	return not opened and not opening and is_instance_valid(target) and global_position.distance_to(target.global_position) <= INTERACTION_RANGE

func interact(target = null) -> bool:
	var actor = target if is_instance_valid(target) else player
	if not can_interact(actor):
		return false
	opening = true
	open_t = 0.0
	get_tree().call_group("audio_bus","play_ui_panel_open")
	queue_redraw()
	return true

func _draw() -> void:
	var bob: float = sin(t*2.6)*1.8
	var open_ratio: float = clampf(open_t,0.0,1.0)
	var lid_angle: float = -0.92 * ease(open_ratio,0.8)
	var aura_color: Color = Color("#f2cf7a",0.18)
	var wood_body: Color = Color("#6f5838")
	var metal: Color = Color("#e7c76a")
	var metal_dark: Color = Color("#8d6f27")
	if chest_tier == "silver":
		aura_color = Color("#dfe6ef",0.16)
		wood_body = Color("#65553f")
		metal = Color("#dfe5ed")
		metal_dark = Color("#9aa6b4")
	elif chest_tier == "gold":
		aura_color = Color("#f1d580",0.24)
		wood_body = Color("#6c5132")
		metal = Color("#f3d76e")
		metal_dark = Color("#a37b1d")
	var glow: float = 1.0 + open_ratio*1.8
	draw_circle(Vector2(0,8+bob),30.0*glow,Color(aura_color.r,aura_color.g,aura_color.b,aura_color.a*(0.65+open_ratio*0.7)))
	draw_circle(Vector2(0,6+bob),20.0,Color(0,0,0,0.08))
	var body: Rect2 = Rect2(Vector2(-20,-8+bob),Vector2(40,26))
	draw_rect(body,wood_body,true)
	draw_rect(body,Color(0.14,0.11,0.08,0.88),false,2.0)
	draw_rect(Rect2(Vector2(-20,0+bob),Vector2(40,5)),metal,true)
	draw_rect(Rect2(Vector2(-12,-8+bob),Vector2(6,26)),metal,true)
	draw_rect(Rect2(Vector2(6,-8+bob),Vector2(6,26)),metal,true)
	draw_rect(Rect2(Vector2(-4,-2+bob),Vector2(8,12)),metal,true)
	draw_rect(Rect2(Vector2(-4,-2+bob),Vector2(8,12)),metal_dark,false,1.0)
	for p in [Vector2(-15,-2),Vector2(15,-2),Vector2(-13,12),Vector2(13,12)]:
		draw_circle(p+Vector2(0,bob),1.5,metal_dark)
	# lid transform
	draw_set_transform(Vector2(0,-10+bob), lid_angle, Vector2.ONE)
	var lid: Rect2 = Rect2(Vector2(-22,-11),Vector2(44,13))
	draw_rect(lid,wood_body.lightened(0.12),true)
	draw_rect(lid,Color(0.14,0.11,0.08,0.88),false,2.0)
	draw_rect(Rect2(Vector2(-14,-11),Vector2(7,13)),metal,true)
	draw_rect(Rect2(Vector2(7,-11),Vector2(7,13)),metal,true)
	draw_line(Vector2(-16,-7),Vector2(16,-7),Color(1,1,1,0.10),1.0)
	draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
	# interior light burst
	if opening:
		var burst_alpha: float = sin(open_ratio*PI)
		draw_circle(Vector2(0,-8+bob),18.0+open_ratio*24.0,Color(metal.r,metal.g,metal.b,0.10+burst_alpha*0.18))
		for i in range(9):
			var a: float = TAU*float(i)/9.0 + flash_t*0.6
			var s: Vector2 = Vector2(cos(a),sin(a))*(12.0+open_ratio*22.0)
			draw_line(Vector2(0,-10+bob),Vector2(0,-10+bob)+s,Color(metal.r,metal.g,metal.b,0.18*burst_alpha),1.4)
	# sparkles
	var sparkle_count: int = 3 if chest_tier == "elite" else 5
	for i in range(sparkle_count):
		var a2: float = flash_t*1.1+TAU*float(i)/float(sparkle_count)
		var r: float = 19.0+float((i*7)%8)+open_ratio*6.0
		var s2: Vector2 = Vector2(cos(a2)*r,sin(a2)*10.0-r*0.18)+Vector2(0,bob-12-open_ratio*8.0)
		draw_line(s2+Vector2(-2,0),s2+Vector2(2,0),Color(metal.r,metal.g,metal.b,0.24),1.1)
		draw_line(s2+Vector2(0,-2),s2+Vector2(0,2),Color(metal.r,metal.g,metal.b,0.24),1.1)
	_draw_interaction_prompt(bob)
	if life_time > 0.0 and not opening:
		var base_ttl: float = 105.0 if chest_tier == "gold" else 90.0
		var ratio: float = clampf(life_time/base_ttl,0.0,1.0)
		draw_arc(Vector2(0,30+bob),15.0,-PI*0.5,-PI*0.5+TAU*ratio,28,Color(metal.r,metal.g,metal.b,0.32),2.0)

func _draw_interaction_prompt(bob: float) -> void:
	if opened or opening or not is_instance_valid(player) or global_position.distance_to(player.global_position) > INTERACTION_RANGE:
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var text: String = Loc.t("interact.chest")
	var width: float = 126.0
	var rect := Rect2(Vector2(-width*0.5,-55+bob),Vector2(width,22))
	draw_rect(rect,Color(0.025,0.032,0.030,0.90),true)
	draw_rect(rect,Color(0.95,0.92,0.82,0.18),false,1.0)
	draw_string(font,rect.position+Vector2(10,15),text,HORIZONTAL_ALIGNMENT_CENTER,width-20.0,8,Color(0.96,0.94,0.88,0.90))
