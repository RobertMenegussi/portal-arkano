extends Node2D

signal map_requested

var player
var enabled: bool = false
var show_prompt: bool = false
var e_was_down: bool = false
var t: float = 0.0

func configure(target) -> void:
	player = target

func activate() -> void:
	enabled = true
	queue_redraw()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 18
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	show_prompt = false
	if not enabled or not is_instance_valid(player) or not player.active:
		queue_redraw()
		return
	var dist: float = global_position.distance_to(player.global_position)
	if dist <= 104.0:
		show_prompt = true
		var down: bool = Input.is_key_pressed(KEY_E)
		if down and not e_was_down:
			map_requested.emit()
		e_was_down = down
	else:
		e_was_down = false
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#f8f3e8")
	# posts
	draw_rect(Rect2(Vector2(-64, 24), Vector2(8, 62)), Color(0.08,0.08,0.08,0.30), true)
	draw_rect(Rect2(Vector2(56, 24), Vector2(8, 62)), Color(0.08,0.08,0.08,0.30), true)
	# board
	var board: Rect2 = Rect2(Vector2(-72,-48), Vector2(144,88))
	draw_rect(board, paper, true)
	for i in range(3):
		draw_rect(board.grow(-float(i) * 1.8), Color(0.08,0.08,0.08,0.18 - float(i) * 0.03), false, 1.1)
	# miniature route scribble
	var route: PackedVector2Array = PackedVector2Array([
		Vector2(-52,18),Vector2(-32,2),Vector2(-8,8),Vector2(12,-8),Vector2(34,-18),Vector2(55,-31)
	])
	draw_polyline(route, Color(0.08,0.08,0.08,0.36), 2.0)
	for p in route:
		draw_circle(p, 3.1, paper)
		draw_arc(p, 3.1, 0.0, TAU, 12, Color(0.08,0.08,0.08,0.48), 1.0)
	# castle mark
	draw_rect(Rect2(Vector2(48,-39),Vector2(15,12)), Color(0.08,0.08,0.08,0.22), false, 1.2)
	draw_line(Vector2(50,-39),Vector2(50,-46),ink,1.2)
	draw_line(Vector2(61,-39),Vector2(61,-46),ink,1.2)
	# plaque
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font, Vector2(-47,36), "MAPA DAS TERRAS CINZENTAS", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color(0.08,0.08,0.08,0.58))
	if show_prompt:
		var pulse: float = 1.0 + sin(t * 4.0) * 0.04
		_draw_oval(Vector2(0,-70), Vector2(39.0 * pulse, 13.0 * pulse), Color(1,1,1,0.94))
		draw_arc(Vector2(0,-70),39.0,0.0,TAU,26,Color(0.08,0.08,0.08,0.30),1.0)
		if font != null:
			draw_string(font, Vector2(-26,-65), "E  examinar", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, ink)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)
