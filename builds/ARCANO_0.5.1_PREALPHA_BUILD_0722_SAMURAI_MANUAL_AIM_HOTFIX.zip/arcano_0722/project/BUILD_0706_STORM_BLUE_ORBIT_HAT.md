# BUILD 0706 — Storm blue mantle + Orbit big hat

## Main changes
- Storm HUD portrait now uses a darker blue mantle/collar with lighter blue lightning accents to reduce silhouette confusion.
- Orbit HUD portrait now has a much more visible wizard hat / big hat so the class reads instantly.
- Kept the previous readability pass, hit impact portrait animation and dash lightning containers.

## Files changed
- hud_display.gd
- endless_main.gd
