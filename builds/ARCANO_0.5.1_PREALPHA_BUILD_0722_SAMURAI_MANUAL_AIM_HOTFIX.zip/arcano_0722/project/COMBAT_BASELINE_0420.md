# ARCANO 0.2.0 - Combat Baseline

Tomos are disabled in this build so the three class kits can be evaluated without modifiers.

## Orbital
- automatic sustained pressure
- 6 visible orbiting stones
- slight accuracy cone (~1 degree baseline)
- 1 damage, 0.48s cadence, 1.10s reload, projectile speed 780

## Tempestade
- deliberate heavy area strike
- slight target error rather than perfect aimbot accuracy
- 2 damage, radius 42, 0.32s charge

## Fenda
- completely reworked from a travelling projectile into a persistent ground scar
- 2 charges
- 340 range
- 28 half-width damage zone
- 1 damage tick every 0.90s
- scar lasts 4.0s
- 2.40s reload after charges are spent
- enemies crossing the scar take damage; enemies remaining on it take repeated damage

## Auto-targeting
- nearest remains the default
- slight target hysteresis prevents constant target flickering
- supported targeting modes remain nearest, lowest current HP, highest max HP, and manual mouse

## Progression
- XP and level remain active
- level-up trait choice is disabled
- elite chests temporarily heal 1 HP instead of granting traits
