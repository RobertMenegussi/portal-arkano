# BUILD 0712 — Enemy pacing + Flux tune

## Enemy scaling
- Reworked HP scaling so the first minutes grow through horde density instead of HP sponge behavior.
- HP growth now begins gently after roughly 2 minutes and ramps much slower through the early/mid game.
- Spider HP remains fixed; spiders are meant to threaten through speed and numbers, not durability.
- Enemy HP scaling now rounds instead of always rounding upward, preventing tiny multipliers from instantly adding a full HP point to low-health mobs.

## Flux
- Normal kill gain: 0.70 -> 0.95.
- Elite kill gain: 7.0 -> 8.0.
- Delay before passive Flux loss: 2.15s -> 2.60s.
- Passive Flux drain: 5.1/s -> 4.2/s.

Goal: noticeably easier to maintain/build Flow without making it automatic.
