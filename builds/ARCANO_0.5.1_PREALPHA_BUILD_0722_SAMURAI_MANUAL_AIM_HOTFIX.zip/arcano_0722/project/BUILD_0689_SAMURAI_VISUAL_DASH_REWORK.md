# BUILD 0689 — SAMURAI VISUAL + DASH REWORK

## Focus
Single-class polish pass focused on Samurai.

## Visuals
- Reworked the Samurai sprite into a richer, more premium-looking silhouette.
- Added layered clothing, sleeves, shoulder pieces, sash, pleats, headband ribbons and clearer katana/sheath detail.
- Introduced small color accents (muted crimson/gold) to make the class feel more premium without breaking the ink-sketch style.
- Gave the Samurai a more deliberate stalking walk/read compared to the generic mage posture.
- Updated the Samurai class preview art to match the new direction.

## Dash
- Samurai dash is now much faster and significantly longer.
- Samurai now has 2 dash charges by default.
- Samurai dash recharge now uses a single 4 second refill that restores the full stack.
- Added a stronger slash-style dash read and follow-through effects.
- Added a Samurai-specific dash finish pulse to sell the iai-cut feel more strongly.

## Files changed
- player.gd
- mage_preview.gd
