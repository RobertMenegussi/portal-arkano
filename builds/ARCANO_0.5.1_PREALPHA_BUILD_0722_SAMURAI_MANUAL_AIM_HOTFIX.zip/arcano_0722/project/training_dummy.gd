extends StaticBody2D

var total_damage: int = 0
var hit_count: int = 0
var window_damage: int = 0
var window_time: float = 0.0
var display_dps: float = 0.0
var hit_flash: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy")
	add_to_group("sandbox_spawn")
	collision_layer = 4
	collision_mask = 0
	z_index = 22
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 23.0
	collider.shape = shape
	add_child(collider)

func _process(delta: float) -> void:
	hit_flash = move_toward(hit_flash,0.0,delta*7.0)
	window_time += delta
	if window_time >= 1.0:
		display_dps = float(window_damage) / window_time
		window_damage = 0
		window_time = 0.0
	queue_redraw()

func take_damage(amount: int, _direction: Vector2) -> void:
	total_damage += amount
	window_damage += amount
	hit_count += 1
	hit_flash = 1.0
	get_tree().call_group("audio_bus","play_enemy_hit")
	get_tree().call_group("screen_fx","pulse_enemy_hit")

func apply_external_force(_force: Vector2) -> void:
	pass

func reset_stats() -> void:
	total_damage = 0
	hit_count = 0
	window_damage = 0
	window_time = 0.0
	display_dps = 0.0

func _draw() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"),hit_flash*0.65)
	var paper: Color = Color("#f8f4e9")
	draw_circle(Vector2(0,18),24.0,Color(0.08,0.08,0.08,0.05))
	draw_rect(Rect2(Vector2(-15,-24),Vector2(30,48)),paper,true)
	draw_rect(Rect2(Vector2(-15,-24),Vector2(30,48)),ink,false,2.0)
	draw_line(Vector2(-15,-8),Vector2(15,-8),ink,1.0)
	draw_line(Vector2(-15,8),Vector2(15,8),ink,1.0)
	draw_line(Vector2(0,-24),Vector2(0,24),ink,1.0)
	draw_circle(Vector2.ZERO,5.0,ink)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(-52,-40),"DUMMY",HORIZONTAL_ALIGNMENT_CENTER,104,10,Color(0.08,0.08,0.08,0.55))
		draw_string(font,Vector2(-70,43),"DPS "+str(snappedf(display_dps,0.1))+"  •  TOTAL "+str(total_damage),HORIZONTAL_ALIGNMENT_CENTER,140,9,Color(0.08,0.08,0.08,0.45))
