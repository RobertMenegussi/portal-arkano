extends Node2D

var pattern: String = "nova"
var radius: float = 120.0
var direction: Vector2 = Vector2.RIGHT
var points: Array = []
var accent: int = 0
var t: float = 0.0
var duration: float = 0.42
var visual_timer: float = 0.0

func configure(effect_pattern: String,origin: Vector2,radius_value: float,dir: Vector2,target_points: Array,accent_index: int = 0) -> void:
	pattern = effect_pattern
	global_position = origin
	radius = radius_value
	direction = dir.normalized() if dir.length_squared() > 0.001 else Vector2.RIGHT
	points = target_points.duplicate()
	accent = accent_index

func _ready() -> void:
	z_index = 40
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("run_vfx")

func _process(delta: float) -> void:
	t += delta
	if t >= duration:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _palette() -> Color:
	match accent % 4:
		1: return Color("#e1c98d")
		2: return Color("#a8c5cf")
		3: return Color("#c7a6a0")
		_: return Color("#e9e6db")

func _draw() -> void:
	var p: float = clampf(t/duration,0.0,1.0)
	var fade: float = 1.0-p
	var c: Color = _palette()
	c.a = 0.52*fade
	var ink: Color = Color(0.04,0.04,0.04,0.34*fade)
	match pattern:
		"nova":
			var rr: float = radius*(0.18+0.82*p)
			draw_arc(Vector2.ZERO,rr,0.0,TAU,44,c,2.4)
			draw_arc(Vector2.ZERO,rr*0.72,0.0,TAU,36,ink,1.2)
			for i in range(8):
				var a: float = TAU*float(i)/8.0
				draw_line(Vector2(cos(a),sin(a))*rr*0.72,Vector2(cos(a),sin(a))*rr,c,1.2)
		"bolt":
			for point_value in points:
				var point: Vector2 = point_value
				_draw_lightning(Vector2.ZERO,point,c,ink,p)
		"rain":
			for point_value in points:
				var point: Vector2 = point_value
				draw_line(point+Vector2(-3,-44)*(1.0-p),point,c,2.0)
				draw_circle(point,8.0+18.0*p,Color(c.r,c.g,c.b,0.12*fade))
				draw_arc(point,10.0+18.0*p,0.0,TAU,22,c,1.5)
		"cone":
			var angle: float = direction.angle()
			draw_arc(Vector2.ZERO,radius*(0.55+0.35*p),angle-0.74,angle+0.74,30,c,3.0)
			draw_arc(Vector2.ZERO,radius*(0.72+0.20*p),angle-0.60,angle+0.60,28,ink,1.3)
		"line":
			var end: Vector2 = direction*radius
			_draw_lightning(Vector2.ZERO,end,c,ink,p)
		"orbit":
			var rr2: float = radius*0.72
			draw_arc(Vector2.ZERO,rr2,0.0,TAU,48,Color(c.r,c.g,c.b,0.26*fade),2.0)
			for i in range(6):
				var a2: float = t*7.0+TAU*float(i)/6.0
				var q: Vector2 = Vector2(cos(a2)*rr2,sin(a2)*rr2*0.70)
				_draw_diamond(q,4.0+2.0*fade,c)
		"burst":
			for i in range(10):
				var a3: float = TAU*float(i)/10.0+0.18
				var a0: Vector2 = Vector2(cos(a3),sin(a3))*radius*0.12
				var a1: Vector2 = Vector2(cos(a3),sin(a3))*radius*(0.28+0.72*p)
				draw_line(a0,a1,c,1.8)
		"aura":
			var rr3: float = radius*(0.88+sin(t*20.0)*0.05)
			draw_circle(Vector2.ZERO,rr3,Color(c.r,c.g,c.b,0.035*fade))
			draw_arc(Vector2.ZERO,rr3,0.0,TAU,42,c,1.8)
			for i in range(5):
				var a4: float = t*2.0+TAU*float(i)/5.0
				draw_circle(Vector2(cos(a4),sin(a4))*rr3,2.0,c)
		"mark":
			for point_value in points:
				var point: Vector2 = point_value
				draw_arc(point,18.0+12.0*p,0.0,TAU,28,c,2.1)
				draw_line(point+Vector2(-14,0),point+Vector2(14,0),ink,1.2)
				draw_line(point+Vector2(0,-14),point+Vector2(0,14),ink,1.2)
		"spiral":
			for i in range(18):
				var f: float = float(i)/17.0
				var a5: float = f*TAU*2.2+t*7.0
				var q2: Vector2 = Vector2(cos(a5),sin(a5))*radius*f*0.72
				draw_circle(q2,1.6+1.4*fade,c)

func _draw_lightning(a: Vector2,b: Vector2,c: Color,ink: Color,progress: float) -> void:
	var pts: PackedVector2Array = PackedVector2Array([a])
	for i in range(1,7):
		var f: float = float(i)/7.0
		var base: Vector2 = a.lerp(b,f)
		var normal: Vector2 = Vector2(-(b-a).y,(b-a).x).normalized()
		var jitter: float = sin(float(i)*7.31+t*35.0)*7.0*(1.0-f*0.4)
		pts.append(base+normal*jitter)
	pts.append(b*clampf(0.25+progress*0.9,0.0,1.0))
	draw_polyline(pts,ink,3.2)
	draw_polyline(pts,c,1.5)

func _draw_diamond(center: Vector2,r: float,color: Color) -> void:
	var poly := PackedVector2Array([center+Vector2(0,-r),center+Vector2(r*0.72,0),center+Vector2(0,r),center+Vector2(-r*0.72,0)])
	draw_colored_polygon(poly,color)
