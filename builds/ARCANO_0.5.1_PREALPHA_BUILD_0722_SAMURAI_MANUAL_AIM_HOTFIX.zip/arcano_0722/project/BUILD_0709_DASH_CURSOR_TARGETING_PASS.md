# BUILD 0709 — Dash world icons + R target toggle + manual aim cursor

## Main changes
- Dash reload indicator moved away from the HUD portrait and into the battlefield, close to the player.
- New dash indicator style uses a tiny running/dash icon with motion streaks and refill progress.
- Removed the in-menu attack method workflow for gameplay use; R now toggles only between nearest auto-targeting and mouse manual aim.
- Added a new quality manual aim cursor for mouse mode so hidden-cursor gameplay remains readable.
- Mouse mode now keeps automatic firing active, but aims toward the mouse position (including Storm lightning targeting).

## Files changed
- player.gd
- hud_display.gd
- endless_main.gd
- endless_aim_cursor.gd
