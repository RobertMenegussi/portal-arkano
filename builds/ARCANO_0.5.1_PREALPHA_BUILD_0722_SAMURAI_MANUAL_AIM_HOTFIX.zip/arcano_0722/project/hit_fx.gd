extends Node2D

var direction: Vector2 = Vector2.RIGHT
var tint: Color = Color("#111111")
var life: float = 0.34
var max_life: float = 0.34
var visual_timer: float = 0.0
var streaks: Array = []
var flecks: Array = []
var twist: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 60
	twist = randf_range(-0.8, 0.8)
	for i in range(16):
		var a: float = direction.angle() + randf_range(-1.75, 1.75)
		streaks.append({
			"angle": a,
			"len": randf_range(10.0, 26.0),
			"speed": randf_range(54.0, 155.0),
			"offset": randf_range(0.0, 6.0)
		})
	for i in range(12):
		flecks.append({
			"angle": randf_range(0.0, TAU),
			"speed": randf_range(42.0, 115.0),
			"size": randf_range(1.0, 3.0)
		})

func _process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 30.0
		queue_redraw()

func _draw() -> void:
	var ratio: float = clampf(life / max_life, 0.0, 1.0)
	var elapsed: float = max_life - life
	var impact: float = 1.0 - ratio
	var dir_main: Vector2 = direction.normalized()
	if dir_main.length_squared() < 0.001:
		dir_main = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir_main.y, dir_main.x)
	var warm_flash: Color = Color(1, 0.99, 0.95, 0.78 * ratio)
	var ink_soft: Color = Color(tint.r, tint.g, tint.b, ratio * 0.34)

	draw_circle(Vector2.ZERO, 11.0 * ratio + 2.0, warm_flash)
	draw_circle(Vector2.ZERO, 5.0 + impact * 3.0, Color(1, 1, 1, 0.22 * ratio))

	var ring_r: float = lerpf(4.0, 31.0, impact)
	for i in range(5):
		var start_a: float = float(i) * PI * 0.4 + twist + impact * 0.6
		draw_arc(Vector2.ZERO, ring_r + float(i % 2) * 2.0, start_a, start_a + 0.8, 9, ink_soft, 1.4)

	var slash_len: float = 19.0 + impact * 10.0
	draw_line(-dir_main * slash_len - side * 6.0, dir_main * slash_len + side * 6.0, Color(tint.r, tint.g, tint.b, ratio * 0.54), 2.4)
	draw_line(-dir_main * (slash_len * 0.72) + side * 8.0, dir_main * (slash_len * 0.72) - side * 8.0, Color(1, 1, 1, ratio * 0.20), 1.4)
	draw_line(-side * 14.0 + dir_main * 1.0, side * 14.0 - dir_main * 1.0, Color(tint.r, tint.g, tint.b, ratio * 0.28), 1.4)

	for item in streaks:
		var a: float = float(item["angle"])
		var len_v: float = float(item["len"])
		var speed_v: float = float(item["speed"])
		var off_v: float = float(item["offset"]) + elapsed * speed_v
		var dir: Vector2 = Vector2(cos(a), sin(a))
		var p: Vector2 = dir * off_v
		draw_line(p, p + dir * len_v * ratio, Color(tint.r, tint.g, tint.b, ratio * 0.82), 1.6)
		if ratio > 0.15:
			draw_circle(p + dir * len_v * ratio, 0.9 + ratio, Color(1, 1, 1, 0.22 * ratio))

	for fleck in flecks:
		var fa: float = float(fleck["angle"])
		var fd: Vector2 = Vector2(cos(fa), sin(fa))
		var fp: Vector2 = fd * float(fleck["speed"]) * elapsed
		draw_circle(fp, float(fleck["size"]) * ratio, Color(tint.r, tint.g, tint.b, ratio * 0.52))
