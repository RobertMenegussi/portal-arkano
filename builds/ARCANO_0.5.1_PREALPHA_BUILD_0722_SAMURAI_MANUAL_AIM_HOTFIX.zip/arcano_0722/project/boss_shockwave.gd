extends Node2D

var player
var t: float = 0.0
var duration: float = 1.05
var wave_count: int = 3
var max_radius: float = 150.0
var hit_waves: Array = [false, false, false]

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 40
	hit_waves.resize(maxi(1,wave_count))
	for i in range(hit_waves.size()):
		hit_waves[i] = false

func _process(delta: float) -> void:
	t += delta
	_update_hits()
	if t >= duration:
		queue_free()
		return
	queue_redraw()

func _update_hits() -> void:
	if not is_instance_valid(player) or not player.active:
		return
	var dist: float = global_position.distance_to(player.global_position)
	for i in range(wave_count):
		var local_t: float = t - float(i) * 0.22
		if local_t < 0.0:
			continue
		var p: float = clampf(local_t / 0.62, 0.0, 1.0)
		var r: float = p * max_radius
		if not hit_waves[i] and absf(dist-r) < 13.0 and p < 1.0:
			hit_waves[i] = true
			var dir: Vector2 = (player.global_position-global_position).normalized()
			player.take_damage(1, dir)

func _draw() -> void:
	for i in range(wave_count):
		var local_t: float = t - float(i)*0.22
		if local_t < 0.0:
			continue
		var p: float = clampf(local_t/0.62,0.0,1.0)
		var alpha: float = (1.0-p)*0.34
		draw_arc(Vector2.ZERO, p*max_radius, 0.0, TAU, 42, Color(0.08,0.08,0.08,alpha), 3.0)
		draw_arc(Vector2.ZERO, p*max_radius+4.0, 0.0, TAU, 42, Color(1,1,1,alpha*0.35), 1.0)
