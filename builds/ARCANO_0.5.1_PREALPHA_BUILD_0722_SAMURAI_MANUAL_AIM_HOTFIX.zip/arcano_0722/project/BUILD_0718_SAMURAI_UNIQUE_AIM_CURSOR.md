# BUILD 0718 — Samurai unique aim cursor

## Main changes
- Restored visible aim feedback for Samurai in mouse/manual mode.
- Samurai no longer overrides mouse aim with nearest-enemy auto facing while in manual mode.
- Added a unique melee cursor for Samurai with a slash/blade feel instead of the generic ranged reticle.
- The Samurai cursor positions itself along the melee direction relative to the player so the player can read short-range spacing more clearly.

## Files changed
- player.gd
- endless_aim_cursor.gd
- endless_main.gd
