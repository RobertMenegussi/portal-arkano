# ARCANO 0.5.1-prealpha — Build 0670

## Performance / Horde pass

This build is a broad runtime optimization pass aimed at dense Endless runs without removing gameplay systems or combat content.

### Enemy simulation
- Endless enemy ceilings trimmed modestly (~7–9%) instead of cutting the horde identity.
- Standard enemies are ~4–5% smaller; large standard mobs ~4% smaller; Elite Reaver ~2% smaller.
- Existing far-enemy cheap steering switches slightly earlier while still returning to full AI before attack ranges.
- Soft crowd separation is cached/staggered instead of recomputed for every enemy every physics frame.
- Spatial enemy hash is rebuilt at 15 Hz and shared by attacks, AI helpers and effects.
- Large-radius queries use a flat cached enemy list instead of walking hundreds of empty hash cells.
- Local effects (slashes, orbit blade, ricochet, rifts, lightning, bursts) query nearby buckets rather than repeatedly scanning the entire SceneTree.

### Rune / combat runtime
- Style Rune definitions are cached when the build changes instead of re-reading/scanning the 100-Rune catalog every frame.
- Periodic Rune execution reuses the visible-enemy list inside each proc.
- Tome Arsenal nearest/densest/whip/orbit-blade targeting now uses the Endless spatial index.
- Expanding Arcane Burst hit scans run at 30 Hz while keeping its visual animation and lifetime.
- Projectile and enemy-arrow lifetimes no longer allocate one SceneTreeTimer per projectile; wall-clock expiry is preserved across pauses.
- Several hot distance checks now use squared distance where an exact square root is unnecessary.

### Rendering / UI
- Enemy custom redraw rate is distance-aware (near 30 Hz, far 16–18 Hz) while movement/physics stay at full physics cadence.
- Projectiles and major combat VFX redraw at 30 Hz instead of rebuilding custom draw commands every frame.
- HUD, XP meter, boss indicator and threat arrows own throttled redraw cadences; duplicate controller redraw requests were removed.
- Hit FX, Rune FX, dash afterimages and shield-break FX retain the same content/lifetime but rebuild their drawing at 30 Hz.
- XP orbs redraw at 20 Hz and idle far-away orbs perform proximity checks at ~14 Hz until attraction begins.

### Persistent death-mark batching
- Slime/skeleton death animations still play normally.
- Once settled, their exact final marks are transferred to static batches of up to 64 deaths per CanvasItem.
- This preserves the run's accumulated ink/bone aftermath without leaving one processing/render node per dead enemy.

## Rune of Vision — 5 ranks

Added a new Foundation Rune family: **Rune of Vision / Runa da Visão / 視界のルーン / Runa de Visión**.

- Rank I: ~3% more battlefield visible per direction.
- Rank II: ~6% total.
- Rank III: ~10% total.
- Rank IV: ~13% total.
- Rank V: ~16% total.

Each rank multiplies Endless camera zoom by 0.97. The Rune card supports five rank pips dynamically.

## Validation
- 81 GDScript files scanned.
- All `res://` preload/load paths found.
- Rough delimiter/string static validation passed across all GDScript files.
- FOV rank math validated: 3.1%, 6.3%, 9.6%, 13.0%, 16.5% effective width/height gain.
- No Godot executable is available in the build environment, so runtime/FPS profiling must be performed in-engine on the playtest machine.
