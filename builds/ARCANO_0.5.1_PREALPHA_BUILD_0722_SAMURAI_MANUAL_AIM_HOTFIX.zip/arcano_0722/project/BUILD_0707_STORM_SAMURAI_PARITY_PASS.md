# BUILD 0707 — Storm & Samurai visual parity pass

## Goal
Bring Storm and Samurai closer to Orbit's in-game quality by giving them smoother eye tracking, stronger body motion, and more readable held-weapon/focus details.

## Main changes
- Added smoothed visual aim and movement directions used by the eyes and body posing.
- Eyes now track targets with smoother motion instead of snapping directly to aim direction.
- Storm base in-game sprite got a richer idle/walk pose with body/head leaning, more cloth motion, and a visible lightning focus rod in the hand.
- Samurai base in-game sprite got richer walk posing, better body follow, and a more readable held katana pose while keeping the sheath visible on the hip.
- Kept previous HUD portrait work from build 0706.

## Files changed
- player.gd
- endless_main.gd
