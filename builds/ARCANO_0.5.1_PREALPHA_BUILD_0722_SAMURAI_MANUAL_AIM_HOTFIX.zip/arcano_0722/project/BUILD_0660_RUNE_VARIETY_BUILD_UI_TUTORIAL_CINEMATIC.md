# ARCANO 0.5.1-prealpha — Build 0660

## Rune variety / offer logic
- Level-up offers now have three distinct roles instead of three random cards from one giant pool:
  1. a class/signature Rune,
  2. a foundation Rune,
  3. a wildcard / mechanic Rune.
- Class slot prioritizes Runes that actually alter the current class kit. Samurai and Orbital therefore consistently see upgrades connected to their own combat identity.
- The game remembers recent offered Rune ids and Rune families, reducing repeat cards even when the player did not pick them.
- Old percentage-stat Rune families remain readable by old saves, but no longer appear in new run offers or the Arcane Runes catalog. This removes near-duplicate stat clutter without breaking compatibility.

## Rune descriptions / rank clarity
- User-facing descriptions were rebuilt for every offered Rune path:
  - 9 foundation Rune families,
  - all 100 style Runes,
  - 8 mutations,
  - 25 mechanic Runes.
- Style Rune descriptions are generated from the effect that actually runs: trigger, target shape, hit count, damage and cooldown.
- Awkward cooldown values were normalized to whole / half seconds.
- Vitality no longer says `+10% health`; life is explained as actual life hits/pips.
- Foundation ranks I / II / III now scale differently and the card states both what the current pick adds and the total contribution of that Rune line.
- Ranked cards also draw 1/2/3 small rank marks for immediate visual reading.
- Removed the old extra stat-preview rows from level-up cards so cards read like game choices rather than a spreadsheet.

## TAB / ESC information architecture
- TAB was rebuilt as a lightweight build view only:
  - acquired Runes,
  - one-use item belt slots [1]–[9] + [0].
- Run statistics moved to the ESC pause screen.
- ESC now shows class, run time, health, Rune count, kills / Elites, base damage, attack rate, movement, Dash charges and XP bonus.
- Opening ESC closes the TAB overlay first, avoiding stacked panels.

## Tutorial pacing / camera
- Removed the line that reveals Sensei as a future Boss.
- Tutorial Rune explanation now matches the new three-role offer system and the I/II/III progression.
- Tutorial TAB explanation now teaches the new TAB build view and points the player to ESC for run statistics.
- Completing an action no longer jumps to the next subject on the same frame. A short confirmation beat is inserted before the next lesson.
- Added short camera glances / zooms toward teaching targets: Orbital target, Samurai target, XP, ground items, vase, chests, Dragon Breath targets, Flux target and Elite.
- Camera returns control after each demonstration and preserves the tutorial's combat locks.

## Compatibility
- Internal Rune ids were preserved.
- Legacy percentage families remain in `all_ids()` / effect handling for existing saves but are hidden from new user-facing pools.
- Version remains `0.5.1-prealpha`; build id is now `0660`.

## Runtime note
Godot is not installed in the build environment, so this package received static / source validation only. Runtime feel and final UI spacing should be playtested in-engine.
