extends Button

var trait_id: String = ""
var title_text: String = "TRAÇO"
var description_text: String = ""
var rarity_text: String = "ARCANO"
var class_kind: String = "orbit"
var hovered_local: bool = false
var hover_t: float = 0.0
var pressed_t: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	focus_mode = Control.FOCUS_NONE
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	clip_contents = true
	mouse_entered.connect(_on_enter)
	mouse_exited.connect(_on_exit)
	button_down.connect(_on_down)
	button_up.connect(_on_up)
	var clear: StyleBoxFlat = StyleBoxFlat.new()
	clear.bg_color = Color(0,0,0,0)
	for key in ["normal","hover","pressed","focus"]:
		add_theme_stylebox_override(key,clear)

func _on_enter() -> void:
	hovered_local = true

func _on_exit() -> void:
	hovered_local = false

func _on_down() -> void:
	pressed_t = 1.0

func _on_up() -> void:
	pressed_t = 0.0

func _process(delta: float) -> void:
	hover_t = move_toward(hover_t,1.0 if hovered_local else 0.0,delta*8.5)
	pressed_t = move_toward(pressed_t,0.0,delta*12.0)
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var font = ThemeDB.fallback_font
	var lift: float = -4.0*hover_t+2.0*pressed_t
	var rect: Rect2 = Rect2(Vector2(3,7+lift),size-Vector2(6,14))
	draw_rect(Rect2(rect.position+Vector2(0,6),rect.size),Color(0.08,0.08,0.08,0.055),true)
	draw_rect(rect,Color(1,1,1,0.91+hover_t*0.06),true)
	draw_rect(rect,Color(0.08,0.08,0.08,0.18+hover_t*0.12),false,1.2)
	for i in range(3):
		var y: float = rect.position.y+10.0+float(i)*3.0
		draw_line(Vector2(rect.position.x+10,y),Vector2(rect.end.x-10,y),Color(0.08,0.08,0.08,0.025),1.0)
	_draw_glyph(rect.position+Vector2(32,34),ink)
	if font == null:
		return
	draw_string(font,rect.position+Vector2(58,25),rarity_text,HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-72,9,Color(0.08,0.08,0.08,0.34))
	draw_string(font,rect.position+Vector2(58,49),title_text,HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-72,16,ink)
	var lines: Array[String] = _wrap(font,description_text,11,rect.size.x-30.0,4)
	for i in range(lines.size()):
		draw_string(font,rect.position+Vector2(15,82+float(i)*17.0),lines[i],HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-30.0,11,Color(0.08,0.08,0.08,0.58))
	draw_line(Vector2(rect.position.x+15,rect.end.y-30),Vector2(rect.end.x-15,rect.end.y-30),Color(0.08,0.08,0.08,0.08),1.0)
	draw_string(font,Vector2(rect.position.x+15,rect.end.y-12),"ESCOLHER",HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-30.0,9,Color(0.08,0.08,0.08,0.38+hover_t*0.25))

func _draw_glyph(center: Vector2, ink: Color) -> void:
	match class_kind:
		"storm":
			draw_polyline(PackedVector2Array([center+Vector2(-5,-12),center+Vector2(3,-4),center+Vector2(-2,2),center+Vector2(7,12)]),ink,2.4)
		"rift":
			draw_arc(center+Vector2(-2,0),12.0,-1.25,1.25,18,ink,2.1)
			draw_arc(center+Vector2(4,0),8.0,PI-1.0,PI+1.0,14,Color(0.08,0.08,0.08,0.28),1.4)
		_:
			var d: PackedVector2Array = PackedVector2Array([center+Vector2(0,-12),center+Vector2(9,0),center+Vector2(0,12),center+Vector2(-9,0),center+Vector2(0,-12)])
			draw_polyline(d,ink,2.0)

func _wrap(font, value: String, font_size: int, width: float, max_lines: int) -> Array[String]:
	var out: Array[String] = []
	var words: PackedStringArray = value.split(" ")
	var current: String = ""
	for word in words:
		var candidate: String = word if current == "" else current+" "+word
		if font.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,font_size).x <= width:
			current = candidate
		else:
			if current != "":
				out.append(current)
			if out.size() >= max_lines:
				break
			current = word
	if out.size() < max_lines and current != "":
		out.append(current)
	return out
