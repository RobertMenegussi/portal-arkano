extends Node2D

const EnemyScript = preload("res://enemy.gd")

var enemy_type: String = "slime"
var player
var enabled: bool = false
var triggered: bool = false
var spawned: bool = false
var trigger_radius: float = 260.0
var telegraph_time: float = 0.72
var t: float = 0.0
var fade_t: float = 0.0
var sketch_frame: int = 0
var sketch_timer: float = 0.0

func configure(kind: String, target) -> void:
	enemy_type = kind
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 12
	visible = false

func activate() -> void:
	enabled = true

func _process(delta: float) -> void:
	if not enabled or spawned:
		return

	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.065
		sketch_frame += 1

	if not triggered and is_instance_valid(player) and player.active:
		if global_position.distance_to(player.global_position) <= trigger_radius:
			triggered = true
			visible = true
			t = 0.0
			get_tree().call_group("screen_fx", "pulse_spawn")
			if player.has_method("add_camera_shake"):
				player.add_camera_shake(2.4)

	if triggered:
		t += delta
		queue_redraw()
		if t >= telegraph_time:
			_spawn_enemy()

func _spawn_enemy() -> void:
	if spawned:
		return
	spawned = true

	var enemy = EnemyScript.new()
	enemy.configure(enemy_type, player)
	enemy.global_position = global_position
	get_tree().current_scene.add_child(enemy)

	var tween := create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.22)
	tween.tween_callback(queue_free)

func sketch_jitter(index: int, amount: float) -> float:
	return sin(float(sketch_frame) * 2.41 + float(index) * 4.11) * amount

func _draw() -> void:
	if not triggered:
		return

	var charge: float = clampf(t / telegraph_time, 0.0, 1.0)
	var ink := Color("#111111")
	var ring: float = 16.0 + charge * 17.0

	for pass_i in range(4):
		var center := Vector2(sketch_jitter(10 + pass_i, 1.8), sketch_jitter(20 + pass_i, 1.8))
		draw_arc(center, ring + sketch_jitter(30 + pass_i, 2.0), 0.0, TAU, 28, Color(0.06, 0.06, 0.06, 0.14 + charge * 0.16), 1.4)

	for i in range(8):
		var a: float = TAU * float(i) / 8.0 + t * 4.0
		var p := Vector2(cos(a), sin(a)) * (10.0 + charge * 20.0)
		draw_circle(p, 1.7 + charge * 1.2, Color(0.05, 0.05, 0.05, 0.22 + charge * 0.40))

	draw_circle(Vector2.ZERO, 6.0 + charge * 10.0, Color(0.04, 0.04, 0.04, 0.05 + charge * 0.16))
