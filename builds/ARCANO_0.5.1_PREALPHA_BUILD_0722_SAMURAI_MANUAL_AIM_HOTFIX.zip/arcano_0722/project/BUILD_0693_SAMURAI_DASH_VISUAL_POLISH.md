# BUILD 0693 — SAMURAI DASH VISUAL POLISH

## Focus
A richer and more eye-catching Samurai dash presentation.

## Changes
- Added a Samurai recovery pose during the short post-dash stun to make the whole action read more like a complete animation.
- Reworked the Samurai dash pose with more flourish, richer silhouette reading and stronger weapon presentation.
- Upgraded Samurai dash effects with more slash layers, brighter highlights, accent arcs, sparks and a ring burst.
- Added lingering finish visuals during the post-dash recovery window so the move feels more premium and flashy.

## Files changed
- player.gd
- endless_main.gd
