extends Node2D

var t: float = 0.0
var life: float = 1.08

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 8

func _process(delta: float) -> void:
	t += delta
	if t >= life:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	var p: float = clampf(t / life, 0.0, 1.0)
	var fade: float = 1.0 - p
	var ink := Color(0.05, 0.05, 0.05, fade * 0.45)

	for i in range(5):
		var radius: float = 18.0 + p * 65.0 + float(i) * 4.0
		draw_arc(Vector2.ZERO, radius, p * (1.0 + float(i) * 0.15), TAU + p * (1.0 + float(i) * 0.15), 30, Color(0.05, 0.05, 0.05, fade * 0.16), 1.2)

	for i in range(14):
		var a: float = TAU * float(i) / 14.0 + p * 4.0
		var dist: float = 12.0 + p * 54.0
		var pos := Vector2(cos(a), sin(a)) * dist
		draw_circle(pos, 1.4 + float(i % 3) * 0.5, ink)
