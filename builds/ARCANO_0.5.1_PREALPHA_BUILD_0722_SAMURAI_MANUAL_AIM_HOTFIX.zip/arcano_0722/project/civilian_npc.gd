extends Node2D

signal interaction_requested(lines, source)

var player
var civilian_style: String = "elder"
var dialogue_lines: Array = []
var dialogue_open: bool = false
var show_prompt: bool = false
var e_was_down: bool = false
var t: float = 0.0
var frame_id: int = 0

func configure(target, style_id: String, lines: Array) -> void:
	player = target
	civilian_style = style_id
	dialogue_lines = lines

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 24

func _process(delta: float) -> void:
	t += delta
	frame_id += 1
	show_prompt = false
	if dialogue_open or not is_instance_valid(player) or not player.active:
		queue_redraw()
		return
	var dist: float = global_position.distance_to(player.global_position)
	if dist <= 86.0:
		show_prompt = true
		var down: bool = Input.is_key_pressed(KEY_E)
		if down and not e_was_down:
			interaction_requested.emit(dialogue_lines,self)
		e_was_down = down
	else:
		e_was_down = false
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var bob: float = sin(t * 2.2 + global_position.x * 0.01) * 0.55
	_draw_oval(Vector2(0,20),Vector2(16,4.5),Color(0.08,0.08,0.08,0.06))
	match civilian_style:
		"parent":
			_draw_parent(bob,ink,paper)
		"skeptic":
			_draw_skeptic(bob,ink,paper)
		"apprentice":
			_draw_apprentice(bob,ink,paper)
		_:
			_draw_elder(bob,ink,paper)
	if show_prompt:
		_draw_prompt(ink)

func _draw_elder(bob: float, ink: Color, paper: Color) -> void:
	_sketch_line(Vector2(-5,8+bob),Vector2(-7,20),ink,2.2,2,1)
	_sketch_line(Vector2(4,8+bob),Vector2(5,20),ink,2.2,2,2)
	var coat: PackedVector2Array = PackedVector2Array([Vector2(-12,9+bob),Vector2(11,9+bob),Vector2(8,-7+bob),Vector2(-8,-7+bob)])
	draw_colored_polygon(coat,ink)
	draw_circle(Vector2(0,-15+bob),9.0,ink)
	var beard: PackedVector2Array = PackedVector2Array([Vector2(-6,-10+bob),Vector2(6,-10+bob),Vector2(3,1+bob),Vector2(-2,5+bob),Vector2(-6,0+bob)])
	draw_colored_polygon(beard,Color(0.20,0.20,0.20,0.36))
	draw_circle(Vector2(-3,-15+bob),1.6,paper)
	draw_circle(Vector2(3,-15+bob),1.6,paper)
	_sketch_line(Vector2(11,-2+bob),Vector2(17,21),Color(0.08,0.08,0.08,0.40),1.6,2,20)

func _draw_parent(bob: float, ink: Color, paper: Color) -> void:
	var dress: PackedVector2Array = PackedVector2Array([Vector2(-13,18),Vector2(14,18),Vector2(9,-6+bob),Vector2(-8,-7+bob)])
	draw_colored_polygon(dress,ink)
	draw_circle(Vector2(0,-15+bob),9.5,ink)
	var bun: Vector2 = Vector2(8,-23+bob)
	draw_circle(bun,4.5,ink)
	draw_circle(Vector2(-3,-15+bob),1.7,paper)
	draw_circle(Vector2(3,-15+bob),1.7,paper)
	# child hand/shape beside parent
	draw_circle(Vector2(18,2+bob),5.0,Color(0.10,0.10,0.10,0.72))
	_sketch_line(Vector2(14,6+bob),Vector2(18,15),Color(0.10,0.10,0.10,0.72),2.0,2,30)

func _draw_skeptic(bob: float, ink: Color, paper: Color) -> void:
	var jacket: PackedVector2Array = PackedVector2Array([Vector2(-14,10+bob),Vector2(14,10+bob),Vector2(10,-8+bob),Vector2(-10,-8+bob)])
	draw_colored_polygon(jacket,ink)
	_sketch_line(Vector2(-5,9+bob),Vector2(-7,21),ink,2.4,2,1)
	_sketch_line(Vector2(5,9+bob),Vector2(7,21),ink,2.4,2,2)
	draw_circle(Vector2(0,-16+bob),9.5,ink)
	# flat cap
	draw_rect(Rect2(Vector2(-11,-27+bob),Vector2(21,5)),ink,true)
	draw_line(Vector2(7,-24+bob),Vector2(15,-22+bob),ink,2.0)
	draw_circle(Vector2(-3,-16+bob),1.7,paper)
	draw_circle(Vector2(3,-16+bob),1.7,paper)
	# arms crossed
	_sketch_line(Vector2(-11,-1+bob),Vector2(9,5+bob),paper,1.0,2,40)
	_sketch_line(Vector2(11,-1+bob),Vector2(-8,5+bob),paper,1.0,2,42)

func _draw_apprentice(bob: float, ink: Color, paper: Color) -> void:
	var tunic: PackedVector2Array = PackedVector2Array([Vector2(-12,10+bob),Vector2(12,10+bob),Vector2(9,-7+bob),Vector2(-9,-7+bob)])
	draw_colored_polygon(tunic,ink)
	_sketch_line(Vector2(-5,9+bob),Vector2(-7,21),ink,2.2,2,1)
	_sketch_line(Vector2(5,9+bob),Vector2(7,21),ink,2.2,2,2)
	draw_circle(Vector2(0,-15+bob),9.0,ink)
	# short messy hair
	var hair: PackedVector2Array = PackedVector2Array([Vector2(-9,-19+bob),Vector2(-5,-27+bob),Vector2(0,-22+bob),Vector2(4,-29+bob),Vector2(9,-20+bob)])
	draw_colored_polygon(hair,ink)
	draw_circle(Vector2(-3,-15+bob),1.7,paper)
	draw_circle(Vector2(3,-15+bob),1.7,paper)
	# fake practice sword at belt
	_sketch_line(Vector2(9,4+bob),Vector2(20,15),Color(0.08,0.08,0.08,0.32),1.6,2,50)

func _draw_prompt(ink: Color) -> void:
	var y: float = -48.0
	var pulse: float = 1.0 + sin(t * 3.5) * 0.04
	_draw_oval(Vector2(0,y),Vector2(31.0*pulse,12.0*pulse),Color(1,1,1,0.93))
	draw_arc(Vector2(0,y),31.0,0.0,TAU,24,Color(0.08,0.08,0.08,0.27),1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(-17,y+4),"E  falar",HORIZONTAL_ALIGNMENT_LEFT,-1,9,ink)

func _sketch_line(a: Vector2,b: Vector2,color: Color,width: float,passes: int,seed: int) -> void:
	for i in range(passes):
		var off: Vector2 = Vector2(sin(float(frame_id+seed+i)*0.37)*0.35,cos(float(frame_id+seed+i)*0.31)*0.35)
		draw_line(a+off,b-off,color,width)

func _draw_oval(center: Vector2,radii: Vector2,color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center+Vector2(cos(a)*radii.x,sin(a)*radii.y))
	draw_colored_polygon(points,color)
