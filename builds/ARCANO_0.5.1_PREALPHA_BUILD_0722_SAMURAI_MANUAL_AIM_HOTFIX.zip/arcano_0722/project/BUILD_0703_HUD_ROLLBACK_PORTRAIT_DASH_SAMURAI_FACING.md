# BUILD 0703 — HUD rollback + portrait + dash readability + samurai facing

## Main changes
- Reverted to the older HUD base.
- Added animated portrait/face to the old left HUD for Orbit, Storm and Samurai.
- Portrait reacts to aim direction, damage and Arcane Surge state.
- Improved dash readability on the old HUD with a subtle panel, clearer charge circles and recharge progress on the next recovering charge.
- Samurai now prioritizes facing the nearest enemy in active gameplay so his in-game look direction matches combat focus better.

## Files changed
- hud_display.gd
- player.gd
- endless_main.gd
