extends Button

@export var label_text: String = "BOTAO"
@export var subtitle_text: String = ""
@export var font_size: int = 22
@export var primary: bool = true

var frame_id: int = 0
var hover_t: float = 0.0
var press_t: float = 0.0
var hovered_local: bool = false
var pressed_local: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	focus_mode = Control.FOCUS_NONE
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	mouse_entered.connect(_on_enter)
	mouse_exited.connect(_on_exit)
	button_down.connect(_on_down)
	button_up.connect(_on_up)
	mouse_filter = Control.MOUSE_FILTER_STOP
	clip_contents = true
	var clear: StyleBoxFlat = StyleBoxFlat.new()
	clear.bg_color = Color(0, 0, 0, 0)
	add_theme_stylebox_override("normal", clear)
	add_theme_stylebox_override("hover", clear)
	add_theme_stylebox_override("pressed", clear)
	add_theme_stylebox_override("focus", clear)

func _process(delta: float) -> void:
	frame_id += 1
	hover_t = move_toward(hover_t, 1.0 if hovered_local else 0.0, delta * 9.0)
	press_t = move_toward(press_t, 1.0 if pressed_local else 0.0, delta * 18.0)
	queue_redraw()

func _draw() -> void:
	var ink: Color = Color("#f1eee7")
	var sub_ink: Color = Color(0.90, 0.90, 0.88, 0.64)
	var panel_fill: Color = Color(0.08, 0.09, 0.10, 0.92 if primary else 0.82)
	var accent_fill: Color = Color(0.16, 0.17, 0.18, 0.88)
	var float_y: float = lerpf(0.0, -6.0, hover_t) + press_t * 2.0
	var outer: Rect2 = Rect2(Vector2(0, float_y), size)
	var body: Rect2 = outer.grow(-6.0)
	body = Rect2(body.position + Vector2(0, 1.5), body.size - Vector2(0, 4.0))
	var shadow: Rect2 = Rect2(body.position + Vector2(0, 8), body.size - Vector2(0, 8))
	_draw_rough_panel(shadow, Color(0.02, 0.02, 0.02, 0.14), Color(0, 0, 0, 0), 0.0)
	_draw_rough_panel(body, panel_fill, Color(0.95, 0.94, 0.90, 0.22 + hover_t * 0.16), hover_t)
	var glow: float = hover_t * 0.16
	if glow > 0.001:
		_draw_rough_panel(body.grow(2.0), Color(0, 0, 0, 0), Color(0.98, 0.97, 0.93, glow), 0.0)
	var tab_rect: Rect2 = Rect2(body.position + Vector2(10, 8), Vector2(40, body.size.y - 16))
	_draw_rough_panel(tab_rect, accent_fill, Color(0.95, 0.94, 0.90, 0.18), 0.0)
	var rune_center: Vector2 = Vector2(tab_rect.position.x + tab_rect.size.x * 0.5, tab_rect.position.y + tab_rect.size.y * 0.5)
	_draw_diamond(rune_center, 7.0 + hover_t * 0.8, ink)
	for i in range(4):
		var ry: float = rune_center.y - 16.0 + float(i) * 11.0 + sin(float(frame_id) * 0.08 + float(i)) * 0.45
		draw_line(Vector2(rune_center.x + 10.0, ry), Vector2(body.end.x - 20.0, ry), Color(0.92, 0.92, 0.90, 0.032 + hover_t * 0.016), 1.0)
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var content_left: float = body.position.x + 60.0
	var content_right: float = body.end.x - 20.0
	var content_width: float = maxf(30.0, content_right - content_left)
	var title_font: int = _fit_font_size(font, label_text, font_size, content_width, 14)
	var show_subtitle: bool = subtitle_text != "" and body.size.y >= 66.0
	var safe_subtitle: String = subtitle_text if show_subtitle else ""
	var subtitle_font: int = _fit_font_size(font, safe_subtitle, maxi(10, title_font - 8), content_width, 9)
	if not show_subtitle:
		var title_h: float = float(title_font)
		var title_y: float = body.position.y + body.size.y * 0.5 + title_h * 0.34
		_draw_sketch_text(font, Vector2(content_left, title_y), label_text, content_width, title_font, ink, 0.15 + hover_t * 0.10)
	else:
		var title_y2: float = body.position.y + 18.0 + float(title_font) * 0.68
		_draw_sketch_text(font, Vector2(content_left, title_y2), label_text, content_width, title_font, ink, 0.15 + hover_t * 0.10)
		var subtitle_y: float = minf(body.end.y - 10.0, title_y2 + float(subtitle_font) + 8.0)
		draw_string(font, Vector2(content_left, subtitle_y), safe_subtitle, HORIZONTAL_ALIGNMENT_LEFT, content_width, subtitle_font, sub_ink)
	var accent_y: float = body.end.y - 7.0
	var accent_len: float = lerpf(24.0, minf(content_width, 68.0 + content_width * 0.22), hover_t)
	draw_line(Vector2(content_left, accent_y), Vector2(content_left + accent_len, accent_y + sin(float(frame_id) * 0.08) * 0.3), Color(0.95, 0.94, 0.90, 0.18 + hover_t * 0.12), 1.2)
	var arrow_x: float = body.end.x - 16.0 - hover_t * 3.0
	var mid_y: float = body.position.y + body.size.y * 0.5
	draw_line(Vector2(arrow_x - 9.0, mid_y - 5.0), Vector2(arrow_x, mid_y), Color(0.96, 0.95, 0.90, 0.26 + hover_t * 0.20), 1.5)
	draw_line(Vector2(arrow_x - 9.0, mid_y + 5.0), Vector2(arrow_x, mid_y), Color(0.96, 0.95, 0.90, 0.26 + hover_t * 0.20), 1.5)

func _draw_rough_panel(rect: Rect2, fill: Color, border: Color, energy: float) -> void:
	if fill.a > 0.001:
		draw_rect(rect, fill, true)
	if border.a > 0.001:
		for i in range(3):
			var inset: float = float(i) * 1.4
			var r: Rect2 = rect.grow(-inset)
			draw_rect(r, Color(border.r, border.g, border.b, border.a * (1.0 - float(i) * 0.26)), false, 1.0)
	var cuts: int = 5
	for i in range(cuts):
		var px: float = rect.position.x + 12.0 + float(i) * ((rect.size.x - 24.0) / float(maxi(1, cuts - 1)))
		var py: float = rect.position.y + 5.0 + sin(float(frame_id) * 0.05 + float(i) * 0.8) * 0.6
		draw_line(Vector2(px - 4.0, py), Vector2(px + 4.0, py), Color(0.95, 0.94, 0.90, 0.034 + energy * 0.028), 1.0)

func _draw_diamond(center: Vector2, radius_value: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(0, -radius_value),
		center + Vector2(radius_value * 0.76, 0),
		center + Vector2(0, radius_value),
		center + Vector2(-radius_value * 0.76, 0)
	])
	draw_colored_polygon(poly, color)

func _draw_sketch_text(font, pos: Vector2, value: String, width: float, text_size: int, color: Color, ghost_alpha: float) -> void:
	for i in range(3):
		var off: Vector2 = Vector2(sin(float(frame_id) * 0.10 + float(i) * 1.7) * 0.7, cos(float(frame_id) * 0.08 + float(i) * 1.3) * 0.5)
		draw_string(font, pos + off, value, HORIZONTAL_ALIGNMENT_LEFT, width, text_size, Color(color.r, color.g, color.b, ghost_alpha))
	draw_string(font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, width, text_size, color)

func _fit_font_size(font, value: String, requested: int, max_width: float, minimum: int) -> int:
	if value == "":
		return requested
	var result: int = requested
	while result > minimum and font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, result).x > max_width:
		result -= 1
	return result

func _on_enter() -> void:
	hovered_local = true

func _on_exit() -> void:
	hovered_local = false
	pressed_local = false

func _on_down() -> void:
	pressed_local = true

func _on_up() -> void:
	pressed_local = false
