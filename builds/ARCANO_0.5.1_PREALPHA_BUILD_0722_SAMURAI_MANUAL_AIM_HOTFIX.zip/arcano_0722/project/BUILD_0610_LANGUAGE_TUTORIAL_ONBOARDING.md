# ARCANO 0.5.0-prealpha — Build 0610

## First-launch language gate
- A clean install now opens a dedicated language selection screen before the main menu or tutorial prompt.
- Available choices: English, PT-BR, Japanese and Spanish.
- The selection is persisted to `user://settings.cfg`.
- Choosing English now persists correctly too; previously selecting the already-active default could return before saving.
- Returning players with an existing valid language selection skip the gate.
- The regular globe picker remains available in the main menu.

## Tutorial input isolation
- Dialogue click / Space / Enter / E no longer leaks into combat attacks.
- While Sensei dialogue is visible, player attacks are explicitly locked.
- The exact click/Space that closes the last dialogue line is suppressed until release before gameplay resumes.
- Tutorial objectives are now action-driven instead of confirmation-driven.

## Tutorial UI / Rune card fix
- Full Sensei dialogue appears only during explanation beats.
- During an interactive objective, the dialogue collapses into a compact objective card.
- The objective card uses `MOUSE_FILTER_IGNORE`, so Rune cards and gameplay UI underneath remain clickable.
- This fixes the previous tutorial layer covering the level-up Rune selection.
- Level-up is gated during tutorial examples and force-opened only during the Rune lesson, preventing random XP from opening cards early.

## Real class demonstrations
- Orbital is demonstrated first with a stationary ranged target so automatic visible-target combat can be observed directly.
- The tutorial then temporarily switches the player to Samurai.
- The Samurai target is outside blade range and stationary, forcing the player to approach before the melee slash can connect.
- Dash is demonstrated while playing Samurai, then the tutorial returns to Orbital for the remaining systems.
- Other class mechanics are not demonstrated, keeping the lesson spoiler-light.

## Dash recharge HUD
- Existing dash diamonds now show a live circular recharge ring on the next missing charge.
- The HUD also shows the remaining recharge time in seconds.
- The display naturally supports builds with multiple dash charges.
- The Sensei explicitly explains the new visual immediately after the player performs a real dash.

## Pickups and chest teaching
- The common-pickup lesson now creates a real scenario:
  - player health is lowered so Heal has a visible result;
  - loose XP is placed around the player so Magnet visibly pulls it;
  - durable stationary training enemies are created so Annihilation visibly clears them.
- Silver and gold tutorial chests are real world chests and must be opened by touching them.
- Tutorial chest outcomes are deterministic to avoid accidental modal level-ups during the lesson.
- Follow-up Sensei dialogue explains every current Silver reward and every current Gold reward individually.

## Dialogue pass
- Tutorial dialogue was rewritten to be more characterful and immersive while still explaining mechanics precisely.
- New dialogue and objective copy is localized in English, PT-BR, Japanese and Spanish.
- Common systems, Gold XP, Runes, Runic Vases, chests, Flow / Arcane Surge, elites/boss timing, TAB and menu systems remain covered.

## Validation
- Static bracket/structure checks passed for all modified GDScript files.
- Localization reference scan found 0 missing referenced keys.
- Localization coverage scan found 0 entries missing any of EN / PT-BR / JA / ES.
- No Godot executable is installed in this environment, so runtime execution was not claimed.
