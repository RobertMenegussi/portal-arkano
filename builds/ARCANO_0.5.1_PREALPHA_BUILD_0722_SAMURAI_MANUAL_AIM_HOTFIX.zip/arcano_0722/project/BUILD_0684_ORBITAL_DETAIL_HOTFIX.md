# BUILD 0684 — ORBITAL DETAIL HOTFIX

- Restored `_draw_orbit_dash_fx()` accidentally removed during Build 0683 skin refactor.
- Preserves all Build 0683 Orbital detail/richness changes.
- Updates the Endless build label to 0684.
