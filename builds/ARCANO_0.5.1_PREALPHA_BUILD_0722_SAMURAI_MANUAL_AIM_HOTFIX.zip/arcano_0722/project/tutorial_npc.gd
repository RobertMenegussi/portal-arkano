extends Node2D

signal interaction_requested(role, lines)

var player
var role: String = "guide"
var display_name: String = "NPC"
var dialogue_lines: Array = []
var talk_enabled: bool = true
var dialogue_open: bool = false
var show_prompt: bool = false
var e_was_down: bool = false
var frame_id: int = 0
var timer: float = 0.0
var pulse_t: float = 0.0

func configure(target, role_id: String, name_text: String, line_list: Array) -> void:
	player = target
	role = role_id
	display_name = name_text
	dialogue_lines = line_list

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 26

func _process(delta: float) -> void:
	pulse_t += delta
	timer -= delta
	if timer <= 0.0:
		timer = 0.065
		frame_id += 1
		queue_redraw()

	show_prompt = false
	if not talk_enabled or dialogue_open:
		return
	if not is_instance_valid(player) or not player.active:
		return

	var dist: float = global_position.distance_to(player.global_position)
	if dist <= 94.0:
		show_prompt = true
		var down: bool = Input.is_key_pressed(KEY_E)
		if down and not e_was_down:
			interaction_requested.emit(role, dialogue_lines)
		e_was_down = down
	else:
		e_was_down = false

func _draw() -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	var bob: float = sin(float(frame_id) * 0.22) * 0.75
	_draw_oval(Vector2(0, 23), Vector2(20, 5.6), Color(0.08,0.08,0.08,0.07))

	match role:
		"merchant":
			_draw_merchant(Vector2(0,bob), ink, paper)
		"bridge":
			_draw_guard(Vector2(0,bob), ink, paper)
		_:
			_draw_mentor(Vector2(0,bob), ink, paper)

	if show_prompt:
		_draw_prompt(ink)

func _draw_mentor(c: Vector2, ink: Color, paper: Color) -> void:
	# Tall old mentor: long mantle, hooded crown and a clear beard silhouette.
	_sketch_line(c + Vector2(-6, 11), c + Vector2(-7, 23), ink, 2.5, 3, 1)
	_sketch_line(c + Vector2(6, 11), c + Vector2(7, 23), ink, 2.5, 3, 2)
	var robe: PackedVector2Array = PackedVector2Array([
		c + Vector2(-17, 13), c + Vector2(17, 13), c + Vector2(13,-6), c + Vector2(7,-13), c + Vector2(-9,-12), c + Vector2(-14,-4)
	])
	draw_colored_polygon(robe, ink)
	draw_circle(c + Vector2(0,-15), 10.5, ink)
	var hood: PackedVector2Array = PackedVector2Array([
		c + Vector2(-15,-20), c + Vector2(15,-20), c + Vector2(10,-35), c + Vector2(-1,-43), c + Vector2(-12,-33)
	])
	draw_colored_polygon(hood, ink)
	# beard under the face
	var beard: PackedVector2Array = PackedVector2Array([
		c + Vector2(-8,-9), c + Vector2(8,-9), c + Vector2(5,6), c + Vector2(0,13), c + Vector2(-6,5)
	])
	draw_colored_polygon(beard, Color(0.20,0.20,0.20,0.36))
	draw_circle(c + Vector2(-4,-15), 1.9, paper)
	draw_circle(c + Vector2(4,-15), 1.9, paper)
	# walking cane / wand-like pointer, distinct from player combat magic
	_sketch_line(c + Vector2(12, 1), c + Vector2(22, 24), Color(0.12,0.12,0.12,0.38), 2.0, 2, 40)
	for i in range(3):
		draw_circle(c + Vector2(-23 + float(i) * 4.0, -29 - float(i) * 4.0), 1.2, Color(0.08,0.08,0.08,0.10))

func _draw_merchant(c: Vector2, ink: Color, paper: Color) -> void:
	# Shorter, wider silhouette with an oversized backpack and dangling wares.
	var pack: PackedVector2Array = PackedVector2Array([
		c + Vector2(-26,-7), c + Vector2(-9,-18), c + Vector2(-5,16), c + Vector2(-25,18), c + Vector2(-31,5)
	])
	draw_colored_polygon(pack, Color(0.13,0.13,0.13,0.94))
	var coat: PackedVector2Array = PackedVector2Array([
		c + Vector2(-14,12), c + Vector2(18,12), c + Vector2(14,-7), c + Vector2(5,-14), c + Vector2(-10,-12), c + Vector2(-16,-3)
	])
	draw_colored_polygon(coat, ink)
	_sketch_line(c + Vector2(-6, 10), c + Vector2(-8, 22), ink, 2.7, 3, 5)
	_sketch_line(c + Vector2(8, 10), c + Vector2(10, 22), ink, 2.7, 3, 7)
	draw_circle(c + Vector2(1,-15), 10.0, ink)
	# low hood and scarf
	var hood: PackedVector2Array = PackedVector2Array([
		c + Vector2(-13,-20), c + Vector2(15,-20), c + Vector2(11,-30), c + Vector2(0,-35), c + Vector2(-12,-29)
	])
	draw_colored_polygon(hood, ink)
	_sketch_line(c + Vector2(-10,-6), c + Vector2(13,-2), paper, 1.0, 2, 50)
	draw_circle(c + Vector2(-3,-15), 1.8, paper)
	draw_circle(c + Vector2(5,-15), 1.8, paper)
	# trinkets / fragment charms
	for i in range(3):
		var charm: Vector2 = c + Vector2(20 + float(i) * 5.0, 2 + float(i % 2) * 7.0)
		_draw_diamond(charm, 3.0 + float(i) * 0.4, paper)
		draw_line(c + Vector2(13, -1), charm, Color(0.08,0.08,0.08,0.18), 1.0)

func _draw_guard(c: Vector2, ink: Color, paper: Color) -> void:
	# No hat: messy hair, bare head, headband, short jacket and spear.
	_sketch_line(c + Vector2(-6, 10), c + Vector2(-8, 23), ink, 2.6, 3, 1)
	_sketch_line(c + Vector2(6, 10), c + Vector2(8, 23), ink, 2.6, 3, 2)
	var jacket: PackedVector2Array = PackedVector2Array([
		c + Vector2(-15,11), c + Vector2(15,11), c + Vector2(12,-5), c + Vector2(7,-10), c + Vector2(-8,-10), c + Vector2(-14,-4)
	])
	draw_colored_polygon(jacket, ink)
	draw_circle(c + Vector2(0,-16), 10.5, ink)
	# messy hair spikes
	var hair: PackedVector2Array = PackedVector2Array([
		c + Vector2(-11,-20), c + Vector2(-8,-31), c + Vector2(-2,-25), c + Vector2(3,-34), c + Vector2(7,-25), c + Vector2(13,-29), c + Vector2(11,-19)
	])
	draw_colored_polygon(hair, ink)
	_sketch_line(c + Vector2(-9,-18), c + Vector2(9,-19), paper, 1.1, 2, 60)
	draw_circle(c + Vector2(-4,-15), 1.9, paper)
	draw_circle(c + Vector2(4,-15), 1.9, paper)
	# spear is taller and immediately readable.
	_sketch_line(c + Vector2(18, 21), c + Vector2(23, -39), Color(0.12,0.12,0.12,0.48), 2.2, 3, 70)
	var tip: PackedVector2Array = PackedVector2Array([
		c + Vector2(23,-46), c + Vector2(19,-37), c + Vector2(27,-37)
	])
	draw_colored_polygon(tip, ink)
	# nervous little shoulder motion
	var shoulder_y: float = sin(pulse_t * 9.0) * 0.7
	draw_line(c + Vector2(-13,-1 + shoulder_y), c + Vector2(-20,7 + shoulder_y), Color(0.12,0.12,0.12,0.25), 2.0)

func _draw_prompt(ink: Color) -> void:
	var y: float = -58.0
	var pulse: float = 1.0 + absf(sin(pulse_t * 3.2)) * 0.05
	_draw_oval(Vector2(0,y), Vector2(32.0*pulse,13.0*pulse), Color(1,1,1,0.94))
	for i in range(2):
		draw_arc(Vector2(_j(60+i,0.45), y + _j(70+i,0.45)), 32.0, 0.0, TAU, 26, Color(0.08,0.08,0.08,0.26), 1.0)
	var key_rect: Rect2 = Rect2(Vector2(-17,y-8),Vector2(18,16))
	draw_rect(key_rect,Color(0.08,0.08,0.08,0.08),true)
	draw_rect(key_rect,Color(0.08,0.08,0.08,0.30),false,1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font, Vector2(-12, y + 5), "E", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, ink)
		draw_string(font, Vector2(5, y + 4), "falar", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color(0.08,0.08,0.08,0.62))

func _j(index: int, amount: float) -> float:
	return sin(float(frame_id) * 2.7 + float(index) * 4.1) * amount

func _sketch_line(a: Vector2, b: Vector2, color: Color, width: float, passes: int, seed: int) -> void:
	for i in range(passes):
		var off_a: Vector2 = Vector2(_j(seed + i * 2, 0.75), _j(seed + i * 2 + 1, 0.75))
		var off_b: Vector2 = Vector2(_j(seed + 20 + i * 2, 0.75), _j(seed + 21 + i * 2, 0.75))
		draw_line(a + off_a, b + off_b, color, width)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(0,-radius), center + Vector2(radius*0.75,0), center + Vector2(0,radius), center + Vector2(-radius*0.75,0)
	])
	draw_colored_polygon(poly, color)
