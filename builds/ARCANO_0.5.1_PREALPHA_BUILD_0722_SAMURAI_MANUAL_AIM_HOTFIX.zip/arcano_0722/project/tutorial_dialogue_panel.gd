extends Control

signal advanced

var speaker: String = ""
var full_text: String = ""
var visible_chars: float = 0.0
var emotion: String = "calm"
var t: float = 0.0
var task_text: String = ""
var typing_done: bool = false
var action_mode: bool = false
var line_age: float = 0.0
var card_age: float = 0.0
var last_tick_char: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

func set_line(speaker_value: String, text_value: String, emotion_value: String = "calm") -> void:
	action_mode = false
	mouse_filter = Control.MOUSE_FILTER_STOP
	speaker = speaker_value
	full_text = text_value
	emotion = emotion_value
	visible_chars = 0.0
	typing_done = false
	line_age = 0.0
	last_tick_char = 0
	get_tree().call_group("audio_bus", "play_dialogue_open")
	queue_redraw()

func set_task(value: String) -> void:
	task_text = value
	queue_redraw()

func set_action_mode(value: bool) -> void:
	action_mode = value
	if value:
		card_age = 0.0
	mouse_filter = Control.MOUSE_FILTER_IGNORE if value else Control.MOUSE_FILTER_STOP
	queue_redraw()

func _process(delta: float) -> void:
	t += delta
	line_age += delta
	if action_mode:
		card_age += delta
	if not action_mode and not typing_done:
		visible_chars += delta * 62.0
		var current_char: int = mini(int(visible_chars), full_text.length())
		if current_char >= last_tick_char + 3 and current_char > 0:
			last_tick_char = current_char
			var ch: String = full_text.substr(current_char - 1, 1)
			if ch.strip_edges() != "" and not [".", ",", "!", "?", ":", ";", "…", "—", "-", "
"].has(ch):
				get_tree().call_group("audio_bus", "play_dialogue_tick", speaker, emotion)
		if int(visible_chars) >= full_text.length():
			visible_chars = float(full_text.length())
			typing_done = true
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if action_mode:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_advance_or_complete()
		accept_event()
	elif event is InputEventKey and event.pressed and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER or event.keycode == KEY_E):
		_advance_or_complete()
		accept_event()

func _unhandled_key_input(event: InputEvent) -> void:
	if action_mode:
		return
	if event is InputEventKey and event.pressed and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER or event.keycode == KEY_E):
		_advance_or_complete()
		get_viewport().set_input_as_handled()

func _advance_or_complete() -> void:
	if not typing_done:
		visible_chars = float(full_text.length())
		typing_done = true
		queue_redraw()
		return
	advanced.emit()

func _draw() -> void:
	var font = ThemeDB.fallback_font
	if font == null:
		return
	if action_mode:
		_draw_action_card(font)
		return
	var entry: float = clampf(line_age / 0.22, 0.0, 1.0)
	var eased_entry: float = 1.0 - pow(1.0 - entry, 3.0)
	var shake := Vector2(0.0, (1.0 - eased_entry) * 5.0)
	var reaction_fade: float = maxf(0.0, 1.0 - line_age / 0.42)
	if emotion == "surprised":
		shake += Vector2(sin(t * 32.0), cos(t * 27.0)) * 0.28 * reaction_fade
	elif emotion == "serious":
		shake += Vector2(sin(t * 19.0), 0) * 0.10 * reaction_fade
	elif emotion == "happy":
		shake += Vector2(0, sin(t * 4.0) * 0.06) * reaction_fade
	var rect := Rect2(Vector2(40, 338) + shake, Vector2(880, 170))
	var panel_alpha: float = 0.84 + 0.13 * eased_entry
	draw_rect(rect, Color(0.025, 0.032, 0.030, panel_alpha), true)
	for i in range(2):
		draw_rect(rect.grow(-float(i) * 2.0), Color(0.93, 0.91, 0.85, 0.09 - float(i) * 0.03 + 0.05 * eased_entry), false, 1.0)
	var portrait := Rect2(rect.position + Vector2(16, 14), Vector2(96, 114))
	draw_rect(portrait, Color(1, 1, 1, 0.04), true)
	draw_rect(portrait, Color(1, 1, 1, 0.10), false, 1.0)
	_draw_face(portrait.get_center(), emotion)
	draw_string(font, rect.position + Vector2(126, 28), speaker, HORIZONTAL_ALIGNMENT_LEFT, 560, 13, Color(0.94, 0.93, 0.89, 0.92))
	var mood_anchor := rect.position + Vector2(114, 22)
	match emotion:
		"happy":
			draw_circle(mood_anchor, 2.4 + sin(t * 4.0) * 0.35, Color(0.86, 0.88, 0.80, 0.52))
			draw_line(mood_anchor + Vector2(-6, -4), mood_anchor + Vector2(-3, -2), Color(0.86, 0.88, 0.80, 0.28), 1.0)
		"surprised":
			draw_arc(mood_anchor, 4.0 + sin(t * 7.0) * 0.8, 0, TAU, 12, Color(0.86, 0.88, 0.80, 0.46), 1.0)
		"serious":
			draw_line(mood_anchor + Vector2(-5, 1), mood_anchor + Vector2(5, 1), Color(0.86, 0.88, 0.80, 0.45), 1.5)
		_:
			draw_circle(mood_anchor, 1.8, Color(0.86, 0.88, 0.80, 0.36))
	var shown: String = full_text.left(int(visible_chars))
	_draw_wrapped(font, shown, rect.position + Vector2(126, 50), 706, 11, Color(0.91, 0.90, 0.86, 0.80))
	if typing_done:
		draw_string(font, rect.position + Vector2(706, 152), Loc.t("tutorial.continue"), HORIZONTAL_ALIGNMENT_RIGHT, 240, 8, Color(0.92, 0.91, 0.86, 0.40))
	draw_string(font, Vector2(788, 28), Loc.t("tutorial.skip"), HORIZONTAL_ALIGNMENT_RIGHT, 150, 8, Color(1, 1, 1, 0.25))

func _draw_action_card(font) -> void:
	if task_text == "":
		return
	var pulse: float = 0.5 + sin(t * 4.0) * 0.5
	var entry: float = clampf(card_age / 0.24, 0.0, 1.0)
	var eased_entry: float = 1.0 - pow(1.0 - entry, 3.0)
	var rect := Rect2(Vector2(614 + (1.0 - eased_entry) * 18.0, 74), Vector2(314, 68))
	draw_rect(rect, Color(0.025, 0.032, 0.030, 0.92), true)
	draw_rect(rect, Color(0.93, 0.91, 0.85, 0.12 + 0.06 * pulse), false, 1.0)
	draw_circle(rect.position + Vector2(18, 18), 3.4, Color(0.78, 0.85, 0.82, 0.74))
	draw_string(font, rect.position + Vector2(30, 22), Loc.t("tutorial.sensei"), HORIZONTAL_ALIGNMENT_LEFT, 250, 8, Color(0.94, 0.93, 0.89, 0.42))
	_draw_wrapped(font, task_text, rect.position + Vector2(14, 42), 286, 9, Color(0.90, 0.91, 0.86, 0.86))

func _draw_face(c: Vector2, mood: String) -> void:
	var ink := Color(0.92, 0.90, 0.84, 0.76)
	draw_circle(c, 28.0, Color(0, 0, 0, 0.20))
	draw_arc(c, 25.0, PI * 1.05, PI * 1.95, 28, ink, 2.0)
	draw_line(c + Vector2(-31, -8), c + Vector2(31, -8), ink, 2.4)
	match mood:
		"happy":
			draw_arc(c + Vector2(-8, 2), 4.0, 0, PI, 12, ink, 1.6)
			draw_arc(c + Vector2(8, 2), 4.0, 0, PI, 12, ink, 1.6)
		"surprised":
			draw_circle(c + Vector2(-8, 2), 3.0, ink)
			draw_circle(c + Vector2(8, 2), 3.0, ink)
			draw_circle(c + Vector2(0, 13), 3.0, ink)
		"serious":
			draw_line(c + Vector2(-13, -2), c + Vector2(-4, 1), ink, 1.8)
			draw_line(c + Vector2(13, -2), c + Vector2(4, 1), ink, 1.8)
			draw_circle(c + Vector2(-8, 4), 2.0, ink)
			draw_circle(c + Vector2(8, 4), 2.0, ink)
		_:
			draw_circle(c + Vector2(-8, 3), 2.2, ink)
			draw_circle(c + Vector2(8, 3), 2.2, ink)

func _draw_wrapped(font, text: String, pos: Vector2, width: float, font_size: int, color: Color) -> void:
	var line: String = ""
	var y: float = pos.y
	if not text.contains(" "):
		for i in range(text.length()):
			var ch: String = text.substr(i, 1)
			var candidate: String = line + ch
			if font.get_string_size(candidate, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > width and line != "":
				draw_string(font, Vector2(pos.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, width, font_size, color)
				y += 17.0
				line = ch
			else:
				line = candidate
	else:
		var words: PackedStringArray = text.split(" ")
		for word_value in words:
			var word: String = str(word_value)
			var candidate: String = word if line == "" else line + " " + word
			if font.get_string_size(candidate, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > width and line != "":
				draw_string(font, Vector2(pos.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, width, font_size, color)
				y += 17.0
				line = word
			else:
				line = candidate
	if line != "":
		draw_string(font, Vector2(pos.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, width, font_size, color)
