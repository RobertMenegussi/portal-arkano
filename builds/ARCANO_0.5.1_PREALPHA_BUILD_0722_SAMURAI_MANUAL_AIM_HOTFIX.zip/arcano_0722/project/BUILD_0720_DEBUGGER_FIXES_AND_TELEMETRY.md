# BUILD 0720 — Debugger fixes + persistent telemetry

## Errors fixed from the supplied Godot debugger log
1. `endless_aim_cursor.gd`: invalid `z_index = 5000`
   - Godot accepts CanvasItem z-index only from -4096 to 4096.
   - Changed to `4000`.

2. `hud_display.gd` -> `Loc.f("hud.hp", [...])`
   - `hud.hp` did not exist in the localization dictionary.
   - This caused a string formatting error every HUD redraw.
   - Added `hud.hp` in EN / PT-BR / JA / ES.
   - Hardened `Loc.f()` so a future missing formatted key cannot create per-frame error spam.

## ARCANO_DEBUG.txt
Added `ArcanoDebug` as an autoload.

Writes to:
`user://ARCANO_DEBUG.txt`

Every ~2 seconds during a run it records:
- FPS
- live enemy count
- loose XP count
- enemy/player projectile counts
- horde performance tier
- run time
- level / kills / class
- target mode
- HP / Flux
- player position

It also records RUN_START / RUN_END and a sustained-low-FPS warning after two consecutive samples below 45 FPS.

The file is appended between sessions so it can be sent back for performance investigation.
