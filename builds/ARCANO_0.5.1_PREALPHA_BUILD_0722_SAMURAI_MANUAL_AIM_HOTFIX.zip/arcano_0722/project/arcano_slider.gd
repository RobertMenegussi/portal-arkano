extends Control

signal value_changed(value: float)

var value: float = 0.5
var hover_t: float = 0.0
var dragging: bool = false
var frame_id: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	custom_minimum_size = Vector2(220, 28)

func set_value_silent(next_value: float) -> void:
	value = clampf(next_value, 0.0, 1.0)
	queue_redraw()

func _process(delta: float) -> void:
	frame_id += 1
	var hovered: bool = Rect2(Vector2.ZERO, size).has_point(get_local_mouse_position())
	hover_t = move_toward(hover_t, 1.0 if hovered or dragging else 0.0, delta * 9.0)
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		dragging = event.pressed
		if event.pressed:
			_set_from_mouse(event.position.x)
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		_set_from_mouse(event.position.x)
		accept_event()

func _set_from_mouse(mouse_x: float) -> void:
	var left: float = 10.0
	var right: float = maxf(left + 1.0, size.x - 10.0)
	var next_value: float = clampf((mouse_x - left) / (right - left), 0.0, 1.0)
	if absf(next_value - value) > 0.001:
		value = next_value
		value_changed.emit(value)
		queue_redraw()

func _draw() -> void:
	var left: float = 10.0
	var right: float = maxf(left + 1.0, size.x - 10.0)
	var cy: float = size.y * 0.5
	var fill_x: float = lerpf(left, right, value)
	# shadow line
	draw_line(Vector2(left, cy + 1.0), Vector2(right, cy + 1.0), Color(0,0,0,0.28), 5.0)
	# neutral track
	draw_line(Vector2(left, cy), Vector2(right, cy), Color(0.92,0.91,0.87,0.16), 3.0)
	# selected portion
	draw_line(Vector2(left, cy), Vector2(fill_x, cy), Color(0.96,0.95,0.90,0.78), 3.0)
	# tiny scratch passes
	for i in range(3):
		var jitter: float = sin(float(frame_id) * 0.06 + float(i) * 1.9) * 0.45
		draw_line(Vector2(left, cy + jitter), Vector2(fill_x, cy + jitter), Color(0.96,0.95,0.90,0.08 + hover_t * 0.04), 1.0)
	# handle
	var r: float = 6.5 + hover_t * 1.2
	draw_circle(Vector2(fill_x, cy + 1.5), r + 2.5, Color(0,0,0,0.22))
	_draw_diamond(Vector2(fill_x, cy), r, Color(0.96,0.95,0.90,0.98))
	_draw_diamond(Vector2(fill_x, cy), r - 2.1, Color(0.09,0.10,0.11,1.0))

func _draw_diamond(center: Vector2, radius_value: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(0, -radius_value),
		center + Vector2(radius_value * 0.76, 0),
		center + Vector2(0, radius_value),
		center + Vector2(-radius_value * 0.76, 0)
	])
	draw_colored_polygon(poly, color)
