extends Node2D

var t: float = 0.0
var charge_time: float = 0.42
var life: float = 0.76
var radius: float = 62.0
var damage: int = 1
var hit_done: bool = false
var cached_controller = null
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 68
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	t += delta
	if not hit_done and t >= charge_time:
		hit_done = true
		_burst()
	if t >= life:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0 / 30.0
		queue_redraw()

func _burst() -> void:
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(global_position, radius + 24.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var d: float = global_position.distance_to(enemy.global_position)
		if d <= radius:
			var dir: Vector2 = (enemy.global_position - global_position).normalized()
			if dir.length_squared() < 0.001:
				dir = Vector2.RIGHT
			enemy.take_damage(damage, dir)
	get_tree().call_group("screen_fx", "pulse_rift")
	get_tree().call_group("audio_bus", "play_rift")

func _draw() -> void:
	var ink: Color = Color("#111111")
	var ghost: Color = Color(0.84, 0.93, 1.0, 0.28)
	if t < charge_time:
		var p: float = clampf(t / charge_time, 0.0, 1.0)
		for i in range(4):
			var r: float = lerpf(radius + 26.0 + float(i) * 9.0, radius * 0.42 + float(i) * 6.0, p)
			draw_arc(Vector2.ZERO, r, -2.5 + float(i) * 0.42, 2.5 + float(i) * 0.42, 34, Color(ghost.r, ghost.g, ghost.b, 0.08 + p * 0.15), 1.1)
		for i in range(7):
			var a: float = -t * 3.5 + float(i) * TAU / 7.0
			var pos: Vector2 = Vector2(cos(a), sin(a)) * lerpf(58.0, 18.0, p)
			draw_circle(pos, 1.5 + p * 0.5, Color(1, 1, 1, 0.18))
		for i in range(4):
			var wobble: float = sin(t * 8.0 + float(i)) * 3.5
			draw_line(Vector2(wobble, -14.0 - float(i) * 10.0), Vector2(-wobble, 12.0 + float(i) * 6.0), Color(ink.r, ink.g, ink.b, 0.10 + p * 0.08), 1.0)
	else:
		var q: float = clampf((t - charge_time) / maxf(0.001, life - charge_time), 0.0, 1.0)
		var alpha: float = 1.0 - q
		for i in range(10):
			var a2: float = float(i) * TAU / 10.0 + q * 0.5
			var a_pos: Vector2 = Vector2(cos(a2), sin(a2)) * (10.0 + q * radius)
			draw_line(Vector2.ZERO, a_pos, Color(ink.r, ink.g, ink.b, 0.28 * alpha), 1.4)
			if i % 2 == 0:
				draw_circle(a_pos, 1.2 + alpha, Color(1, 1, 1, 0.18 * alpha))
		draw_circle(Vector2.ZERO, radius * (0.26 + q * 0.22), Color(ghost.r, ghost.g, ghost.b, 0.10 * alpha))
		draw_arc(Vector2.ZERO, radius * q, 0.0, TAU, 40, Color(ink.r, ink.g, ink.b, 0.34 * alpha), 2.4)
		draw_arc(Vector2.ZERO, radius * q + 5.0, 0.0, TAU, 40, Color(1, 1, 1, 0.16 * alpha), 1.0)
