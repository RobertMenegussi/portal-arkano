extends Node2D

var life: float = 0.22
var max_life: float = 0.22
var sketch_frame: int = 0
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 15

func _process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _draw() -> void:
	var a: float = clampf(life / max_life, 0.0, 1.0) * 0.13
	var ink := Color(0.05, 0.05, 0.05, a)

	draw_colored_polygon(PackedVector2Array([
		Vector2(-13, 11),
		Vector2(13, 11),
		Vector2(9, -5),
		Vector2(-9, -5)
	]), ink)
	draw_circle(Vector2(0, -10), 9.5, ink)
	draw_colored_polygon(PackedVector2Array([
		Vector2(-16, -16),
		Vector2(16, -16),
		Vector2(4, -36),
		Vector2(-7, -28)
	]), ink)
