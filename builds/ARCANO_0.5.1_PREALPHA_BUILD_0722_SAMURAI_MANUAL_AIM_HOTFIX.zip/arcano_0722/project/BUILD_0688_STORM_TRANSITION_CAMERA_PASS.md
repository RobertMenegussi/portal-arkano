# BUILD 0688 — STORM TRANSITION + CAMERA PASS

## Storm
- Increased Storm dash duration slightly for a stronger lightning-travel feel.
- Added a transformation transition into lightning form and a return transition back to human form.
- Kept the lightning form lingering very briefly after the dash so the re-materialization reads more clearly.
- Boosted Storm lightning emphasis during/after dash.

## Camera
- Reworked the player camera follow pass to feel smoother and less flickery.
- Disabled the extra built-in position smoothing layer to avoid the double-smoothing / jitter feeling.
- Replaced it with a gentler manual look-ahead smoothing pass.
- Smoothed zoom transitions more cleanly.
- Reduced global camera shake intensity substantially so combat feels less irritating.

## Files changed
- player.gd
- endless_main.gd
- sandbox_main.gd
- endless_tutorial.gd
