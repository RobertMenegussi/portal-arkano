# BUILD 0714 — Paper-horde size/quantity pass

## Goals
- Make enemies a little smaller on screen.
- Reinforce a paper/fragile feel: less HP, same damage.
- Use the reduced size to support a denser bullet-heaven horde.

## Main changes
- Lowered base HP for core enemies (slime, spider, skeleton, stalker, brute, shaman, warder).
- Softened the global enemy HP scaling curve so density stays the main pressure earlier in the run.
- Reduced enemy collision radii a bit to match the smaller visual read.
- Reduced final enemy world scale by roughly 6-8% depending on type.
- Increased enemy caps and slightly accelerated horde fill so the screen can host a larger crowd.
- Increased chances for extra disposable basic spawns.
- Damage values were left unchanged.

## Files changed
- enemy.gd
- endless_main.gd
