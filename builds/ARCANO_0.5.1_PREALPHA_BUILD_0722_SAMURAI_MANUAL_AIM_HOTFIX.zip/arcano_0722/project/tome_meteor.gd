extends Node2D

var delay: float = 0.48
var life: float = 0.82
var radius: float = 58.0
var damage: int = 1
var t: float = 0.0
var hit_done: bool = false
var cached_controller = null
var visual_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 72
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	t += delta
	if not hit_done and t >= delay:
		hit_done = true
		_impact()
	if t >= life:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _impact() -> void:
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(global_position,radius+24.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		if global_position.distance_squared_to(enemy.global_position) <= radius*radius:
			var dir: Vector2 = (enemy.global_position-global_position).normalized()
			if dir.length_squared() < 0.001:
				dir = Vector2.RIGHT
			enemy.take_damage(damage,dir)
	get_tree().call_group("screen_fx","pulse_boss")
	get_tree().call_group("audio_bus","play_rift")

func _draw() -> void:
	var ink: Color = Color("#111111")
	if t < delay:
		var p: float = clampf(t/maxf(0.001,delay),0.0,1.0)
		draw_arc(Vector2.ZERO,radius,0.0,TAU,34,Color(0.08,0.08,0.08,0.08+p*0.18),1.6)
		draw_arc(Vector2.ZERO,maxf(8.0,radius*(1.0-p)),0.0,TAU,26,Color(0.08,0.08,0.08,0.16+p*0.12),1.2)
		var fall_y: float = lerpf(-180.0,-18.0,p)
		draw_circle(Vector2(0,fall_y),7.0+p*2.0,ink)
		draw_line(Vector2(0,fall_y-28),Vector2(0,fall_y-8),Color(0.08,0.08,0.08,0.12),2.0)
	else:
		var q: float = clampf((t-delay)/maxf(0.001,life-delay),0.0,1.0)
		var alpha: float = 1.0-q
		for i in range(3):
			draw_arc(Vector2.ZERO,radius*(0.35+q*0.75)-float(i)*6.0,0.0,TAU,38,Color(ink.r,ink.g,ink.b,0.24*alpha),2.0)
		for i in range(8):
			var a: float = TAU*float(i)/8.0
			draw_line(Vector2.ZERO,Vector2(cos(a),sin(a))*radius*(0.45+q*0.55),Color(0.08,0.08,0.08,0.16*alpha),1.2)
