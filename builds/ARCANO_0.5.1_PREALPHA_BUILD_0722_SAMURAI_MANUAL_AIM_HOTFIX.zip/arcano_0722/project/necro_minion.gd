extends CharacterBody2D

var player
var dead: bool = false
var t: float = 0.0
var life_time: float = 8.0
var speed: float = 178.0
var hit_flash: float = 0.0
var visual_timer: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("enemy")
	add_to_group("necro_minion")
	collision_layer = 4
	collision_mask = 1
	z_index = 23
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 8.0
	collider.shape = shape
	add_child(collider)

func _physics_process(delta: float) -> void:
	if dead:
		return
	t += delta
	life_time -= delta
	hit_flash = move_toward(hit_flash, 0.0, delta * 9.0)
	if life_time <= 0.0:
		_die(false)
		return
	if not is_instance_valid(player) or not player.active:
		velocity = Vector2.ZERO
		return
	var to_player: Vector2 = player.global_position - global_position
	var d2: float = to_player.length_squared()
	if d2 <= 400.0:
		player.take_damage(1, to_player.normalized())
		_die(true)
		return
	velocity = to_player.normalized() * speed
	# Disposable summons do not need expensive CharacterBody wall resolution.
	global_position += velocity*delta
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/24.0
		queue_redraw()

func take_damage(_amount: int, _hit_direction: Vector2) -> void:
	if dead:
		return
	hit_flash = 1.0
	get_tree().call_group("endless_controller","on_enemy_defeated",global_position,"minion",false)
	if is_instance_valid(player):
		player.on_enemy_killed(false)
	_die(false)

func apply_external_force(force: Vector2) -> void:
	global_position += force * 0.015

func heal_enemy(_amount: int) -> void:
	pass

func _die(on_hit: bool) -> void:
	if dead:
		return
	dead = true
	collision_layer = 0
	collision_mask = 0
	if on_hit:
		get_tree().call_group("screen_fx", "pulse_enemy_hit")
	else:
		get_tree().call_group("audio_bus", "play_enemy_die")
	queue_free()

func _draw() -> void:
	var ink: Color = Color("#111111").lerp(Color("#777777"), hit_flash * 0.65)
	var bob: float = sin(t * 9.0) * 1.7
	draw_circle(Vector2(0, 8), 8.0, Color(0.08,0.08,0.08,0.05))
	# tiny disposable bone wisp: skull + dangling jaw + two claw legs
	draw_circle(Vector2(0, -4 + bob), 7.0, Color("#f3eee3"))
	draw_arc(Vector2(0, -4 + bob), 7.0, 0.0, TAU, 18, ink, 1.3)
	draw_circle(Vector2(-2.6, -5 + bob), 1.6, ink)
	draw_circle(Vector2(2.6, -5 + bob), 1.6, ink)
	draw_line(Vector2(-3,1+bob), Vector2(3,1+bob), ink, 1.2)
	draw_line(Vector2(-2,3+bob), Vector2(-6,9+bob), ink, 1.6)
	draw_line(Vector2(2,3+bob), Vector2(6,9+bob), ink, 1.6)
	for i in range(3):
		var a: float = t * 5.0 + float(i) * TAU / 3.0
		draw_circle(Vector2(cos(a)*11.0,sin(a)*7.0),1.2,Color(0.08,0.08,0.08,0.12))
