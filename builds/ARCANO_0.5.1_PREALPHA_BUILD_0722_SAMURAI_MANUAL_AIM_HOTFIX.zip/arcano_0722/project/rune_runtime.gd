extends Node2D

const Catalog = preload("res://endless_catalog.gd")
const RuneEffectScript = preload("res://rune_effect.gd")

var player
var cooldowns: Dictionary = {}
var visual_t: float = 0.0
var last_dash_state: bool = false
var cached_upgrade_count: int = -1
var cached_style_entries: Array = []
var cached_periodic_entries: Array = []
var cached_controller = null
var visual_redraw_timer: float = 0.0

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 18
	add_to_group("rune_runtime")
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	if not is_instance_valid(player):
		return
	visual_t += delta
	_refresh_style_cache()
	for key in cooldowns.keys():
		cooldowns[key] = maxf(0.0,float(cooldowns[key])-delta)
	for item in cached_periodic_entries:
		var entry: Dictionary = item
		_try_trigger(str(entry.get("id","")),entry)
	visual_redraw_timer -= delta
	if visual_redraw_timer <= 0.0:
		visual_redraw_timer = 1.0/30.0
		queue_redraw()

func _refresh_style_cache() -> void:
	if not is_instance_valid(player):
		return
	if cached_upgrade_count == player.endless_upgrades.size():
		return
	cached_upgrade_count = player.endless_upgrades.size()
	cached_style_entries.clear()
	cached_periodic_entries.clear()
	for id_value in player.endless_upgrades:
		var rune_id: String = str(id_value)
		var data: Dictionary = Catalog.get_style_data(rune_id)
		if data.is_empty():
			continue
		cached_style_entries.append(data)
		if str(data.get("trigger","")) == "periodic":
			cached_periodic_entries.append(data)

func on_enemy_killed(_elite: bool = false) -> void:
	_trigger_event("kill")

func on_dash_started() -> void:
	_trigger_event("dash")

func on_player_damaged() -> void:
	_trigger_event("hurt")

func on_basic_attack() -> void:
	_trigger_event("basic")

func _trigger_event(trigger_name: String) -> void:
	if not is_instance_valid(player):
		return
	_refresh_style_cache()
	for item in cached_style_entries:
		var data: Dictionary = item
		if str(data.get("trigger","")) == trigger_name:
			_try_trigger(str(data.get("id","")),data)

func _try_trigger(rune_id: String,data: Dictionary) -> void:
	if float(cooldowns.get(rune_id,0.0)) > 0.0:
		return
	cooldowns[rune_id] = float(data.get("cooldown",4.0))
	_execute(data)

func _execute(data: Dictionary) -> void:
	if not is_instance_valid(player):
		return
	var pattern: String = str(data.get("pattern","nova"))
	var radius: float = float(data.get("radius",120.0))
	var damage: int = int(data.get("damage",1))
	var count_value: int = int(data.get("count",1))
	var accent: int = int(data.get("accent",0))
	var dir: Vector2 = player.aim_direction.normalized() if player.aim_direction.length_squared() > 0.001 else Vector2.RIGHT
	var hit_nodes: Array = []
	var target_points: Array = []
	var visible_pool: Array = _visible_enemies()
	match pattern:
		"nova","aura":
			for enemy in visible_pool:
				if enemy.global_position.distance_squared_to(player.global_position) <= radius*radius:
					hit_nodes.append(enemy)
		"cone":
			var cos_limit: float = cos(0.78)
			for enemy in visible_pool:
				var d: Vector2 = enemy.global_position-player.global_position
				if d.length() <= radius and d.length_squared() > 0.001 and dir.dot(d.normalized()) >= cos_limit:
					hit_nodes.append(enemy)
		"line":
			for enemy in visible_pool:
				var d2: Vector2 = enemy.global_position-player.global_position
				var along: float = d2.dot(dir)
				var side: float = absf(d2.cross(dir))
				if along >= 0.0 and along <= radius and side <= 38.0:
					hit_nodes.append(enemy)
		"orbit":
			var inner: float = radius*0.42
			for enemy in visible_pool:
				var dist: float = enemy.global_position.distance_to(player.global_position)
				if dist >= inner and dist <= radius:
					hit_nodes.append(enemy)
		"bolt":
			var pool: Array = _nearest_from_pool(visible_pool,count_value)
			for enemy in pool:
				hit_nodes.append(enemy)
				target_points.append(enemy.global_position-player.global_position)
		"rain","spiral":
			var pool2: Array = visible_pool.duplicate()
			pool2.shuffle()
			for i in range(mini(count_value+1,pool2.size())):
				hit_nodes.append(pool2[i])
				target_points.append(pool2[i].global_position-player.global_position)
		"mark":
			var best
			var best_hp: float = -1.0
			for enemy in visible_pool:
				var hp: float = float(enemy.get("max_health"))
				if hp > best_hp:
					best_hp = hp
					best = enemy
			if is_instance_valid(best):
				hit_nodes.append(best)
				target_points.append(best.global_position-player.global_position)
		"burst":
			var pool3: Array = _nearest_from_pool(visible_pool,count_value+2)
			for enemy in pool3:
				if enemy.global_position.distance_to(player.global_position) <= radius:
					hit_nodes.append(enemy)
	for enemy in hit_nodes:
		_damage_enemy(enemy,damage)
	_spawn_vfx(pattern,radius,dir,target_points,accent)
	get_tree().call_group("audio_bus","play_rune_proc")

func _damage_enemy(enemy,damage: int) -> void:
	if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
		return
	var d: Vector2 = enemy.global_position-player.global_position
	var final_damage: int = damage
	if player.has_method("_roll_endless_damage"):
		final_damage = player._roll_endless_damage(damage)
	enemy.take_damage(maxi(1,final_damage),d.normalized() if d.length_squared() > 0.001 else Vector2.RIGHT)

func _nearest_enemies(limit_value: int) -> Array:
	return _nearest_from_pool(_visible_enemies(),limit_value)

func _nearest_from_pool(pool: Array,limit_value: int) -> Array:
	var source: Array = pool.duplicate()
	var result: Array = []
	while not source.is_empty() and result.size() < limit_value:
		var best_index: int = 0
		var best_distance: float = INF
		for i in range(source.size()):
			var enemy = source[i]
			var distance_value: float = enemy.global_position.distance_squared_to(player.global_position)
			if distance_value < best_distance:
				best_distance = distance_value
				best_index = i
		result.append(source[best_index])
		source.remove_at(best_index)
	return result

func _visible_enemies() -> Array:
	var result: Array = []
	if not is_instance_valid(player):
		return result
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(player.global_position,900.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		if enemy.get("dead") == true:
			continue
		if player.has_method("_is_endless_target_on_screen") and not player._is_endless_target_on_screen(enemy):
			continue
		result.append(enemy)
	return result

func _spawn_vfx(pattern: String,radius: float,dir: Vector2,target_points: Array,accent: int) -> void:
	var fx = RuneEffectScript.new()
	fx.configure(pattern,player.global_position,radius,dir,target_points,accent)
	get_tree().current_scene.add_child(fx)

func _draw() -> void:
	if not is_instance_valid(player):
		return
	_refresh_style_cache()
	var count_style: int = cached_style_entries.size()
	if count_style <= 0:
		return
	var intensity: float = clampf(float(count_style)/12.0,0.0,1.0)
	for i in range(mini(6,count_style)):
		var a: float = visual_t*(0.28+float(i)*0.035)+TAU*float(i)/float(maxi(1,mini(6,count_style)))
		var rr: float = 34.0+float(i%3)*6.0+sin(visual_t*1.8+float(i))*2.0
		var p: Vector2 = Vector2(cos(a)*rr,sin(a)*rr*0.66)
		draw_circle(p,1.4+intensity,Color(0.92,0.90,0.82,0.10+0.11*intensity))
