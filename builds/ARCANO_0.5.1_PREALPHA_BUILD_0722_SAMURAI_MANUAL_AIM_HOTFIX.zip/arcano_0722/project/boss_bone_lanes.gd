extends Node2D

var player
var horizontal: bool = false
var lane_offsets: Array = []
var warning_time: float = 0.72
var strike_time: float = 0.18
var elapsed: float = 0.0
var hit_done: bool = false
var lane_width: float = 22.0
var arena_half_length: float = 350.0

func configure(target, use_horizontal: bool, offsets: Array) -> void:
	player = target
	horizontal = use_horizontal
	lane_offsets = offsets

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 71
	get_tree().call_group("audio_bus","play_boss_mark")

func _process(delta: float) -> void:
	elapsed += delta
	if not hit_done and elapsed >= warning_time:
		hit_done = true
		_do_hits()
		get_tree().call_group("screen_fx","pulse_boss_mark")
	if elapsed >= warning_time+strike_time+0.20:
		queue_free()
		return
	queue_redraw()

func _do_hits() -> void:
	if not is_instance_valid(player) or not player.active:
		return
	var local: Vector2 = player.global_position-global_position
	for off in lane_offsets:
		var distance_to_lane: float = absf(local.y-off) if horizontal else absf(local.x-off)
		var along: float = absf(local.x) if horizontal else absf(local.y)
		if distance_to_lane <= lane_width and along <= arena_half_length:
			var push: Vector2 = Vector2(0,1) if horizontal else Vector2(1,0)
			player.take_damage(1,push)
			return

func _draw() -> void:
	var warning: bool = elapsed < warning_time
	var p: float = clampf(elapsed/maxf(warning_time,0.001),0.0,1.0)
	for off in lane_offsets:
		if horizontal:
			var a: Vector2 = Vector2(-arena_half_length,off)
			var b: Vector2 = Vector2(arena_half_length,off)
			if warning:
				draw_line(a,b,Color(0.08,0.08,0.08,0.07+p*0.18),2.0)
				for x in range(-320,321,64):
					draw_line(Vector2(float(x),off-8),Vector2(float(x)+18,off+8),Color(0.08,0.08,0.08,0.10+p*0.12),1.0)
			else:
				draw_line(a,b,Color(0.08,0.08,0.08,0.62),6.0)
				draw_line(a+Vector2(0,5),b+Vector2(0,5),Color(1,1,1,0.32),1.5)
		else:
			var a2: Vector2 = Vector2(off,-arena_half_length)
			var b2: Vector2 = Vector2(off,arena_half_length)
			if warning:
				draw_line(a2,b2,Color(0.08,0.08,0.08,0.07+p*0.18),2.0)
				for y in range(-320,321,64):
					draw_line(Vector2(off-8,float(y)),Vector2(off+8,float(y)+18),Color(0.08,0.08,0.08,0.10+p*0.12),1.0)
			else:
				draw_line(a2,b2,Color(0.08,0.08,0.08,0.62),6.0)
				draw_line(a2+Vector2(5,0),b2+Vector2(5,0),Color(1,1,1,0.32),1.5)
