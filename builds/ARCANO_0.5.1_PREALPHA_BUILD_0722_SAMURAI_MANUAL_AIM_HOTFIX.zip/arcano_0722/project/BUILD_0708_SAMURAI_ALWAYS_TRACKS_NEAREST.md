# BUILD 0708 — Samurai always tracks nearest enemy

## Change
- Samurai now keeps looking at the nearest enemy full-time instead of only snapping focus when a target is relatively close.
- This affects in-game facing / eye direction so the class feels more aware and alive during the whole run.

## Files changed
- player.gd
- endless_main.gd
