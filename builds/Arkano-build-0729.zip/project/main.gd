extends Node2D

const PlayerScript = preload("res://player.gd")
const SpawnPointScript = preload("res://spawn_point.gd")
const CrosshairScript = preload("res://crosshair.gd")
const ScreenFxScript = preload("res://screen_fx.gd")
const PlayerSpawnScript = preload("res://player_spawn.gd")
const ScribbleTextScript = preload("res://scribble_text.gd")
const TutorialNPCScript = preload("res://tutorial_npc.gd")
const AudioManagerScript = preload("res://audio_manager.gd")
const MenuBlobScript = preload("res://menu_blob.gd")
const ArcanoLogoScript = preload("res://arcano_logo.gd")
const MenuButtonScript = preload("res://menu_button.gd")
const HudDisplayScript = preload("res://hud_display.gd")
const MagePreviewScript = preload("res://mage_preview.gd")
const ShopItemButtonScript = preload("res://shop_item_button.gd")
const MiniBossSkeletonScript = preload("res://mini_boss_skeleton.gd")
const DialogueTextScript = preload("res://dialogue_text.gd")
const DialoguePortraitScript = preload("res://dialogue_portrait.gd")
const DialogueFrameScript = preload("res://dialogue_frame.gd")
const FragmentCounterScript = preload("res://fragment_counter.gd")
const BossBarScript = preload("res://boss_bar.gd")
const CivilianScript = preload("res://civilian_npc.gd")
const WorldMapBoardScript = preload("res://world_map_board.gd")
const WorldMapPanelScript = preload("res://world_map_panel.gd")
const ObjectivePanelScript = preload("res://objective_panel.gd")
const FluxMeterScript = preload("res://flux_meter.gd")
const TraitCardScript = preload("res://trait_card.gd")
const EncounterZoneScript = preload("res://encounter_zone.gd")
const EliteReaverScript = preload("res://elite_reaver.gd")
const ExplorationCacheScript = preload("res://exploration_cache.gd")
const EnemyScript = preload("res://enemy.gd")

const WORLD_SIZE: Vector2 = Vector2(5800.0, 1440.0)
const GAME_VERSION: String = "0.0.15-prealpha"
const BUILD_NUMBER: String = "0235"
const RESOLUTION_OPTIONS = [Vector2i(960,540), Vector2i(1280,720), Vector2i(1366,768), Vector2i(1600,900), Vector2i(1920,1080), Vector2i(2560,1440), Vector2i(3840,2160)]

var player
var spawners: Array = []
var tutorial_npc
var merchant_npc
var bridge_npc
var mini_boss
var civilians: Array = []
var world_map_board
var post_gate
var audio_manager

var game_started: bool = false
var death_open: bool = false
var pause_open: bool = false
var dialogue_open: bool = false
var settings_open: bool = false
var dialogue_lines: Array = []
var dialogue_index: int = 0

var menu_layer: CanvasLayer
var menu_root: Control
var menu_main_panel: Control
var menu_settings_panel: Control
var pause_layer: CanvasLayer
var death_layer: CanvasLayer
var hud_layer: CanvasLayer
var dialogue_layer: CanvasLayer
var fade_layer: CanvasLayer
var fade_rect: ColorRect
var crosshair
var hud_widget
var health_text
var dash_text
var objective_text
var dialogue_text
var dialogue_speaker
var dialogue_tone
var dialogue_portrait
var dialogue_hint
var dialogue_frame
var settings_button
var play_button
var menu_blob
var mage_select_panel: Control
var build_end_layer: CanvasLayer
var currency_text
var currency_display
var boss_bar
var objective_panel
var area_banner
var controls_hint
var world_map_layer: CanvasLayer
var world_map_open: bool = false
var shop_layer: CanvasLayer
var choice_layer: CanvasLayer
var cutscene_layer: CanvasLayer
var shop_open: bool = false
var mini_boss_choice_open: bool = false
var ink_fragments: int = 5
var env_time: float = 0.0
var lore_seen: bool = false
var merchant_met: bool = false
var bridge_seen: bool = false
var mini_boss_resolved: bool = false
var spared_guardian: bool = false
var pending_dialogue_action: String = ""
var current_dialogue_source
var world_map_seen: bool = false
var current_area: String = ""
var controls_hint_time: float = 14.0
var cutscene_open: bool = false
var resolution_index: int = 1
var fullscreen_enabled: bool = false
var screen_shake_enabled: bool = true
var post_fx_enabled: bool = true
var selected_mage_type: String = "orbit"
var encounters: Array = []
var exploration_caches: Array = []
var elite_enemy
var encounter_completed_count: int = 0
var trait_layer: CanvasLayer
var trait_open: bool = false
var pending_trait_rewards: Array = []
var ambient_wind_timer: float = 2.8
var flux_meter
var first_branch: String = ""

# Hidden development / admin sandbox. F10 -> code ARCANO.
var admin_layer: CanvasLayer
var admin_panel_open: bool = false
var admin_unlocked: bool = false
var admin_mode: bool = false
var admin_code_input: LineEdit
var admin_status_label: Label
var admin_spawned: Array = []
var admin_return_position: Vector2 = Vector2(360,650)
var admin_previous_paused: bool = false
const ADMIN_CODE: String = "ARCANO"
const ADMIN_SPAWN: Vector2 = Vector2(5050,720)

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("game_controller")
	RenderingServer.set_default_clear_color(Color("#ebe5d8"))
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	_create_audio()
	_load_game_settings()
	_apply_window_settings()
	_create_world_collision()
	_create_player()
	_create_spawners()
	_create_tutorial_npc()
	_create_encounters()
	_create_screen_fx()
	_create_hud()
	_create_dialogue_ui()
	_create_fade_overlay()
	_create_main_menu()
	queue_redraw()
	if bool(get_tree().get_meta("arcano_quick_restart", false)):
		selected_mage_type = str(get_tree().get_meta("arcano_mage_type", "orbit"))
		get_tree().set_meta("arcano_quick_restart", false)
		player.set_mage_type(selected_mage_type)
		call_deferred("_start_game")

func _create_audio() -> void:
	audio_manager = AudioManagerScript.new()
	add_child(audio_manager)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F10:
		_toggle_admin_panel()
		get_viewport().set_input_as_handled()
		return
	if admin_panel_open:
		if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
			_close_admin_panel()
			get_viewport().set_input_as_handled()
		return
	if trait_open:
		return
	if world_map_open and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		_close_world_map()
		get_viewport().set_input_as_handled()
		return
	if shop_open and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		_close_shop()
		get_viewport().set_input_as_handled()
		return

	if dialogue_open:
		if event is InputEventKey and event.pressed and not event.echo:
			if event.keycode == KEY_E or event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
				if is_instance_valid(dialogue_text) and dialogue_text.is_typing():
					dialogue_text.finish_line()
				else:
					_advance_dialogue()
				get_viewport().set_input_as_handled()
		return

	if cutscene_open or not game_started or death_open or mini_boss_choice_open or trait_open:
		return

	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		if pause_open:
			_resume_game()
		else:
			_pause_game()
		get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	env_time += _delta
	queue_redraw()
	ambient_wind_timer = maxf(0.0, ambient_wind_timer - _delta)
	if ambient_wind_timer <= 0.0 and game_started and not pause_open and not dialogue_open and not cutscene_open and not death_open:
		ambient_wind_timer = randf_range(5.5, 9.5)
		get_tree().call_group("audio_bus","play_wind_gust")
	if controls_hint_time > 0.0:
		controls_hint_time = maxf(0.0, controls_hint_time - _delta)
		if is_instance_valid(controls_hint):
			controls_hint.modulate.a = clampf(controls_hint_time / 2.0, 0.0, 1.0)
	if game_started and is_instance_valid(player):
		_update_hud()
		_update_area_state()
		_try_open_next_trait()

func _exit_tree() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#ebe5d8"), true)
	var village: Rect2 = Rect2(70,70,1180,1300)
	var field: Rect2 = Rect2(1270,70,930,1300)
	var river: Rect2 = Rect2(2230,70,260,1300)
	var bridge: Rect2 = Rect2(2200,650,320,150)
	var arena: Rect2 = Rect2(2550,90,880,1240)
	var post_area: Rect2 = Rect2(3470,90,760,1240)

	draw_rect(village,Color("#f8f5ee"),true)
	draw_rect(field,Color("#f5f1e7"),true)
	draw_rect(arena,Color("#f7f3eb"),true)
	draw_rect(post_area,Color("#fbf8f1"),true)
	_draw_paper_noise(Rect2(70,70,4160,1300))
	_draw_sketch_border(village,Color(0.08,0.08,0.08,0.10))
	_draw_sketch_border(field,Color(0.08,0.08,0.08,0.08))
	_draw_sketch_border(arena,Color(0.08,0.08,0.08,0.14))
	_draw_sketch_border(post_area,Color(0.08,0.08,0.08,0.08))

	# VILA SEGURA
	_draw_path_strip(PackedVector2Array([Vector2(150,720),Vector2(420,700),Vector2(760,715),Vector2(1120,720),Vector2(1260,720)]),60.0)
	_draw_house(Vector2(250,250),Vector2(200,130))
	_draw_house(Vector2(560,230),Vector2(210,140))
	_draw_house(Vector2(930,300),Vector2(190,122))
	_draw_house(Vector2(830,980),Vector2(230,142))
	_draw_house(Vector2(320,1070),Vector2(190,118))
	_draw_well(Vector2(530,760))
	_draw_fence(Rect2(120,470,250,18),8)
	_draw_fence(Rect2(720,470,330,18),10)
	_draw_fence(Rect2(180,1180,300,18),10)
	_draw_grass_patch(Rect2(100,110,260,140),14)
	_draw_grass_patch(Rect2(430,390,230,140),12)
	_draw_grass_patch(Rect2(1040,540,140,160),10)
	_draw_grass_patch(Rect2(120,820,230,210),12)
	_draw_tree_cluster(Vector2(150,1190),4)
	_draw_tree_cluster(Vector2(1130,1180),4)
	_draw_dead_tree(Vector2(1080,185),1.0)
	_draw_merchant_rug(Rect2(900,760,132,76))
	_draw_lantern_cluster(Vector2(520,700))
	_draw_signpost(Vector2(1195,705),"CAMPO")
	_draw_shrub_patch(Rect2(160,330,180,90),6)
	_draw_shrub_patch(Rect2(575,540,140,90),5)
	_draw_shrub_patch(Rect2(960,850,160,90),6)
	_draw_cart(Vector2(700,760),Vector2(98,40))
	_draw_rope_flags(Vector2(180,145),Vector2(645,130),7)
	_draw_rope_flags(Vector2(645,155),Vector2(965,200),5)
	_draw_window_marks(Vector2(250,250),Vector2(200,130),2)
	_draw_window_marks(Vector2(560,230),Vector2(210,140),2)
	_draw_window_marks(Vector2(930,300),Vector2(190,122),2)

	# CAMPO ABERTO / EXPLORAÇÃO
	_draw_path_strip(PackedVector2Array([Vector2(1260,720),Vector2(1500,690),Vector2(1770,690),Vector2(2080,710),Vector2(2210,720)]),58.0)
	_draw_path_strip(PackedVector2Array([Vector2(1460,690),Vector2(1500,430),Vector2(1740,320),Vector2(2060,250)]),34.0)
	_draw_path_strip(PackedVector2Array([Vector2(1540,735),Vector2(1630,980),Vector2(1820,1100),Vector2(2110,1170)]),36.0)
	_draw_grass_patch(Rect2(1310,120,250,170),14)
	_draw_grass_patch(Rect2(1570,820,190,150),11)
	_draw_grass_patch(Rect2(1900,390,190,130),10)
	_draw_grass_patch(Rect2(1820,1070,240,190),13)
	_draw_tree_cluster(Vector2(1390,200),3)
	_draw_tree_cluster(Vector2(2080,1220),3)
	_draw_dead_tree(Vector2(1660,230),0.9)
	_draw_dead_tree(Vector2(2020,990),0.9)
	_draw_ruin_pillar(Vector2(1495,370),Vector2(118,36))
	_draw_ruin_pillar(Vector2(1930,515),Vector2(104,32))
	_draw_ruin_pillar(Vector2(1710,1080),Vector2(120,38))
	_draw_tree_stump(Vector2(1540,1045),Vector2(34,22))
	_draw_tree_stump(Vector2(2055,300),Vector2(38,24))
	_draw_rock_cluster(Vector2(1810,620),6)
	_draw_rock_cluster(Vector2(2080,820),4)
	_draw_signpost(Vector2(1470,680),"RUÍNAS")
	_draw_signpost(Vector2(1600,760),"POÇO")
	_draw_signpost(Vector2(1980,715),"PONTE")
	_draw_shrub_patch(Rect2(1370,560,180,100),6)
	_draw_shrub_patch(Rect2(1710,250,130,80),4)
	_draw_shrub_patch(Rect2(1880,1180,160,80),5)
	_draw_cart(Vector2(1865,700),Vector2(90,36))

	# RIO + PONTE
	_draw_river_vertical(river)
	_draw_bridge_planks(bridge)
	_draw_reed_patch(Vector2(2255,610),8)
	_draw_reed_patch(Vector2(2455,860),8)
	_draw_rock_cluster(Vector2(2270,980),4)
	_draw_rock_cluster(Vector2(2450,430),4)
	_draw_bridge_posts(bridge)
	_draw_water_swirl(river,18)

	# ARENA DO OLHEIRO
	_draw_arena_ground(Vector2(2990,720),360.0)
	_draw_ruin_pillar(Vector2(2660,250),Vector2(126,40))
	_draw_ruin_pillar(Vector2(3320,250),Vector2(126,40))
	_draw_ruin_pillar(Vector2(2680,1170),Vector2(150,42))
	_draw_ruin_pillar(Vector2(3310,1170),Vector2(150,42))
	_draw_dead_tree(Vector2(2700,680),1.10)
	_draw_dead_tree(Vector2(3290,760),1.00)
	_draw_rock_cluster(Vector2(2800,420),6)
	_draw_rock_cluster(Vector2(3200,1010),7)
	_draw_ink_pool(Vector2(2880,1040),36.0,22.0)
	_draw_ink_pool(Vector2(3130,395),30.0,18.0)
	_draw_shrub_patch(Rect2(2770,850,120,80),4)
	_draw_shrub_patch(Rect2(3140,560,120,80),4)
	_draw_ruin_banner(Vector2(2990,245),Vector2(90,52))

	# ESTRADA PÓS-BOSS
	_draw_path_strip(PackedVector2Array([Vector2(3430,720),Vector2(3660,710),Vector2(3920,700),Vector2(4200,690)]),64.0)
	_draw_grass_patch(Rect2(3560,170,250,200),13)
	_draw_grass_patch(Rect2(3920,930,220,190),13)
	_draw_tree_cluster(Vector2(3690,250),4)
	_draw_tree_cluster(Vector2(4090,280),4)
	_draw_dead_tree(Vector2(3780,1110),1.0)
	_draw_signpost(Vector2(3620,720),"CASTELO")
	_draw_signpost(Vector2(3900,700),"MAPA")
	_draw_shrub_patch(Rect2(3600,820,180,90),5)
	_draw_cart(Vector2(4010,845),Vector2(86,34))
	if not mini_boss_resolved:
		_draw_gate(Vector2(3470,730))
	_draw_fence(Rect2(4195,560,18,250),8)
	_draw_path_strip(PackedVector2Array([Vector2(4200,690),Vector2(4280,690)]),42.0)
	# CAMPO DEV / ADM — isolado do mapa normal.
	var dev_field: Rect2 = Rect2(4440,90,1280,1260)
	draw_rect(dev_field,Color("#f4f0e7"),true)
	_draw_sketch_border(dev_field,Color(0.08,0.08,0.08,0.11))
	_draw_path_strip(PackedVector2Array([Vector2(4560,720),Vector2(5050,720),Vector2(5580,720)]),72.0)
	_draw_grass_patch(Rect2(4490,150,300,190),12)
	_draw_grass_patch(Rect2(5350,1010,280,190),12)
	_draw_tree_cluster(Vector2(4570,210),3)
	_draw_tree_cluster(Vector2(5600,1180),3)
	_draw_rock_cluster(Vector2(4680,1120),5)
	_draw_rock_cluster(Vector2(5480,280),5)
	_draw_signpost(Vector2(4565,705),"CAMPO DEV")
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,Vector2(4890,165),"SANDBOX DE TESTES",HORIZONTAL_ALIGNMENT_CENTER,320,20,Color(0.08,0.08,0.08,0.34))
		draw_string(font,Vector2(4870,195),"F10  •  painel ADM",HORIZONTAL_ALIGNMENT_CENTER,360,10,Color(0.08,0.08,0.08,0.25))

	# Ambiência cinematográfica: vento e partículas sutis em todo o mapa.
	_draw_wind_lines(Rect2(90,90,5630,1240),36,1.0)
	_draw_dust_motes(Rect2(90,90,5630,1240),72)

func _draw_path_strip(points: PackedVector2Array, width: float) -> void:
	if points.size() < 2:
		return
	for i in range(points.size()-1):
		draw_line(points[i],points[i+1],Color(1,1,1,0.34),width)
		draw_line(points[i],points[i+1],Color(0.08,0.08,0.08,0.055),1.0)
	for p in points:
		draw_circle(p,width*0.48,Color(1,1,1,0.20))

func _draw_house(center: Vector2, size: Vector2) -> void:
	var body: Rect2 = Rect2(center-size*0.5,size)
	draw_rect(body,Color(1,1,1,0.42),true)
	for i in range(2):
		draw_rect(body.grow(-float(i)*1.7),Color(0.08,0.08,0.08,0.16-float(i)*0.03),false,1.1)
	var roof: PackedVector2Array = PackedVector2Array([body.position+Vector2(-8,6),Vector2(center.x,body.position.y-38),Vector2(body.end.x+8,body.position.y+6)])
	draw_polyline(roof,Color(0.08,0.08,0.08,0.24),2.0)
	var door: Rect2 = Rect2(Vector2(center.x-15,body.end.y-44),Vector2(30,44))
	draw_rect(door,Color(0.08,0.08,0.08,0.08),true)
	draw_rect(door,Color(0.08,0.08,0.08,0.18),false,1.0)
	for side in [-1.0,1.0]:
		var w: Rect2 = Rect2(Vector2(center.x+side*52.0-12.0,center.y-10.0),Vector2(24,20))
		draw_rect(w,Color(1,1,1,0.38),true)
		draw_rect(w,Color(0.08,0.08,0.08,0.14),false,1.0)

func _draw_well(center: Vector2) -> void:
	_draw_oval(center,Vector2(30,18),Color(1,1,1,0.45))
	draw_arc(center,30.0,0.0,TAU,28,Color(0.08,0.08,0.08,0.24),1.4)
	draw_arc(center,20.0,0.0,TAU,24,Color(0.08,0.08,0.08,0.18),1.0)
	draw_line(center+Vector2(-26,-8),center+Vector2(-26,-48),Color(0.08,0.08,0.08,0.25),2.0)
	draw_line(center+Vector2(26,-8),center+Vector2(26,-48),Color(0.08,0.08,0.08,0.25),2.0)
	draw_line(center+Vector2(-31,-48),center+Vector2(31,-48),Color(0.08,0.08,0.08,0.25),2.0)

func _draw_fence(rect: Rect2, posts: int) -> void:
	if posts <= 1:
		return
	draw_line(Vector2(rect.position.x,rect.position.y+5),Vector2(rect.end.x,rect.position.y+5),Color(0.08,0.08,0.08,0.16),2.0)
	draw_line(Vector2(rect.position.x,rect.position.y+13),Vector2(rect.end.x,rect.position.y+13),Color(0.08,0.08,0.08,0.12),1.5)
	for i in range(posts):
		var x: float = rect.position.x + rect.size.x * float(i) / float(posts-1)
		draw_line(Vector2(x,rect.position.y-8),Vector2(x,rect.position.y+23),Color(0.08,0.08,0.08,0.20),2.0)

func _draw_tree_cluster(center: Vector2, count: int) -> void:
	for i in range(count):
		var angle: float = TAU*float(i)/maxf(1.0,float(count))
		var p: Vector2 = center+Vector2(cos(angle)*42.0,sin(angle)*28.0)
		_draw_dead_tree(p,0.72+float(i%3)*0.08)

func _draw_dead_tree(center: Vector2, scale_value: float) -> void:
	var ink: Color = Color(0.08,0.08,0.08,0.18)
	draw_line(center+Vector2(0,30*scale_value),center+Vector2(0,-30*scale_value),ink,4.0*scale_value)
	draw_line(center+Vector2(0,-10*scale_value),center+Vector2(-18,-28)*scale_value,ink,2.0*scale_value)
	draw_line(center+Vector2(0,-18*scale_value),center+Vector2(20,-38)*scale_value,ink,2.0*scale_value)
	draw_line(center+Vector2(15,-33)*scale_value,center+Vector2(28,-24)*scale_value,Color(0.08,0.08,0.08,0.12),1.4*scale_value)

func _draw_river_vertical(rect: Rect2) -> void:
	draw_rect(rect,Color(1,1,1,0.30),true)
	var x: float = rect.position.x+18.0
	var idx: int = 0
	while x < rect.end.x-12.0:
		var sway: float = sin(env_time*1.8+float(idx)*0.8)*8.0
		draw_line(Vector2(x,rect.position.y+12),Vector2(x+sway,rect.end.y-12),Color(0.08,0.08,0.08,0.065),1.1)
		x += 24.0
		idx += 1

func _draw_arena_ground(center: Vector2, radius: float) -> void:
	for i in range(4):
		draw_arc(center,radius-float(i)*13.0,0.0,TAU,64,Color(0.08,0.08,0.08,0.09-float(i)*0.012),1.1)
	for i in range(18):
		var a: float = TAU*float(i)/18.0
		var inner: Vector2 = center+Vector2(cos(a),sin(a))*radius*0.62
		var outer: Vector2 = center+Vector2(cos(a),sin(a))*radius*0.84
		draw_line(inner,outer,Color(0.08,0.08,0.08,0.045),1.0)

func _draw_gate(center: Vector2) -> void:
	for i in range(5):
		var y: float = center.y - 110.0 + float(i)*54.0
		draw_line(Vector2(center.x-18,y),Vector2(center.x+18,y+16),Color(0.08,0.08,0.08,0.25),3.0)
	draw_line(center+Vector2(-20,-140),center+Vector2(-20,140),Color(0.08,0.08,0.08,0.28),3.0)
	draw_line(center+Vector2(20,-140),center+Vector2(20,140),Color(0.08,0.08,0.08,0.28),3.0)

func _draw_signpost(center: Vector2, label_text: String) -> void:
	draw_line(center+Vector2(0,22),center+Vector2(0,-30),Color(0.08,0.08,0.08,0.28),2.5)
	var sign: Rect2 = Rect2(center+Vector2(-42,-42),Vector2(84,24))
	draw_rect(sign,Color(1,1,1,0.48),true)
	draw_rect(sign,Color(0.08,0.08,0.08,0.18),false,1.0)
	var font = ThemeDB.fallback_font
	if font != null:
		draw_string(font,sign.position+Vector2(8,16),label_text,HORIZONTAL_ALIGNMENT_LEFT,68,9,Color(0.08,0.08,0.08,0.56))

func _draw_paper_noise(rect: Rect2) -> void:

	var x: float = rect.position.x + 45.0
	while x < rect.end.x:
		var y: float = rect.position.y + 38.0
		while y < rect.end.y:
			var noise_seed: float = sin(x * 0.017 + y * 0.021)
			var alpha: float = 0.010 + absf(noise_seed) * 0.006
			draw_line(Vector2(x - 5.0, y), Vector2(x + 7.0, y + noise_seed * 2.5), Color(0.12, 0.11, 0.10, alpha), 1.0)
			y += 88.0
		x += 94.0

func _draw_sketch_border(rect: Rect2, color: Color) -> void:
	for i in range(3):
		var off: float = float(i) - 1.0
		draw_rect(rect.grow(-8.0 + off * 1.5), color, false, 1.2)

func _draw_floor_scribble(center: Vector2, radius: float) -> void:
	for i in range(4):
		var r: float = radius - float(i) * 7.0
		draw_arc(center + Vector2(float(i - 2), float((i % 2) - 1)), r, 0.0, TAU, 34, Color(0.08, 0.08, 0.08, 0.055), 1.0)

func _draw_hatching_strip(rect: Rect2) -> void:
	draw_rect(rect, Color(1, 1, 1, 0.15), true)
	var x: float = rect.position.x + 10.0
	while x < rect.end.x:
		draw_line(Vector2(x, rect.position.y + rect.size.y), Vector2(x + 22.0, rect.position.y), Color(0.08, 0.08, 0.08, 0.07), 1.0)
		x += 18.0

func _draw_bookshelf(center: Vector2, size: Vector2) -> void:
	var rect: Rect2 = Rect2(center - size * 0.5, size)
	draw_rect(rect, Color(1, 1, 1, 0.45), true)
	for i in range(3):
		draw_rect(rect.grow(-float(i) * 1.5), Color(0.08, 0.08, 0.08, 0.17 - float(i) * 0.04), false, 1.1)
	var x: float = rect.position.x + 8.0
	while x < rect.end.x - 8.0:
		draw_line(Vector2(x, rect.position.y + 5.0), Vector2(x, rect.end.y - 5.0), Color(0.08, 0.08, 0.08, 0.18), 1.0)
		x += 14.0

func _draw_bench(center: Vector2, size: Vector2) -> void:
	var rect: Rect2 = Rect2(center - size * 0.5, size)
	draw_rect(rect, Color(1, 1, 1, 0.50), true)
	for i in range(3):
		draw_rect(rect.grow(-float(i) * 1.3), Color(0.08, 0.08, 0.08, 0.18 - float(i) * 0.04), false, 1.1)
	draw_line(Vector2(rect.position.x + 12, rect.end.y), Vector2(rect.position.x + 18, rect.end.y + 16), Color(0.08, 0.08, 0.08, 0.18), 1.1)
	draw_line(Vector2(rect.end.x - 12, rect.end.y), Vector2(rect.end.x - 18, rect.end.y + 16), Color(0.08, 0.08, 0.08, 0.18), 1.1)

func _draw_paper_scraps(center: Vector2) -> void:
	var offsets: Array = [Vector2(-18, -8), Vector2(10, 6), Vector2(22, -12)]
	for item in offsets:
		var pos: Vector2 = center + item
		var r: Rect2 = Rect2(pos - Vector2(12, 8), Vector2(24, 16))
		draw_rect(r, Color(1, 1, 1, 0.36), true)
		draw_rect(r, Color(0.08, 0.08, 0.08, 0.12), false, 1.0)

func _draw_ink_pool(center: Vector2, rx: float, ry: float) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(28):
		var a: float = TAU * float(i) / 28.0
		var wobble: float = 1.0 + sin(float(i) * 2.2) * 0.09
		points.append(center + Vector2(cos(a) * rx * wobble, sin(a) * ry * wobble))
	draw_colored_polygon(points, Color(0.05, 0.05, 0.05, 0.05))

func _draw_candle_cluster(center: Vector2) -> void:
	for i in range(3):
		var offset: Vector2 = Vector2(float(i * 12), sin(float(i)) * 3.0)
		var base: Rect2 = Rect2(center + offset - Vector2(4, 12), Vector2(8, 16))
		draw_rect(base, Color(1,1,1,0.55), true)
		draw_rect(base, Color(0.08,0.08,0.08,0.14), false, 1.0)
		draw_circle(center + offset + Vector2(0,-14), 2.2, Color(0.08,0.08,0.08,0.16))

func _draw_prop_shadow(center: Vector2, size: Vector2) -> void:
	draw_rect(Rect2(center - size * 0.5 + Vector2(4, 5), size), Color(0.06, 0.06, 0.06, 0.06), true)

func _create_player() -> void:
	player = PlayerScript.new()
	player.global_position = Vector2(320,730)
	player.died.connect(_on_player_died)
	add_child(player)

func _create_spawners() -> void:
	# The village and road are intentionally calm. Regular enemies enter as boss summons in this build.
	spawners.clear()

func _add_spawner(kind: String, pos: Vector2) -> void:

	var spawner = SpawnPointScript.new()
	spawner.configure(kind, player)
	spawner.global_position = pos
	add_child(spawner)
	spawners.append(spawner)


func _create_tutorial_npc() -> void:
	tutorial_npc = TutorialNPCScript.new()
	tutorial_npc.configure(player,"guide","Mentor",[
		{"who":"Mentor","tone":"soft","text":"Então você veio mesmo."},
		{"who":"Mago","tone":"normal","text":"Você fala isso como se eu tivesse opção."},
		{"who":"Mentor","tone":"mocking","text":"Opção sempre tem. Bom senso é que anda raro."},
		{"who":"Mentor","tone":"grave","text":"Antes de atravessar a ponte, olha a vila. Olha direito."},
		{"who":"Mago","tone":"soft","text":"Parece que alguém apagou tudo."},
		{"who":"Mentor","tone":"grave","text":"Foi quase isso. Dracaris roubou a cor aos poucos. Primeiro do campo. Depois do rio. Depois da memória das pessoas."},
		{"who":"Mago","tone":"normal","text":"E os guerreiros que tentaram impedir?"},
		{"who":"Mentor","tone":"grave","text":"Viraram nomes em placas. Espadachins, ladinos, cavaleiros... todos enfrentaram o mesmo problema do mesmo jeito."},
		{"who":"Mago","tone":"mocking","text":"E eu sou o problema novo."},
		{"who":"Mentor","tone":"soft","text":"Você é a variável que Dracaris ainda não mediu."},
		{"who":"Mentor","tone":"normal","text":"Conversa com quem ficou. Depois passa na bancada do mercante. O mundo conta melhor sua história quando você escuta quem sobrou."}
	])
	tutorial_npc.global_position = Vector2(220,730)
	tutorial_npc.interaction_requested.connect(_on_npc_interaction_requested.bind(tutorial_npc))
	add_child(tutorial_npc)

	merchant_npc = TutorialNPCScript.new()
	merchant_npc.configure(player,"merchant","Mercante",[])
	merchant_npc.global_position = Vector2(960,790)
	merchant_npc.interaction_requested.connect(_on_npc_interaction_requested.bind(merchant_npc))
	add_child(merchant_npc)

	bridge_npc = TutorialNPCScript.new()
	bridge_npc.configure(player,"bridge","Vigia",[
		{"who":"Vigia","tone":"shout","text":"Ei! Não atravessa ainda."},
		{"who":"Mago","tone":"normal","text":"A ponte tá quebrada?"},
		{"who":"Vigia","tone":"nervous","text":"A ponte tá ótima. O problema respira."},
		{"who":"Mago","tone":"mocking","text":"Isso ajudou bastante."},
		{"who":"Vigia","tone":"grave","text":"Os monstros dali já não patrulham. Eles esperam ordem."},
		{"who":"Vigia","tone":"nervous","text":"E tem um esqueleto grande na arena. Não fica caçando. Fica olhando."},
		{"who":"Mago","tone":"normal","text":"Olhando o quê?"},
		{"who":"Vigia","tone":"soft","text":"Desde que você chegou? Você."},
		{"who":"Vigia","tone":"rapid","text":"Se ele pular, sai da marca. Se levantar os braços, não atira. Se o chão começar a riscar... corre primeiro e pergunta depois."}
	])
	bridge_npc.global_position = Vector2(2205,730)
	bridge_npc.interaction_requested.connect(_on_npc_interaction_requested.bind(bridge_npc))
	add_child(bridge_npc)

	_create_civilian("elder",Vector2(430,560),[
		{"who":"Velho","tone":"soft","text":"Quando eu era menino, o céu tinha uma cor que doía de tão forte."},
		{"who":"Mago","tone":"normal","text":"Azul?"},
		{"who":"Velho","tone":"soft","text":"É. Azul. Engraçado precisar lembrar o nome antes de lembrar a cor."},
		{"who":"Velho","tone":"grave","text":"Dracaris não roubou só o que a gente via. Roubou o jeito de lembrar."}
	])
	_create_civilian("parent",Vector2(700,930),[
		{"who":"Moradora","tone":"soft","text":"Meu filho acha que as histórias de cor são invenção."},
		{"who":"Mago","tone":"soft","text":"Ele nunca viu nenhuma?"},
		{"who":"Moradora","tone":"grave","text":"Nasceu depois. Pra ele, o mundo sempre foi assim."},
		{"who":"Moradora","tone":"soft","text":"Se você voltar com uma única cor... volta por aqui primeiro."}
	])
	_create_civilian("skeptic",Vector2(930,520),[
		{"who":"Aldeão","tone":"mocking","text":"Mais um herói?"},
		{"who":"Mago","tone":"normal","text":"Não me chamaria disso."},
		{"who":"Aldeão","tone":"mocking","text":"Melhor. Os que gostavam do título viraram estátua sem estátua."},
		{"who":"Aldeão","tone":"normal","text":"Espera... isso em volta de você é magia?"},
		{"who":"Mago","tone":"soft","text":"Agora você ficou interessado."},
		{"who":"Aldeão","tone":"nervous","text":"Agora eu fiquei preocupado de um jeito diferente."}
	])
	_create_civilian("apprentice",Vector2(510,1030),[
		{"who":"Aprendiz","tone":"shout","text":"Você é mago mesmo?!"},
		{"who":"Mago","tone":"mocking","text":"Depende. Tem dívida envolvida?"},
		{"who":"Aprendiz","tone":"rapid","text":"Os espadachins treinavam perto das ruínas. Diziam que magia era truque pra quem não sabia segurar espada."},
		{"who":"Mago","tone":"normal","text":"E onde eles estão?"},
		{"who":"Aprendiz","tone":"soft","text":"...nas ruínas."},
		{"who":"Mago","tone":"mocking","text":"Argumento forte."}
	])

	mini_boss = MiniBossSkeletonScript.new()
	mini_boss.configure(player)
	mini_boss.global_position = Vector2(2990,720)
	mini_boss.intro_cutscene_requested.connect(_start_boss_intro_cutscene)
	mini_boss.defeat_cutscene_requested.connect(_start_boss_defeat_cutscene)
	mini_boss.defeated_event.connect(_on_mini_boss_defeated)
	mini_boss.post_defeat_interaction_requested.connect(_start_post_boss_interaction)
	add_child(mini_boss)

	world_map_board = WorldMapBoardScript.new()
	world_map_board.configure(player)
	world_map_board.global_position = Vector2(3890,700)
	world_map_board.map_requested.connect(_open_world_map)
	add_child(world_map_board)

func _create_civilian(style_id: String, pos: Vector2, lines: Array) -> void:
	var npc = CivilianScript.new()
	npc.configure(player,style_id,lines)
	npc.global_position = pos
	npc.interaction_requested.connect(_on_civilian_interaction)
	add_child(npc)
	civilians.append(npc)


func _create_encounters() -> void:
	encounters.clear()
	exploration_caches.clear()
	# Encounters now live outside the village, in broad field pockets.
	_add_encounter("north_gauntlet","gauntlet",Vector2(1500,360),"normal","ROTA DAS RUÍNAS")
	_add_encounter("south_survival","survival",Vector2(1700,1080),"normal","TRILHA DO POÇO")
	_add_encounter("totem_break","totems",Vector2(1930,520),"normal","SELOS DE DRACARIS")
	_add_encounter("bridge_ambush","ambush",Vector2(1980,920),"normal","EMBOSCADA")

	elite_enemy = EliteReaverScript.new()
	elite_enemy.configure(player)
	elite_enemy.global_position = Vector2(2130,220)
	elite_enemy.engaged.connect(_on_elite_engaged)
	elite_enemy.defeated.connect(_on_elite_defeated)
	add_child(elite_enemy)

	_add_exploration_cache(Vector2(1420,180),6)
	_add_exploration_cache(Vector2(2080,1230),5)

func _add_encounter(id_value: String, kind: String, pos: Vector2, tier: String, title: String) -> void:
	var encounter = EncounterZoneScript.new()
	encounter.configure(id_value,kind,player,tier,title)
	encounter.global_position = pos
	encounter.started.connect(_on_encounter_started)
	encounter.completed.connect(_on_encounter_completed)
	add_child(encounter)
	encounters.append(encounter)

func _add_exploration_cache(pos: Vector2, reward: int) -> void:
	var cache = ExplorationCacheScript.new()
	cache.configure(player,reward)
	cache.global_position = pos
	cache.opened.connect(_on_exploration_cache_opened)
	add_child(cache)
	exploration_caches.append(cache)

func _on_encounter_started(encounter_id: String) -> void:
	if first_branch == "":
		if encounter_id.begins_with("north"):
			first_branch = "Ruínas"
		elif encounter_id.begins_with("south"):
			first_branch = "Poço"
	if encounter_id == "north_gauntlet":
		_show_area_banner("ROTA DAS RUÍNAS")
	elif encounter_id == "south_survival":
		_show_area_banner("TRILHA DO POÇO")
	elif encounter_id == "totem_break":
		_show_area_banner("QUEBRE OS SELOS")
	else:
		_show_area_banner("EMBOSCADA")
	get_tree().call_group("screen_fx","pulse_spawn")

func _on_encounter_completed(encounter_id: String, reward_tier: String) -> void:
	encounter_completed_count += 1
	var reward: int = 5 if reward_tier == "rare" else 3
	add_fragments(reward)
	var source_name: String = "Encontro concluído"
	match encounter_id:
		"north_gauntlet":
			source_name = "Rota das Ruínas"
		"south_survival":
			source_name = "Trilha do Poço"
		"totem_break":
			source_name = "Selos quebrados"
		"bridge_ambush":
			source_name = "Emboscada vencida"
	_queue_trait_reward(reward_tier,source_name)

func _on_elite_engaged() -> void:
	_show_area_banner("CARRASCO DE TINTA  •  ELITE")
	get_tree().call_group("screen_fx","pulse_boss")

func _on_elite_defeated() -> void:
	add_fragments(8)
	encounter_completed_count += 1
	_queue_trait_reward("rare","Carrasco de Tinta")

func _on_exploration_cache_opened(reward: int) -> void:
	add_fragments(reward)
	if is_instance_valid(player):
		player.heal(1)
		player.add_flux(18.0)
	_show_area_banner("ACHADO ARCANO  •  ◆ "+str(reward)+"  •  +1 VIDA")

func _queue_trait_reward(tier: String, source_name: String) -> void:
	pending_trait_rewards.append({"tier":tier,"source":source_name})
	call_deferred("_try_open_next_trait")

func _try_open_next_trait() -> void:
	if pending_trait_rewards.is_empty() or trait_open or cutscene_open or dialogue_open or shop_open or pause_open or death_open or mini_boss_choice_open or world_map_open:
		return
	if not game_started or not is_instance_valid(player) or not player.active:
		return
	var reward: Dictionary = pending_trait_rewards.pop_front()
	_open_trait_selection(str(reward.get("tier","normal")),str(reward.get("source","Encontro")))

func _trait_catalog() -> Array:
	var catalog: Array = []
	match selected_mage_type:
		"storm":
			catalog = [
				{"id":"storm_chain","title":"Corrente Viva","description":"O raio salta para outro inimigo próximo depois do impacto."},
				{"id":"storm_aftershock","title":"Eco do Trovão","description":"Toda descarga deixa uma segunda queda menor no mesmo ponto."},
				{"id":"storm_overcharge","title":"Nuvem Pesada","description":"A conjuração fica um pouco mais longa, mas o raio ganha dano e área."},
				{"id":"storm_twin","title":"Céu Partido","description":"Cada conjuração chama uma descarga menor ao lado do impacto principal."},
				{"id":"storm_dodge_prime","title":"Olho da Tempestade","description":"Esquivar por pouco de um projétil zera a espera do próximo raio."}
			]
		"rift":
			catalog = [
				{"id":"rift_cross","title":"Cruz do Abismo","description":"No meio do caminho a fissura abre dois cortes laterais menores."},
				{"id":"rift_endburst","title":"Fim Violento","description":"O final de cada fissura explode e atinge uma área ao redor."},
				{"id":"rift_gravity","title":"Fenda Gravitacional","description":"Inimigos próximos são puxados para a linha da ruptura."},
				{"id":"rift_reload_guard","title":"Recomposição Hostil","description":"Ao iniciar o reload, uma ruptura defensiva explode ao redor do mago."},
				{"id":"rift_longscar","title":"Cicatriz Longa","description":"A fissura ganha muito mais alcance e atravessa formações maiores."}
			]
		_:
			catalog = [
				{"id":"orbit_split","title":"Estilhaço Gêmeo","description":"Ao acertar, a pedra se parte em dois projéteis menores."},
				{"id":"orbit_ricochet","title":"Ricochete Arcano","description":"O primeiro impacto procura outro alvo próximo e desvia até ele."},
				{"id":"orbit_last_burst","title":"Última Pedra","description":"O sexto disparo do ciclo explode ao atingir algo."},
				{"id":"orbit_reload_burst","title":"Recarga Violenta","description":"Finalizar a recarga libera uma onda de dano ao redor do mago."},
				{"id":"orbit_contact","title":"Órbita Cortante","description":"Pedras ainda orbitando ferem inimigos que chegam perto demais."}
			]
	catalog.append({"id":"generic_vitality","title":"Tinta Vital","description":"Aumenta a vida máxima em 1 e cura imediatamente."})
	catalog.append({"id":"generic_flux","title":"Reservatório Arcano","description":"O Surto Arcano dura mais e fica mais fácil aproveitar o pico de poder."})
	catalog.append({"id":"generic_dash","title":"Passo Rasgado","description":"As cargas de dash voltam mais rapidamente."})
	return catalog

func _open_trait_selection(tier: String, source_name: String) -> void:
	var pool: Array = []
	for entry_value in _trait_catalog():
		var entry: Dictionary = entry_value
		var trait_id: String = str(entry.get("id",""))
		if tier == "rare" and trait_id.begins_with("generic_"):
			continue
		if trait_id != "" and not player.has_trait(trait_id):
			pool.append(entry)
	if pool.is_empty():
		add_fragments(5)
		return
	pool.shuffle()
	while pool.size() < 3:
		pool.append(pool[pool.size()-1])
	trait_open = true
	get_tree().paused = true
	player.active = false
	player.suppress_attack_until_release()
	if is_instance_valid(crosshair):
		crosshair.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	trait_layer = CanvasLayer.new()
	trait_layer.layer = 109
	trait_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(trait_layer)
	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.925,0.90,0.84,0.965)
	trait_layer.add_child(bg)
	var shade: ColorRect = ColorRect.new()
	shade.position = Vector2(0,0)
	shade.size = Vector2(960,540)
	shade.color = Color(0.08,0.08,0.08,0.035)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	trait_layer.add_child(shade)
	var title: Label = Label.new()
	title.position = Vector2(0,38)
	title.size = Vector2(960,38)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = "ESCOLHA UM TRAÇO ARCANO"
	title.add_theme_font_size_override("font_size",24)
	title.add_theme_color_override("font_color",Color("#111111"))
	trait_layer.add_child(title)
	var sub: Label = Label.new()
	sub.position = Vector2(140,78)
	sub.size = Vector2(680,42)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sub.text = source_name+" abriu uma recompensa rara da sua classe. Escolha uma mutação do seu kit." if tier == "rare" else source_name+" abriu uma nova possibilidade para esta tentativa. A escolha muda sua build."
	sub.add_theme_font_size_override("font_size",11)
	sub.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.48))
	trait_layer.add_child(sub)

	for i in range(3):
		var entry: Dictionary = pool[i]
		var card = TraitCardScript.new()
		card.position = Vector2(70+float(i)*278.0,132)
		card.size = Vector2(260,326)
		card.trait_id = str(entry.get("id",""))
		card.title_text = str(entry.get("title","Traço"))
		card.description_text = str(entry.get("description",""))
		card.rarity_text = "TRAÇO RARO" if tier == "rare" else "TRAÇO ARCANO"
		card.class_kind = selected_mage_type
		card.pressed.connect(_choose_trait.bind(card.trait_id,card.title_text))
		card.mouse_entered.connect(_on_ui_hover)
		card.pressed.connect(_on_ui_click)
		trait_layer.add_child(card)

	var hint: Label = Label.new()
	hint.position = Vector2(0,480)
	hint.size = Vector2(960,22)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.text = "Não existe escolha perfeita. Escolhe o que combina com a build que você está montando."
	hint.add_theme_font_size_override("font_size",10)
	hint.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.38))
	trait_layer.add_child(hint)

func _choose_trait(trait_id: String, title_text: String) -> void:
	if not trait_open or not is_instance_valid(player):
		return
	if not player.apply_arcane_trait(trait_id):
		return
	trait_open = false
	if is_instance_valid(trait_layer):
		trait_layer.queue_free()
	get_tree().paused = false
	player.active = true
	player.suppress_attack_until_release()
	if is_instance_valid(crosshair):
		crosshair.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	_show_area_banner("TRAÇO ADQUIRIDO  •  "+title_text.to_upper())
	call_deferred("_try_open_next_trait")

func _create_world_collision() -> void:
	# outer world
	_add_wall(Vector2(2900,45),Vector2(5740,30),false)
	_add_wall(Vector2(2900,1395),Vector2(5740,30),false)
	_add_wall(Vector2(45,720),Vector2(30,1380),false)
	_add_wall(Vector2(5755,720),Vector2(30,1380),false)

	# village houses / props (safe zone, no enemies spawn here)
	_add_wall(Vector2(250,250),Vector2(200,130))
	_add_wall(Vector2(560,230),Vector2(210,140))
	_add_wall(Vector2(930,300),Vector2(190,122))
	_add_wall(Vector2(830,980),Vector2(230,142))
	_add_wall(Vector2(320,1070),Vector2(190,118))
	_add_wall(Vector2(530,760),Vector2(58,58))
	_add_wall(Vector2(1080,185),Vector2(46,110))

	# field props create readable lanes but keep it wide and open
	_add_wall(Vector2(1495,370),Vector2(118,36))
	_add_wall(Vector2(1930,515),Vector2(104,32))
	_add_wall(Vector2(1710,1080),Vector2(120,38))
	_add_wall(Vector2(1390,200),Vector2(70,90),false)
	_add_wall(Vector2(2080,1220),Vector2(80,100),false)

	# river is impassable except across the bridge
	_add_wall(Vector2(2360,330),Vector2(250,510),false)
	_add_wall(Vector2(2360,1095),Vector2(250,510),false)

	# arena ruins
	_add_wall(Vector2(2660,250),Vector2(126,40))
	_add_wall(Vector2(3320,250),Vector2(126,40))
	_add_wall(Vector2(2680,1170),Vector2(150,42))
	_add_wall(Vector2(3310,1170),Vector2(150,42))
	_add_wall(Vector2(2700,680),Vector2(46,140))
	_add_wall(Vector2(3290,760),Vector2(46,130))

	# post-boss corridor gate
	_add_wall(Vector2(3470,290),Vector2(40,480),false)
	_add_wall(Vector2(3470,1160),Vector2(40,360),false)
	post_gate = _add_wall(Vector2(3470,730),Vector2(40,360),false)
	_add_wall(Vector2(3780,1110),Vector2(46,120))
	# Hard divider: normal campaign cannot walk into the developer sandbox.
	_add_wall(Vector2(4385,720),Vector2(34,1380),false)

func _add_wall(pos: Vector2, size: Vector2, draw_visual: bool = true) -> StaticBody2D:
	var wall: StaticBody2D = StaticBody2D.new()
	wall.global_position = pos
	wall.collision_layer = 1
	wall.collision_mask = 0
	wall.z_index = 9
	add_child(wall)
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = size
	collider.shape = shape
	wall.add_child(collider)
	if draw_visual:
		var fill: Polygon2D = Polygon2D.new()
		fill.polygon = _rect_points(size)
		fill.color = Color("#f4efe4")
		wall.add_child(fill)
		for i in range(3):
			var line: Line2D = Line2D.new()
			line.width = 1.2
			line.default_color = Color(0.08,0.08,0.08,0.34 - float(i)*0.06)
			var off: Vector2 = Vector2(float(i-1)*1.2,float((i%2)-1)*1.1)
			line.points = PackedVector2Array([Vector2(-size.x/2.0,-size.y/2.0)+off,Vector2(size.x/2.0,-size.y/2.0)+off,Vector2(size.x/2.0,size.y/2.0)+off,Vector2(-size.x/2.0,size.y/2.0)+off,Vector2(-size.x/2.0,-size.y/2.0)+off])
			wall.add_child(line)
	return wall

func _rect_points(size: Vector2) -> PackedVector2Array:
	return PackedVector2Array([Vector2(-size.x/2.0,-size.y/2.0), Vector2(size.x/2.0,-size.y/2.0), Vector2(size.x/2.0,size.y/2.0), Vector2(-size.x/2.0,size.y/2.0)])

func _create_screen_fx() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 15
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var fx = ScreenFxScript.new()
	fx.position = Vector2.ZERO
	fx.size = Vector2(960, 540)
	fx.process_mode = Node.PROCESS_MODE_ALWAYS
	fx.set_post_fx_enabled(post_fx_enabled)
	layer.add_child(fx)


func _create_hud() -> void:
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 30
	hud_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	hud_layer.visible = false
	add_child(hud_layer)

	hud_widget = HudDisplayScript.new()
	hud_widget.position = Vector2(14,14)
	hud_widget.size = Vector2(300,82)
	hud_widget.configure(player)
	hud_layer.add_child(hud_widget)

	flux_meter = FluxMeterScript.new()
	flux_meter.position = Vector2(360,16)
	flux_meter.size = Vector2(238,48)
	flux_meter.configure(player)
	hud_layer.add_child(flux_meter)

	currency_display = FragmentCounterScript.new()
	currency_display.position = Vector2(840,18)
	currency_display.size = Vector2(104,32)
	currency_display.set_fragments(ink_fragments)
	hud_layer.add_child(currency_display)

	objective_panel = ObjectivePanelScript.new()
	objective_panel.position = Vector2(618,58)
	objective_panel.size = Vector2(326,72)
	objective_panel.set_objective("Fala com o mentor e conhece a Vila Desbotada.","Vila Desbotada")
	hud_layer.add_child(objective_panel)

	boss_bar = BossBarScript.new()
	boss_bar.position = Vector2.ZERO
	boss_bar.size = Vector2(960,64)
	boss_bar.configure(mini_boss)
	hud_layer.add_child(boss_bar)

	controls_hint = Label.new()
	controls_hint.position = Vector2(196,500)
	controls_hint.size = Vector2(568,24)
	controls_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_hint.text = "WASD mover  •  mouse atacar  •  SHIFT dash  •  E interagir  •  ESC pausa"
	controls_hint.add_theme_font_size_override("font_size",11)
	controls_hint.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.46))
	hud_layer.add_child(controls_hint)

	area_banner = Label.new()
	area_banner.position = Vector2(250,72)
	area_banner.size = Vector2(460,42)
	area_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	area_banner.add_theme_font_size_override("font_size",20)
	area_banner.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.82))
	hud_layer.add_child(area_banner)

	crosshair = CrosshairScript.new()
	crosshair.visible = false
	hud_layer.add_child(crosshair)

func _update_hud() -> void:
	if is_instance_valid(hud_widget):
		hud_widget.queue_redraw()
	if is_instance_valid(currency_display):
		currency_display.set_fragments(ink_fragments)
	if is_instance_valid(boss_bar):
		boss_bar.queue_redraw()
	if not is_instance_valid(objective_panel):
		return
	var area_name: String = _get_area_name()
	if admin_mode:
		objective_panel.set_objective("F10 abre o painel ADM. Spawna, troca classe, dá recursos e limpa a arena.",area_name)
		return
	if not lore_seen:
		objective_panel.set_objective("Fala com o mentor e entende por que a vila perdeu a cor.",area_name)
	elif not merchant_met:
		objective_panel.set_objective("Passa na bancada do mercante antes de seguir.",area_name)
	elif encounter_completed_count <= 0:
		objective_panel.set_objective("Escolhe uma rota da vila. Encontros e áreas escondidas podem mudar sua build.",area_name)
	elif not bridge_seen:
		objective_panel.set_objective("Sua build começou a tomar forma. Explora mais ou segue até o Vigia.",area_name)
	elif is_instance_valid(mini_boss) and not mini_boss.battle_started and not mini_boss.defeated:
		objective_panel.set_objective("Atravessa a ponte. O Olheiro está esperando na arena.",area_name)
	elif is_instance_valid(mini_boss) and mini_boss.battle_started and not mini_boss.defeated:
		objective_panel.set_objective("Derruba o Olheiro Distante. Os reforços chegam conforme a luta piora.",area_name)
	elif is_instance_valid(mini_boss) and mini_boss.defeated and not mini_boss_resolved:
		objective_panel.set_objective("Interage com o Olheiro derrotado. O aviso de E permanece até você decidir.",area_name)
	elif mini_boss_resolved and not world_map_seen:
		objective_panel.set_objective("O caminho abriu. Segue pela estrada e examina o mapa adiante.",area_name)
	else:
		objective_panel.set_objective("O mapa revelou as rotas dos Guardiões das Cores.",area_name)

func _get_area_name() -> String:
	if not is_instance_valid(player):
		return ""
	var x: float = player.global_position.x
	if x < 1260.0:
		return "Vila Desbotada"
	if x < 2230.0:
		return "Campos Cinzentos"
	if x < 2550.0:
		return "Ponte do Vigia"
	if x < 3470.0:
		return "Arena do Olheiro"
	if x < 4385.0:
		return "Estrada Cinzenta"
	return "Campo DEV"

func _mage_display_name(kind: String) -> String:
	match kind:
		"storm":
			return "Mago da Tempestade"
		"rift":
			return "Mago da Fenda"
		_:
			return "Mago Orbital"

func _update_area_state() -> void:
	var area: String = _get_area_name()
	if area == "" or area == current_area:
		return
	current_area = area
	_show_area_banner(area.to_upper())

func _show_area_banner(value: String) -> void:
	if not is_instance_valid(area_banner):
		return
	area_banner.text = value
	area_banner.modulate.a = 0.0
	area_banner.position.y = 82.0
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(area_banner,"modulate:a",0.78,0.24)
	tween.parallel().tween_property(area_banner,"position:y",72.0,0.24).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.tween_interval(1.15)
	tween.tween_property(area_banner,"modulate:a",0.0,0.46)

func _create_dialogue_ui() -> void:

	dialogue_layer = CanvasLayer.new()
	dialogue_layer.layer = 60
	dialogue_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	dialogue_layer.visible = false
	add_child(dialogue_layer)

	var shade: ColorRect = ColorRect.new()
	shade.position = Vector2(0, 310)
	shade.size = Vector2(960, 230)
	shade.color = Color(0.08,0.08,0.08,0.08)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dialogue_layer.add_child(shade)

	dialogue_frame = DialogueFrameScript.new()
	dialogue_frame.position = Vector2(66, 334)
	dialogue_frame.size = Vector2(828, 188)
	dialogue_layer.add_child(dialogue_frame)

	dialogue_portrait = DialoguePortraitScript.new()
	dialogue_portrait.position = Vector2(78, 350)
	dialogue_portrait.size = Vector2(112, 132)
	dialogue_layer.add_child(dialogue_portrait)

	var name_plate: PanelContainer = PanelContainer.new()
	name_plate.position = Vector2(210, 348)
	name_plate.size = Vector2(260, 34)
	name_plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var name_style: StyleBoxFlat = StyleBoxFlat.new()
	name_style.bg_color = Color("#151515")
	name_style.border_color = Color(0.05,0.05,0.05,0.75)
	name_style.set_border_width_all(1)
	name_style.corner_radius_top_left = 5
	name_style.corner_radius_top_right = 5
	name_style.corner_radius_bottom_left = 5
	name_style.corner_radius_bottom_right = 5
	name_style.content_margin_left = 12
	name_style.content_margin_right = 12
	name_style.content_margin_top = 5
	name_style.content_margin_bottom = 5
	name_plate.add_theme_stylebox_override("panel", name_style)
	dialogue_layer.add_child(name_plate)

	dialogue_speaker = Label.new()
	dialogue_speaker.text = ""
	dialogue_speaker.add_theme_font_size_override("font_size", 15)
	dialogue_speaker.add_theme_color_override("font_color", Color("#fffdf7"))
	dialogue_speaker.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	dialogue_speaker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_plate.add_child(dialogue_speaker)

	dialogue_tone = ScribbleTextScript.new()
	dialogue_tone.position = Vector2(670, 354)
	dialogue_tone.size = Vector2(180, 20)
	dialogue_tone.centered = true
	dialogue_tone.font_size = 10
	dialogue_tone.jitter_amount = 0.04
	dialogue_tone.ink = Color(0.08,0.08,0.08,0.42)
	dialogue_layer.add_child(dialogue_tone)

	dialogue_text = DialogueTextScript.new()
	dialogue_text.position = Vector2(210, 394)
	dialogue_text.size = Vector2(650, 92)
	dialogue_layer.add_child(dialogue_text)

	dialogue_hint = ScribbleTextScript.new()
	dialogue_hint.position = Vector2(210, 492)
	dialogue_hint.size = Vector2(500, 18)
	dialogue_hint.font_size = 10
	dialogue_hint.jitter_amount = 0.02
	dialogue_hint.ink = Color(0.08,0.08,0.08,0.44)
	dialogue_hint.text = "E / ENTER / ESPAÇO  •  continuar"
	dialogue_layer.add_child(dialogue_hint)

func _open_tutorial_dialogue(lines: Array) -> void:

	_open_dialogue(lines, tutorial_npc, "")

func _open_dialogue(lines: Array, source_npc = null, after_action: String = "") -> void:
	if dialogue_open or pause_open or death_open or shop_open:
		return
	dialogue_open = true
	current_dialogue_source = source_npc
	dialogue_lines = lines
	dialogue_index = 0
	pending_dialogue_action = after_action
	dialogue_layer.visible = true
	_show_dialogue_line(0)
	if is_instance_valid(player):
		player.active = false
	if is_instance_valid(crosshair):
		crosshair.visible = false
	if is_instance_valid(tutorial_npc):
		tutorial_npc.dialogue_open = source_npc == tutorial_npc
	if is_instance_valid(merchant_npc):
		merchant_npc.dialogue_open = source_npc == merchant_npc
	if is_instance_valid(bridge_npc):
		bridge_npc.dialogue_open = source_npc == bridge_npc
	if is_instance_valid(source_npc) and source_npc != tutorial_npc and source_npc != merchant_npc and source_npc != bridge_npc:
		source_npc.set("dialogue_open",true)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _show_dialogue_line(index: int) -> void:
	if index < 0 or index >= dialogue_lines.size():
		return
	var entry = dialogue_lines[index]
	var who: String = ""
	var tone_name: String = "normal"
	var body: String = ""
	if entry is Dictionary:
		who = str(entry.get("who", ""))
		tone_name = str(entry.get("tone", "normal"))
		body = str(entry.get("text", ""))
	else:
		body = str(entry)
	dialogue_speaker.text = who.to_upper()
	dialogue_tone.text = _tone_label(tone_name)
	dialogue_portrait.set_speaker(who, tone_name)
	dialogue_frame.set_line(who, tone_name)
	dialogue_text.start_line(body, tone_name, who)
	get_tree().call_group("audio_bus", "play_dialogue_open")

func _tone_label(tone_name: String) -> String:
	match tone_name:
		"nervous": return "nervoso"
		"rapid": return "falando rápido"
		"shout": return "alto"
		"grave": return "baixo"
		"soft": return "calmo"
		"hurt": return "ferido"
		"mocking": return "irônico"
		_: return ""

func _advance_dialogue() -> void:
	dialogue_index += 1
	if dialogue_index >= dialogue_lines.size():
		_close_dialogue()
	else:
		_show_dialogue_line(dialogue_index)

func _close_dialogue() -> void:
	dialogue_open = false
	dialogue_layer.visible = false
	if is_instance_valid(tutorial_npc):
		tutorial_npc.dialogue_open = false
	if is_instance_valid(merchant_npc):
		merchant_npc.dialogue_open = false
	if is_instance_valid(bridge_npc):
		bridge_npc.dialogue_open = false
	if is_instance_valid(current_dialogue_source) and current_dialogue_source != tutorial_npc and current_dialogue_source != merchant_npc and current_dialogue_source != bridge_npc:
		current_dialogue_source.set("dialogue_open",false)
	current_dialogue_source = null
	if is_instance_valid(player):
		player.suppress_attack_until_release()

	if pending_dialogue_action == "boss_intro_finish":
		pending_dialogue_action = ""
		_finish_boss_intro_cutscene()
		return
	if pending_dialogue_action == "boss_choice":
		pending_dialogue_action = ""
		_open_boss_choice()
		return
	if pending_dialogue_action == "open_shop":
		pending_dialogue_action = ""
		_open_shop()
		return
	if pending_dialogue_action == "build_end":
		pending_dialogue_action = ""
		_show_build_end()
		return

	if is_instance_valid(player) and not death_open and not pause_open and not shop_open and not mini_boss_choice_open and not cutscene_open:
		player.active = true
	if is_instance_valid(crosshair):
		crosshair.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN

func _create_fade_overlay() -> void:



	fade_layer = CanvasLayer.new()
	fade_layer.layer = 120
	fade_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(fade_layer)
	fade_rect = ColorRect.new()
	fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fade_rect.color = Color(0.03,0.03,0.03,0.0)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_layer.add_child(fade_rect)

func _fade_to(alpha: float, duration: float) -> Tween:
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(fade_rect, "color:a", alpha, duration)
	return tween


func _create_main_menu() -> void:
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 80
	menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(menu_layer)

	menu_root = Control.new()
	menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_root.mouse_filter = Control.MOUSE_FILTER_PASS
	menu_layer.add_child(menu_root)

	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color("#ede7db")
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_root.add_child(bg)

	var main_frame: PanelContainer = PanelContainer.new()
	main_frame.position = Vector2(42, 26)
	main_frame.size = Vector2(876, 488)
	main_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var frame_style: StyleBoxFlat = StyleBoxFlat.new()
	frame_style.bg_color = Color("#faf6ee")
	frame_style.border_color = Color(0.08,0.08,0.08,0.16)
	frame_style.set_border_width_all(1)
	frame_style.corner_radius_top_left = 14
	frame_style.corner_radius_top_right = 14
	frame_style.corner_radius_bottom_left = 14
	frame_style.corner_radius_bottom_right = 14
	main_frame.add_theme_stylebox_override("panel", frame_style)
	menu_root.add_child(main_frame)

	menu_main_panel = Control.new()
	menu_main_panel.position = Vector2(42, 26)
	menu_main_panel.size = Vector2(876, 488)
	menu_main_panel.clip_contents = true
	menu_main_panel.mouse_filter = Control.MOUSE_FILTER_PASS
	menu_root.add_child(menu_main_panel)

	menu_settings_panel = Control.new()
	menu_settings_panel.position = Vector2(918, 26)
	menu_settings_panel.size = Vector2(876, 488)
	menu_settings_panel.clip_contents = true
	menu_settings_panel.mouse_filter = Control.MOUSE_FILTER_PASS
	menu_root.add_child(menu_settings_panel)

	var logo: Control = ArcanoLogoScript.new()
	logo.position = Vector2(98, 14)
	logo.size = Vector2(620, 120)
	menu_main_panel.add_child(logo)

	var button_card: PanelContainer = PanelContainer.new()
	button_card.position = Vector2(38, 154)
	button_card.size = Vector2(388, 274)
	button_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var card_style: StyleBoxFlat = StyleBoxFlat.new()
	card_style.bg_color = Color(1,1,1,0.34)
	card_style.border_color = Color(0.08,0.08,0.08,0.10)
	card_style.set_border_width_all(1)
	card_style.corner_radius_top_left = 10
	card_style.corner_radius_top_right = 10
	card_style.corner_radius_bottom_left = 10
	card_style.corner_radius_bottom_right = 10
	button_card.add_theme_stylebox_override("panel", card_style)
	menu_main_panel.add_child(button_card)

	var blob_card: PanelContainer = PanelContainer.new()
	blob_card.position = Vector2(472, 154)
	blob_card.size = Vector2(330, 274)
	blob_card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	blob_card.add_theme_stylebox_override("panel", card_style)
	menu_main_panel.add_child(blob_card)

	play_button = _make_scribble_button("Jogar", Vector2(58, 178), Vector2(348, 64), 24, "", true)
	play_button.pressed.connect(_open_mage_select)
	menu_main_panel.add_child(play_button)

	settings_button = _make_scribble_button("Configurações", Vector2(58, 260), Vector2(348, 64), 20, "", false)
	settings_button.pressed.connect(_open_settings)
	menu_main_panel.add_child(settings_button)

	var quit_btn: Button = _make_scribble_button("Sair do jogo", Vector2(58, 342), Vector2(348, 64), 19, "", false)
	quit_btn.pressed.connect(_quit_game)
	menu_main_panel.add_child(quit_btn)

	menu_blob = MenuBlobScript.new()
	menu_blob.position = Vector2(486, 156)
	menu_blob.size = Vector2(300, 244)
	menu_main_panel.add_child(menu_blob)

	var build_label: Label = Label.new()
	build_label.position = Vector2(586, 458)
	build_label.size = Vector2(252, 18)
	build_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	build_label.text = "PRE-ALPHA " + GAME_VERSION.trim_suffix("-prealpha") + "  •  BUILD " + BUILD_NUMBER
	build_label.add_theme_font_size_override("font_size", 10)
	build_label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.08, 0.34))
	build_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_main_panel.add_child(build_label)

	var settings_title: Label = Label.new()
	settings_title.position = Vector2(62, 34)
	settings_title.size = Vector2(500, 42)
	settings_title.text = "Configurações"
	settings_title.add_theme_font_size_override("font_size", 28)
	settings_title.add_theme_color_override("font_color", Color("#111111"))
	menu_settings_panel.add_child(settings_title)

	var audio_head: Label = _make_settings_heading("Áudio", Vector2(64, 94), Vector2(310, 28))
	menu_settings_panel.add_child(audio_head)
	_create_audio_slider(menu_settings_panel, "Volume geral", 134.0, audio_manager.master_volume, _on_master_changed, 64.0, 330.0)
	_create_audio_slider(menu_settings_panel, "Música", 214.0, audio_manager.music_volume, _on_music_changed, 64.0, 330.0)
	_create_audio_slider(menu_settings_panel, "Efeitos", 294.0, audio_manager.sfx_volume, _on_sfx_changed, 64.0, 330.0)

	var video_head: Label = _make_settings_heading("Vídeo", Vector2(466, 94), Vector2(310, 28))
	menu_settings_panel.add_child(video_head)
	_create_resolution_setting(menu_settings_panel, Vector2(466, 138))
	_create_toggle_setting(menu_settings_panel, "Tela cheia", Vector2(466, 220), fullscreen_enabled, _on_fullscreen_toggled)
	_create_toggle_setting(menu_settings_panel, "Tremor de tela", Vector2(466, 282), screen_shake_enabled, _on_screen_shake_toggled)
	_create_toggle_setting(menu_settings_panel, "Pós-processamento", Vector2(466, 344), post_fx_enabled, _on_post_fx_toggled)

	var back_btn: Button = _make_scribble_button("Voltar", Vector2(288, 414), Vector2(300, 52), 18, "", false)
	back_btn.pressed.connect(_close_settings)
	menu_settings_panel.add_child(back_btn)

	mage_select_panel = Control.new()
	mage_select_panel.position = Vector2(42,26)
	mage_select_panel.size = Vector2(876,488)
	mage_select_panel.clip_contents = true
	mage_select_panel.mouse_filter = Control.MOUSE_FILTER_PASS
	mage_select_panel.visible = false
	menu_root.add_child(mage_select_panel)


	var mage_title: Label = Label.new()
	mage_title.position = Vector2(0,24)
	mage_title.size = Vector2(876,38)
	mage_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mage_title.text = "Escolha o seu mago"
	mage_title.add_theme_font_size_override("font_size",28)
	mage_title.add_theme_color_override("font_color",Color("#111111"))
	mage_select_panel.add_child(mage_title)

	var mage_hint: Label = Label.new()
	mage_hint.position = Vector2(110,64)
	mage_hint.size = Vector2(656,24)
	mage_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mage_hint.text = "Cada um tem silhueta, magia e melhorias próprias."
	mage_hint.add_theme_font_size_override("font_size",13)
	mage_hint.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.52))
	mage_select_panel.add_child(mage_hint)

	_create_mage_choice_card(mage_select_panel,"orbit","Mago Orbital","Seis pedras, tiros diretos e uma recarga que pune quem gasta tudo sem pensar.",Vector2(36,96),true)
	_create_mage_choice_card(mage_select_panel,"storm","Mago da Tempestade","Canaliza por um instante, escolhe o ponto e chama um raio pesado do céu.",Vector2(310,96),false)
	_create_mage_choice_card(mage_select_panel,"rift","Mago da Fenda","Duas fissuras por ciclo. Gaste as duas e recomponha o abismo antes de atacar de novo.",Vector2(584,96),false)

	var mage_back: Button = _make_scribble_button("Voltar", Vector2(308,428), Vector2(260,44),17,"",false)
	mage_back.pressed.connect(_close_mage_select)
	mage_select_panel.add_child(mage_back)

	if is_instance_valid(audio_manager):
		audio_manager.play_menu_music()


func _create_mage_choice_card(parent: Control, kind: String, title_text: String, desc: String, pos: Vector2, primary: bool) -> void:
	var card: PanelContainer = PanelContainer.new()
	card.position = pos
	card.size = Vector2(256,316)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(1,1,1,0.42)
	style.border_color = Color(0.08,0.08,0.08,0.14)
	style.set_border_width_all(1)
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	card.add_theme_stylebox_override("panel",style)
	parent.add_child(card)

	var preview = MagePreviewScript.new()
	preview.mage_type = kind
	preview.position = pos + Vector2(38,8)
	preview.size = Vector2(180,150)
	parent.add_child(preview)

	var title: Label = Label.new()
	title.position = pos + Vector2(16,160)
	title.size = Vector2(224,28)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = title_text
	title.add_theme_font_size_override("font_size",18)
	title.add_theme_color_override("font_color",Color("#111111"))
	parent.add_child(title)

	var description: Label = Label.new()
	description.position = pos + Vector2(18,192)
	description.size = Vector2(220,58)
	description.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	description.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description.text = desc
	description.add_theme_font_size_override("font_size",12)
	description.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.58))
	parent.add_child(description)

	var choose: Button = _make_scribble_button("Escolher",pos+Vector2(28,258),Vector2(200,44),17,"",primary)
	choose.pressed.connect(_select_mage_and_start.bind(kind))
	parent.add_child(choose)

func _create_audio_slider(parent: Control, label_text: String, y: float, value: float, callback: Callable, x: float = 92.0, width: float = 500.0) -> void:
	var label: Label = Label.new()
	label.position = Vector2(x, y)
	label.size = Vector2(width - 70.0, 22)
	label.text = label_text
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color("#111111"))
	parent.add_child(label)

	var slider: HSlider = HSlider.new()
	slider.position = Vector2(x, y + 28)
	slider.size = Vector2(width - 58.0, 20)
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.01
	slider.value = value
	slider.value_changed.connect(callback)
	parent.add_child(slider)

	var value_label: Label = Label.new()
	value_label.position = Vector2(x + width - 52.0, y + 24)
	value_label.size = Vector2(52, 24)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.text = str(int(round(value * 100.0))) + "%"
	value_label.add_theme_font_size_override("font_size", 13)
	value_label.add_theme_color_override("font_color", Color(0.08,0.08,0.08,0.64))
	parent.add_child(value_label)
	slider.value_changed.connect(func(v: float) -> void: value_label.text = str(int(round(v * 100.0))) + "%")
	slider.mouse_entered.connect(_on_ui_hover)
	slider.drag_ended.connect(func(_value_changed: bool) -> void: _on_ui_click())

func _make_settings_heading(value: String, pos: Vector2, heading_size: Vector2) -> Label:
	var label: Label = Label.new()
	label.position = pos
	label.size = heading_size
	label.text = value
	label.add_theme_font_size_override("font_size", 18)
	label.add_theme_color_override("font_color", Color(0.08,0.08,0.08,0.72))
	return label

func _create_resolution_setting(parent: Control, pos: Vector2) -> void:
	var label: Label = Label.new()
	label.position = pos
	label.size = Vector2(300, 22)
	label.text = "Resolução da janela"
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color("#111111"))
	parent.add_child(label)
	var options: OptionButton = OptionButton.new()
	options.position = pos + Vector2(0, 30)
	options.size = Vector2(300, 34)
	for option_index in range(RESOLUTION_OPTIONS.size()):
		var resolution_value: Vector2i = RESOLUTION_OPTIONS[option_index]
		options.add_item(str(resolution_value.x) + " × " + str(resolution_value.y))
	options.select(clampi(resolution_index, 0, RESOLUTION_OPTIONS.size() - 1))
	options.item_selected.connect(_on_resolution_selected)
	options.mouse_entered.connect(_on_ui_hover)
	parent.add_child(options)

func _create_toggle_setting(parent: Control, label_text: String, pos: Vector2, enabled: bool, callback: Callable) -> void:
	var label: Label = Label.new()
	label.position = pos
	label.size = Vector2(220, 28)
	label.text = label_text
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color("#111111"))
	parent.add_child(label)
	var toggle: CheckButton = CheckButton.new()
	toggle.position = pos + Vector2(228, 0)
	toggle.size = Vector2(72, 30)
	toggle.button_pressed = enabled
	toggle.toggled.connect(callback)
	toggle.mouse_entered.connect(_on_ui_hover)
	parent.add_child(toggle)

func _make_scribble_button(label_text: String, pos: Vector2, size: Vector2, font_size: int, subtitle_text: String = "", primary: bool = true) -> Button:
	var button: Button = MenuButtonScript.new()
	button.position = pos
	button.size = size
	button.label_text = label_text
	button.subtitle_text = subtitle_text
	button.primary = primary
	button.font_size = font_size
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_entered.connect(_on_ui_hover)
	button.pressed.connect(_on_ui_click)
	return button

func _on_ui_hover() -> void:
	get_tree().call_group("audio_bus", "play_ui_hover")

func _on_ui_click() -> void:
	get_tree().call_group("audio_bus", "play_ui_click")

func _open_mage_select() -> void:
	if not is_instance_valid(mage_select_panel):
		return
	menu_main_panel.visible = false
	menu_settings_panel.visible = false
	mage_select_panel.visible = true

func _close_mage_select() -> void:
	if is_instance_valid(mage_select_panel):
		mage_select_panel.visible = false
	menu_main_panel.visible = true
	menu_settings_panel.visible = true

func _select_mage_and_start(kind: String) -> void:
	selected_mage_type = kind
	if is_instance_valid(player):
		player.set_mage_type(kind)
	_start_game()

func _open_settings() -> void:
	if settings_open:
		return
	settings_open = true
	var tween: Tween = create_tween()
	tween.tween_property(menu_main_panel, "position:x", -876.0, 0.24)
	tween.parallel().tween_property(menu_settings_panel, "position:x", 42.0, 0.24)

func _close_settings() -> void:
	if not settings_open:
		return
	settings_open = false
	var tween: Tween = create_tween()
	tween.tween_property(menu_main_panel, "position:x", 42.0, 0.24)
	tween.parallel().tween_property(menu_settings_panel, "position:x", 918.0, 0.24)

func _quit_game() -> void:
	get_tree().quit()


func _load_game_settings() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		resolution_index = clampi(int(cfg.get_value("video", "resolution_index", resolution_index)), 0, RESOLUTION_OPTIONS.size() - 1)
		fullscreen_enabled = bool(cfg.get_value("video", "fullscreen", fullscreen_enabled))
		screen_shake_enabled = bool(cfg.get_value("video", "screen_shake", screen_shake_enabled))
		post_fx_enabled = bool(cfg.get_value("video", "post_fx", post_fx_enabled))

func _save_game_settings() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.load("user://settings.cfg")
	cfg.set_value("video", "resolution_index", resolution_index)
	cfg.set_value("video", "fullscreen", fullscreen_enabled)
	cfg.set_value("video", "screen_shake", screen_shake_enabled)
	cfg.set_value("video", "post_fx", post_fx_enabled)
	cfg.save("user://settings.cfg")

func _apply_window_settings() -> void:
	if fullscreen_enabled:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		var target_size: Vector2i = RESOLUTION_OPTIONS[resolution_index]
		DisplayServer.window_set_size(target_size)

func _on_resolution_selected(index: int) -> void:
	resolution_index = clampi(index, 0, RESOLUTION_OPTIONS.size() - 1)
	if not fullscreen_enabled:
		var target_size: Vector2i = RESOLUTION_OPTIONS[resolution_index]
		DisplayServer.window_set_size(target_size)
	_save_game_settings()
	_on_ui_click()

func _on_fullscreen_toggled(value: bool) -> void:
	fullscreen_enabled = value
	_apply_window_settings()
	_save_game_settings()
	_on_ui_click()

func _on_screen_shake_toggled(value: bool) -> void:
	screen_shake_enabled = value
	if is_instance_valid(player):
		player.set_screen_shake_enabled(value)
	_save_game_settings()
	_on_ui_click()

func _on_post_fx_toggled(value: bool) -> void:
	post_fx_enabled = value
	get_tree().call_group("screen_fx","set_post_fx_enabled",value)
	_save_game_settings()
	_on_ui_click()

func _on_master_changed(v: float) -> void:

	if is_instance_valid(audio_manager):
		audio_manager.set_master_volume(v)

func _on_music_changed(v: float) -> void:
	if is_instance_valid(audio_manager):
		audio_manager.set_music_volume(v)

func _on_sfx_changed(v: float) -> void:
	if is_instance_valid(audio_manager):
		audio_manager.set_sfx_volume(v)

func _start_game() -> void:
	if game_started:
		return
	game_started = true
	lore_seen = false
	merchant_met = false
	bridge_seen = false
	encounter_completed_count = 0
	pending_trait_rewards.clear()
	hud_layer.visible = true
	crosshair.visible = true
	var spawn_fx = PlayerSpawnScript.new()
	spawn_fx.global_position = player.global_position
	add_child(spawn_fx)
	player.begin_spawn()
	for spawner in spawners:
		if is_instance_valid(spawner):
			spawner.activate()
	var tween: Tween = create_tween()
	tween.tween_property(menu_root, "modulate:a", 0.0, 0.24)
	await tween.finished
	menu_layer.queue_free()
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	get_tree().call_group("screen_fx", "pulse_spawn")
	if is_instance_valid(audio_manager):
		audio_manager.play_game_music()
	fade_rect.color.a = 0.18
	_fade_to(0.0, 0.24)


func _on_npc_interaction_requested(role: String, lines: Array, source_npc) -> void:
	match role:
		"guide":
			lore_seen = true
			_open_dialogue(lines, source_npc, "")
		"merchant":
			if not merchant_met:
				merchant_met = true
				_open_dialogue([
					{"who":"Mercante", "tone":"shout", "text":"Opa. Mão longe da bolsa."},
					{"who":"Mago", "tone":"normal", "text":"Eu nem encostei."},
					{"who":"Mercante", "tone":"mocking", "text":"Ótimo. Tá aprendendo rápido."},
					{"who":"Mercante", "tone":"normal", "text":"Tá vendo esses cacos pretos que caem dos bichos? Fragmentos."},
					{"who":"Mago", "tone":"normal", "text":"Moeda?"},
					{"who":"Mercante", "tone":"normal", "text":"Moeda, resto de magia, pedaço do que o mundo perdeu... chama do que quiser. Eu aceito."},
					{"who":"Mago", "tone":"mocking", "text":"Conveniente."},
					{"who":"Mercante", "tone":"soft", "text":"Eu sobrevivo sendo conveniente."}
				], source_npc, "open_shop")
			else:
				_open_dialogue([
					{"who":"Mercante", "tone":"normal", "text":"Voltou? Então mostra os fragmentos."}
				], source_npc, "open_shop")
		"bridge":
			bridge_seen = true
			_open_dialogue(lines, source_npc, "")

func _on_civilian_interaction(lines: Array, source) -> void:
	_open_dialogue(lines,source,"")

func _on_mini_boss_defeated() -> void:
	add_fragments(4)

func _show_cutscene_bars() -> void:
	if is_instance_valid(cutscene_layer):
		return
	cutscene_layer = CanvasLayer.new()
	cutscene_layer.layer = 50
	cutscene_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(cutscene_layer)
	var top_bar: ColorRect = ColorRect.new()
	top_bar.name = "TopBar"
	top_bar.position = Vector2(0, -52)
	top_bar.size = Vector2(960, 52)
	top_bar.color = Color(0.03,0.03,0.03,0.92)
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cutscene_layer.add_child(top_bar)
	var bottom_bar: ColorRect = ColorRect.new()
	bottom_bar.name = "BottomBar"
	bottom_bar.position = Vector2(0, 540)
	bottom_bar.size = Vector2(960, 52)
	bottom_bar.color = Color(0.03,0.03,0.03,0.92)
	bottom_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cutscene_layer.add_child(bottom_bar)
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(top_bar, "position:y", 0.0, 0.24).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(bottom_bar, "position:y", 488.0, 0.24).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

func _hide_cutscene_bars() -> void:
	if not is_instance_valid(cutscene_layer):
		return
	var top_bar = cutscene_layer.get_node_or_null("TopBar")
	var bottom_bar = cutscene_layer.get_node_or_null("BottomBar")
	if top_bar == null or bottom_bar == null:
		cutscene_layer.queue_free()
		return
	var layer_to_free: CanvasLayer = cutscene_layer
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(top_bar, "position:y", -52.0, 0.20)
	tween.parallel().tween_property(bottom_bar, "position:y", 540.0, 0.20)
	tween.finished.connect(layer_to_free.queue_free)
	cutscene_layer = null

func _clear_enemy_projectiles() -> void:
	for projectile in get_tree().get_nodes_in_group("enemy_projectile"):
		if is_instance_valid(projectile):
			projectile.queue_free()

func _start_boss_intro_cutscene() -> void:
	if cutscene_open or not is_instance_valid(mini_boss) or not is_instance_valid(player):
		return
	cutscene_open = true
	_show_cutscene_bars()
	_clear_enemy_projectiles()
	get_tree().paused = true
	player.set_cutscene_lock(true)
	player.suppress_attack_until_release()
	if is_instance_valid(crosshair):
		crosshair.visible = false
	if is_instance_valid(audio_manager):
		audio_manager.stop_all_music()
	mini_boss.begin_intro_cutscene()
	get_tree().call_group("audio_bus","play_boss_reveal")
	get_tree().call_group("screen_fx","pulse_boss")
	var target_offset: Vector2 = mini_boss.global_position-player.global_position
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(player.camera,"position",target_offset,0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tween.parallel().tween_property(player.camera,"zoom",Vector2(1.16,1.16),0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tween.parallel().tween_property(mini_boss,"scale",Vector2.ONE,0.62).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(mini_boss,"modulate:a",1.0,0.34)
	await tween.finished
	_open_dialogue(mini_boss.battle_intro_lines,null,"boss_intro_finish")

func _finish_boss_intro_cutscene() -> void:
	if not is_instance_valid(player) or not is_instance_valid(mini_boss):
		return
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(player.camera,"position",Vector2.ZERO,0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tween.parallel().tween_property(player.camera,"zoom",Vector2.ONE,0.45).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	await tween.finished
	mini_boss.finish_intro_cutscene()
	player.set_cutscene_lock(false)
	player.suppress_attack_until_release()
	cutscene_open = false
	_hide_cutscene_bars()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if is_instance_valid(crosshair):
		crosshair.visible = true
	if is_instance_valid(audio_manager):
		audio_manager.play_boss_music()

func _start_boss_defeat_cutscene() -> void:
	if cutscene_open or not is_instance_valid(mini_boss) or not is_instance_valid(player):
		return
	cutscene_open = true
	_show_cutscene_bars()
	_clear_enemy_projectiles()
	get_tree().paused = true
	player.set_cutscene_lock(true)
	player.suppress_attack_until_release()
	if is_instance_valid(crosshair):
		crosshair.visible = false
	if is_instance_valid(audio_manager):
		audio_manager.stop_all_music()
	mini_boss.begin_defeat_cutscene()
	get_tree().call_group("screen_fx","pulse_kill")
	get_tree().call_group("audio_bus","play_boss_fall")
	var target_offset: Vector2 = mini_boss.global_position-player.global_position
	var camera_tween: Tween = create_tween()
	camera_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	camera_tween.tween_property(player.camera,"position",target_offset,0.42).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	camera_tween.parallel().tween_property(player.camera,"zoom",Vector2(1.20,1.20),0.42).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	await camera_tween.finished
	var fall_tween: Tween = create_tween()
	fall_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	fall_tween.tween_property(mini_boss,"defeat_progress",1.0,1.05).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	await fall_tween.finished
	mini_boss.finish_defeat_pose()
	var return_tween: Tween = create_tween()
	return_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	return_tween.tween_property(player.camera,"position",Vector2.ZERO,0.46).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	return_tween.parallel().tween_property(player.camera,"zoom",Vector2.ONE,0.46).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	await return_tween.finished
	player.set_cutscene_lock(false)
	player.suppress_attack_until_release()
	cutscene_open = false
	_hide_cutscene_bars()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if is_instance_valid(crosshair):
		crosshair.visible = true
	if is_instance_valid(audio_manager):
		audio_manager.play_game_music()

func _start_post_boss_interaction() -> void:
	if cutscene_open or mini_boss_resolved or not is_instance_valid(mini_boss) or not is_instance_valid(player):
		return
	cutscene_open = true
	_show_cutscene_bars()
	_clear_enemy_projectiles()
	get_tree().paused = true
	player.set_cutscene_lock(true)
	player.suppress_attack_until_release()
	if is_instance_valid(crosshair):
		crosshair.visible = false
	var target_offset: Vector2 = mini_boss.global_position-player.global_position
	var tween: Tween = create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.tween_property(player.camera,"position",target_offset,0.40).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
	tween.parallel().tween_property(player.camera,"zoom",Vector2(1.14,1.14),0.40)
	await tween.finished
	_open_dialogue(mini_boss.defeated_lines,null,"boss_choice")

func add_fragments(amount: int) -> void:


	ink_fragments += amount

func _spend_fragments(amount: int) -> bool:
	if ink_fragments < amount:
		return false
	ink_fragments -= amount
	return true


func _open_shop() -> void:
	if shop_open or pause_open or death_open or dialogue_open:
		return
	shop_open = true
	if is_instance_valid(player):
		player.active = false
	if is_instance_valid(crosshair):
		crosshair.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	shop_layer = CanvasLayer.new()
	shop_layer.layer = 95
	shop_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(shop_layer)

	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.94,0.91,0.84,0.94)
	shop_layer.add_child(bg)
	var panel: PanelContainer = PanelContainer.new()
	panel.position = Vector2(48,34)
	panel.size = Vector2(864,472)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color("#fbf7ee")
	style.border_color = Color(0.08,0.08,0.08,0.18)
	style.set_border_width_all(1)
	style.corner_radius_top_left = 14
	style.corner_radius_top_right = 14
	style.corner_radius_bottom_left = 14
	style.corner_radius_bottom_right = 14
	panel.add_theme_stylebox_override("panel",style)
	shop_layer.add_child(panel)

	var title: Label = Label.new()
	title.position = Vector2(76,56)
	title.size = Vector2(570,30)
	title.text = "Mercante  /  " + _mage_shop_name()
	title.add_theme_font_size_override("font_size",22)
	title.add_theme_color_override("font_color",Color("#111111"))
	shop_layer.add_child(title)
	var subtitle: Label = Label.new()
	subtitle.position = Vector2(78,90)
	subtitle.size = Vector2(650,42)
	subtitle.text = _mage_shop_subtitle()
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.add_theme_font_size_override("font_size",11)
	subtitle.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.50))
	shop_layer.add_child(subtitle)
	var purse: Label = Label.new()
	purse.position = Vector2(756,58)
	purse.size = Vector2(120,26)
	purse.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	purse.text = "◆  " + str(ink_fragments)
	purse.add_theme_font_size_override("font_size",16)
	purse.add_theme_color_override("font_color",Color("#111111"))
	purse.name = "PurseLabel"
	shop_layer.add_child(purse)

	var catalog: Array = _get_shop_catalog()
	for i in range(catalog.size()):
		var item: Dictionary = catalog[i]
		var pos: Vector2
		if i < 3:
			pos = Vector2(76 + float(i)*270.0,148)
		else:
			pos = Vector2(76 + float(i-3)*270.0,278)
		var kind: String = str(item["kind"])
		var progress: Dictionary = _upgrade_progress(kind)
		var card = ShopItemButtonScript.new()
		card.position = pos
		card.size = Vector2(250,116)
		card.item_title = str(item["title"])
		card.item_description = str(item["description"])
		card.price = int(item["price"])
		card.accent_kind = selected_mage_type
		card.maxed = bool(progress["maxed"])
		card.status_text = str(progress["label"])
		card.set_meta("upgrade_kind",kind)
		card.pressed.connect(_buy_shop_item.bind(kind,int(item["price"])))
		card.mouse_entered.connect(_on_ui_hover)
		card.pressed.connect(_on_ui_click)
		shop_layer.add_child(card)

	var status: Label = Label.new()
	status.position = Vector2(78,410)
	status.size = Vector2(560,22)
	status.text = "Melhorias desta bancada são permanentes durante a tentativa atual."
	status.add_theme_font_size_override("font_size",10)
	status.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.42))
	status.name = "ShopStatus"
	shop_layer.add_child(status)
	var close_btn: Button = _make_scribble_button("Fechar",Vector2(666,420),Vector2(210,42),15,"",false)
	close_btn.pressed.connect(_close_shop)
	shop_layer.add_child(close_btn)

func _mage_shop_name() -> String:
	match selected_mage_type:
		"storm":
			return "Oficina da Tempestade"
		"rift":
			return "Oficina da Fenda"
	return "Oficina Orbital"

func _mage_shop_subtitle() -> String:
	match selected_mage_type:
		"storm":
			return "Condução, alcance e impacto. O raio é lento de preparar, então cada queda precisa valer a abertura."
		"rift":
			return "Duas rupturas por ciclo. Ajuste direção, alcance e recarga sem transformar a Fenda em spam infinito."
	return "Controle as seis pedras: precisão, dano, retorno da órbita e pequenas chances de eco arcano."

func _get_shop_catalog() -> Array:
	match selected_mage_type:
		"storm":
			return [
				{"kind":"storm_tempo","title":"Condutor refinado","description":"Encurta a canalização necessária antes de chamar o raio.","price":7},
				{"kind":"storm_power","title":"Canalização profunda","description":"Aumenta o dano do impacto principal da descarga.","price":10},
				{"kind":"storm_accuracy","title":"Precisão da queda","description":"Reduz o desvio entre a marca escolhida e o ponto real do impacto.","price":6},
				{"kind":"storm_radius","title":"Marca tempestuosa","description":"Expande a área atingida pela queda principal.","price":9},
				{"kind":"trait:storm_chain","title":"Corrente viva","description":"O impacto procura outro inimigo próximo e salta até ele. Muda o comportamento do raio.","price":13},
				{"kind":"relic_storm_burned","title":"Condutor queimado","description":"RELÍQUIA INSTÁVEL: cria uma segunda queda, mas aumenta canalização e imprecisão.","price":12}
			]
		"rift":
			return [
				{"kind":"rift_power","title":"Ruptura afiada","description":"Aumenta o dano causado a cada alvo atravessado pela fissura.","price":10},
				{"kind":"rift_range","title":"Linha instável","description":"Faz a fissura viajar por uma distância maior antes de se fechar.","price":8},
				{"kind":"rift_accuracy","title":"Ângulo firme","description":"Reduz o desvio angular da linha em relação ao ponto da sua mira.","price":6},
				{"kind":"rift_reload","title":"Recarga do abismo","description":"Encurta a recomposição depois de gastar as duas rupturas.","price":9},
				{"kind":"trait:rift_gravity","title":"Fenda gravitacional","description":"A ruptura passa a puxar inimigos próximos para o próprio corte.","price":13},
				{"kind":"relic_rift_voracious","title":"Fenda faminta","description":"RELÍQUIA INSTÁVEL: mais dano, largura e alcance, mas o reload fica bem mais lento.","price":12}
			]
		_:
			return [
				{"kind":"accuracy","title":"Pedras mais estáveis","description":"Reduz o desvio das pedras e deixa os tiros mais fiéis à mira.","price":6},
				{"kind":"orbit_power","title":"Núcleo reforçado","description":"Aumenta o dano individual de cada pedra lançada.","price":10},
				{"kind":"orbit_reload","title":"Recarga ritual","description":"Reconstrói o círculo de pedras mais rapidamente.","price":8},
				{"kind":"orbit_echo","title":"Eco arcano","description":"Chance de repetir um disparo fraco sem gastar outra pedra.","price":9},
				{"kind":"trait:orbit_contact","title":"Órbita cortante","description":"As pedras que ainda orbitam o mago passam a ferir inimigos que encostam nelas.","price":13},
				{"kind":"relic_orbit_hungry","title":"Pedra faminta","description":"RELÍQUIA INSTÁVEL: mais dano por pedra, mas você perde uma pedra e recarrega mais devagar.","price":12}
			]

func _upgrade_progress(kind: String) -> Dictionary:
	if kind.begins_with("trait:"):
		var trait_id: String = kind.trim_prefix("trait:")
		var owned: bool = player.has_trait(trait_id)
		return {"maxed":owned,"label":"TRAÇO ARCANO  •  " + ("ADQUIRIDO" if owned else "ALTERA O KIT")}
	if kind.begins_with("relic_"):
		var relic_owned: bool = player.has_relic(kind)
		return {"maxed":relic_owned,"label":"RELÍQUIA INSTÁVEL  •  " + ("ADQUIRIDA" if relic_owned else "PODER + RISCO")}
	var current: int = 0
	var maximum: int = 1
	match kind:
		"accuracy":
			current = player.accuracy_level
			maximum = player.max_accuracy_level
		"orbit_power":
			current = player.orbit_power_upgrades
			maximum = 2
		"orbit_reload":
			current = player.orbit_reload_upgrades
			maximum = 3
		"orbit_speed":
			current = player.orbit_speed_upgrades
			maximum = 3
		"orbit_echo":
			current = player.orbit_echo_upgrades
			maximum = 3
		"storm_tempo":
			current = player.storm_tempo_upgrades
			maximum = 3
		"storm_power":
			current = player.storm_power_upgrades
			maximum = 2
		"storm_range":
			current = player.storm_range_upgrades
			maximum = 3
		"storm_radius":
			current = player.storm_radius_upgrades
			maximum = 3
		"storm_accuracy":
			current = player.storm_accuracy_upgrades
			maximum = 4
		"rift_power":
			current = player.rift_power_upgrades
			maximum = 2
		"rift_range":
			current = player.rift_range_upgrades
			maximum = 3
		"rift_tempo":
			current = player.rift_tempo_upgrades
			maximum = 3
		"rift_accuracy":
			current = player.rift_accuracy_upgrades
			maximum = 4
		"rift_reload":
			current = player.rift_reload_upgrades
			maximum = 3
	var at_max: bool = current >= maximum
	var prefix: String = "PERMANENTE"
	if at_max:
		prefix = "LIMITE ATINGIDO"
	return {"maxed":at_max,"label":prefix + "  •  " + str(current) + "/" + str(maximum)}

func _buy_shop_item(kind: String, price: int) -> void:
	if not is_instance_valid(player):
		return
	var status = shop_layer.get_node_or_null("ShopStatus") if is_instance_valid(shop_layer) else null
	var can_buy: bool = true
	if kind.begins_with("trait:"):
		can_buy = not player.has_trait(kind.trim_prefix("trait:"))
	elif kind.begins_with("relic_"):
		can_buy = player.can_buy_relic(kind)
	else:
		can_buy = player.can_buy_style_upgrade(kind)
	if not can_buy:
		if status != null:
			status.text = "Essa melhoria já está ativa ou chegou ao limite."
		return
	if ink_fragments < price:
		if status != null:
			status.text = "Fragmentos insuficientes. Você tem ◆ " + str(ink_fragments) + "."
		return
	var applied: bool = false
	if kind.begins_with("trait:"):
		applied = player.apply_arcane_trait(kind.trim_prefix("trait:"))
	elif kind.begins_with("relic_"):
		applied = player.apply_unstable_relic(kind)
	else:
		applied = player.apply_style_upgrade(kind)
	if not applied:
		return
	_spend_fragments(price)
	if status != null:
		status.text = "Melhoria aplicada. Sua build mudou imediatamente."
	if is_instance_valid(shop_layer):
		var purse = shop_layer.get_node_or_null("PurseLabel")
		if purse != null:
			purse.text = "◆  " + str(ink_fragments)
		for child in shop_layer.get_children():
			if child.has_meta("upgrade_kind"):
				var child_kind: String = str(child.get_meta("upgrade_kind"))
				var progress: Dictionary = _upgrade_progress(child_kind)
				child.maxed = bool(progress["maxed"])
				child.disabled = child.maxed
				child.status_text = str(progress["label"])
				child.queue_redraw()

func _close_shop() -> void:


	shop_open = false
	if is_instance_valid(shop_layer):
		shop_layer.queue_free()
	if is_instance_valid(player) and not pause_open and not death_open and not dialogue_open and not mini_boss_choice_open:
		player.active = true
	if is_instance_valid(crosshair):
		crosshair.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN

func _open_boss_choice() -> void:
	mini_boss_choice_open = true
	choice_layer = CanvasLayer.new()
	choice_layer.layer = 98
	choice_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(choice_layer)
	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.95,0.92,0.86,0.92)
	choice_layer.add_child(bg)
	var title: ScribbleTextScript = ScribbleTextScript.new()
	title.position = Vector2(0, 120)
	title.size = Vector2(960, 40)
	title.centered = true
	title.font_size = 24
	title.text = "O que fazer com o Olheiro Distante?"
	title.ink = Color("#111111")
	choice_layer.add_child(title)
	var sub: ScribbleTextScript = ScribbleTextScript.new()
	sub.position = Vector2(0, 158)
	sub.size = Vector2(960, 24)
	sub.centered = true
	sub.font_size = 13
	sub.jitter_amount = 0.08
	sub.text = "Poupar pode render consequências futuras. Finalizar rende mais fragmentos agora."
	sub.ink = Color(0.08,0.08,0.08,0.52)
	choice_layer.add_child(sub)
	var spare: Button = _make_scribble_button("Poupar", Vector2(180,252), Vector2(260,64),20,"Deixar o olheiro viver",true)
	spare.pressed.connect(_resolve_boss_choice.bind(true))
	choice_layer.add_child(spare)
	var finish: Button = _make_scribble_button("Finalizar", Vector2(520,252), Vector2(260,64),20,"Encerrar a missão dele",false)
	finish.pressed.connect(_resolve_boss_choice.bind(false))
	choice_layer.add_child(finish)

func _resolve_boss_choice(spare: bool) -> void:
	mini_boss_choice_open = false
	mini_boss_resolved = true
	spared_guardian = spare
	_save_story_choice()
	if spare:
		add_fragments(4)
	else:
		add_fragments(8)
	if is_instance_valid(choice_layer):
		choice_layer.queue_free()
	if is_instance_valid(mini_boss):
		mini_boss.resolve_outcome(spare)
	if is_instance_valid(post_gate):
		post_gate.queue_free()
		post_gate = null
	if is_instance_valid(world_map_board):
		world_map_board.activate()
	if is_instance_valid(player):
		var tween: Tween = create_tween()
		tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
		tween.tween_property(player.camera,"position",Vector2.ZERO,0.38).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
		tween.parallel().tween_property(player.camera,"zoom",Vector2.ONE,0.38)
		await tween.finished
		player.set_cutscene_lock(false)
		player.suppress_attack_until_release()
	cutscene_open = false
	_hide_cutscene_bars()
	get_tree().paused = false
	if is_instance_valid(crosshair):
		crosshair.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if is_instance_valid(audio_manager):
		audio_manager.play_game_music()
	_show_area_banner("ESTRADA CINZENTA")

func _open_world_map() -> void:
	if world_map_open or not mini_boss_resolved:
		return
	world_map_open = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(player):
		player.active = false
	if is_instance_valid(crosshair):
		crosshair.visible = false
	world_map_layer = CanvasLayer.new()
	world_map_layer.layer = 108
	world_map_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(world_map_layer)
	var panel = WorldMapPanelScript.new()
	panel.position = Vector2.ZERO
	panel.size = Vector2(960,540)
	world_map_layer.add_child(panel)
	var close_btn: Button = _make_scribble_button("Continuar",Vector2(742,470),Vector2(160,42),15,"",true)
	close_btn.pressed.connect(_close_world_map)
	world_map_layer.add_child(close_btn)
	var hint: Label = Label.new()
	hint.position = Vector2(88,478)
	hint.size = Vector2(520,20)
	hint.text = "Passe o mouse pelos pontos do mapa.  •  ESC também fecha."
	hint.add_theme_font_size_override("font_size",10)
	hint.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.42))
	world_map_layer.add_child(hint)

func _close_world_map() -> void:
	if not world_map_open:
		return
	world_map_open = false
	if is_instance_valid(world_map_layer):
		world_map_layer.queue_free()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if not world_map_seen:
		world_map_seen = true
		_open_dialogue([
			{"who":"Mago","tone":"soft","text":"Ruínas dos Espadachins... Refúgio dos Ladinos... Santuário das Cores."},
			{"who":"Mago","tone":"grave","text":"Quatro guardiões entre aqui e o castelo."},
			{"who":"Mago","tone":"mocking","text":"Dracaris podia ter escolhido uma casa mais perto."},
			{"who":"Mago","tone":"soft","text":"Tá. Uma cor de cada vez."}
		],null,"build_end")
		return
	if is_instance_valid(player):
		player.active = true
	if is_instance_valid(crosshair):
		crosshair.visible = true

func _save_story_choice() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.load("user://story_flags.cfg")
	cfg.set_value("choices","olheiro_spared",spared_guardian)
	cfg.set_value("choices","olheiro_resolved",true)
	cfg.save("user://story_flags.cfg")

func _show_build_end() -> void:
	if is_instance_valid(build_end_layer):
		return
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(crosshair):
		crosshair.visible = false
	if is_instance_valid(audio_manager):
		audio_manager.stop_all_music()
	build_end_layer = CanvasLayer.new()
	build_end_layer.layer = 115
	build_end_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(build_end_layer)
	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.935,0.91,0.85,0.98)
	build_end_layer.add_child(bg)
	var panel: PanelContainer = PanelContainer.new()
	panel.position = Vector2(116,64)
	panel.size = Vector2(728,410)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(1,1,1,0.56)
	style.border_color = Color(0.08,0.08,0.08,0.16)
	style.set_border_width_all(1)
	style.corner_radius_top_left = 14
	style.corner_radius_top_right = 14
	style.corner_radius_bottom_left = 14
	style.corner_radius_bottom_right = 14
	panel.add_theme_stylebox_override("panel",style)
	build_end_layer.add_child(panel)
	var title: Label = Label.new()
	title.position = Vector2(160,96)
	title.size = Vector2(640,42)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = "FIM DA PRE-ALPHA"
	title.add_theme_font_size_override("font_size",28)
	title.add_theme_color_override("font_color",Color("#111111"))
	build_end_layer.add_child(title)
	var subtitle: Label = Label.new()
	subtitle.position = Vector2(180,142)
	subtitle.size = Vector2(600,62)
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.text = "O caminho até Dracaris foi revelado. Quatro Guardiões das Cores ainda separam o mago do castelo."
	subtitle.add_theme_font_size_override("font_size",14)
	subtitle.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.64))
	build_end_layer.add_child(subtitle)
	var route: Label = Label.new()
	route.position = Vector2(188,218)
	route.size = Vector2(584,78)
	route.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	route.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	route.text = "Vila Desbotada  →  Ruínas dos Espadachins  →  Refúgio dos Ladinos  →  Santuário das Cores  →  Castelo de Dracaris"
	route.add_theme_font_size_override("font_size",12)
	route.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.48))
	build_end_layer.add_child(route)
	var result: Label = Label.new()
	result.position = Vector2(180,286)
	result.size = Vector2(600,34)
	result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result.text = "O Olheiro foi poupado. Essa escolha foi registrada." if spared_guardian else "O Olheiro foi finalizado. Essa escolha foi registrada."
	result.add_theme_font_size_override("font_size",12)
	result.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.48))
	build_end_layer.add_child(result)
	var run_stats: Label = Label.new()
	run_stats.position = Vector2(150,320)
	run_stats.size = Vector2(660,30)
	run_stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var branch_name: String = first_branch if first_branch != "" else "rota livre"
	var trait_count: int = player.arcane_traits.size() if is_instance_valid(player) else 0
	var surge_count: int = player.flux_activation_count if is_instance_valid(player) else 0
	run_stats.text = "Rota: " + branch_name + "  •  Traços: " + str(trait_count) + "  •  Encontros: " + str(encounter_completed_count) + "  •  Surtos: " + str(surge_count)
	run_stats.add_theme_font_size_override("font_size",10)
	run_stats.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.38))
	build_end_layer.add_child(run_stats)
	var build: Label = Label.new()
	build.position = Vector2(0,352)
	build.size = Vector2(960,20)
	build.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	build.text = "ARCANO " + GAME_VERSION + "  •  BUILD " + BUILD_NUMBER
	build.add_theme_font_size_override("font_size",10)
	build.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.34))
	build_end_layer.add_child(build)
	var again: Button = _make_scribble_button("Jogar novamente",Vector2(230,392),Vector2(238,48),16,"",true)
	again.pressed.connect(_restart_run)
	build_end_layer.add_child(again)
	var menu_btn: Button = _make_scribble_button("Voltar ao menu",Vector2(492,392),Vector2(238,48),16,"",false)
	menu_btn.pressed.connect(_return_to_menu)
	build_end_layer.add_child(menu_btn)

func _draw_grass_patch(rect: Rect2, blades: int) -> void:
	for i in range(blades):
		var x: float = rect.position.x + (rect.size.x / maxf(1.0, float(blades - 1))) * float(i)
		var base_y: float = rect.position.y + rect.size.y * (0.25 + float((i * 17) % 100) / 140.0)
		var sway: float = sin(env_time * 1.8 + float(i) * 0.8) * 3.0
		var h: float = 10.0 + float((i * 13) % 7)
		draw_line(Vector2(x, base_y), Vector2(x + sway, base_y - h), Color(0.08,0.08,0.08,0.12), 1.0)
		if i % 2 == 0:
			draw_line(Vector2(x - 1.5, base_y), Vector2(x + sway * 0.5 - 4.0, base_y - h * 0.74), Color(0.08,0.08,0.08,0.08), 1.0)

func _draw_river_band(rect: Rect2) -> void:
	draw_rect(rect, Color(1,1,1,0.28), true)
	for i in range(12):
		var y: float = rect.position.y + 18.0 + float(i) * 22.0
		var wave: float = sin(env_time * 2.4 + float(i) * 0.7) * 7.0
		draw_line(Vector2(rect.position.x + 10.0, y), Vector2(rect.end.x - 10.0, y + wave), Color(0.08,0.08,0.08,0.08), 1.3)
	for i in range(7):
		var cx: float = rect.position.x + 26.0 + float(i) * 42.0
		var cy: float = rect.position.y + 20.0 + float((i * 37) % 220)
		draw_circle(Vector2(cx, cy), 2.0, Color(0.08,0.08,0.08,0.06))

func _draw_bridge_planks(rect: Rect2) -> void:
	draw_rect(rect, Color(1,1,1,0.54), true)
	for i in range(3):
		draw_rect(rect.grow(-float(i) * 1.5), Color(0.08,0.08,0.08,0.17 - float(i) * 0.04), false, 1.1)
	var x: float = rect.position.x + 10.0
	while x < rect.end.x - 8.0:
		draw_line(Vector2(x, rect.position.y + 10.0), Vector2(x, rect.end.y - 10.0), Color(0.08,0.08,0.08,0.14), 1.0)
		x += 18.0
	draw_line(rect.position + Vector2(0, 10), rect.position + Vector2(rect.size.x, 10), Color(0.08,0.08,0.08,0.18), 1.2)
	draw_line(rect.position + Vector2(0, rect.size.y - 10), rect.position + Vector2(rect.size.x, rect.size.y - 10), Color(0.08,0.08,0.08,0.18), 1.2)

func _draw_reed_patch(center: Vector2, count: int) -> void:
	for i in range(count):
		var off: float = float(i) * 6.0
		var sway: float = sin(env_time * 1.8 + float(i)) * 2.2
		draw_line(center + Vector2(off, 8), center + Vector2(off + sway, -12 - float(i % 3) * 2.0), Color(0.08,0.08,0.08,0.12), 1.0)

func _draw_rock_cluster(center: Vector2, count: int) -> void:
	for i in range(count):
		var off: Vector2 = Vector2(float(i * 9), float((i % 2) * 6))
		_draw_oval(center + off, Vector2(7 + float(i % 3), 5 + float((i + 1) % 2)), Color(0.08,0.08,0.08,0.10))

func _draw_tree_stump(center: Vector2, size: Vector2) -> void:
	var rect: Rect2 = Rect2(center - size * 0.5, size)
	draw_rect(rect, Color(1,1,1,0.45), true)
	for i in range(3):
		draw_rect(rect.grow(-float(i) * 1.2), Color(0.08,0.08,0.08,0.18 - float(i) * 0.04), false, 1.1)
	var y: float = rect.position.y + 10.0
	while y < rect.end.y - 8.0:
		draw_line(Vector2(rect.position.x + 8.0, y), Vector2(rect.end.x - 8.0, y), Color(0.08,0.08,0.08,0.08), 1.0)
		y += 18.0

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)

func _draw_ruin_pillar(center: Vector2, size: Vector2) -> void:
	var rect: Rect2 = Rect2(center - size * 0.5, size)
	draw_rect(rect, Color(1,1,1,0.36), true)
	for i in range(2):
		draw_rect(rect.grow(-float(i) * 1.4), Color(0.08,0.08,0.08,0.14), false, 1.1)
	for i in range(5):
		var x: float = rect.position.x + 10.0 + float(i) * 22.0
		draw_line(Vector2(x, rect.position.y + 4.0), Vector2(x + 10.0, rect.end.y - 4.0), Color(0.08,0.08,0.08,0.08), 1.0)

func _draw_table_prop(center: Vector2, size: Vector2) -> void:
	_draw_bench(center, size)
	for i in range(3):
		var px: float = center.x - 24.0 + float(i) * 24.0
		draw_circle(Vector2(px, center.y - 4.0), 3.0, Color(0.08,0.08,0.08,0.10))

func _draw_lantern_cluster(center: Vector2) -> void:
	_draw_candle_cluster(center)
	for i in range(3):
		draw_arc(center + Vector2(float(i) * 12.0, -16.0), 4.0, 0.0, PI, 10, Color(0.08,0.08,0.08,0.12), 1.0)

func _draw_merchant_rug(rect: Rect2) -> void:
	draw_rect(rect, Color(1,1,1,0.20), true)
	draw_rect(rect, Color(0.08,0.08,0.08,0.14), false, 1.0)
	for i in range(5):
		var x: float = rect.position.x + 8.0 + float(i) * 20.0
		draw_line(Vector2(x, rect.position.y + 8.0), Vector2(x + 8.0, rect.end.y - 8.0), Color(0.08,0.08,0.08,0.07), 1.0)

func _pause_game() -> void:
	if pause_open or dialogue_open or shop_open or mini_boss_choice_open or cutscene_open:
		return
	pause_open = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(crosshair):
		crosshair.visible = false
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 100
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pause_layer)
	var bg: ColorRect = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.95, 0.92, 0.86, 0.92)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.name = "PauseBG"
	pause_layer.add_child(bg)
	_build_pause_main()

func _clear_pause_content() -> void:
	if not is_instance_valid(pause_layer):
		return
	for child in pause_layer.get_children():
		if child.name != "PauseBG":
			child.queue_free()

func _build_pause_main() -> void:
	_clear_pause_content()
	var panel: PanelContainer = PanelContainer.new()
	panel.position = Vector2(266,82)
	panel.size = Vector2(428,390)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(1,1,1,0.64)
	style.border_color = Color(0.08,0.08,0.08,0.16)
	style.set_border_width_all(1)
	style.corner_radius_top_left = 14
	style.corner_radius_top_right = 14
	style.corner_radius_bottom_left = 14
	style.corner_radius_bottom_right = 14
	panel.add_theme_stylebox_override("panel",style)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_layer.add_child(panel)
	var title: Label = Label.new()
	title.position = Vector2(302,110)
	title.size = Vector2(356,38)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = "Pausado"
	title.add_theme_font_size_override("font_size",28)
	title.add_theme_color_override("font_color",Color("#111111"))
	pause_layer.add_child(title)
	var info: Label = Label.new()
	info.position = Vector2(302,150)
	info.size = Vector2(356,24)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.text = _get_area_name() + "  •  " + _mage_display_name(selected_mage_type)
	info.add_theme_font_size_override("font_size",10)
	info.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.40))
	pause_layer.add_child(info)
	var resume: Button = _make_scribble_button("Retomar",Vector2(320,196),Vector2(320,52),18,"",true)
	resume.pressed.connect(_resume_game)
	pause_layer.add_child(resume)
	var restart: Button = _make_scribble_button("Reiniciar tentativa",Vector2(320,258),Vector2(320,52),16,"",false)
	restart.pressed.connect(_restart_run)
	pause_layer.add_child(restart)
	var config: Button = _make_scribble_button("Configurações",Vector2(320,320),Vector2(320,52),16,"",false)
	config.pressed.connect(_build_pause_settings)
	pause_layer.add_child(config)
	var menu_btn: Button = _make_scribble_button("Voltar ao menu",Vector2(320,382),Vector2(320,52),16,"",false)
	menu_btn.pressed.connect(_return_to_menu)
	pause_layer.add_child(menu_btn)

func _build_pause_settings() -> void:
	_clear_pause_content()
	var settings_root: Control = Control.new()
	settings_root.name = "PauseSettingsRoot"
	settings_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_root.mouse_filter = Control.MOUSE_FILTER_PASS
	settings_root.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_layer.add_child(settings_root)

	var title: Label = Label.new()
	title.position = Vector2(0, 62)
	title.size = Vector2(960, 42)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = "Configurações"
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color("#111111"))
	settings_root.add_child(title)

	settings_root.add_child(_make_settings_heading("Áudio", Vector2(92, 126), Vector2(310, 28)))
	_create_audio_slider(settings_root, "Volume geral", 164.0, audio_manager.master_volume, _on_master_changed, 92.0, 330.0)
	_create_audio_slider(settings_root, "Música", 242.0, audio_manager.music_volume, _on_music_changed, 92.0, 330.0)
	_create_audio_slider(settings_root, "Efeitos", 320.0, audio_manager.sfx_volume, _on_sfx_changed, 92.0, 330.0)

	settings_root.add_child(_make_settings_heading("Vídeo", Vector2(526, 126), Vector2(310, 28)))
	_create_resolution_setting(settings_root, Vector2(526, 168))
	_create_toggle_setting(settings_root, "Tela cheia", Vector2(526, 250), fullscreen_enabled, _on_fullscreen_toggled)
	_create_toggle_setting(settings_root, "Tremor de tela", Vector2(526, 312), screen_shake_enabled, _on_screen_shake_toggled)
	_create_toggle_setting(settings_root, "Pós-processamento", Vector2(526, 374), post_fx_enabled, _on_post_fx_toggled)

	var back: Button = _make_scribble_button("Voltar", Vector2(330, 430), Vector2(300, 48), 18, "", false)
	back.pressed.connect(_build_pause_main)
	settings_root.add_child(back)

func _resume_game() -> void:


	pause_open = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if is_instance_valid(crosshair):
		crosshair.visible = true
	if is_instance_valid(pause_layer):
		pause_layer.queue_free()

func _on_player_died() -> void:
	if death_open:
		return
	death_open = true
	dialogue_open = false
	if is_instance_valid(dialogue_layer):
		dialogue_layer.visible = false
	if is_instance_valid(crosshair):
		crosshair.visible = false
	var tween: Tween = _fade_to(0.90, 0.36)
	await tween.finished
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_show_death_screen()


func _show_death_screen() -> void:
	death_layer = CanvasLayer.new()
	death_layer.layer = 110
	death_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(death_layer)
	var title: ScribbleTextScript = ScribbleTextScript.new()
	title.position = Vector2(0,118)
	title.size = Vector2(960,64)
	title.centered = true
	title.font_size = 44
	title.text = "VOCÊ CAIU"
	title.ink = Color("#111111")
	death_layer.add_child(title)
	var subtitle: ScribbleTextScript = ScribbleTextScript.new()
	subtitle.position = Vector2(0,178)
	subtitle.size = Vector2(960,26)
	subtitle.centered = true
	subtitle.font_size = 14
	subtitle.jitter_amount = 0.06
	subtitle.text = "Você caiu antes de chegar a Dracaris."
	subtitle.ink = Color(0.08,0.08,0.08,0.56)
	death_layer.add_child(subtitle)
	var run_info: ScribbleTextScript = ScribbleTextScript.new()
	run_info.position = Vector2(0,218)
	run_info.size = Vector2(960,24)
	run_info.centered = true
	run_info.font_size = 12
	run_info.jitter_amount = 0.04
	run_info.text = _get_area_name() + "  •  " + _mage_display_name(selected_mage_type) + "  •  ◆ " + str(ink_fragments)
	run_info.ink = Color(0.08,0.08,0.08,0.42)
	death_layer.add_child(run_info)
	var retry: Button = _make_scribble_button("Reiniciar",Vector2(320,278),Vector2(320,58),18,"",true)
	retry.pressed.connect(_restart_run)
	death_layer.add_child(retry)
	var menu_btn: Button = _make_scribble_button("Voltar ao menu",Vector2(320,352),Vector2(320,52),18,"",false)
	menu_btn.pressed.connect(_return_to_menu)
	death_layer.add_child(menu_btn)

func _restart_run() -> void:
	get_tree().paused = false
	get_tree().set_meta("arcano_quick_restart",true)
	get_tree().set_meta("arcano_mage_type",selected_mage_type)
	get_tree().reload_current_scene()

func _return_to_menu() -> void:
	get_tree().paused = false
	get_tree().set_meta("arcano_quick_restart",false)
	get_tree().reload_current_scene()


func _draw_shrub_patch(rect: Rect2, bushes: int) -> void:
	for i in range(bushes):
		var px: float = rect.position.x + rect.size.x * float(i + 1) / float(bushes + 1)
		var py: float = rect.position.y + rect.size.y * (0.28 + 0.48 * absf(sin(float(i) * 1.71)))
		var rx: float = 16.0 + fmod(float(i) * 7.0, 8.0)
		var ry: float = 8.0 + fmod(float(i) * 5.0, 5.0)
		_draw_oval(Vector2(px, py), Vector2(rx, ry), Color(0.12, 0.12, 0.12, 0.09))
		for p in range(3):
			var off: Vector2 = Vector2(float(p - 1) * 6.0, sin(float(p + i)) * 1.5)
			draw_arc(Vector2(px, py) + off, rx * 0.55, PI, TAU, 10, Color(0.08, 0.08, 0.08, 0.12), 1.0)

func _draw_cart(center: Vector2, size: Vector2) -> void:
	var body: Rect2 = Rect2(center - size * 0.5, size)
	draw_rect(body, Color(1,1,1,0.34), true)
	draw_rect(body, Color(0.08,0.08,0.08,0.14), false, 1.1)
	for side in [-1.0, 1.0]:
		var wheel: Vector2 = center + Vector2(side * (size.x * 0.34), size.y * 0.55)
		draw_circle(wheel, 9.0, Color(1,1,1,0.28))
		draw_arc(wheel, 9.0, 0.0, TAU, 16, Color(0.08,0.08,0.08,0.18), 1.2)
		draw_line(wheel + Vector2(-6,0), wheel + Vector2(6,0), Color(0.08,0.08,0.08,0.14), 1.0)
		draw_line(wheel + Vector2(0,-6), wheel + Vector2(0,6), Color(0.08,0.08,0.08,0.14), 1.0)

func _draw_rope_flags(a: Vector2, b: Vector2, count: int) -> void:
	draw_line(a, b, Color(0.08,0.08,0.08,0.12), 1.2)
	for i in range(count):
		var t: float = float(i + 1) / float(count + 1)
		var p: Vector2 = a.lerp(b, t)
		var sag: float = 8.0 + sin(env_time * 1.3 + float(i) * 0.7) * 2.5
		var w: float = 8.0 + float(i % 3) * 2.0
		var poly: PackedVector2Array = PackedVector2Array([p, p + Vector2(w, 3), p + Vector2(0, sag)])
		draw_colored_polygon(poly, Color(0.08,0.08,0.08,0.10))

func _draw_window_marks(center: Vector2, size: Vector2, count: int) -> void:
	for i in range(count):
		var xo: float = lerpf(-size.x * 0.25, size.x * 0.25, float(i) / maxf(1.0, float(count - 1)))
		var pos: Vector2 = center + Vector2(xo, -8.0)
		var r: Rect2 = Rect2(pos - Vector2(12, 10), Vector2(24, 20))
		draw_rect(r, Color(1,1,1,0.28), true)
		draw_rect(r, Color(0.08,0.08,0.08,0.12), false, 1.0)

func _draw_bridge_posts(rect: Rect2) -> void:
	var left_x: float = rect.position.x + 20.0
	var right_x: float = rect.end.x - 20.0
	draw_line(Vector2(left_x, rect.position.y + 20), Vector2(left_x, rect.end.y - 20), Color(0.08,0.08,0.08,0.12), 2.0)
	draw_line(Vector2(right_x, rect.position.y + 20), Vector2(right_x, rect.end.y - 20), Color(0.08,0.08,0.08,0.12), 2.0)
	for i in range(6):
		var y: float = rect.position.y + 18.0 + float(i) * (rect.size.y - 36.0) / 5.0
		draw_line(Vector2(left_x, y), Vector2(rect.position.x + rect.size.x * 0.5, y - 8.0), Color(0.08,0.08,0.08,0.08), 1.0)
		draw_line(Vector2(right_x, y), Vector2(rect.position.x + rect.size.x * 0.5, y + 8.0), Color(0.08,0.08,0.08,0.08), 1.0)

func _draw_water_swirl(rect: Rect2, count: int) -> void:
	for i in range(count):
		var x: float = rect.position.x + 26.0 + fmod(float(i) * 31.0 + env_time * 18.0, rect.size.x - 52.0)
		var y: float = rect.position.y + 35.0 + fmod(float(i) * 63.0, rect.size.y - 70.0)
		var rr: float = 6.0 + fmod(float(i) * 5.0, 6.0)
		draw_arc(Vector2(x, y), rr, 0.0, TAU * 0.82, 14, Color(0.08,0.08,0.08,0.07), 1.0)

func _draw_ruin_banner(center: Vector2, size: Vector2) -> void:
	draw_line(center + Vector2(-size.x * 0.5, -size.y * 0.4), center + Vector2(size.x * 0.5, -size.y * 0.4), Color(0.08,0.08,0.08,0.14), 1.6)
	var wobble: float = sin(env_time * 1.6) * 5.0
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(-size.x * 0.42, -size.y * 0.36),
		center + Vector2(size.x * 0.40, -size.y * 0.30),
		center + Vector2(size.x * 0.22, size.y * 0.35 + wobble),
		center + Vector2(-size.x * 0.34, size.y * 0.22 - wobble * 0.3)
	])
	draw_colored_polygon(poly, Color(0.08,0.08,0.08,0.08))
	draw_polyline(PackedVector2Array([poly[0], poly[1], poly[2], poly[3], poly[0]]), Color(0.08,0.08,0.08,0.11), 1.0)

func _draw_wind_lines(rect: Rect2, count: int, speed: float = 1.0) -> void:
	for i in range(count):
		var line_seed: float = float(i) * 17.13
		var x: float = rect.position.x + fmod(env_time * 78.0 * speed + line_seed * 29.0, rect.size.x + 180.0) - 90.0
		var y: float = rect.position.y + 40.0 + fmod(line_seed * 53.0, rect.size.y - 80.0) + sin(env_time * 0.8 + line_seed) * 14.0
		var length_value: float = 30.0 + fmod(line_seed * 11.0, 42.0)
		draw_line(Vector2(x, y), Vector2(x + length_value, y + sin(env_time * 3.0 + line_seed) * 3.0), Color(0.08,0.08,0.08,0.036), 1.1)
		draw_line(Vector2(x + length_value * 0.55, y - 2.0), Vector2(x + length_value, y + 1.5), Color(0.08,0.08,0.08,0.026), 1.0)

func _draw_dust_motes(rect: Rect2, count: int) -> void:
	for i in range(count):
		var mote_seed: float = float(i) * 9.41
		var x: float = rect.position.x + fmod(mote_seed * 67.0 + env_time * (8.0 + fmod(mote_seed, 4.0)), rect.size.x)
		var y: float = rect.position.y + fmod(mote_seed * 41.0 + env_time * (3.0 + fmod(mote_seed, 3.0)), rect.size.y)
		var alpha: float = 0.018 + absf(sin(env_time * 1.2 + mote_seed)) * 0.025
		draw_circle(Vector2(x, y), 1.0 + fmod(mote_seed, 2.0), Color(0.08,0.08,0.08,alpha))


# ------------------------------------------------------------------
# DEV / ADMIN SANDBOX
# ------------------------------------------------------------------
func _toggle_admin_panel() -> void:
	if admin_panel_open:
		_close_admin_panel()
		return
	_open_admin_panel()

func _open_admin_panel() -> void:
	if admin_panel_open:
		return
	admin_panel_open = true
	admin_previous_paused = get_tree().paused
	get_tree().paused = true
	if is_instance_valid(player):
		player.active = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	admin_layer = CanvasLayer.new()
	admin_layer.layer = 220
	admin_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(admin_layer)

	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02,0.02,0.02,0.68)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	admin_layer.add_child(dim)

	var panel: Panel = Panel.new()
	panel.position = Vector2(110,58)
	panel.size = Vector2(740,424)
	panel.process_mode = Node.PROCESS_MODE_ALWAYS
	admin_layer.add_child(panel)

	var title: Label = Label.new()
	title.position = Vector2(28,18)
	title.size = Vector2(684,32)
	title.text = "ARCANO  •  DEV SANDBOX"
	title.add_theme_font_size_override("font_size",22)
	panel.add_child(title)

	admin_status_label = Label.new()
	admin_status_label.position = Vector2(30,55)
	admin_status_label.size = Vector2(680,25)
	admin_status_label.text = "Ferramenta interna. Código necessário." if not admin_unlocked else "ADM desbloqueado  •  F10 fecha o painel"
	admin_status_label.add_theme_font_size_override("font_size",11)
	panel.add_child(admin_status_label)

	if not admin_unlocked:
		admin_code_input = LineEdit.new()
		admin_code_input.position = Vector2(30,105)
		admin_code_input.size = Vector2(430,42)
		admin_code_input.placeholder_text = "Código ADM"
		admin_code_input.secret = true
		admin_code_input.text_submitted.connect(_try_unlock_admin)
		panel.add_child(admin_code_input)
		var unlock: Button = Button.new()
		unlock.position = Vector2(478,105)
		unlock.size = Vector2(160,42)
		unlock.text = "DESBLOQUEAR"
		unlock.pressed.connect(_try_unlock_admin.bind(""))
		panel.add_child(unlock)
		var help: Label = Label.new()
		help.position = Vector2(30,164)
		help.size = Vector2(650,28)
		help.text = "Atalho: F10  •  código desta build: ARCANO"
		help.add_theme_font_size_override("font_size",10)
		panel.add_child(help)
		admin_code_input.grab_focus()
		return

	_create_admin_controls(panel)

func _try_unlock_admin(submitted: String = "") -> void:
	var value: String = submitted
	if value == "" and is_instance_valid(admin_code_input):
		value = admin_code_input.text
	if value.strip_edges().to_upper() != ADMIN_CODE:
		if is_instance_valid(admin_status_label):
			admin_status_label.text = "Código inválido."
		return
	admin_unlocked = true
	_close_admin_panel(false)
	call_deferred("_open_admin_panel")

func _create_admin_controls(panel: Control) -> void:
	var left_x: float = 30.0
	var mid_x: float = 265.0
	var right_x: float = 500.0
	var y: float = 96.0
	_admin_button(panel,"ENTRAR NO CAMPO DEV",Vector2(left_x,y),Vector2(205,36),_admin_enter_sandbox)
	_admin_button(panel,"VOLTAR AO MAPA",Vector2(mid_x,y),Vector2(205,36),_admin_leave_sandbox)
	_admin_button(panel,"LIMPAR ARENA",Vector2(right_x,y),Vector2(205,36),_admin_clear_spawned)
	y += 50.0
	_admin_button(panel,"Spawn Slime",Vector2(left_x,y),Vector2(205,34),_admin_spawn_enemy.bind("slime"))
	_admin_button(panel,"Spawn Esqueleto",Vector2(mid_x,y),Vector2(205,34),_admin_spawn_enemy.bind("skeleton"))
	_admin_button(panel,"Spawn Stalker",Vector2(right_x,y),Vector2(205,34),_admin_spawn_enemy.bind("stalker"))
	y += 43.0
	_admin_button(panel,"Spawn Xamã",Vector2(left_x,y),Vector2(205,34),_admin_spawn_enemy.bind("shaman"))
	_admin_button(panel,"Spawn Warder",Vector2(mid_x,y),Vector2(205,34),_admin_spawn_enemy.bind("warder"))
	_admin_button(panel,"Spawn Elite",Vector2(right_x,y),Vector2(205,34),_admin_spawn_elite)
	y += 43.0
	_admin_button(panel,"SPAWN OLHEIRO",Vector2(left_x,y),Vector2(205,34),_admin_spawn_boss)
	_admin_button(panel,"+50 ◆",Vector2(mid_x,y),Vector2(205,34),_admin_add_fragments)
	_admin_button(panel,"Fluxo 100%",Vector2(right_x,y),Vector2(205,34),_admin_fill_flux)
	y += 43.0
	_admin_button(panel,"Cura + recarga",Vector2(left_x,y),Vector2(205,34),_admin_restore_player)
	_admin_button(panel,"GOD MODE",Vector2(mid_x,y),Vector2(205,34),_admin_toggle_god)
	_admin_button(panel,"Traço raro",Vector2(right_x,y),Vector2(205,34),_admin_trait_reward)
	y += 43.0
	_admin_button(panel,"Orbital",Vector2(left_x,y),Vector2(205,34),_admin_set_class.bind("orbit"))
	_admin_button(panel,"Tempestade",Vector2(mid_x,y),Vector2(205,34),_admin_set_class.bind("storm"))
	_admin_button(panel,"Fenda",Vector2(right_x,y),Vector2(205,34),_admin_set_class.bind("rift"))

	var footer: Label = Label.new()
	footer.position = Vector2(30,370)
	footer.size = Vector2(675,28)
	footer.text = "Sandbox isolado do mapa normal. Os spawns aparecem próximos do Luke."
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.add_theme_font_size_override("font_size",10)
	panel.add_child(footer)

func _admin_button(parent: Control, text_value: String, pos: Vector2, button_size: Vector2, callback: Callable) -> void:
	var button: Button = Button.new()
	button.position = pos
	button.size = button_size
	button.text = text_value
	button.process_mode = Node.PROCESS_MODE_ALWAYS
	button.pressed.connect(callback)
	parent.add_child(button)

func _close_admin_panel(restore_pause: bool = true) -> void:
	if not admin_panel_open:
		return
	admin_panel_open = false
	if is_instance_valid(admin_layer):
		admin_layer.queue_free()
	if restore_pause:
		get_tree().paused = admin_previous_paused
	if is_instance_valid(player) and game_started and not get_tree().paused and not death_open:
		player.active = true
		player.suppress_attack_until_release()
	if game_started and not get_tree().paused:
		Input.mouse_mode = Input.MOUSE_MODE_HIDDEN

func _admin_enter_sandbox() -> void:
	if not game_started or not is_instance_valid(player):
		if is_instance_valid(admin_status_label):
			admin_status_label.text = "Inicia uma partida primeiro; depois F10 entra no sandbox."
		return
	admin_return_position = player.global_position
	admin_mode = true
	player.global_position = ADMIN_SPAWN
	player.velocity = Vector2.ZERO
	player.health = player.max_health
	player.collision_layer = 2
	player.refill_dash()
	player.refill_magic()
	if is_instance_valid(boss_bar):
		boss_bar.configure(null)
	_close_admin_panel()
	_show_area_banner("CAMPO DEV  •  F10")

func _admin_leave_sandbox() -> void:
	if not game_started or not is_instance_valid(player):
		return
	_admin_clear_spawned()
	admin_mode = false
	player.global_position = admin_return_position
	player.velocity = Vector2.ZERO
	if is_instance_valid(boss_bar):
		boss_bar.configure(mini_boss)
	_close_admin_panel()
	_show_area_banner("RETORNO AO MAPA")

func _admin_spawn_enemy(kind: String) -> void:
	if not admin_mode or not is_instance_valid(player):
		if is_instance_valid(admin_status_label):
			admin_status_label.text = "Entra no Campo DEV antes de spawnar."
		return
	var enemy = EnemyScript.new()
	enemy.configure(kind,player)
	var angle: float = randf_range(0.0,TAU)
	enemy.global_position = player.global_position + Vector2(cos(angle),sin(angle))*randf_range(150.0,240.0)
	add_child(enemy)
	admin_spawned.append(enemy)

func _admin_spawn_elite() -> void:
	if not admin_mode or not is_instance_valid(player):
		return
	var elite = EliteReaverScript.new()
	elite.configure(player)
	elite.global_position = player.global_position + Vector2(230,0)
	add_child(elite)
	admin_spawned.append(elite)

func _admin_spawn_boss() -> void:
	if not admin_mode or not is_instance_valid(player):
		return
	var boss = MiniBossSkeletonScript.new()
	boss.configure(player)
	boss.global_position = player.global_position + Vector2(300,0)
	add_child(boss)
	boss.intro_requested = true
	boss.finish_intro_cutscene()
	admin_spawned.append(boss)
	if is_instance_valid(boss_bar):
		boss_bar.configure(boss)
	_close_admin_panel()
	_show_area_banner("TESTE  •  OLHEIRO DISTANTE")

func _admin_clear_spawned() -> void:
	for node in admin_spawned:
		if is_instance_valid(node):
			node.queue_free()
	admin_spawned.clear()
	if is_instance_valid(boss_bar):
		boss_bar.configure(null if admin_mode else mini_boss)
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "Arena limpa."

func _admin_add_fragments() -> void:
	add_fragments(50)
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "+50 Fragmentos."

func _admin_fill_flux() -> void:
	if is_instance_valid(player):
		player.add_flux(100.0)
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "Fluxo preenchido."

func _admin_restore_player() -> void:
	if not is_instance_valid(player):
		return
	player.health = player.max_health
	player.collision_layer = 2
	player.active = true
	player.refill_dash()
	player.refill_magic()
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "Vida, dash e magia restaurados."

func _admin_toggle_god() -> void:
	if not is_instance_valid(player):
		return
	player.admin_god_mode = not player.admin_god_mode
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "GOD MODE: "+("ON" if player.admin_god_mode else "OFF")

func _admin_trait_reward() -> void:
	if not game_started:
		return
	_close_admin_panel()
	_queue_trait_reward("rare","ADM")

func _admin_set_class(kind: String) -> void:
	if not is_instance_valid(player):
		return
	selected_mage_type = kind
	player.set_mage_type(kind)
	player.refill_magic()
	if is_instance_valid(admin_status_label):
		admin_status_label.text = "Classe: "+_mage_display_name(kind)
