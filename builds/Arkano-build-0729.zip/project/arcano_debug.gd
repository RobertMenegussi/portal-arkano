extends Node

const LOG_PATH: String = "user://ARCANO_DEBUG.txt"
const SAMPLE_INTERVAL: float = 2.0
const FLUSH_INTERVAL: float = 6.0

var log_file: FileAccess
var sample_timer: float = 0.25
var flush_timer: float = FLUSH_INTERVAL
var last_run_active: bool = false
var low_fps_streak: int = 0
var session_started_msec: int = 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	session_started_msec = Time.get_ticks_msec()
	_open_log()
	var version_info: Dictionary = Engine.get_version_info()
	_write_line("")
	_write_line("============================================================")
	_write_line("ARCANO DEBUG SESSION")
	_write_line("Started: " + Time.get_datetime_string_from_system())
	_write_line("Godot: " + str(version_info.get("string", "unknown")))
	_write_line("OS: " + OS.get_name())
	_write_line("Log: " + LOG_PATH)
	_write_line("============================================================")
	_flush()

func _exit_tree() -> void:
	if log_file != null:
		_write_line("Session ended: " + Time.get_datetime_string_from_system())
		_flush()
		log_file = null

func _process(delta: float) -> void:
	sample_timer -= delta
	flush_timer -= delta

	if sample_timer <= 0.0:
		sample_timer = SAMPLE_INTERVAL
		_sample_game()

	if flush_timer <= 0.0:
		flush_timer = FLUSH_INTERVAL
		_flush()

func _open_log() -> void:
	if FileAccess.file_exists(LOG_PATH):
		log_file = FileAccess.open(LOG_PATH, FileAccess.READ_WRITE)
		if log_file != null:
			log_file.seek_end()
	else:
		log_file = FileAccess.open(LOG_PATH, FileAccess.WRITE)

func _write_line(text: String) -> void:
	if log_file == null:
		return
	log_file.store_line(text)

func _flush() -> void:
	if log_file != null:
		log_file.flush()

func _sample_game() -> void:
	var controller = get_tree().get_first_node_in_group("endless_controller")
	var fps: int = int(round(Engine.get_frames_per_second()))
	var scene_name: String = "none"
	if is_instance_valid(get_tree().current_scene):
		scene_name = str(get_tree().current_scene.name)

	if not is_instance_valid(controller):
		_write_line("[PERF] fps=%d scene=%s run=false" % [fps, scene_name])
		last_run_active = false
		low_fps_streak = 0
		return

	var run_now: bool = bool(controller.run_active)
	if run_now != last_run_active:
		if run_now:
			_write_line("[EVENT] RUN_START class=%s mode=%s" % [str(controller.selected_class), str(controller.attack_target_mode)])
		else:
			_write_line("[EVENT] RUN_END")
		last_run_active = run_now
		_flush()

	if not run_now:
		_write_line("[PERF] fps=%d scene=%s run=false" % [fps, scene_name])
		low_fps_streak = 0
		return
	if get_tree().paused:
		var paused_enemy_count: int = int(controller.registered_enemy_ids.size())
		_write_line("[PERF] fps=%d scene=%s run=true paused=true enemies=%d" % [fps, scene_name, paused_enemy_count])
		low_fps_streak = 0
		return

	var enemy_count: int = int(controller.registered_enemy_ids.size())
	var xp_count: int = int(controller.cached_orb_count)
	var projectile_count: int = get_tree().get_nodes_in_group("enemy_projectile").size()
	var player_projectile_count: int = get_tree().get_nodes_in_group("player_projectile").size()
	var horde_tier: int = int(controller.get_horde_performance_tier()) if controller.has_method("get_horde_performance_tier") else 0
	var xp_tier: int = int(controller.get_xp_performance_tier()) if controller.has_method("get_xp_performance_tier") else horde_tier
	var elapsed_value: float = float(controller.elapsed)
	var level_value: int = int(controller.level)
	var kill_value: int = int(controller.kill_count)
	var class_value: String = str(controller.selected_class)
	var target_mode: String = str(controller.attack_target_mode)

	var hp_text: String = "-"
	var flux_text: String = "-"
	var player_pos: String = "-"
	if is_instance_valid(controller.player):
		var p = controller.player
		hp_text = "%d/%d" % [int(p.health), int(p.max_health)]
		flux_text = "%.1f" % float(p.flux)
		player_pos = "(%.0f,%.0f)" % [p.global_position.x, p.global_position.y]

	var uptime_s: float = float(Time.get_ticks_msec() - session_started_msec) / 1000.0
	_write_line(
		"[PERF] uptime=%.1fs run=%.1fs fps=%d enemies=%d xp=%d eproj=%d pproj=%d tier=%d xptier=%d lvl=%d kills=%d class=%s target=%s hp=%s flux=%s pos=%s"
		% [uptime_s, elapsed_value, fps, enemy_count, xp_count, projectile_count, player_projectile_count, horde_tier, xp_tier, level_value, kill_value, class_value, target_mode, hp_text, flux_text, player_pos]
	)

	if fps < 45:
		low_fps_streak += 1
	else:
		low_fps_streak = 0

	# Two consecutive samples below 45 FPS = useful warning, not one random hitch.
	if low_fps_streak == 2:
		_write_line(
			"[WARN] sustained_low_fps fps=%d enemies=%d xp=%d eproj=%d pproj=%d horde_tier=%d xp_tier=%d"
			% [fps, enemy_count, xp_count, projectile_count, player_projectile_count, horde_tier, xp_tier]
		)
		_flush()
