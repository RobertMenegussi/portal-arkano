extends Node2D

const Catalog = preload("res://endless_catalog.gd")
const RuneEffectScript = preload("res://rune_effect.gd")

var player
var cooldowns: Dictionary = {}
var visual_t: float = 0.0
var last_dash_state: bool = false
var cached_upgrade_count: int = -1
var cached_style_entries: Array = []
var cached_periodic_entries: Array = []
var cached_all_ids: Array[String] = []
var cached_foundation_keys: Dictionary = {}
var cached_controller = null
var visual_redraw_timer: float = 0.0
var acquire_fx_timer: float = 0.0
var acquire_fx_duration: float = 0.82
var acquire_fx_id: String = ""
var acquire_fx_category: String = "ARCANE"

func configure(target) -> void:
	player = target

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 18
	add_to_group("rune_runtime")
	cached_controller = get_tree().get_first_node_in_group("endless_controller")

func _process(delta: float) -> void:
	if not is_instance_valid(player):
		return
	visual_t += delta
	acquire_fx_timer = maxf(0.0, acquire_fx_timer - delta)
	_refresh_style_cache()
	for key in cooldowns.keys():
		cooldowns[key] = maxf(0.0,float(cooldowns[key])-delta)
	for item in cached_periodic_entries:
		var entry: Dictionary = item
		_try_trigger(str(entry.get("id","")),entry)
	visual_redraw_timer -= delta
	if visual_redraw_timer <= 0.0:
		# All Rune ambience is intentionally cheap: one player-local draw pass.
		visual_redraw_timer = 1.0/24.0
		queue_redraw()

func _refresh_style_cache(force: bool = false) -> void:
	if not is_instance_valid(player):
		return
	if not force and cached_upgrade_count == player.endless_upgrades.size():
		return
	cached_upgrade_count = player.endless_upgrades.size()
	cached_style_entries.clear()
	cached_periodic_entries.clear()
	cached_all_ids.clear()
	cached_foundation_keys.clear()
	for id_value in player.endless_upgrades:
		var rune_id: String = str(id_value)
		if rune_id == "":
			continue
		cached_all_ids.append(rune_id)
		if Catalog.is_foundation_rune(rune_id):
			cached_foundation_keys[Catalog.get_offer_key(rune_id)] = true
		var data: Dictionary = Catalog.get_style_data(rune_id)
		if data.is_empty():
			continue
		cached_style_entries.append(data)
		if str(data.get("trigger","")) == "periodic":
			cached_periodic_entries.append(data)

func on_rune_acquired(rune_id: String) -> void:
	_refresh_style_cache(true)
	acquire_fx_id = rune_id
	acquire_fx_category = Catalog.get_category(rune_id)
	acquire_fx_timer = acquire_fx_duration
	queue_redraw()

func on_enemy_killed(_elite: bool = false) -> void:
	_trigger_event("kill")

func on_dash_started() -> void:
	_trigger_event("dash")

func on_player_damaged() -> void:
	_trigger_event("hurt")

func on_basic_attack() -> void:
	_trigger_event("basic")

func _trigger_event(trigger_name: String) -> void:
	if not is_instance_valid(player):
		return
	_refresh_style_cache()
	for item in cached_style_entries:
		var data: Dictionary = item
		if str(data.get("trigger","")) == trigger_name:
			_try_trigger(str(data.get("id","")),data)

func _try_trigger(rune_id: String,data: Dictionary) -> void:
	if float(cooldowns.get(rune_id,0.0)) > 0.0:
		return
	cooldowns[rune_id] = float(data.get("cooldown",4.0))
	_execute(data)

func _execute(data: Dictionary) -> void:
	if not is_instance_valid(player):
		return
	var pattern: String = str(data.get("pattern","nova"))
	var radius: float = float(data.get("radius",120.0))
	var damage: int = int(data.get("damage",1))
	var count_value: int = int(data.get("count",1))
	var accent: int = int(data.get("accent",0))
	var dir: Vector2 = player.aim_direction.normalized() if player.aim_direction.length_squared() > 0.001 else Vector2.RIGHT
	var hit_nodes: Array = []
	var target_points: Array = []
	var visible_pool: Array = _visible_enemies()
	match pattern:
		"nova","aura":
			for enemy in visible_pool:
				if enemy.global_position.distance_squared_to(player.global_position) <= radius*radius:
					hit_nodes.append(enemy)
		"cone":
			var cos_limit: float = cos(0.78)
			for enemy in visible_pool:
				var d: Vector2 = enemy.global_position-player.global_position
				if d.length() <= radius and d.length_squared() > 0.001 and dir.dot(d.normalized()) >= cos_limit:
					hit_nodes.append(enemy)
		"line":
			for enemy in visible_pool:
				var d2: Vector2 = enemy.global_position-player.global_position
				var along: float = d2.dot(dir)
				var side: float = absf(d2.cross(dir))
				if along >= 0.0 and along <= radius and side <= 38.0:
					hit_nodes.append(enemy)
		"orbit":
			var inner: float = radius*0.42
			for enemy in visible_pool:
				var dist: float = enemy.global_position.distance_to(player.global_position)
				if dist >= inner and dist <= radius:
					hit_nodes.append(enemy)
		"bolt":
			var pool: Array = _nearest_from_pool(visible_pool,count_value)
			for enemy in pool:
				hit_nodes.append(enemy)
				target_points.append(enemy.global_position-player.global_position)
		"rain","spiral":
			var pool2: Array = visible_pool.duplicate()
			pool2.shuffle()
			for i in range(mini(count_value+1,pool2.size())):
				hit_nodes.append(pool2[i])
				target_points.append(pool2[i].global_position-player.global_position)
		"mark":
			var best
			var best_hp: float = -1.0
			for enemy in visible_pool:
				var hp: float = float(enemy.get("max_health"))
				if hp > best_hp:
					best_hp = hp
					best = enemy
			if is_instance_valid(best):
				hit_nodes.append(best)
				target_points.append(best.global_position-player.global_position)
		"burst":
			var pool3: Array = _nearest_from_pool(visible_pool,count_value+2)
			for enemy in pool3:
				if enemy.global_position.distance_to(player.global_position) <= radius:
					hit_nodes.append(enemy)
	for enemy in hit_nodes:
		_damage_enemy(enemy,damage)
	_spawn_vfx(str(data.get("id","")),pattern,radius,dir,target_points,accent,count_value)
	get_tree().call_group("audio_bus","play_rune_proc")

func _damage_enemy(enemy,damage: int) -> void:
	if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
		return
	var d: Vector2 = enemy.global_position-player.global_position
	var final_damage: int = damage
	if player.has_method("_roll_endless_damage"):
		final_damage = player._roll_endless_damage(damage)
	enemy.take_damage(maxi(1,final_damage),d.normalized() if d.length_squared() > 0.001 else Vector2.RIGHT)

func _nearest_enemies(limit_value: int) -> Array:
	return _nearest_from_pool(_visible_enemies(),limit_value)

func _nearest_from_pool(pool: Array,limit_value: int) -> Array:
	var source: Array = pool.duplicate()
	var result: Array = []
	while not source.is_empty() and result.size() < limit_value:
		var best_index: int = 0
		var best_distance: float = INF
		for i in range(source.size()):
			var enemy = source[i]
			var distance_value: float = enemy.global_position.distance_squared_to(player.global_position)
			if distance_value < best_distance:
				best_distance = distance_value
				best_index = i
		result.append(source[best_index])
		source.remove_at(best_index)
	return result

func _visible_enemies() -> Array:
	var result: Array = []
	if not is_instance_valid(player):
		return result
	var candidates: Array = get_tree().get_nodes_in_group("enemy")
	if is_instance_valid(cached_controller) and cached_controller.has_method("get_nearby_enemies"):
		candidates = cached_controller.get_nearby_enemies(player.global_position,900.0)
	for enemy in candidates:
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		if enemy.get("dead") == true:
			continue
		if player.has_method("_is_endless_target_on_screen") and not player._is_endless_target_on_screen(enemy):
			continue
		result.append(enemy)
	return result

func _spawn_vfx(rune_id: String,pattern: String,radius: float,dir: Vector2,target_points: Array,accent: int,count_value: int = 1) -> void:
	var fx = RuneEffectScript.new()
	fx.configure(rune_id,pattern,player.global_position,radius,dir,target_points,accent,count_value)
	get_tree().current_scene.add_child(fx)

func _category_color(category: String,alpha: float = 1.0) -> Color:
	match category:
		"DAMAGE": return Color(0.84,0.54,0.50,alpha)
		"WEAPON": return Color(0.91,0.82,0.62,alpha)
		"MOVEMENT": return Color(0.63,0.78,0.88,alpha)
		"SURVIVAL": return Color(0.66,0.82,0.69,alpha)
		"UTILITY": return Color(0.68,0.83,0.84,alpha)
		"CONTROL": return Color(0.75,0.67,0.86,alpha)
		_: return Color(0.92,0.90,0.84,alpha)

func _draw() -> void:
	if not is_instance_valid(player):
		return
	_refresh_style_cache()
	_draw_all_rune_field()
	_draw_foundation_signatures()
	_draw_style_cooldowns()
	_draw_acquire_burst()

func _draw_all_rune_field() -> void:
	var count_all: int = cached_all_ids.size()
	if count_all <= 0:
		return
	var visible_count: int = mini(8,count_all)
	var start_index: int = 0
	if count_all > visible_count:
		start_index = int(floor(visual_t*0.42)) % count_all
	var field_alpha: float = clampf(0.055+float(count_all)*0.004,0.06,0.14)
	for i in range(visible_count):
		var idx: int = (start_index+i) % count_all
		var rune_id: String = cached_all_ids[idx]
		var category: String = Catalog.get_category(rune_id)
		var a: float = visual_t*(0.24+0.018*float(i))+TAU*float(i)/float(visible_count)
		var rr: float = 37.0+float(i%3)*5.5+sin(visual_t*1.6+float(idx))*1.8
		var pos: Vector2 = Vector2(cos(a)*rr,sin(a)*rr*0.63)
		var col: Color = _category_color(category,field_alpha)
		_draw_rune_glyph(pos,rune_id,category,col,0.72)
		var tail_dir: Vector2 = Vector2(-sin(a),cos(a)*0.63).normalized()
		draw_line(pos-tail_dir*7.0,pos-tail_dir*2.4,Color(col.r,col.g,col.b,col.a*0.42),0.8)
	# One almost-invisible orbit keeps many passive Runes feeling like one system.
	draw_arc(Vector2.ZERO,42.0+sin(visual_t*1.3)*1.2,0.0,TAU,42,Color(0.92,0.90,0.84,0.035+field_alpha*0.18),0.8)

func _draw_foundation_signatures() -> void:
	if cached_foundation_keys.is_empty():
		return
	var aim: Vector2 = player.aim_direction.normalized() if player.aim_direction.length_squared() > 0.001 else Vector2.RIGHT
	var side: Vector2 = Vector2(-aim.y,aim.x)
	if cached_foundation_keys.has("vitality"):
		var pulse: float = 0.5+0.5*sin(visual_t*4.6)
		var vc: Color = _category_color("SURVIVAL",0.12+0.08*pulse)
		draw_arc(Vector2.ZERO,27.0+pulse*2.0,-PI*0.80,PI*0.80,30,vc,1.25)
		_draw_diamond(Vector2(0,-29.0-pulse*2.0),2.8,Color(vc.r,vc.g,vc.b,0.28))
	if cached_foundation_keys.has("power"):
		var pc: Color = _category_color("DAMAGE",0.17)
		var p0: Vector2 = aim*31.0
		draw_line(p0-side*5.0,p0+side*5.0,pc,1.2)
		draw_line(p0-aim*4.0,p0+aim*5.5,pc,1.0)
	if cached_foundation_keys.has("tempo"):
		var tc: Color = _category_color("WEAPON",0.14)
		for i in range(3):
			var aa: float = -0.55+float(i)*0.55+sin(visual_t*2.0)*0.03
			draw_arc(Vector2.ZERO,32.0+float(i)*2.2,aa,aa+0.25,8,tc,1.0)
	if cached_foundation_keys.has("move"):
		var motion: Vector2 = player.move_direction.normalized() if player.move_direction.length_squared() > 0.001 else Vector2.ZERO
		if motion.length_squared() > 0.001:
			var mc: Color = _category_color("MOVEMENT",0.13)
			var mside: Vector2 = Vector2(-motion.y,motion.x)
			for i in range(3):
				var base: Vector2 = -motion*(24.0+float(i)*5.0)+mside*(float(i)-1.0)*5.0
				draw_line(base-motion*7.0,base,mc,1.0)
	if cached_foundation_keys.has("magnet"):
		var mag_p: float = fmod(visual_t*0.72,1.0)
		var mag_c: Color = _category_color("UTILITY",0.11*(1.0-mag_p))
		draw_arc(Vector2.ZERO,30.0+mag_p*22.0,0.0,TAU,34,mag_c,0.9)
	if cached_foundation_keys.has("wisdom"):
		var wc: Color = _category_color("UTILITY",0.14)
		for i in range(3):
			var wa: float = visual_t*0.72+TAU*float(i)/3.0
			draw_circle(Vector2(cos(wa)*34.0,sin(wa)*21.0),1.2,wc)
	if cached_foundation_keys.has("dashflow"):
		var dc: Color = _category_color("MOVEMENT",0.13)
		for i in range(2):
			var q: Vector2 = Vector2(-11.0+float(i)*22.0,31.0)
			draw_polyline(PackedVector2Array([q+Vector2(-3,-3),q,q+Vector2(3,-3)]),dc,1.0)
	if cached_foundation_keys.has("omen"):
		var oc: Color = Color(0.96,0.80,0.38,0.16+maxf(0.0,sin(visual_t*2.7))*0.08)
		var oa: float = visual_t*0.44+1.1
		_draw_diamond(Vector2(cos(oa)*38.0,sin(oa)*25.0),2.3,oc)
	if cached_foundation_keys.has("hunter"):
		var hc: Color = _category_color("DAMAGE",0.13)
		var h: Vector2 = aim*40.0
		draw_line(h+Vector2(-5,-5),h+Vector2(-1,-5),hc,1.0)
		draw_line(h+Vector2(5,-5),h+Vector2(1,-5),hc,1.0)
		draw_line(h+Vector2(-5,5),h+Vector2(-1,5),hc,1.0)
		draw_line(h+Vector2(5,5),h+Vector2(1,5),hc,1.0)
	if cached_foundation_keys.has("vision"):
		var vc2: Color = _category_color("UTILITY",0.07)
		draw_arc(Vector2.ZERO,54.0,-PI*0.84,-PI*0.16,22,vc2,0.8)

func _draw_style_cooldowns() -> void:
	var style_count: int = cached_style_entries.size()
	if style_count <= 0:
		return
	var shown: int = mini(5,style_count)
	var start: int = maxi(0,style_count-shown)
	for i in range(shown):
		var entry: Dictionary = cached_style_entries[start+i]
		var rune_id: String = str(entry.get("id",""))
		var duration: float = maxf(0.01,float(entry.get("cooldown",4.0)))
		var remaining: float = clampf(float(cooldowns.get(rune_id,0.0)),0.0,duration)
		var fill: float = 1.0-remaining/duration
		var a: float = -PI*0.78+float(i)*0.31
		var pos: Vector2 = Vector2(cos(a)*50.0,sin(a)*35.0)
		var col: Color = _category_color(Catalog.get_category(rune_id),0.18)
		draw_circle(pos,5.5,Color(0.04,0.04,0.04,0.08))
		draw_arc(pos,5.4,-PI*0.5,-PI*0.5+TAU*fill,14,col,1.15)
		_draw_rune_glyph(pos,rune_id,Catalog.get_category(rune_id),Color(col.r,col.g,col.b,0.16+0.12*fill),0.32)
		if fill >= 0.999:
			var ready_pulse: float = maxf(0.0,sin(visual_t*5.0+float(i)))
			draw_arc(pos,7.2+ready_pulse,0.0,TAU,14,Color(col.r,col.g,col.b,0.05+0.06*ready_pulse),0.8)

func _draw_acquire_burst() -> void:
	if acquire_fx_timer <= 0.0 or acquire_fx_id == "":
		return
	var p: float = 1.0-acquire_fx_timer/acquire_fx_duration
	var fade: float = 1.0-p
	var col: Color = _category_color(acquire_fx_category,0.42*fade)
	var r: float = 18.0+46.0*ease(p,0.72)
	draw_arc(Vector2.ZERO,r,0.0,TAU,44,col,2.0)
	draw_arc(Vector2.ZERO,r*0.72,0.0,TAU,32,Color(0.04,0.04,0.04,0.18*fade),1.0)
	for i in range(8):
		var a: float = TAU*float(i)/8.0+visual_t*0.35
		var q: Vector2 = Vector2(cos(a),sin(a))*r
		_draw_diamond(q,2.0+2.0*fade,Color(col.r,col.g,col.b,0.26*fade))
	_draw_rune_glyph(Vector2.ZERO,acquire_fx_id,acquire_fx_category,Color(col.r,col.g,col.b,0.48*fade),1.1+0.25*(1.0-p))

func _draw_rune_glyph(center: Vector2,rune_id: String,category: String,color: Color,scale_value: float) -> void:
	var hash_value: int = 0
	for char_i in range(rune_id.length()):
		hash_value += rune_id.unicode_at(char_i)*(char_i+1)
	var r: float = 4.2*scale_value
	match category:
		"DAMAGE":
			draw_line(center+Vector2(-r,0),center+Vector2(r,0),color,maxf(0.7,1.2*scale_value))
			draw_line(center+Vector2(0,-r),center+Vector2(0,r),color,maxf(0.7,1.0*scale_value))
		"MOVEMENT":
			draw_polyline(PackedVector2Array([center+Vector2(-r,-r*0.45),center+Vector2(0,r*0.45),center+Vector2(r,-r*0.45)]),color,maxf(0.7,1.0*scale_value))
		"SURVIVAL":
			draw_arc(center,r,0.12,PI-0.12,14,color,maxf(0.7,1.0*scale_value))
			draw_line(center+Vector2(-r,0),center+Vector2(0,r),color,maxf(0.7,0.9*scale_value))
			draw_line(center+Vector2(r,0),center+Vector2(0,r),color,maxf(0.7,0.9*scale_value))
		"UTILITY":
			draw_arc(center,r,0.0,TAU,16,color,maxf(0.7,0.9*scale_value))
			draw_circle(center,maxf(0.7,1.1*scale_value),color)
		"CONTROL":
			draw_line(center+Vector2(-r,-r),center+Vector2(r,r),color,maxf(0.7,0.9*scale_value))
			draw_line(center+Vector2(-r,r),center+Vector2(r,-r),color,maxf(0.7,0.9*scale_value))
		_:
			_draw_diamond(center,r,color)
	if absi(hash_value)%3 == 0:
		draw_circle(center+Vector2(r*0.82,-r*0.78),maxf(0.6,0.8*scale_value),color)

func _draw_diamond(center: Vector2,r: float,color: Color) -> void:
	var poly := PackedVector2Array([center+Vector2(0,-r),center+Vector2(r*0.72,0),center+Vector2(0,r),center+Vector2(-r*0.72,0)])
	draw_colored_polygon(poly,color)
