extends Control

const EndlessCatalog = preload("res://endless_catalog.gd")

var player
var controller
var t: float = 0.0
var redraw_timer: float = 0.0
var selected_rune_id: String = ""
var rune_scroll: int = 0
var rune_hitboxes: Array = []
var rune_list_rect: Rect2 = Rect2()
var detail_rect: Rect2 = Rect2()
var detail_close_rect: Rect2 = Rect2()

func configure(target, owner_controller) -> void:
	player = target
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_process(false)
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_default_cursor_shape = Control.CURSOR_ARROW

func open_panel() -> void:
	selected_rune_id = ""
	var ids: Array = _compact_rune_ids()
	rune_scroll = maxi(0,ids.size()-10)
	if rune_scroll % 2 != 0:
		rune_scroll -= 1
	queue_redraw()

func _process(_delta: float) -> void:
	# TAB is a frozen inspection screen. It should not rebuild dozens of text and
	# draw commands 24 times per second while nothing is changing. Redraws are now
	# event-driven from open/scroll/click/mouse movement.
	return

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		queue_redraw()
		return
	if event is InputEventMouseButton and event.pressed:
		var mouse_pos: Vector2 = event.position
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and selected_rune_id == "" and rune_list_rect.has_point(mouse_pos):
			rune_scroll = maxi(0,rune_scroll-2)
			queue_redraw()
			accept_event()
			return
		if event.button_index == MOUSE_BUTTON_WHEEL_DOWN and selected_rune_id == "" and rune_list_rect.has_point(mouse_pos):
			var ids: Array = _compact_rune_ids()
			var max_start: int = maxi(0,ids.size()-10)
			if max_start % 2 != 0:
				max_start += 1
			rune_scroll = mini(max_start,rune_scroll+2)
			queue_redraw()
			accept_event()
			return
		if event.button_index == MOUSE_BUTTON_LEFT:
			if selected_rune_id != "":
				if detail_close_rect.has_point(mouse_pos) or not detail_rect.has_point(mouse_pos):
					selected_rune_id = ""
					queue_redraw()
					accept_event()
				return
			for entry_value in rune_hitboxes:
				var entry: Dictionary = entry_value
				var rect: Rect2 = entry.get("rect",Rect2())
				if rect.has_point(mouse_pos):
					selected_rune_id = str(entry.get("id",""))
					queue_redraw()
					accept_event()
					return

func _draw() -> void:
	if not is_instance_valid(player) or not is_instance_valid(controller):
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var ink: Color = Color("#f2efe5")
	var faint: Color = Color(0.92,0.91,0.86,0.56)
	var panel := Rect2(Vector2(40,24),Vector2(880,492))
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.015,0.018,0.018,0.46),true)
	draw_rect(panel,Color(0.026,0.032,0.031,0.982),true)
	for i in range(3):
		draw_rect(panel.grow(-float(i)*2.0),Color(1,1,1,0.05-float(i)*0.012),false,1.0)
	for i in range(6):
		var x: float = panel.position.x+24.0+float(i)*146.0
		draw_line(Vector2(x,panel.position.y+56.0),Vector2(x+22.0,panel.position.y+53.0+sin(t*2.0+float(i))*1.5),Color(1,1,1,0.04),1.0)
	draw_string(font,panel.position+Vector2(24,32),Loc.t("tab.build_title"),HORIZONTAL_ALIGNMENT_LEFT,500,21,ink)
	draw_string(font,panel.position+Vector2(24,52),Loc.t("tab.build_sub"),HORIZONTAL_ALIGNMENT_LEFT,720,10,faint)

	var rune_rect := Rect2(panel.position+Vector2(18,72),Vector2(548,392))
	var item_rect := Rect2(panel.position+Vector2(580,72),Vector2(282,392))
	rune_list_rect = rune_rect
	_draw_section(font,rune_rect,Loc.f("stats.runes",[_compact_rune_ids().size()]),ink,faint)
	_draw_section(font,item_rect,Loc.t("hud.relic_details_title"),ink,faint)
	_draw_runes(font,rune_rect,ink,faint)
	_draw_items(font,item_rect,ink,faint)
	draw_string(font,Vector2(panel.position.x+20,panel.end.y-10),Loc.t("tab.build_footer"),HORIZONTAL_ALIGNMENT_LEFT,840,9,faint)
	if selected_rune_id != "":
		_draw_rune_detail(font,panel,ink,faint)

func _draw_section(font,rect: Rect2,title: String,ink: Color,faint: Color) -> void:
	draw_rect(rect,Color(1,1,1,0.03),true)
	draw_rect(rect,Color(1,1,1,0.055),false,1.0)
	draw_string(font,rect.position+Vector2(14,22),title,HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-28,12,ink)
	draw_string(font,Vector2(rect.end.x-14,rect.position.y+22),"◆",HORIZONTAL_ALIGNMENT_RIGHT,16,10,Color(faint.r,faint.g,faint.b,0.36))
	draw_line(rect.position+Vector2(14,31),Vector2(rect.end.x-14,rect.position.y+31),Color(1,1,1,0.065),1.0)

func _compact_rune_ids() -> Array:
	var source: Array = controller.acquired_traits if is_instance_valid(controller) else []
	var result: Array = []
	var family_slot: Dictionary = {}
	for value in source:
		var id: String = str(value)
		var key: String = EndlessCatalog.get_offer_key(id)
		if EndlessCatalog.is_foundation_rune(id):
			if family_slot.has(key):
				result[int(family_slot[key])] = id
			else:
				family_slot[key] = result.size()
				result.append(id)
		else:
			result.append(id)
	return result

func _draw_runes(font,rect: Rect2,ink: Color,faint: Color) -> void:
	rune_hitboxes.clear()
	var ids: Array = _compact_rune_ids()
	if ids.is_empty():
		draw_string(font,rect.position+Vector2(14,58),Loc.t("stats.no_runes"),HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-28,10,faint)
		return
	var shown: int = mini(10,maxi(0,ids.size()-rune_scroll))
	for i in range(shown):
		var col: int = i%2
		var row: int = floori(float(i)/2.0)
		var chip := Rect2(rect.position+Vector2(12+col*266,42+row*62),Vector2(254,55))
		var id: String = str(ids[rune_scroll+i])
		rune_hitboxes.append({"rect":chip,"id":id})
		_draw_rune_chip(font,chip,id,ink,faint)
	if ids.size() > 10:
		var first_shown: int = rune_scroll+1
		var last_shown: int = mini(ids.size(),rune_scroll+shown)
		var page_text: String = Loc.f("tab.rune_scroll",[first_shown,last_shown,ids.size()])
		draw_string(font,Vector2(rect.position.x+14,rect.end.y-12),page_text,HORIZONTAL_ALIGNMENT_LEFT,rect.size.x-28,8,faint)

func _draw_rune_chip(font,rect: Rect2,id: String,ink: Color,faint: Color) -> void:
	var mouse_over: bool = rect.has_point(get_local_mouse_position()) and selected_rune_id == ""
	draw_rect(rect,Color(0,0,0,0.18 if mouse_over else 0.14),true)
	draw_rect(rect,Color(1,1,1,0.10 if mouse_over else 0.05),false,1.0)
	var icon_center: Vector2 = rect.position+Vector2(20,27)
	draw_circle(icon_center,11.0,Color(1,1,1,0.05))
	_draw_rune_icon(icon_center,id,ink)
	var rune_name: String = EndlessCatalog.get_trait_name(id)
	var desc: String = EndlessCatalog.get_description(id,str(player.mage_type))
	var cat: String = EndlessCatalog.get_category_label(EndlessCatalog.get_category(id))
	draw_string(font,rect.position+Vector2(38,16),rune_name,HORIZONTAL_ALIGNMENT_LEFT,145,9,ink)
	draw_string(font,rect.position+Vector2(182,16),cat,HORIZONTAL_ALIGNMENT_RIGHT,62,7,Color(0.78,0.84,0.90,0.58))
	var summary: String = _shorten(desc,60)
	draw_string(font,rect.position+Vector2(38,35),summary,HORIZONTAL_ALIGNMENT_LEFT,200,7,faint)
	draw_string(font,Vector2(rect.end.x-7,rect.end.y-5),Loc.t("tab.expand"),HORIZONTAL_ALIGNMENT_RIGHT,80,6,Color(faint.r,faint.g,faint.b,0.32 if not mouse_over else 0.60))

func _draw_rune_detail(font,panel: Rect2,ink: Color,faint: Color) -> void:
	detail_rect = Rect2(panel.position+Vector2(44,64),Vector2(panel.size.x-88,panel.size.y-112))
	detail_close_rect = Rect2(Vector2(detail_rect.end.x-44,detail_rect.position.y+14),Vector2(28,28))
	draw_rect(Rect2(Vector2.ZERO,size),Color(0.01,0.012,0.012,0.72),true)
	draw_rect(detail_rect,Color(0.030,0.036,0.035,0.995),true)
	draw_rect(detail_rect,Color(1,1,1,0.12),false,1.0)
	var category: String = EndlessCatalog.get_category(selected_rune_id)
	var cat_label: String = EndlessCatalog.get_category_label(category)
	var name_value: String = EndlessCatalog.get_trait_name(selected_rune_id)
	var desc: String = EndlessCatalog.get_description(selected_rune_id,str(player.mage_type))
	var icon_center: Vector2 = detail_rect.position+Vector2(42,50)
	draw_circle(icon_center,22.0,Color(1,1,1,0.05))
	draw_arc(icon_center,22.0,0.0,TAU,28,Color(1,1,1,0.12),1.0)
	_draw_rune_icon(icon_center,selected_rune_id,ink)
	draw_string(font,detail_rect.position+Vector2(78,38),name_value,HORIZONTAL_ALIGNMENT_LEFT,540,22,ink)
	draw_string(font,detail_rect.position+Vector2(80,60),cat_label,HORIZONTAL_ALIGNMENT_LEFT,400,9,Color(0.72,0.82,0.88,0.64))
	draw_rect(detail_close_rect,Color(1,1,1,0.035),true)
	draw_rect(detail_close_rect,Color(1,1,1,0.10),false,1.0)
	draw_string(font,detail_close_rect.position+Vector2(0,19),"×",HORIZONTAL_ALIGNMENT_CENTER,detail_close_rect.size.x,15,ink)
	draw_line(detail_rect.position+Vector2(28,82),Vector2(detail_rect.end.x-28,detail_rect.position.y+82),Color(1,1,1,0.08),1.0)
	var lines: Array[String] = _wrap_text(desc,92,13)
	for i in range(lines.size()):
		draw_string(font,detail_rect.position+Vector2(30,112+float(i)*18.0),lines[i],HORIZONTAL_ALIGNMENT_LEFT,detail_rect.size.x-60,11,Color(0.94,0.93,0.89,0.78))
	var footer_y: float = detail_rect.end.y-24.0
	draw_string(font,Vector2(detail_rect.position.x+30,footer_y),Loc.t("tab.detail_footer"),HORIZONTAL_ALIGNMENT_LEFT,detail_rect.size.x-60,8,faint)

func _draw_items(font,rect: Rect2,ink: Color,faint: Color) -> void:
	var slots: Array = controller.get_consumable_slots() if controller.has_method("get_consumable_slots") else []
	for i in range(10):
		var y: float = rect.position.y+49.0+float(i)*33.0
		var key: String = controller.get_consumable_key_label(i) if controller.has_method("get_consumable_key_label") else str(i+1)
		var item_id: String = str(slots[i]) if i < slots.size() else ""
		var row_rect := Rect2(Vector2(rect.position.x+10,y-16),Vector2(rect.size.x-20,28))
		draw_rect(row_rect,Color(0,0,0,0.12),true)
		draw_rect(row_rect,Color(1,1,1,0.03),false,1.0)
		draw_rect(Rect2(Vector2(rect.position.x+13,y-13),Vector2(24,22)),Color(1,1,1,0.04),true)
		draw_string(font,Vector2(rect.position.x+13,y+3),key,HORIZONTAL_ALIGNMENT_CENTER,24,8,ink)
		if item_id == "":
			draw_string(font,Vector2(rect.position.x+46,y+3),Loc.t("hud.relic_empty"),HORIZONTAL_ALIGNMENT_LEFT,206,8,Color(faint.r,faint.g,faint.b,0.34))
			continue
		var item_name: String = controller.get_consumable_name(item_id) if controller.has_method("get_consumable_name") else item_id
		var desc: String = controller.get_consumable_description(item_id) if controller.has_method("get_consumable_description") else ""
		_draw_item_icon(Vector2(rect.position.x+50,y-2),item_id,ink)
		draw_string(font,Vector2(rect.position.x+64,y-1),item_name,HORIZONTAL_ALIGNMENT_LEFT,180,9,ink)
		draw_string(font,Vector2(rect.position.x+64,y+9),_shorten(desc,52),HORIZONTAL_ALIGNMENT_LEFT,180,7,faint)

func _draw_rune_icon(center: Vector2,id: String,color: Color) -> void:
	var idx: int = 0
	for char_i in range(id.length()):
		idx += id.unicode_at(char_i)*(char_i+1)
	match absi(idx)%6:
		0:
			draw_line(center+Vector2(-6,0),center+Vector2(6,0),color,1.7)
			draw_circle(center+Vector2(4,0),2.2,color)
		1:
			_draw_diamond(center,5.0,color)
		2:
			draw_arc(center,6.0,-1.0,1.0,14,color,1.4)
		3:
			draw_polyline(PackedVector2Array([center+Vector2(-5,4),center+Vector2(-1,-3),center+Vector2(2,2),center+Vector2(6,-5)]),color,1.7)
		4:
			draw_arc(center,6.4,0.0,TAU,18,color,1.2)
			draw_circle(center,2.0,color)
		_:
			draw_line(center+Vector2(-5,-4),center+Vector2(5,4),color,1.5)
			draw_line(center+Vector2(-5,4),center+Vector2(5,-4),color,1.5)

func _draw_item_icon(center: Vector2,item_id: String,color: Color) -> void:
	match item_id:
		"magnet":
			draw_arc(center+Vector2(0,1),5.0,PI*0.12,PI*0.88,16,color,1.8)
			draw_line(center+Vector2(-5,-1),center+Vector2(-5,4),color,1.8)
			draw_line(center+Vector2(5,-1),center+Vector2(5,4),color,1.8)
		"heal":
			draw_line(center+Vector2(-4,0),center+Vector2(4,0),color,1.8)
			draw_line(center+Vector2(0,-4),center+Vector2(0,4),color,1.8)
		_:
			draw_circle(center,2.1,color)

func _draw_diamond(center: Vector2,radius: float,color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([center+Vector2(0,-radius),center+Vector2(radius*0.75,0),center+Vector2(0,radius),center+Vector2(-radius*0.75,0)])
	draw_colored_polygon(poly,color)

func _shorten(value: String,limit: int) -> String:
	var clean: String = value.replace("\n"," ").strip_edges()
	if clean.length() <= limit:
		return clean
	return clean.substr(0,maxi(1,limit-1)).strip_edges()+"…"

func _wrap_text(value: String,max_chars: int,max_lines: int) -> Array[String]:
	var clean: String = value.replace("\n"," ").strip_edges()
	var result: Array[String] = []
	var current: String = ""
	for word_value in clean.split(" ",false):
		var word: String = str(word_value)
		var candidate: String = word if current == "" else current+" "+word
		if candidate.length() <= max_chars:
			current = candidate
		else:
			if current != "":
				result.append(current)
			current = word
			if result.size() >= max_lines:
				break
	if result.size() < max_lines and current != "":
		result.append(current)
	if result.size() >= max_lines and not result.is_empty():
		var last_index: int = result.size()-1
		if result[last_index].length() >= max_chars-1:
			result[last_index] = result[last_index].left(maxi(1,max_chars-1)).strip_edges()+"…"
	return result
