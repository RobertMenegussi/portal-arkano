# BUILD 0725 — Official minimal hat icon

## Change
- Replaced the previous ARKANO application icon with the approved minimalist pointed wizard-hat artwork.
- Added the approved high-resolution PNG source.
- Regenerated the project PNG icon and multi-resolution Windows ICO.
- Project settings point to the new icon for the game window/taskbar and Windows export.

## Icon files
- `arkano_icon_source.png` — approved high-resolution source
- `arkano_icon.png` — 512x512 transparent project icon
- `arkano_icon.ico` — Windows multi-resolution icon
