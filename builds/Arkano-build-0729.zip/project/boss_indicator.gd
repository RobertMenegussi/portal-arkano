extends Control

var controller
var t: float = 0.0
var redraw_timer: float = 0.0

func configure(owner_controller) -> void:
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	if get_tree().paused:
		return
	t += delta
	redraw_timer -= delta
	if redraw_timer <= 0.0:
		redraw_timer = 1.0/24.0
		queue_redraw()

func _draw() -> void:
	if not is_instance_valid(controller):
		return
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var c := Vector2(18,16)
	var pulse: float = 1.0 + 0.05*sin(t*3.0)
	var ink := Color(0.08,0.08,0.075,0.58)
	# horned boss icon; no textual "BOSS" label.
	draw_circle(c,8.2*pulse,Color(0.08,0.08,0.075,0.10))
	var horn_l := PackedVector2Array([c+Vector2(-6,-5)*pulse,c+Vector2(-13,-13)*pulse,c+Vector2(-9,-1)*pulse])
	var horn_r := PackedVector2Array([c+Vector2(6,-5)*pulse,c+Vector2(13,-13)*pulse,c+Vector2(9,-1)*pulse])
	draw_colored_polygon(horn_l,ink)
	draw_colored_polygon(horn_r,ink)
	draw_circle(c,6.0*pulse,ink)
	draw_circle(c+Vector2(-2.2,-1.0),1.0,Color(0.92,0.90,0.82,0.72))
	draw_circle(c+Vector2(2.2,-1.0),1.0,Color(0.92,0.90,0.82,0.72))
	var text_value: String = "--:--"
	if bool(controller.boss_defeated):
		text_value = "✓"
	elif bool(controller.boss_spawned):
		text_value = "!"
	else:
		var remaining: float = maxf(0.0,float(controller.boss_spawn_time)-float(controller.elapsed))
		text_value = controller._format_time(remaining)
	draw_string(font,Vector2(34,20),text_value,HORIZONTAL_ALIGNMENT_LEFT,74,12,ink)
