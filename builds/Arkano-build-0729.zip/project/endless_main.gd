extends Node2D

const PlayerScript = preload("res://player.gd")
const EnemyScript = preload("res://enemy.gd")
const EliteScript = preload("res://elite_reaver.gd")
const MiniBossSkeletonScript = preload("res://mini_boss_skeleton.gd")
const BossBarScript = preload("res://boss_bar.gd")
const AudioManagerScript = preload("res://audio_manager.gd")
const ScreenFxScript = preload("res://screen_fx.gd")
const HudDisplayScript = preload("res://hud_display.gd")
const XpMeterScript = preload("res://xp_meter.gd")
const XpOrbScript = preload("res://xp_orb.gd")
const PickupScript = preload("res://endless_pickup.gd")
const ChestScript = preload("res://endless_chest.gd")
const EndlessCatalog = preload("res://endless_catalog.gd")
const MenuBackdropScript = preload("res://endless_menu_backdrop.gd")
const RadialMenuBlurScript = preload("res://radial_menu_blur.gd")
const RadialMenuFxScript = preload("res://radial_menu_fx.gd")
const MenuBlobScript = preload("res://menu_blob.gd")
const MenuButtonScript = preload("res://menu_button.gd")
const ArcanoLogoScript = preload("res://arcano_logo.gd")
const MagePreviewScript = preload("res://mage_preview.gd")
const TraitCardScript = preload("res://endless_trait_card.gd")
const StatsPanelScript = preload("res://run_inventory_panel.gd")
const ArcanoSliderScript = preload("res://arcano_slider.gd")
const ThreatIndicatorScript = preload("res://threat_indicator.gd")
const XpVaseScript = preload("res://xp_vase.gd")
const LanguagePickerScript = preload("res://language_picker.gd")
const InitialLanguageScreenScript = preload("res://initial_language_screen.gd")
const BossIndicatorScript = preload("res://boss_indicator.gd")
const TutorialScript = preload("res://endless_tutorial.gd")
const DeathDecalBatchScript = preload("res://death_decal_batch.gd")
const EndlessAimCursorScript = preload("res://endless_aim_cursor.gd")

const WORLD_SIZE: Vector2 = Vector2(7000.0,4400.0)
const CENTER: Vector2 = Vector2(3500.0,2200.0)
const VERSION: String = "0.5.1-prealpha"
const BUILD: String = "0729"

var player
var audio_manager
var run_active: bool = false
var selected_class: String = "orbit"
var elapsed: float = 0.0
var spawn_accumulator: float = 0.0
var cleanup_timer: float = 2.0
var next_wave_time: float = 60.0
var next_elite_time: float = 120.0
var wave_number: int = 0
var kill_count: int = 0
var elite_kills: int = 0
var level: int = 1
var xp: int = 0
var xp_needed: int = 8
var pending_levelups: int = 0
var pending_rare_choices: int = 0
var levelup_open: bool = false
var dead_open: bool = false
var pause_open: bool = false
var acquired_traits: Array = []
var recent_rune_offer_keys: Array[String] = []
var recent_rune_offer_ids: Array[String] = []
var menu_layer: CanvasLayer
var class_layer: CanvasLayer
var hud_layer: CanvasLayer
var level_layer: CanvasLayer
var death_layer: CanvasLayer
var pause_layer: CanvasLayer
var hud_widget
var timer_label: Label
var level_label: Label
var kill_label: Label
var xp_bar: ProgressBar
var xp_label: Label
var xp_meter
var boss_timer_label: Label
var boss_indicator
var boss_bar
var threat_indicator
var boss_instance
var boss_spawned: bool = false
var boss_defeated: bool = false
var boss_spawn_time: float = 480.0
var banner_label: Label
var banner_timer: float = 0.0
var progress: Dictionary = {}
var best_time: float = 0.0
var best_kills: int = 0
var stats_layer: CanvasLayer
var stats_panel
var stats_visible: bool = false
var director_stationary_time: float = 0.0
var director_density_timer: float = 0.0
var director_local_enemy_count: int = 0
var director_pressure: float = 0.0
var skeleton_shot_tokens: float = 4.0
var skeleton_shot_token_max: float = 5.0
var skeleton_shot_refill: float = 2.8
var spatial_buckets: Dictionary = {}
var spatial_enemy_cache: Array = []
var spatial_cell_size: float = 78.0
var spatial_frame: int = 0
var spatial_rebuild_timer: float = 0.0
var horde_performance_tier: int = 0
var horde_budget_timer: float = 0.0
var feedback_budget_timer: float = 0.0
var hit_feedback_budget: int = 18
var death_feedback_budget: int = 12
var hud_refresh_timer: float = 0.0
var registered_enemy_ids: Dictionary = {}
var cached_orb_count: int = 0
var xp_merge_target
var death_decal_batch
var aim_cursor
var world_chest_timer: float = 38.0
var silver_chest_timer: float = 70.0
var gold_chest_timer: float = 180.0
var vase_spawn_timer: float = 42.0
var vases_broken_run: int = 0
var skeleton_entry_time: float = 55.0
var stalker_entry_time: float = 135.0
var brute_entry_time: float = 235.0
var warder_entry_time: float = 330.0
var shaman_entry_time: float = 370.0
var menu_blob
var radial_fx
var radial_buttons: Array = []
var menu_overlay: Control
var menu_maps_panel: Control
var menu_traits_panel: Control
var menu_classes_panel: Control
var menu_config_panel: Control
var menu_profile_panel: Control
var selected_map_name: String = "Silent Fields"
var radial_target_open: bool = false
var radial_anim: float = 0.0
var menu_mode_tag: Label
var menu_click_hint: Label
var menu_record_line: Label
var menu_version_line: Label
var attack_target_mode: String = "nearest"
var radial_blur
var radial_dismiss_area: Control
var config_attack_button
var config_shake_button
var config_resolution_button
var config_display_button
var config_postfx_button
var config_master_slider
var config_music_slider
var config_sfx_slider
var config_master_value: Label
var config_music_value: Label
var config_sfx_value: Label
var config_help_desc: Label
var config_attack_desc: Label
var config_choice_panel: Panel
var config_choice_title: Label
var config_choice_action: String = ""
var trait_detail_title: Label
var trait_detail_desc: Label
var trait_detail_status: Label
var selected_trait_family: int = 0
var trait_filter_tag: String = "all"
var trait_filter_row: HBoxContainer
var trait_list_box: VBoxContainer
var language_picker
var tutorial_active: bool = false
var tutorial_pending: bool = false
var tutorial_controller
var tutorial_prompt_layer: CanvasLayer
var tutorial_allow_levelup: bool = false
var consumable_slots: Array[String] = ["","","","","","","","","",""]
var consumable_details_visible: bool = false
var consumable_use_count: int = 0
var last_consumable_used: String = ""
var last_consumable_slot: int = -1
var tutorial_consumables_locked: bool = false
var language_gate_layer: CanvasLayer
var frontend_ready: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("endless_controller")
	RenderingServer.set_default_clear_color(Color("#171a18"))
	_load_progress()
	call_deferred("_apply_saved_display_settings")
	_create_audio()
	_create_world_collision()
	_create_screen_fx()
	if not Loc.language_changed.is_connected(_on_language_changed):
		Loc.language_changed.connect(_on_language_changed)
	# On a clean install, language is the first decision the player sees.
	# No English tutorial/menu copy is shown before that choice.
	if Loc.has_method("has_saved_language") and Loc.has_saved_language():
		_initialize_frontend()
	else:
		_show_initial_language_gate()
	queue_redraw()

func _L(key: String) -> String:
	return Loc.t(key)

func _LF(key: String,args: Array) -> String:
	return Loc.f(key,args)

func _initialize_frontend() -> void:
	if frontend_ready:
		return
	frontend_ready = true
	_create_menu()
	_create_class_select()
	class_layer.visible = false
	call_deferred("_maybe_offer_tutorial")

func _show_initial_language_gate() -> void:
	if is_instance_valid(language_gate_layer):
		return
	language_gate_layer = CanvasLayer.new()
	language_gate_layer.layer = 310
	language_gate_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(language_gate_layer)
	var screen = InitialLanguageScreenScript.new()
	screen.position = Vector2.ZERO
	screen.size = Vector2(960,540)
	screen.language_selected.connect(_on_initial_language_selected)
	language_gate_layer.add_child(screen)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _on_initial_language_selected(code: String) -> void:
	Loc.set_language(code)
	if is_instance_valid(language_gate_layer):
		language_gate_layer.queue_free()
	language_gate_layer = null
	_initialize_frontend()

func _on_language_changed(_code: String) -> void:
	if not frontend_ready:
		return
	call_deferred("_rebuild_localized_menu")

func _rebuild_localized_menu() -> void:
	if run_active or not frontend_ready:
		return
	if is_instance_valid(menu_layer):
		remove_child(menu_layer)
		menu_layer.queue_free()
	if is_instance_valid(class_layer):
		remove_child(class_layer)
		class_layer.queue_free()
	_create_menu()
	_create_class_select()
	class_layer.visible = false

func _set_language(code: String) -> void:
	Loc.set_language(code)

func _create_audio() -> void:
	audio_manager = AudioManagerScript.new()
	add_child(audio_manager)
	call_deferred("_start_menu_music")

func _start_menu_music() -> void:
	if is_instance_valid(audio_manager):
		audio_manager.play_menu_music()

func _create_world_collision() -> void:
	_add_wall(Vector2(WORLD_SIZE.x*0.5,20),Vector2(WORLD_SIZE.x,40))
	_add_wall(Vector2(WORLD_SIZE.x*0.5,WORLD_SIZE.y-20),Vector2(WORLD_SIZE.x,40))
	_add_wall(Vector2(20,WORLD_SIZE.y*0.5),Vector2(40,WORLD_SIZE.y))
	_add_wall(Vector2(WORLD_SIZE.x-20,WORLD_SIZE.y*0.5),Vector2(40,WORLD_SIZE.y))
	# Sparse landmarks: enough to shape movement without choking a horde.
	_add_wall(Vector2(1660,900),Vector2(190,70))
	_add_wall(Vector2(4380,1050),Vector2(160,70))
	_add_wall(Vector2(1240,2700),Vector2(130,60))
	_add_wall(Vector2(4250,2800),Vector2(180,65))

func _add_wall(pos: Vector2,size: Vector2) -> void:
	var body: StaticBody2D = StaticBody2D.new()
	body.global_position = pos
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = size
	collider.shape = shape
	body.add_child(collider)

func _create_screen_fx() -> void:
	var layer: CanvasLayer = CanvasLayer.new()
	layer.layer = 15
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	var fx = ScreenFxScript.new()
	fx.position = Vector2.ZERO
	fx.size = Vector2(960,540)
	fx.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(fx)
	fx.set_post_fx_enabled(bool(progress.get("post_fx", true)))

func _create_menu() -> void:
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 200
	menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(menu_layer)

	var backdrop = MenuBackdropScript.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(backdrop)

	radial_fx = RadialMenuFxScript.new()
	radial_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(radial_fx)

	var logo = ArcanoLogoScript.new()
	logo.position = Vector2(220,26)
	logo.size = Vector2(520,120)
	logo.tapped.connect(_on_logo_tapped)
	menu_layer.add_child(logo)

	menu_mode_tag = Label.new()
	var mode_tag: Label = menu_mode_tag
	mode_tag.position = Vector2(0,132)
	mode_tag.size = Vector2(960,22)
	mode_tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mode_tag.text = ""
	mode_tag.add_theme_font_size_override("font_size",9)
	mode_tag.add_theme_color_override("font_color",Color(1,1,1,0.34))
	menu_layer.add_child(mode_tag)

	menu_blob = MenuBlobScript.new()
	menu_blob.position = Vector2(300,92)
	menu_blob.size = Vector2(360,360)
	menu_blob.clicked.connect(_toggle_radial_menu)
	menu_layer.add_child(menu_blob)

	menu_click_hint = Label.new()
	var click_hint: Label = menu_click_hint
	click_hint.position = Vector2(0,448)
	click_hint.size = Vector2(960,28)
	click_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	click_hint.text = ""
	click_hint.visible = false
	click_hint.add_theme_font_size_override("font_size",10)
	click_hint.add_theme_color_override("font_color",Color(1,1,1,0.28))
	menu_layer.add_child(click_hint)

	menu_record_line = Label.new()
	var record_line: Label = menu_record_line
	record_line.position = Vector2(0,486)
	record_line.size = Vector2(960,20)
	record_line.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	record_line.text = _LF("menu.record",[_format_time(best_time),best_kills])
	record_line.add_theme_font_size_override("font_size",10)
	record_line.add_theme_color_override("font_color",Color(1,1,1,0.34))
	menu_layer.add_child(record_line)

	menu_version_line = Label.new()
	var version: Label = menu_version_line
	version.position = Vector2(712,16)
	version.size = Vector2(224,18)
	version.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	version.text = VERSION+"  •  "+_L("menu.build")+" "+BUILD
	version.add_theme_font_size_override("font_size",8)
	version.add_theme_color_override("font_color",Color(1,1,1,0.34))
	menu_layer.add_child(version)

	language_picker = LanguagePickerScript.new()
	language_picker.position = Vector2(18,14)
	language_picker.size = Vector2(190,190)
	language_picker.language_selected.connect(_set_language)
	menu_layer.add_child(language_picker)

	radial_blur = RadialMenuBlurScript.new()
	radial_blur.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(radial_blur)

	# Invisible click catcher: when the radial menu is open, any click that
	# does not land on one of the radial buttons closes it.
	radial_dismiss_area = Control.new()
	radial_dismiss_area.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	radial_dismiss_area.mouse_filter = Control.MOUSE_FILTER_STOP
	radial_dismiss_area.visible = false
	radial_dismiss_area.gui_input.connect(_on_radial_dismiss_input)
	menu_layer.add_child(radial_dismiss_area)

	_create_radial_menu()
	_create_menu_overlays()

func _create_radial_menu() -> void:
	radial_buttons.clear()
	var center: Vector2 = Vector2(480,308)
	var definitions: Array = [
		{"label":_L("menu.play"),"sub":_L("menu.play_sub"),"angle":-1.57,"action":"play"},
		{"label":_L("menu.maps"),"sub":_L("menu.maps_sub"),"angle":-0.67,"action":"maps"},
		{"label":_L("menu.classes"),"sub":_L("menu.classes_sub"),"angle":0.23,"action":"classes"},
		{"label":_L("menu.profile"),"sub":_L("menu.profile_sub"),"angle":1.13,"action":"profile"},
		{"label":_L("menu.runes"),"sub":_L("menu.runes_sub"),"angle":2.03,"action":"traits"},
		{"label":_L("menu.tutorial"),"sub":_L("menu.tutorial_sub"),"angle":2.93,"action":"tutorial"},
		{"label":_L("menu.config"),"sub":_L("menu.config_sub"),"angle":3.83,"action":"config"}
	]
	for data_value in definitions:
		var data: Dictionary = data_value
		var button = MenuButtonScript.new()
		button.size = Vector2(236,68)
		button.label_text = str(data.get("label",""))
		button.subtitle_text = str(data.get("sub",""))
		button.font_size = 16
		button.primary = true
		button.visible = false
		button.modulate.a = 0.0
		button.set_meta("radial_angle", float(data.get("angle",0.0)))
		button.set_meta("radial_action", str(data.get("action","")))
		button.position = center - button.size * 0.5
		button.mouse_entered.connect(_menu_hover_sfx)
		button.pressed.connect(_menu_click_sfx)
		button.pressed.connect(_on_radial_action.bind(str(data.get("action",""))))
		menu_layer.add_child(button)
		radial_buttons.append(button)

func _create_menu_overlays() -> void:
	menu_overlay = Control.new()
	menu_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_overlay.visible = false
	menu_layer.add_child(menu_overlay)
	var veil: ColorRect = ColorRect.new()
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	veil.color = Color(0.02,0.02,0.02,0.48)
	menu_overlay.add_child(veil)

	menu_maps_panel = _make_menu_panel(_L("menu.maps"))
	menu_overlay.add_child(menu_maps_panel)
	_fill_maps_panel(menu_maps_panel)

	menu_classes_panel = _make_menu_panel(_L("menu.classes"))
	menu_overlay.add_child(menu_classes_panel)
	_fill_classes_panel(menu_classes_panel)

	menu_traits_panel = _make_menu_panel(_L("menu.runes"))
	menu_overlay.add_child(menu_traits_panel)
	_fill_traits_panel(menu_traits_panel)

	menu_profile_panel = _make_menu_panel(_L("menu.profile"))
	menu_overlay.add_child(menu_profile_panel)
	_fill_profile_panel(menu_profile_panel)

	menu_config_panel = _make_menu_panel(_L("menu.config"))
	menu_overlay.add_child(menu_config_panel)
	_fill_config_panel(menu_config_panel)
	_create_config_choice_panel(menu_overlay)

func _make_menu_panel(title_text: String) -> Control:
	var panel: Panel = Panel.new()
	panel.position = Vector2(102,52)
	panel.size = Vector2(756,430)
	panel.visible = false
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.10,0.11,0.12,0.97)
	style.border_color = Color(0.96,0.95,0.90,0.10)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.shadow_color = Color(0,0,0,0.22)
	style.shadow_size = 10
	panel.add_theme_stylebox_override("panel", style)
	var title: Label = Label.new()
	title.position = Vector2(28,22)
	title.size = Vector2(500,28)
	title.text = title_text
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color(0.96,0.95,0.90,0.94))
	panel.add_child(title)
	var close = MenuButtonScript.new()
	close.position = Vector2(524,16)
	close.size = Vector2(208,46)
	close.label_text = _L("menu.back")
	close.subtitle_text = ""
	close.font_size = 12
	close.primary = false
	close.mouse_entered.connect(_menu_hover_sfx)
	close.pressed.connect(_menu_click_sfx)
	close.pressed.connect(_close_menu_overlay)
	panel.add_child(close)
	return panel

func _profile_value_label(panel: Control,pos: Vector2,size_value: Vector2,title_text: String,value_text: String,sub_text: String = "") -> void:
	var card: Panel = Panel.new()
	card.position = pos
	card.size = size_value
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.055,0.062,0.064,0.92)
	style.border_color = Color(0.96,0.95,0.90,0.07)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	card.add_theme_stylebox_override("panel",style)
	panel.add_child(card)
	var title: Label = Label.new()
	title.position = Vector2(14,12)
	title.size = Vector2(size_value.x-28,18)
	title.text = title_text
	title.add_theme_font_size_override("font_size",9)
	title.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.48))
	card.add_child(title)
	var value: Label = Label.new()
	value.position = Vector2(14,31)
	value.size = Vector2(size_value.x-28,28)
	value.text = value_text
	value.add_theme_font_size_override("font_size",19)
	value.add_theme_color_override("font_color",Color(0.96,0.95,0.90,0.94))
	card.add_child(value)
	if sub_text != "":
		var sub: Label = Label.new()
		sub.position = Vector2(14,62)
		sub.size = Vector2(size_value.x-28,size_value.y-68)
		sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		sub.text = sub_text
		sub.add_theme_font_size_override("font_size",8)
		sub.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.40))
		card.add_child(sub)

func _profile_average(total_value: float,count_value: int) -> float:
	if count_value <= 0:
		return 0.0
	return total_value/float(count_value)

func _fill_profile_panel(panel: Control) -> void:
	var recorded_runs: int = int(progress.get("profile_deaths",0))+int(progress.get("profile_abandons",0))
	var runs_started: int = int(progress.get("profile_runs_started",0))
	var total_time: float = float(progress.get("profile_total_time",0.0))
	var total_run_kills: int = int(progress.get("profile_total_run_kills",0))
	var total_run_elites: int = int(progress.get("profile_total_run_elites",0))
	var avg_time: float = _profile_average(total_time,recorded_runs)
	var avg_kills: float = _profile_average(float(total_run_kills),recorded_runs)
	var avg_elites: float = _profile_average(float(total_run_elites),recorded_runs)
	var info: Label = Label.new()
	info.position = Vector2(28,70)
	info.size = Vector2(680,24)
	info.text = _L("profile.info")
	info.add_theme_font_size_override("font_size",10)
	info.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.62))
	panel.add_child(info)
	_profile_value_label(panel,Vector2(28,108),Vector2(166,92),_L("profile.runs_started"),str(runs_started),_L("profile.runs_sub"))
	_profile_value_label(panel,Vector2(210,108),Vector2(166,92),_L("profile.time_record"),_format_time(best_time),_L("profile.time_record_sub"))
	_profile_value_label(panel,Vector2(392,108),Vector2(166,92),_L("profile.kill_record"),str(best_kills),_L("profile.kill_record_sub"))
	_profile_value_label(panel,Vector2(574,108),Vector2(154,92),_L("profile.best_level"),str(int(progress.get("profile_best_level",1))),_L("profile.best_level_sub"))
	_profile_value_label(panel,Vector2(28,216),Vector2(220,92),_L("profile.total_kills"),str(int(progress.get("quest_total_kills",0))),_L("profile.total_kills_sub"))
	_profile_value_label(panel,Vector2(266,216),Vector2(220,92),_L("profile.elites"),str(int(progress.get("quest_elites",0))),_L("profile.elites_sub"))
	_profile_value_label(panel,Vector2(504,216),Vector2(224,92),_L("profile.vases"),str(int(progress.get("quest_vases",0))),_L("profile.vases_sub"))
	_profile_value_label(panel,Vector2(28,324),Vector2(220,82),_L("profile.avg_time"),_format_time(avg_time),_LF("profile.closed_runs",[recorded_runs]))
	_profile_value_label(panel,Vector2(266,324),Vector2(220,82),_L("profile.avg_kills"),"%.1f" % avg_kills,_L("profile.per_run"))
	_profile_value_label(panel,Vector2(504,324),Vector2(224,82),_L("profile.avg_elites"),"%.2f" % avg_elites,_L("profile.per_run"))
func _fill_maps_panel(panel: Control) -> void:
	var info: Label = Label.new()
	info.position = Vector2(28,70)
	info.size = Vector2(650,28)
	info.text = _L("maps.info")
	info.add_theme_font_size_override("font_size",10)
	info.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.72))
	panel.add_child(info)
	var unlocked = MenuButtonScript.new()
	unlocked.position = Vector2(40,118)
	unlocked.size = Vector2(610,88)
	unlocked.label_text = _L("maps.silent_fields")
	unlocked.subtitle_text = _L("maps.silent_sub")
	unlocked.font_size = 18
	unlocked.primary = true
	unlocked.mouse_entered.connect(_menu_hover_sfx)
	unlocked.pressed.connect(_menu_click_sfx)
	unlocked.pressed.connect(_select_map.bind(_L("maps.silent_fields")))
	panel.add_child(unlocked)
	var lore: Label = Label.new()
	lore.position = Vector2(48,214)
	lore.size = Vector2(600,48)
	lore.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lore.text = _L("maps.silent_desc")
	lore.add_theme_font_size_override("font_size",10)
	lore.add_theme_color_override("font_color",Color(0.86,0.86,0.82,0.65))
	panel.add_child(lore)
	var locked = MenuButtonScript.new()
	locked.position = Vector2(40,280)
	locked.size = Vector2(610,78)
	locked.label_text = _L("maps.ash_ruins")
	locked.subtitle_text = _L("maps.locked_soon")
	locked.font_size = 17
	locked.primary = false
	locked.disabled = true
	panel.add_child(locked)
func _fill_classes_panel(panel: Control) -> void:
	var info: Label = Label.new()
	info.position = Vector2(28,70)
	info.size = Vector2(650,28)
	info.text = _L("classes.available")
	info.add_theme_font_size_override("font_size",11)
	info.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.72))
	panel.add_child(info)
	_create_info_class_card(panel,"orbit",Vector2(18,112),_L("class.orbit"),_L("class.orbit_desc"),true,_L("classes.released"))
	_create_info_class_card(panel,"storm",Vector2(196,112),_L("class.storm"),_L("class.storm_desc"),_class_unlocked("storm"),_class_quest_text("storm"))
	_create_info_class_card(panel,"rift",Vector2(374,112),_L("class.rift"),_L("class.rift_desc"),_class_unlocked("rift"),_class_quest_text("rift"))
	_create_info_class_card(panel,"samurai",Vector2(552,112),_L("class.samurai"),_L("class.samurai_desc"),_class_unlocked("samurai"),_class_quest_text("samurai"))
func _create_info_class_card(panel: Control, kind: String, pos: Vector2, title_text: String, desc: String, unlocked: bool, quest_text: String) -> void:
	var card: Panel = Panel.new()
	card.position = pos
	card.size = Vector2(166,252)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.10,0.11,0.12,0.96) if unlocked else Color(0.18,0.18,0.18,0.78)
	style.border_color = Color(0.95,0.94,0.90,0.16)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	card.add_theme_stylebox_override("panel", style)
	panel.add_child(card)
	var preview = MagePreviewScript.new()
	preview.mage_type = kind
	preview.position = Vector2(8,10)
	preview.size = Vector2(150,118)
	if kind == "rift":
		preview.modulate = Color(1,1,1,0.42)
	card.add_child(preview)
	var lbl = Label.new()
	lbl.position = Vector2(10,122)
	lbl.size = Vector2(146,24)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.text = title_text
	lbl.add_theme_font_size_override("font_size", 16)
	lbl.add_theme_color_override("font_color", Color(0.96,0.95,0.90,0.92))
	card.add_child(lbl)
	var desc_lbl = Label.new()
	desc_lbl.position = Vector2(10,156)
	desc_lbl.size = Vector2(146,54)
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_lbl.text = desc
	desc_lbl.add_theme_font_size_override("font_size", 9)
	desc_lbl.add_theme_color_override("font_color", Color(0.86,0.86,0.82,0.66))
	card.add_child(desc_lbl)
	var status = Label.new()
	status.position = Vector2(8,216)
	status.size = Vector2(150,28)
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.text = _L("classes.unlocked") if unlocked else quest_text
	status.add_theme_font_size_override("font_size", 7)
	status.add_theme_color_override("font_color", Color(0.90,0.90,0.86,0.58 if unlocked else 0.78))
	card.add_child(status)
	if kind == "rift":
		var ribbon := Label.new()
		ribbon.position = Vector2(12,12)
		ribbon.size = Vector2(142,18)
		ribbon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		ribbon.text = _L("classes.temporarily_removed")
		ribbon.add_theme_font_size_override("font_size",7)
		ribbon.add_theme_color_override("font_color",Color(0.96,0.94,0.90,0.76))
		card.add_child(ribbon)

func _fill_traits_panel(panel: Control) -> void:
	var title: Label = Label.new()
	title.position = Vector2(28,70)
	title.size = Vector2(700,26)
	title.text = _L("runes.title")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size",17)
	title.add_theme_color_override("font_color",Color(0.95,0.94,0.90,0.92))
	panel.add_child(title)
	var note: Label = Label.new()
	note.position = Vector2(48,96)
	note.size = Vector2(660,34)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.text = _L("runes.note")
	note.add_theme_font_size_override("font_size",8)
	note.add_theme_color_override("font_color",Color(0.82,0.82,0.78,0.52))
	panel.add_child(note)
	trait_filter_row = HBoxContainer.new()
	trait_filter_row.position = Vector2(24,132)
	trait_filter_row.size = Vector2(708,34)
	trait_filter_row.add_theme_constant_override("separation",5)
	panel.add_child(trait_filter_row)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(24,174)
	scroll.size = Vector2(356,226)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	trait_list_box = VBoxContainer.new()
	trait_list_box.custom_minimum_size = Vector2(338,0)
	trait_list_box.add_theme_constant_override("separation",5)
	scroll.add_child(trait_list_box)
	var detail := Panel.new()
	detail.position = Vector2(396,174)
	detail.size = Vector2(336,226)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.055,0.062,0.064,0.92)
	style.border_color = Color(0.96,0.95,0.90,0.08)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	detail.add_theme_stylebox_override("panel",style)
	panel.add_child(detail)
	trait_detail_title = Label.new()
	trait_detail_title.position = Vector2(18,16)
	trait_detail_title.size = Vector2(300,46)
	trait_detail_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	trait_detail_title.add_theme_font_size_override("font_size",15)
	trait_detail_title.add_theme_color_override("font_color",Color(0.96,0.95,0.90,0.94))
	detail.add_child(trait_detail_title)
	trait_detail_status = Label.new()
	trait_detail_status.position = Vector2(18,66)
	trait_detail_status.size = Vector2(300,22)
	trait_detail_status.add_theme_font_size_override("font_size",8)
	trait_detail_status.add_theme_color_override("font_color",Color(0.82,0.84,0.82,0.50))
	detail.add_child(trait_detail_status)
	trait_detail_desc = Label.new()
	trait_detail_desc.position = Vector2(18,96)
	trait_detail_desc.size = Vector2(300,108)
	trait_detail_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	trait_detail_desc.add_theme_font_size_override("font_size",10)
	trait_detail_desc.add_theme_color_override("font_color",Color(0.90,0.89,0.85,0.70))
	detail.add_child(trait_detail_desc)
	_rebuild_trait_filter_row()
	_rebuild_trait_family_list()
	_select_trait_family(selected_trait_family)
func _add_rune_group(panel: Control,title_text: String,pos: Vector2,names: Array) -> void:
	var group: Panel = Panel.new()
	group.position = pos
	group.size = Vector2(218,220)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.075,0.08,0.085,0.88)
	style.border_color = Color(0.92,0.91,0.86,0.12)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	group.add_theme_stylebox_override("panel",style)
	panel.add_child(group)
	var header: Label = Label.new()
	header.position = Vector2(12,12)
	header.size = Vector2(194,20)
	header.text = title_text
	header.add_theme_font_size_override("font_size",10)
	header.add_theme_color_override("font_color",Color(0.94,0.93,0.88,0.72))
	group.add_child(header)
	var y: float = 44.0
	for name_value in names:
		var line: Label = Label.new()
		line.position = Vector2(14,y)
		line.size = Vector2(190,20)
		line.text = "• "+str(name_value)
		line.add_theme_font_size_override("font_size",9)
		line.add_theme_color_override("font_color",Color(0.88,0.88,0.84,0.62))
		group.add_child(line)
		y += 23.0

func _trait_filter_specs() -> Array:
	return [
		{"id":"all","label":_L("filter.all")},
		{"id":"weapon","label":_L("filter.weapon")},
		{"id":"damage","label":_L("filter.damage")},
		{"id":"movement","label":_L("filter.movement")},
		{"id":"survival","label":_L("filter.survival")},
		{"id":"economy","label":_L("filter.utility")}
	]
func _rebuild_trait_filter_row() -> void:
	if not is_instance_valid(trait_filter_row):
		return
	for child in trait_filter_row.get_children():
		child.queue_free()
	for spec in _trait_filter_specs():
		var btn = MenuButtonScript.new()
		btn.custom_minimum_size = Vector2(108,34)
		btn.label_text = str(spec["label"])
		btn.subtitle_text = ""
		btn.font_size = 11
		btn.primary = str(spec["id"]) == trait_filter_tag
		btn.mouse_entered.connect(_menu_hover_sfx)
		btn.pressed.connect(_menu_click_sfx)
		btn.pressed.connect(_set_trait_filter.bind(str(spec["id"])))
		trait_filter_row.add_child(btn)

func _set_trait_filter(filter_id: String) -> void:
	trait_filter_tag = filter_id
	_rebuild_trait_filter_row()
	_rebuild_trait_family_list()
	if not _trait_filter_matches(selected_trait_family, trait_filter_tag):
		var first_match: int = _first_trait_filter_match()
		if first_match >= 0:
			selected_trait_family = first_match
	_select_trait_family(selected_trait_family)

func _first_trait_filter_match() -> int:
	for family in range(EndlessCatalog.FAMILY_IDS.size()):
		if _trait_filter_matches(family, trait_filter_tag):
			return family
	return 0

func _rebuild_trait_family_list() -> void:
	if not is_instance_valid(trait_list_box):
		return
	for child in trait_list_box.get_children():
		child.queue_free()
	for family in range(EndlessCatalog.FAMILY_IDS.size()):
		if not _trait_filter_matches(family, trait_filter_tag):
			continue
		var btn = MenuButtonScript.new()
		btn.custom_minimum_size = Vector2(356,66)
		btn.label_text = EndlessCatalog.get_family_name(family)
		btn.subtitle_text = _trait_filter_subtitle(family)
		btn.font_size = 14
		btn.primary = family == selected_trait_family
		btn.mouse_entered.connect(_menu_hover_sfx)
		btn.pressed.connect(_menu_click_sfx)
		btn.pressed.connect(_select_trait_family.bind(family))
		trait_list_box.add_child(btn)

func _trait_filter_subtitle(family: int) -> String:
	return EndlessCatalog.get_category_label(EndlessCatalog.get_family_category(family)).to_lower()

func _trait_filter_matches(family: int,filter_id: String) -> bool:
	if filter_id == "all":
		return true
	var category: String = EndlessCatalog.get_family_category(family)
	match filter_id:
		"weapon": return category == "WEAPON" or category == "CONTROL"
		"damage": return category == "DAMAGE"
		"movement": return category == "MOVEMENT"
		"survival": return category == "SURVIVAL"
		"economy": return category == "UTILITY"
	return true
func _fill_config_panel(panel: Control) -> void:
	var gameplay_title: Label = Label.new()
	gameplay_title.position = Vector2(36,76)
	gameplay_title.size = Vector2(676,20)
	gameplay_title.text = _L("settings.gameplay")
	gameplay_title.add_theme_font_size_override("font_size", 9)
	gameplay_title.add_theme_color_override("font_color", Color(0.86,0.86,0.82,0.56))
	panel.add_child(gameplay_title)

	config_attack_button = null

	var graphics_title: Label = Label.new()
	graphics_title.position = Vector2(36,100)
	graphics_title.size = Vector2(676,20)
	graphics_title.text = _L("settings.graphics")
	graphics_title.add_theme_font_size_override("font_size", 9)
	graphics_title.add_theme_color_override("font_color", Color(0.86,0.86,0.82,0.56))
	panel.add_child(graphics_title)

	config_resolution_button = MenuButtonScript.new()
	config_resolution_button.position = Vector2(36,124)
	config_resolution_button.size = Vector2(160,62)
	config_resolution_button.label_text = _L("settings.resolution")
	config_resolution_button.font_size = 11
	config_resolution_button.primary = true
	config_resolution_button.mouse_entered.connect(_menu_hover_sfx)
	config_resolution_button.pressed.connect(_menu_click_sfx)
	config_resolution_button.pressed.connect(_open_resolution_picker)
	panel.add_child(config_resolution_button)

	config_display_button = MenuButtonScript.new()
	config_display_button.position = Vector2(208,124)
	config_display_button.size = Vector2(160,62)
	config_display_button.label_text = _L("settings.display")
	config_display_button.font_size = 11
	config_display_button.primary = true
	config_display_button.mouse_entered.connect(_menu_hover_sfx)
	config_display_button.pressed.connect(_menu_click_sfx)
	config_display_button.pressed.connect(_open_display_mode_picker)
	panel.add_child(config_display_button)

	config_shake_button = MenuButtonScript.new()
	config_shake_button.position = Vector2(380,124)
	config_shake_button.size = Vector2(160,62)
	config_shake_button.label_text = _L("settings.shake")
	config_shake_button.font_size = 11
	config_shake_button.primary = true
	config_shake_button.mouse_entered.connect(_menu_hover_sfx)
	config_shake_button.pressed.connect(_menu_click_sfx)
	config_shake_button.pressed.connect(_open_shake_picker)
	panel.add_child(config_shake_button)

	config_postfx_button = MenuButtonScript.new()
	config_postfx_button.position = Vector2(552,124)
	config_postfx_button.size = Vector2(168,62)
	config_postfx_button.label_text = _L("settings.postfx")
	config_postfx_button.font_size = 10
	config_postfx_button.primary = true
	config_postfx_button.mouse_entered.connect(_menu_hover_sfx)
	config_postfx_button.pressed.connect(_menu_click_sfx)
	config_postfx_button.pressed.connect(_open_postfx_picker)
	panel.add_child(config_postfx_button)

	var volume_title: Label = Label.new()
	volume_title.position = Vector2(36,284)
	volume_title.size = Vector2(676,20)
	volume_title.text = _L("settings.volume")
	volume_title.add_theme_font_size_override("font_size", 9)
	volume_title.add_theme_color_override("font_color", Color(0.86,0.86,0.82,0.56))
	panel.add_child(volume_title)

	var audio = _audio_node()
	config_master_slider = _create_volume_slider(panel, _L("settings.master"), 314.0, float(audio.master_volume if audio != null else 0.85), _on_master_slider_changed)
	config_music_slider = _create_volume_slider(panel, _L("settings.music"), 348.0, float(audio.music_volume if audio != null else 0.55), _on_music_slider_changed)
	config_sfx_slider = _create_volume_slider(panel, _L("settings.sfx"), 382.0, float(audio.sfx_volume if audio != null else 0.85), _on_sfx_slider_changed)
	_refresh_config_panel()

func _create_volume_slider(parent: Control, label_text: String, y: float, current_value: float, callback: Callable):
	var label: Label = Label.new()
	label.position = Vector2(38,y)
	label.size = Vector2(122,22)
	label.text = label_text
	label.add_theme_font_size_override("font_size", 10)
	label.add_theme_color_override("font_color", Color(0.92,0.91,0.87,0.76))
	parent.add_child(label)
	var slider = ArcanoSliderScript.new()
	slider.position = Vector2(166,y-3.0)
	slider.size = Vector2(438,28)
	slider.set_value_silent(current_value)
	slider.value_changed.connect(callback)
	parent.add_child(slider)
	var value_label: Label = Label.new()
	value_label.position = Vector2(620,y)
	value_label.size = Vector2(78,22)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_label.text = _volume_text(current_value)
	value_label.add_theme_font_size_override("font_size", 10)
	value_label.add_theme_color_override("font_color", Color(0.96,0.95,0.90,0.90))
	parent.add_child(value_label)
	if y < 330.0:
		config_master_value = value_label
	elif y < 370.0:
		config_music_value = value_label
	else:
		config_sfx_value = value_label
	return slider

func _on_master_slider_changed(value: float) -> void:
	var audio = _audio_node()
	if audio != null:
		audio.set_master_volume(value)
	if is_instance_valid(config_master_value):
		config_master_value.text = _volume_text(value)

func _on_music_slider_changed(value: float) -> void:
	var audio = _audio_node()
	if audio != null:
		audio.set_music_volume(value)
	if is_instance_valid(config_music_value):
		config_music_value.text = _volume_text(value)

func _on_sfx_slider_changed(value: float) -> void:
	var audio = _audio_node()
	if audio != null:
		audio.set_sfx_volume(value)
	if is_instance_valid(config_sfx_value):
		config_sfx_value.text = _volume_text(value)

func _get_attack_target_mode() -> String:
	return attack_target_mode

func _is_manual_mouse_mode() -> bool:
	return attack_target_mode == "mouse"

func _toggle_attack_target_mode() -> void:
	attack_target_mode = "mouse" if attack_target_mode != "mouse" else "nearest"
	progress["attack_target_mode"] = attack_target_mode
	_save_progress()
	_refresh_config_panel()
	if run_active:
		_show_banner(_L("settings.attack_method") + ": " + _attack_mode_label(), 1.2)

func _tutorial_set_attack_target_mode(mode: String) -> void:
	if mode != "mouse" and mode != "nearest":
		mode = "nearest"
	attack_target_mode = mode
	progress["attack_target_mode"] = attack_target_mode
	_save_progress()
	_refresh_config_panel()

func _attack_mode_label() -> String:
	match attack_target_mode:
		"mouse": return _L("settings.mouse")
		_: return _L("settings.nearest")
func _volume_text(value: float) -> String:
	return str(int(round(value * 100.0))) + "%"

func _screen_shake_text() -> String:
	return _L("settings.on") if bool(progress.get("screen_shake",true)) else _L("settings.off")

func _post_fx_text() -> String:
	return _L("settings.on") if bool(progress.get("post_fx",true)) else _L("settings.off")

func _resolution_text() -> String:
	var w: int = int(progress.get("resolution_w",960))
	var h: int = int(progress.get("resolution_h",540))
	return str(w) + " × " + str(h)

func _display_mode_text() -> String:
	match str(progress.get("display_mode","windowed")):
		"borderless": return _L("settings.borderless")
		"fullscreen": return _L("settings.fullscreen")
		_: return _L("settings.window")
func _audio_node():
	var nodes: Array = get_tree().get_nodes_in_group("audio_bus")
	return nodes[0] if nodes.size() > 0 else null

func _refresh_config_panel() -> void:
	if is_instance_valid(config_attack_button):
		config_attack_button.subtitle_text = _attack_mode_label()
	if is_instance_valid(config_shake_button):
		config_shake_button.subtitle_text = _screen_shake_text()
	if is_instance_valid(config_resolution_button):
		config_resolution_button.subtitle_text = _resolution_text()
	if is_instance_valid(config_display_button):
		config_display_button.subtitle_text = _display_mode_text()
	if is_instance_valid(config_postfx_button):
		config_postfx_button.subtitle_text = _post_fx_text()
	var audio = _audio_node()
	if audio != null:
		if is_instance_valid(config_master_slider): config_master_slider.set_value_silent(float(audio.master_volume))
		if is_instance_valid(config_music_slider): config_music_slider.set_value_silent(float(audio.music_volume))
		if is_instance_valid(config_sfx_slider): config_sfx_slider.set_value_silent(float(audio.sfx_volume))
		if is_instance_valid(config_master_value): config_master_value.text = _volume_text(float(audio.master_volume))
		if is_instance_valid(config_music_value): config_music_value.text = _volume_text(float(audio.music_volume))
		if is_instance_valid(config_sfx_value): config_sfx_value.text = _volume_text(float(audio.sfx_volume))

func _create_config_choice_panel(parent: Control) -> void:
	config_choice_panel = Panel.new()
	config_choice_panel.position = Vector2(174,86)
	config_choice_panel.size = Vector2(408,318)
	config_choice_panel.visible = false
	config_choice_panel.z_index = 80
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color(0.055,0.06,0.065,0.995)
	style.border_color = Color(0.96,0.95,0.90,0.18)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.shadow_color = Color(0,0,0,0.42)
	style.shadow_size = 14
	config_choice_panel.add_theme_stylebox_override("panel", style)
	parent.add_child(config_choice_panel)

func _clear_config_choice_panel() -> void:
	if not is_instance_valid(config_choice_panel):
		return
	for child in config_choice_panel.get_children():
		child.queue_free()

func _show_config_choices(title_text: String, action: String, options: Array) -> void:
	if not is_instance_valid(config_choice_panel):
		return
	_clear_config_choice_panel()
	config_choice_action = action
	config_choice_panel.visible = true
	config_choice_title = Label.new()
	config_choice_title.position = Vector2(20,18)
	config_choice_title.size = Vector2(280,26)
	config_choice_title.text = title_text
	config_choice_title.add_theme_font_size_override("font_size", 18)
	config_choice_title.add_theme_color_override("font_color", Color(0.97,0.96,0.92,0.96))
	config_choice_panel.add_child(config_choice_title)
	var desc: Label = Label.new()
	desc.position = Vector2(20,40)
	desc.size = Vector2(364,34)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc.text = _config_choice_description(action)
	desc.add_theme_font_size_override("font_size", 9)
	desc.add_theme_color_override("font_color", Color(0.84,0.84,0.80,0.58))
	config_choice_panel.add_child(desc)
	var current_value: String = _current_config_choice_value(action)
	var y: float = 80.0
	for option_value in options:
		var option: Dictionary = option_value
		var value: String = str(option.get("value", ""))
		var label: String = str(option.get("label", value))
		var btn = MenuButtonScript.new()
		btn.position = Vector2(18,y)
		btn.size = Vector2(372,48)
		btn.label_text = label
		btn.subtitle_text = _L("menu.selected") if value == current_value else ""
		btn.font_size = 13
		btn.primary = value == current_value
		btn.mouse_entered.connect(_menu_hover_sfx)
		btn.pressed.connect(_menu_click_sfx)
		btn.pressed.connect(_apply_config_choice.bind(action, value))
		config_choice_panel.add_child(btn)
		y += 52.0
	var cancel = MenuButtonScript.new()
	cancel.position = Vector2(238,y + 4.0)
	cancel.size = Vector2(152,38)
	config_choice_panel.size.y = y + 50.0
	cancel.label_text = _L("menu.cancel")
	cancel.subtitle_text = ""
	cancel.font_size = 11
	cancel.primary = false
	cancel.pressed.connect(_close_config_choice_panel)
	config_choice_panel.add_child(cancel)

func _close_config_choice_panel() -> void:
	if is_instance_valid(config_choice_panel):
		config_choice_panel.visible = false


func _config_choice_description(action: String) -> String:
	match action:
		"attack": return _L("settings.attack_desc")
		"shake": return _L("settings.shake_desc")
		"postfx": return _L("settings.postfx_desc")
		"resolution": return _L("settings.res_desc")
		"display": return _L("settings.display_desc")
		"master": return _L("settings.master_desc")
		"music": return _L("settings.music_desc")
		"sfx": return _L("settings.sfx_desc")
	return ""
func _current_config_choice_value(action: String) -> String:
	var audio = _audio_node()
	match action:
		"attack": return attack_target_mode
		"shake": return "on" if bool(progress.get("screen_shake", true)) else "off"
		"postfx": return "on" if bool(progress.get("post_fx", true)) else "off"
		"resolution":
			return str(int(progress.get("resolution_w",960)))+"x"+str(int(progress.get("resolution_h",540)))
		"display": return str(progress.get("display_mode","windowed"))
		"master": return str(int(round(float(audio.master_volume if audio != null else 0.85) * 100.0)))
		"music": return str(int(round(float(audio.music_volume if audio != null else 0.55) * 100.0)))
		"sfx": return str(int(round(float(audio.sfx_volume if audio != null else 0.85) * 100.0)))
	return ""

func _open_attack_mode_picker() -> void:
	_show_config_choices(_L("settings.attack_method"),"attack",[
		{"label":_L("settings.nearest"),"value":"nearest"},
		{"label":_L("settings.mouse"),"value":"mouse"}
	])
func _open_shake_picker() -> void:
	_show_config_choices(_L("settings.shake"),"shake",[
		{"label":_L("settings.on"),"value":"on"},
		{"label":_L("settings.off"),"value":"off"}
	])
func _open_postfx_picker() -> void:
	_show_config_choices(_L("settings.postfx"),"postfx",[
		{"label":_L("settings.on"),"value":"on"},
		{"label":_L("settings.off"),"value":"off"}
	])
func _open_resolution_picker() -> void:
	_show_config_choices(_L("settings.resolution"),"resolution", [
		{"label":"960 × 540", "value":"960x540"},
		{"label":"1280 × 720", "value":"1280x720"},
		{"label":"1600 × 900", "value":"1600x900"},
		{"label":"1920 × 1080", "value":"1920x1080"}
	])

func _open_display_mode_picker() -> void:
	_show_config_choices(_L("settings.display"),"display",[
		{"label":_L("settings.window"),"value":"windowed"},
		{"label":_L("settings.fullscreen_borderless"),"value":"borderless"},
		{"label":_L("settings.fullscreen_exclusive"),"value":"fullscreen"}
	])

func _volume_options() -> Array:
	return [
		{"label":"0%", "value":"0"}, {"label":"25%", "value":"25"},
		{"label":"50%", "value":"50"}, {"label":"75%", "value":"75"},
		{"label":"100%", "value":"100"}
	]

func _open_master_volume_picker() -> void:
	_show_config_choices(_L("settings.master"), "master", _volume_options())

func _open_music_volume_picker() -> void:
	_show_config_choices(_L("settings.music"), "music", _volume_options())

func _open_sfx_volume_picker() -> void:
	_show_config_choices(_L("settings.sfx"), "sfx", _volume_options())

func _apply_saved_display_settings() -> void:
	_apply_display_mode(str(progress.get("display_mode","windowed")))

func _apply_display_mode(mode: String) -> void:
	match mode:
		"borderless":
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		"fullscreen":
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
		_:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			call_deferred("_apply_saved_window_size")

func _apply_saved_window_size() -> void:
	if DisplayServer.window_get_mode() != DisplayServer.WINDOW_MODE_WINDOWED:
		return
	var requested := Vector2i(
		int(progress.get("resolution_w",960)),
		int(progress.get("resolution_h",540))
	)
	var screen_size: Vector2i = DisplayServer.screen_get_size()
	var safe_size := Vector2i(
		mini(requested.x, screen_size.x),
		mini(requested.y, screen_size.y)
	)
	DisplayServer.window_set_size(safe_size)
	var centered := Vector2i(
		maxi(0, int(float(screen_size.x - safe_size.x) / 2.0)),
		maxi(0, int(float(screen_size.y - safe_size.y) / 2.0))
	)
	DisplayServer.window_set_position(centered)

func _apply_config_choice(action: String, value: String) -> void:
	match action:
		"attack":
			attack_target_mode = value
			progress["attack_target_mode"] = value
		"shake":
			var enabled: bool = value == "on"
			progress["screen_shake"] = enabled
			if is_instance_valid(player) and player.has_method("set_screen_shake_enabled"):
				player.set_screen_shake_enabled(enabled)
		"postfx":
			var enabled_fx: bool = value == "on"
			progress["post_fx"] = enabled_fx
			get_tree().call_group("screen_fx", "set_post_fx_enabled", enabled_fx)
		"resolution":
			var parts: PackedStringArray = value.split("x")
			if parts.size() == 2:
				var next_size := Vector2i(int(parts[0]), int(parts[1]))
				progress["resolution_w"] = next_size.x
				progress["resolution_h"] = next_size.y
				if str(progress.get("display_mode","windowed")) == "windowed":
					DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
					call_deferred("_apply_saved_window_size")
		"display":
			progress["display_mode"] = value
			_apply_display_mode(value)
		"master", "music", "sfx":
			var audio = _audio_node()
			if audio != null:
				var ratio: float = clampf(float(value) / 100.0, 0.0, 1.0)
				if action == "master": audio.set_master_volume(ratio)
				elif action == "music": audio.set_music_volume(ratio)
				else: audio.set_sfx_volume(ratio)
	_save_progress()
	_refresh_config_panel()
	_close_config_choice_panel()

func _select_trait_family(family: int) -> void:
	selected_trait_family = clampi(family,0,maxi(0,EndlessCatalog.FAMILY_IDS.size()-1))
	var trait_id: String = EndlessCatalog.get_family_preview_id(selected_trait_family,selected_class)
	if is_instance_valid(trait_detail_title):
		trait_detail_title.text = EndlessCatalog.get_family_name(selected_trait_family)
	if is_instance_valid(trait_detail_status):
		trait_detail_status.text = EndlessCatalog.get_category_label(EndlessCatalog.get_family_category(selected_trait_family))+"  •  "+_class_label(selected_class)
	if is_instance_valid(trait_detail_desc):
		trait_detail_desc.text = EndlessCatalog.get_description(trait_id,selected_class)
func _class_label(kind: String) -> String:
	match kind:
		"storm": return _L("class.storm")
		"rift": return _L("class.rift")
		"samurai": return _L("class.samurai")
		_: return _L("class.orbit")
func _on_radial_dismiss_input(event: InputEvent) -> void:
	if not radial_target_open:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		radial_target_open = false
		if is_instance_valid(radial_dismiss_area):
			radial_dismiss_area.visible = false
		get_tree().call_group("audio_bus","play_ui_radial_close")
		get_viewport().set_input_as_handled()

func _toggle_radial_menu() -> void:
	radial_target_open = not radial_target_open
	if is_instance_valid(radial_dismiss_area):
		radial_dismiss_area.visible = radial_target_open
	if radial_target_open:
		for button in radial_buttons:
			if is_instance_valid(button):
				button.visible = true
		get_tree().call_group("audio_bus", "play_ui_radial_open")
	else:
		get_tree().call_group("audio_bus", "play_ui_radial_close")

func _update_menu_radial(delta: float) -> void:
	# A calm elliptical spread keeps the lower cards apart while preserving the
	# radial feeling. The wider X radius is intentional: translated labels can
	# be long, and PROFILE / RUNES must never collide.
	radial_anim = move_toward(radial_anim, 1.0 if radial_target_open else 0.0, delta * 4.25)
	if is_instance_valid(radial_dismiss_area) and radial_dismiss_area.visible != radial_target_open:
		radial_dismiss_area.visible = radial_target_open
	var center: Vector2 = Vector2(480,308)
	var spread: Vector2 = Vector2(315.0,188.0)
	for idx in range(radial_buttons.size()):
		var button = radial_buttons[idx]
		if not is_instance_valid(button):
			continue
		var angle: float = float(button.get_meta("radial_angle", 0.0))
		var reveal: float = clampf((radial_anim - float(idx) * 0.038) / 0.78, 0.0, 1.0)
		var eased: float = reveal * reveal * (3.0 - 2.0 * reveal)
		var settle: float = sin(eased * PI) * 5.0
		var direction: Vector2 = Vector2(cos(angle),sin(angle))
		var final_offset: Vector2 = Vector2(direction.x * spread.x, direction.y * spread.y)
		var settle_offset: Vector2 = direction * settle
		button.position = center + final_offset * eased + settle_offset - button.size * 0.5
		button.modulate.a = clampf(eased * 1.22, 0.0, 1.0)
		button.scale = Vector2.ONE * (0.84 + eased * 0.16)
		button.rotation = (1.0 - eased) * 0.025 * (-1.0 if idx % 2 == 0 else 1.0)
		button.visible = reveal > 0.01 or radial_target_open
		if not radial_target_open and reveal <= 0.01 and radial_anim <= 0.01:
			button.visible = false

func _on_radial_action(action: String) -> void:
	radial_target_open = false
	if is_instance_valid(radial_dismiss_area):
		radial_dismiss_area.visible = false
	match action:
		"play":
			_open_class_select()
		"maps":
			_open_menu_overlay(menu_maps_panel)
		"classes":
			_open_menu_overlay(menu_classes_panel)
		"profile":
			_open_menu_overlay(menu_profile_panel)
		"traits":
			_open_menu_overlay(menu_traits_panel)
		"tutorial":
			_start_tutorial()
		"config":
			_open_menu_overlay(menu_config_panel)

func _open_menu_overlay(target: Control) -> void:
	if not is_instance_valid(menu_overlay):
		return
	menu_overlay.visible = true
	for item in [menu_maps_panel, menu_classes_panel, menu_profile_panel, menu_traits_panel, menu_config_panel]:
		if is_instance_valid(item):
			item.visible = item == target
	get_tree().call_group("audio_bus","play_ui_panel_open")

func _close_menu_overlay() -> void:
	_close_config_choice_panel()
	if is_instance_valid(menu_overlay):
		menu_overlay.visible = false
	for item in [menu_maps_panel, menu_classes_panel, menu_profile_panel, menu_traits_panel, menu_config_panel]:
		if is_instance_valid(item):
			item.visible = false
	get_tree().call_group("audio_bus","play_ui_panel_close")

func _select_map(map_name: String) -> void:
	selected_map_name = map_name
	_close_menu_overlay()
	_show_banner(_LF("banner.map_selected",[map_name]), 1.6)

func _menu_hover_sfx() -> void:
	get_tree().call_group("audio_bus","play_ui_hover")

func _menu_click_sfx() -> void:
	get_tree().call_group("audio_bus","play_ui_click")

func _on_menu_blob_spoken(_text: String) -> void:
	get_tree().call_group("audio_bus","play_blob_tap")

func _on_logo_tapped() -> void:
	get_tree().call_group("audio_bus","play_ui_hover")

func _create_class_select() -> void:
	class_layer = CanvasLayer.new()
	class_layer.layer = 205
	class_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(class_layer)
	var backdrop = MenuBackdropScript.new()
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	class_layer.add_child(backdrop)
	var title: Label = Label.new()
	title.position = Vector2(0,32)
	title.size = Vector2(960,38)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = _L("classes.choose")
	title.add_theme_font_size_override("font_size",24)
	title.add_theme_color_override("font_color",Color("#f0ede4"))
	class_layer.add_child(title)
	var sub: Label = Label.new()
	sub.position = Vector2(170,72)
	sub.size = Vector2(620,28)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.text = _L("classes.choose_sub")
	sub.add_theme_font_size_override("font_size",10)
	sub.add_theme_color_override("font_color",Color(1,1,1,0.46))
	class_layer.add_child(sub)
	_create_class_card("orbit",Vector2(52,124),_L("class.orbit"),_L("classes.unlocked"),_L("class.orbit_desc"),true)
	_create_class_card("storm",Vector2(272,124),_L("class.storm"),_L("classes.unlocked") if _class_unlocked("storm") else _class_quest_text("storm"),_L("class.storm_desc"),_class_unlocked("storm"))
	_create_class_card("rift",Vector2(492,124),_L("class.rift"),_L("classes.unlocked") if _class_unlocked("rift") else _class_quest_text("rift"),_L("class.rift_desc"),_class_unlocked("rift"))
	_create_class_card("samurai",Vector2(712,124),_L("class.samurai"),_L("classes.unlocked") if _class_unlocked("samurai") else _class_quest_text("samurai"),_L("class.samurai_desc"),_class_unlocked("samurai"))
	var back = MenuButtonScript.new()
	back.position = Vector2(380,472)
	back.size = Vector2(200,46)
	back.label_text = _L("menu.back")
	back.subtitle_text = ""
	back.font_size = 15
	back.primary = false
	back.mouse_entered.connect(_menu_hover_sfx)
	back.pressed.connect(_menu_click_sfx)
	back.pressed.connect(_back_to_menu)
	class_layer.add_child(back)

func _create_class_card(kind: String,pos: Vector2,title_text: String,status_text: String,desc: String,unlocked: bool) -> void:
	var card: Button = Button.new()
	card.position = pos
	card.size = Vector2(196,326)
	card.text = ""
	card.focus_mode = Control.FOCUS_NONE
	card.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND if unlocked else Control.CURSOR_FORBIDDEN
	var normal: StyleBoxFlat = StyleBoxFlat.new()
	normal.bg_color = Color(0.91,0.89,0.82,0.94 if unlocked else 0.56)
	normal.border_color = Color(0.92,0.91,0.86,0.12)
	normal.border_width_left = 1
	normal.border_width_top = 1
	normal.border_width_right = 1
	normal.border_width_bottom = 1
	normal.corner_radius_top_left = 2
	normal.corner_radius_top_right = 2
	normal.corner_radius_bottom_left = 2
	normal.corner_radius_bottom_right = 2
	var hover: StyleBoxFlat = normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.97,0.95,0.88,0.99)
	hover.border_color = Color(1,1,1,0.34)
	card.add_theme_stylebox_override("normal",normal)
	card.add_theme_stylebox_override("hover",hover)
	card.add_theme_stylebox_override("pressed",hover)
	card.add_theme_stylebox_override("disabled",normal)
	card.disabled = not unlocked
	var preview = MagePreviewScript.new()
	preview.mage_type = kind
	preview.position = Vector2(13,12)
	preview.size = Vector2(170,154)
	if kind == "rift":
		preview.modulate = Color(1,1,1,0.38)
	card.add_child(preview)
	var name_label: Label = Label.new()
	name_label.position = Vector2(16,172)
	name_label.size = Vector2(164,28)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_label.text = title_text
	name_label.add_theme_font_size_override("font_size",17)
	name_label.add_theme_color_override("font_color",Color("#111513"))
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(name_label)
	var desc_label: Label = Label.new()
	desc_label.position = Vector2(12,208)
	desc_label.size = Vector2(172,58)
	desc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_label.text = desc
	desc_label.add_theme_font_size_override("font_size",9)
	desc_label.add_theme_color_override("font_color",Color(0.08,0.09,0.08,0.54))
	desc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(desc_label)
	var status: Label = Label.new()
	status.position = Vector2(10,274)
	status.size = Vector2(176,42)
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.text = status_text
	status.add_theme_font_size_override("font_size",8)
	status.add_theme_color_override("font_color",Color(0.08,0.09,0.08,0.44 if unlocked else 0.66))
	status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(status)
	if kind == "rift":
		var ribbon := Label.new()
		ribbon.position = Vector2(20,16)
		ribbon.size = Vector2(156,18)
		ribbon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		ribbon.text = _L("classes.temporarily_removed")
		ribbon.add_theme_font_size_override("font_size",7)
		ribbon.add_theme_color_override("font_color",Color(0.08,0.09,0.08,0.62))
		ribbon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(ribbon)
	if unlocked:
		card.mouse_entered.connect(_menu_hover_sfx)
		card.pressed.connect(_menu_click_sfx)
		card.pressed.connect(_start_run.bind(kind))
	class_layer.add_child(card)

func _open_class_select() -> void:
	radial_target_open = false
	menu_layer.visible = false
	class_layer.visible = true
	get_tree().call_group("audio_bus","play_ui_panel_open")

func _back_to_menu() -> void:
	class_layer.visible = false
	menu_layer.visible = true
	radial_target_open = false
	get_tree().call_group("audio_bus","play_ui_panel_close")

func _maybe_offer_tutorial() -> void:
	if bool(progress.get("tutorial_prompted",false)) or run_active:
		return
	progress["tutorial_prompted"] = true
	_save_progress()
	_show_tutorial_prompt()

func _show_tutorial_prompt() -> void:
	if is_instance_valid(tutorial_prompt_layer):
		return
	tutorial_prompt_layer = CanvasLayer.new()
	tutorial_prompt_layer.layer = 270
	tutorial_prompt_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(tutorial_prompt_layer)
	var dim := ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.02,0.025,0.024,0.72)
	tutorial_prompt_layer.add_child(dim)
	var panel := Panel.new()
	panel.position = Vector2(260,150)
	panel.size = Vector2(440,240)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.045,0.052,0.050,0.985)
	style.border_color = Color(0.94,0.92,0.86,0.12)
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.shadow_color = Color(0,0,0,0.38)
	style.shadow_size = 12
	panel.add_theme_stylebox_override("panel",style)
	tutorial_prompt_layer.add_child(panel)
	var title := Label.new()
	title.position = Vector2(28,24)
	title.size = Vector2(384,32)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = _L("tutorial.prompt_title")
	title.add_theme_font_size_override("font_size",22)
	title.add_theme_color_override("font_color",Color(0.96,0.95,0.91,0.94))
	panel.add_child(title)
	var body := Label.new()
	body.position = Vector2(36,70)
	body.size = Vector2(368,70)
	body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.text = _L("tutorial.prompt_body")
	body.add_theme_font_size_override("font_size",10)
	body.add_theme_color_override("font_color",Color(0.90,0.89,0.85,0.66))
	panel.add_child(body)
	var start = MenuButtonScript.new()
	start.position = Vector2(36,164)
	start.size = Vector2(178,48)
	start.label_text = _L("tutorial.start")
	start.font_size = 12
	start.primary = true
	start.pressed.connect(_dismiss_tutorial_prompt.bind(true))
	panel.add_child(start)
	var later = MenuButtonScript.new()
	later.position = Vector2(226,164)
	later.size = Vector2(178,48)
	later.label_text = _L("tutorial.later")
	later.font_size = 12
	later.primary = false
	later.pressed.connect(_dismiss_tutorial_prompt.bind(false))
	panel.add_child(later)

func _dismiss_tutorial_prompt(start_now: bool) -> void:
	if is_instance_valid(tutorial_prompt_layer):
		tutorial_prompt_layer.queue_free()
	tutorial_prompt_layer = null
	if start_now:
		_start_tutorial()

func _start_tutorial() -> void:
	if run_active:
		return
	_close_menu_overlay()
	tutorial_pending = true
	_start_run("orbit")

func _tutorial_set_class(kind: String) -> void:
	if not is_instance_valid(player):
		return
	selected_class = kind
	player.set_mage_type(kind)
	player.refill_dash()
	if is_instance_valid(level_label):
		level_label.text = _LF("hud.level",[level,_class_name(selected_class)])
	if is_instance_valid(hud_widget):
		hud_widget.queue_redraw()
	_show_banner(_class_name(kind),0.85)

func _tutorial_spawn_enemy(kind: String,pos: Vector2,stationary: bool = false,health_override: int = -1,harmless: bool = false,group_name: String = ""):
	var enemy = EnemyScript.new()
	enemy.configure(kind,player)
	if stationary:
		enemy.move_speed = 0.0
	if health_override > 0:
		enemy.max_health = health_override
		enemy.health = health_override
	if harmless:
		enemy.attack_cooldown = 9999.0
		enemy.contact_cooldown = 9999.0
	enemy.endless_controller = self
	enemy.global_position = pos
	add_child(enemy)
	if group_name != "":
		enemy.add_to_group(group_name)
	registered_enemy_ids[enemy.get_instance_id()] = enemy
	return enemy

func _tutorial_force_levelup() -> void:
	if not tutorial_active:
		return
	tutorial_allow_levelup = true
	gain_xp(maxi(1,int(xp_needed)-int(xp)))
	tutorial_allow_levelup = false

func _tutorial_spawn_xp_orb(pos: Vector2, rare: bool = false, group_name: String = ""):
	if not is_instance_valid(player):
		return null
	var orb = XpOrbScript.new()
	orb.configure(player,_rare_xp_value() if rare else 1,self,rare)
	orb.set_pickup_radius(46.0)
	orb.global_position = pos
	add_child(orb)
	if group_name != "":
		orb.add_to_group(group_name)
	cached_orb_count += 1
	return orb

func _tutorial_spawn_pickup(kind: String,pos: Vector2,group_name: String = "tutorial_pickup"):
	if not is_instance_valid(player):
		return null
	var pickup = PickupScript.new()
	pickup.configure(player,kind)
	pickup.global_position = pos
	add_child(pickup)
	pickup.add_to_group("endless_drop")
	if group_name != "":
		pickup.add_to_group(group_name)
	return pickup

func _tutorial_spawn_vase(pos: Vector2) -> void:
	var vase = XpVaseScript.new()
	vase.configure(player,self,240.0)
	vase.global_position = pos
	add_child(vase)

func _tutorial_spawn_elite(pos: Vector2) -> void:
	var elite = EliteScript.new()
	elite.configure(player)
	elite.max_health = 8
	elite.health = 8
	elite.threat_scale = 0.72
	elite.global_position = pos
	add_child(elite)
	elite.active = true
	registered_enemy_ids[elite.get_instance_id()] = elite
	elite.tree_exited.connect(notify_enemy_removed.bind(elite.get_instance_id()))

func _finish_tutorial(completed: bool) -> void:
	if completed:
		progress["tutorial_completed"] = true
		_save_progress()
	tutorial_active = false
	tutorial_pending = false
	tutorial_allow_levelup = false
	run_active = false
	levelup_open = false
	get_tree().paused = false
	_clear_run_nodes()
	if is_instance_valid(hud_layer):
		hud_layer.queue_free()
	if is_instance_valid(level_layer):
		level_layer.queue_free()
	if is_instance_valid(menu_layer):
		menu_layer.visible = true
	if is_instance_valid(class_layer):
		class_layer.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(audio_manager):
		audio_manager.play_menu_music()
	if completed:
		_show_menu_toast(_L("tutorial.complete"))

func _show_menu_toast(text_value: String) -> void:
	if not is_instance_valid(menu_layer):
		return
	var label := Label.new()
	label.position = Vector2(280,458)
	label.size = Vector2(400,30)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.text = text_value
	label.add_theme_font_size_override("font_size",11)
	label.add_theme_color_override("font_color",Color(0.94,0.93,0.88,0.64))
	menu_layer.add_child(label)
	var tween := create_tween()
	tween.tween_interval(1.4)
	tween.tween_property(label,"modulate:a",0.0,0.7)
	tween.tween_callback(label.queue_free)

func _start_run(kind: String) -> void:
	_clear_run_nodes()
	selected_class = kind
	tutorial_active = tutorial_pending
	tutorial_pending = false
	tutorial_allow_levelup = false
	if not tutorial_active:
		progress["profile_runs_started"] = int(progress.get("profile_runs_started",0))+1
		progress["profile_class_"+kind] = int(progress.get("profile_class_"+kind,0))+1
		_save_progress()
	run_active = true
	dead_open = false
	pause_open = false
	elapsed = 0.0
	spawn_accumulator = 0.0
	cleanup_timer = 2.0
	next_wave_time = randf_range(48.0,82.0)
	next_elite_time = randf_range(98.0,154.0)
	boss_spawn_time = 9999.0 if tutorial_active else randf_range(570.0,630.0)
	silver_chest_timer = randf_range(44.0,88.0)
	gold_chest_timer = randf_range(135.0,235.0)
	vase_spawn_timer = randf_range(28.0,54.0)
	vases_broken_run = 0
	skeleton_entry_time = randf_range(38.0,72.0)
	stalker_entry_time = randf_range(102.0,168.0)
	brute_entry_time = randf_range(185.0,285.0)
	warder_entry_time = randf_range(270.0,390.0)
	shaman_entry_time = randf_range(320.0,430.0)
	wave_number = 0
	kill_count = 0
	elite_kills = 0
	boss_spawned = false
	boss_defeated = false
	boss_instance = null
	director_stationary_time = 0.0
	director_density_timer = 0.0
	director_local_enemy_count = 0
	director_pressure = 0.0
	skeleton_shot_tokens = skeleton_shot_token_max
	if is_instance_valid(boss_bar):
		boss_bar.queue_free()
	boss_bar = null
	level = 1
	xp = 0
	xp_needed = _xp_for_next(level)
	pending_levelups = 0
	pending_rare_choices = 0
	consumable_slots = ["","","","","","","","","",""]
	consumable_details_visible = false
	consumable_use_count = 0
	last_consumable_used = ""
	last_consumable_slot = -1
	tutorial_consumables_locked = tutorial_active
	acquired_traits.clear()
	recent_rune_offer_keys.clear()
	recent_rune_offer_ids.clear()
	registered_enemy_ids.clear()
	spatial_buckets.clear()
	spatial_enemy_cache.clear()
	cached_orb_count = 0
	xp_merge_target = null
	menu_layer.visible = false
	class_layer.visible = false
	death_decal_batch = DeathDecalBatchScript.new()
	add_child(death_decal_batch)
	_create_player()
	_create_hud()
	_create_aim_cursor()
	if is_instance_valid(audio_manager):
		audio_manager.play_game_music()
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	if tutorial_active:
		tutorial_controller = TutorialScript.new()
		tutorial_controller.configure(self,player)
		add_child(tutorial_controller)
	else:
		_show_banner(_LF("banner.endless",[_class_name(kind)]),2.4)

func _create_player() -> void:
	player = PlayerScript.new()
	player.set_screen_shake_enabled(bool(progress.get("screen_shake", true)))
	player.global_position = CENTER
	player.set_mage_type(selected_class)
	player.set_endless_mode(true)
	player.died.connect(_on_player_died)
	add_child(player)
	player.visible = true
	player.active = true
	player.spawning = false
	player.modulate = Color.WHITE
	player.scale = Vector2.ONE
	player.health = player.max_health
	player.camera.limit_left = 0
	player.camera.limit_top = 0
	player.camera.limit_right = int(WORLD_SIZE.x)
	player.camera.limit_bottom = int(WORLD_SIZE.y)
	player.camera.position_smoothing_enabled = false
	player.camera.position_smoothing_speed = 0.0

func _create_aim_cursor() -> void:
	if is_instance_valid(aim_cursor):
		aim_cursor.queue_free()
	aim_cursor = EndlessAimCursorScript.new()
	aim_cursor.configure(self)
	add_child(aim_cursor)

func _create_hud() -> void:
	if is_instance_valid(hud_layer):
		hud_layer.queue_free()
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 40
	hud_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(hud_layer)
	hud_widget = HudDisplayScript.new()
	hud_widget.position = Vector2.ZERO
	hud_widget.size = Vector2(960,540)
	hud_widget.configure(player,self)
	hud_layer.add_child(hud_widget)
	timer_label = Label.new()
	timer_label.position = Vector2(390,14)
	timer_label.size = Vector2(180,32)
	timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	timer_label.text = "00:00"
	timer_label.add_theme_font_size_override("font_size",20)
	hud_layer.add_child(timer_label)
	boss_timer_label = null
	boss_indicator = BossIndicatorScript.new()
	boss_indicator.position = Vector2(430,48)
	boss_indicator.size = Vector2(120,34)
	boss_indicator.configure(self)
	hud_layer.add_child(boss_indicator)
	level_label = Label.new()
	level_label.position = Vector2(20,14)
	level_label.size = Vector2(200,26)
	level_label.text = _LF("hud.level",[1,_class_name(selected_class)])
	level_label.add_theme_font_size_override("font_size",11)
	hud_layer.add_child(level_label)
	kill_label = Label.new()
	kill_label.position = Vector2(740,14)
	kill_label.size = Vector2(200,26)
	kill_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	kill_label.text = _LF("hud.kills",[0])
	kill_label.add_theme_font_size_override("font_size",10)
	hud_layer.add_child(kill_label)
	xp_bar = null
	xp_label = null
	xp_meter = XpMeterScript.new()
	xp_meter.position = Vector2(18,40)
	xp_meter.size = Vector2(260,34)
	xp_meter.configure(self)
	hud_layer.add_child(xp_meter)
	banner_label = Label.new()
	banner_label.position = Vector2(180,78)
	banner_label.size = Vector2(600,46)
	banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_label.add_theme_font_size_override("font_size",18)
	banner_label.add_theme_color_override("font_color",Color(0.08,0.08,0.08,0.80))
	hud_layer.add_child(banner_label)
	threat_indicator = ThreatIndicatorScript.new()
	threat_indicator.configure(player)
	threat_indicator.position = Vector2.ZERO
	threat_indicator.size = Vector2(960,540)
	hud_layer.add_child(threat_indicator)

	stats_layer = CanvasLayer.new()
	stats_layer.layer = 90
	stats_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	stats_layer.visible = false
	add_child(stats_layer)
	stats_panel = StatsPanelScript.new()
	stats_panel.position = Vector2.ZERO
	stats_panel.size = Vector2(960,540)
	stats_panel.configure(player,self)
	stats_layer.add_child(stats_panel)
	stats_visible = false

func _process(delta: float) -> void:
	# Front-end animation does not need to keep running invisibly behind an active run.
	if not run_active:
		_update_menu_radial(delta)
		if is_instance_valid(radial_blur):
			radial_blur.open_amount = radial_anim
		if is_instance_valid(radial_fx):
			radial_fx.open_amount = radial_anim
			radial_fx.center_point = Vector2(480, 308)
			var pts: Array = []
			for button in radial_buttons:
				if is_instance_valid(button) and button.visible:
					pts.append(button.position + button.size * 0.5)
			radial_fx.button_points = pts
		var fade: float = 1.0 - radial_anim * 0.62
		if is_instance_valid(menu_mode_tag):
			menu_mode_tag.modulate.a = 0.34 * fade
		if is_instance_valid(menu_click_hint):
			menu_click_hint.modulate.a = 0.28 * fade
		if is_instance_valid(menu_record_line):
			menu_record_line.modulate.a = 0.34 * fade
		if is_instance_valid(menu_version_line):
			menu_version_line.modulate.a = 1.0
	if banner_timer > 0.0:
		banner_timer = maxf(0.0,banner_timer-delta)
		if is_instance_valid(banner_label):
			banner_label.modulate.a = clampf(banner_timer*1.5,0.0,1.0)
	if not run_active or levelup_open or dead_open or pause_open or stats_visible:
		return
	elapsed += delta
	skeleton_shot_tokens = minf(skeleton_shot_token_max,skeleton_shot_tokens+delta*skeleton_shot_refill)
	_update_director_state(delta)
	_update_unlocks()
	if tutorial_active:
		hud_refresh_timer -= delta
		if hud_refresh_timer <= 0.0:
			hud_refresh_timer = 1.0/30.0
			_update_hud()
		return
	_update_spawning(delta)
	_update_world_chests(delta)
	_update_vase_spawning(delta)
	cleanup_timer -= delta
	if cleanup_timer <= 0.0:
		cleanup_timer = 2.0
		_cleanup_far_enemies()
	if elapsed >= next_wave_time:
		wave_number += 1
		next_wave_time = elapsed + randf_range(48.0,88.0)
		_spawn_wave_event()
	if not boss_spawned and elapsed >= boss_spawn_time:
		_spawn_endless_boss()
	if elapsed >= next_elite_time:
		_spawn_elite()
		next_elite_time = elapsed + randf_range(102.0,168.0)
		if not boss_spawned and absf(next_elite_time-boss_spawn_time) < 42.0:
			next_elite_time += randf_range(38.0,68.0)
	hud_refresh_timer -= delta
	if hud_refresh_timer <= 0.0:
		hud_refresh_timer = 1.0/30.0
		_update_hud()

func _update_hud() -> void:
	if is_instance_valid(timer_label): timer_label.text = _format_time(elapsed)
	if is_instance_valid(level_label): level_label.text = _LF("hud.level",[level,_class_name(selected_class)])
	if is_instance_valid(kill_label): kill_label.text = _LF("hud.kills",[kill_count])

func _update_director_state(delta: float) -> void:
	if not is_instance_valid(player):
		return
	if player.velocity.length_squared() < 24.0*24.0:
		director_stationary_time = minf(6.0,director_stationary_time+delta)
	else:
		director_stationary_time = maxf(0.0,director_stationary_time-delta*2.2)
	director_density_timer -= delta
	if director_density_timer <= 0.0:
		director_density_timer = 0.42
		director_local_enemy_count = _count_enemies_near_player(680.0)
	var stage_target: int = mini(34,12+int(elapsed/75.0)*3)
	var shortage: float = clampf(float(stage_target-director_local_enemy_count)/maxf(1.0,float(stage_target)),0.0,1.0)
	var stationary_bonus: float = clampf((director_stationary_time-0.7)/3.3,0.0,1.0)
	director_pressure = clampf(shortage*0.78+stationary_bonus*0.42,0.0,1.0)

func _count_enemies_near_player(radius: float) -> int:
	if not is_instance_valid(player):
		return 0
	var count: int = 0
	var r2: float = radius*radius
	for node in get_nearby_enemies(player.global_position,radius):
		if is_instance_valid(node) and node.global_position.distance_squared_to(player.global_position) <= r2:
			count += 1
	return count

func _update_spawning(delta: float) -> void:
	# Horde pass: more bodies on screen, but the dangerous mob mix is still preserved.
	# The director can add pressure faster when the player is clearing the screen too efficiently.
	# 0.5.1 performance pass: keep the horde dense, just trim the ceiling ~7-9%.
	var enemy_cap: int = 41
	var interval: float = 0.82
	if elapsed < 60.0:
		enemy_cap = 46
		interval = 0.78
	elif elapsed < 150.0:
		enemy_cap = 66
		interval = 0.61
	elif elapsed < 270.0:
		enemy_cap = 88
		interval = 0.49
	elif elapsed < 390.0:
		enemy_cap = 112
		interval = 0.41
	elif elapsed < boss_spawn_time:
		enemy_cap = 132
		interval = 0.36
	else:
		enemy_cap = mini(190,146+int((elapsed-boss_spawn_time)/60.0)*8)
		interval = maxf(0.24,0.34-(elapsed-boss_spawn_time)*0.00018)
	interval *= lerpf(1.0,0.48,director_pressure)
	enemy_cap += int(round(director_pressure*22.0))
	# Keep the target "about 200 enemies" without letting director pressure quietly
	# push the real ceiling above 210 where render/physics cost spikes sharply.
	enemy_cap = mini(enemy_cap,202)
	if _enemy_count() >= enemy_cap:
		return
	spawn_accumulator += delta
	while spawn_accumulator >= interval and _enemy_count() < enemy_cap:
		spawn_accumulator -= interval
		var kind: String = _choose_enemy_kind()
		if kind == "stalker_pack":
			_spawn_stalker_flock()
		else:
			_spawn_enemy(kind)
		# Most waves get an extra disposable body. This creates the Survivor-like
		# carpet of weak enemies without replacing skeletons/brutes/etc.
		var extra_basic_chance: float = 0.40
		if elapsed >= 90.0:
			extra_basic_chance = 0.57
		if elapsed >= 240.0:
			extra_basic_chance = 0.69
		if director_pressure > 0.60:
			extra_basic_chance += 0.10
		if _enemy_count() < enemy_cap and randf() < minf(0.84,extra_basic_chance):
			_spawn_enemy("spider" if randf() < 0.42 else "slime")

func _choose_enemy_kind() -> String:
	# Per-run randomized entry windows replace the old exact minute breakpoints.
	# Basic mobs always remain the backbone; dangerous types slowly enter the pool.
	var danger: float = clampf(elapsed/720.0,0.0,1.0)
	var kinds: Array[String] = ["slime","spider"]
	var weights: Array[float] = [lerpf(0.54,0.31,danger),lerpf(0.28,0.20,danger)]
	if elapsed >= skeleton_entry_time:
		var ramp_skeleton: float = clampf((elapsed-skeleton_entry_time)/105.0,0.0,1.0)
		kinds.append("skeleton")
		weights.append(0.07+0.10*ramp_skeleton)
	if elapsed >= stalker_entry_time:
		var ramp_stalker: float = clampf((elapsed-stalker_entry_time)/125.0,0.0,1.0)
		kinds.append("stalker_pack")
		weights.append(0.035+0.075*ramp_stalker)
	if elapsed >= brute_entry_time:
		var ramp_brute: float = clampf((elapsed-brute_entry_time)/150.0,0.0,1.0)
		kinds.append("brute")
		weights.append(0.025+0.065*ramp_brute)
	if elapsed >= warder_entry_time:
		var ramp_warder: float = clampf((elapsed-warder_entry_time)/150.0,0.0,1.0)
		kinds.append("warder")
		weights.append(0.018+0.060*ramp_warder)
	if elapsed >= shaman_entry_time:
		var ramp_shaman: float = clampf((elapsed-shaman_entry_time)/160.0,0.0,1.0)
		kinds.append("shaman")
		weights.append(0.015+0.050*ramp_shaman)
	var total: float = 0.0
	for weight_value in weights:
		total += weight_value
	var roll: float = randf()*maxf(0.001,total)
	var cursor: float = 0.0
	for i in range(kinds.size()):
		cursor += weights[i]
		if roll <= cursor:
			return kinds[i]
	return "slime"

func _enemy_health_scale(kind: String) -> float:
	var minutes: float = elapsed/60.0
	# Paper-horde pacing: we want more enemies on screen and softer targets.
	# The first real HP growth now starts later and rises more gently.
	var growth_minutes: float = maxf(0.0,minutes-2.6)
	var time_scale: float = 1.0 + pow(growth_minutes/6.6, 1.08) * 0.92
	if kind == "spider":
		# Spiders should feel disposable; their threat is swarm pressure.
		return 1.0
	if kind == "slime":
		return maxf(1.0, time_scale * 0.72)
	if kind == "skeleton" or kind == "stalker" or kind == "shaman":
		return maxf(1.0, time_scale * 0.88)
	if kind == "brute" or kind == "warder":
		return maxf(1.0, time_scale * 0.96)
	return time_scale

func _spawn_stalker_flock() -> void:
	if not is_instance_valid(player):
		return
	var amount: int = mini(6,3+int(elapsed/180.0))
	var base_angle: float = randf_range(0.0,TAU)
	var center_pos: Vector2 = player.global_position+Vector2(cos(base_angle),sin(base_angle))*randf_range(500.0,610.0)
	for i in range(amount):
		if _enemy_count() >= 196:
			break
		var offset: Vector2 = Vector2(-sin(base_angle),cos(base_angle))*(float(i)-float(amount-1)*0.5)*38.0
		_spawn_enemy_at("stalker",center_pos+offset)
	_show_banner(_L("banner.stalker_pack"),0.9)

func _spawn_enemy(kind: String) -> void:
	if not is_instance_valid(player):
		return
	_spawn_enemy_at(kind,_spawn_around_player(440.0 if director_pressure < 0.55 else 390.0,590.0))

func _spawn_enemy_at(kind: String,pos: Vector2) -> void:
	if not is_instance_valid(player):
		return
	var enemy = EnemyScript.new()
	enemy.configure(kind,player)
	var hp_scale: float = _enemy_health_scale(kind)
	# Rounding avoids small enemies jumping an entire HP tier from a tiny scale increase.
	enemy.max_health = maxi(1,int(round(float(enemy.max_health)*hp_scale)))
	enemy.health = enemy.max_health
	var speed_scale: float = minf(1.55,1.0+elapsed/1100.0)
	if kind == "stalker":
		speed_scale *= 1.08
	enemy.move_speed *= speed_scale
	enemy.detect_radius = maxf(enemy.detect_radius,940.0)
	if kind == "skeleton":
		enemy.attack_cooldown = randf_range(0.55,1.55)
	enemy.global_position = Vector2(clampf(pos.x,70.0,WORLD_SIZE.x-70.0),clampf(pos.y,70.0,WORLD_SIZE.y-70.0))
	enemy.endless_controller = self
	add_child(enemy)
	enemy.add_to_group("endless_spawn")
	registered_enemy_ids[enemy.get_instance_id()] = enemy

func _spawn_elite() -> void:
	if not is_instance_valid(player):
		return
	var elite = EliteScript.new()
	elite.configure(player)
	elite.threat_scale = minf(1.55,1.0+elapsed/900.0)
	var minutes: float = elapsed/60.0
	# Elites remain mini-bosses, but the first one is no longer a giant HP wall.
	# ~42 HP at 2:00, ~62 at 4:00, ~84 at 6:00.
	var target_hp: int = int(round(24.0+minutes*6.0+pow(minutes,1.25)*2.5))
	elite.max_health = maxi(28,target_hp)
	elite.health = elite.max_health
	elite.global_position = _spawn_around_player(500.0,610.0)
	add_child(elite)
	elite.active = true
	elite.add_to_group("endless_spawn")
	registered_enemy_ids[elite.get_instance_id()] = elite
	elite.tree_exited.connect(notify_enemy_removed.bind(elite.get_instance_id()))
	_show_banner(_LF("banner.elite_approach",[elite.max_health]),1.8)
	get_tree().call_group("audio_bus","play_boss_reveal")

func _spawn_endless_boss() -> void:
	if boss_spawned or not is_instance_valid(player):
		return
	boss_spawned = true
	boss_instance = MiniBossSkeletonScript.new()
	boss_instance.configure(player)
	boss_instance.max_health = 190+int(elapsed/30.0)*4
	boss_instance.health = boss_instance.max_health
	boss_instance.global_position = _spawn_around_player(520.0,580.0)
	boss_instance.defeated_event.connect(_on_endless_boss_defeated)
	add_child(boss_instance)
	registered_enemy_ids[boss_instance.get_instance_id()] = boss_instance
	boss_instance.tree_exited.connect(notify_enemy_removed.bind(boss_instance.get_instance_id()))
	boss_instance.visible = true
	boss_instance.intro_requested = true
	boss_instance.battle_started = true
	boss_instance.active = true
	boss_instance.process_mode = Node.PROCESS_MODE_PAUSABLE
	boss_bar = BossBarScript.new()
	boss_bar.position = Vector2(0,54)
	boss_bar.size = Vector2(960,64)
	boss_bar.configure(boss_instance)
	hud_layer.add_child(boss_bar)
	_show_banner(_L("banner.boss_arrives"),2.4)
	get_tree().call_group("audio_bus","play_boss_reveal")
	get_tree().call_group("audio_bus","play_boss_music")
	get_tree().call_group("screen_fx","pulse_boss")

func _on_endless_boss_defeated() -> void:
	if boss_defeated:
		return
	boss_defeated = true
	var reward_pos: Vector2 = player.global_position if is_instance_valid(player) else CENTER
	if is_instance_valid(boss_instance):
		reward_pos = boss_instance.global_position
		boss_instance.defeated = true
		boss_instance.active = false
	_spawn_chest(reward_pos)
	if is_instance_valid(player):
		player.on_enemy_killed(true)
	gain_xp(70)
	_show_banner(_L("banner.boss_defeated"),2.2)
	get_tree().call_group("audio_bus","play_boss_fall")
	get_tree().call_group("audio_bus","play_game_music")
	get_tree().call_group("screen_fx","pulse_boss")
	if is_instance_valid(boss_instance):
		boss_instance.queue_free()
	boss_instance = null

func _spawn_wave_event() -> void:
	_show_banner(_LF("banner.wave",[wave_number]),1.8)
	var amount: int = mini(18,4+wave_number)
	for i in range(amount):
		var kind: String = _choose_enemy_kind()
		if kind == "stalker_pack":
			_spawn_stalker_flock()
		else:
			_spawn_enemy(kind)
	get_tree().call_group("screen_fx","pulse_boss")

func _spawn_around_player(min_distance: float,max_distance: float) -> Vector2:
	for attempt in range(8):
		var angle: float = randf_range(0.0,TAU)
		var pos: Vector2 = player.global_position+Vector2(cos(angle),sin(angle))*randf_range(min_distance,max_distance)
		if pos.x > 80.0 and pos.x < WORLD_SIZE.x-80.0 and pos.y > 80.0 and pos.y < WORLD_SIZE.y-80.0:
			return pos
	var fallback: Vector2 = player.global_position+Vector2.RIGHT.rotated(randf_range(0.0,TAU))*min_distance
	return Vector2(clampf(fallback.x,80.0,WORLD_SIZE.x-80.0),clampf(fallback.y,80.0,WORLD_SIZE.y-80.0))

func on_enemy_defeated(pos: Vector2,kind: String,is_elite: bool) -> void:
	if not run_active: return
	kill_count += 1
	if not tutorial_active:
		if kind != "minion":
			progress["quest_total_kills"] = int(progress.get("quest_total_kills",0)) + 1
		if kind == "spider" and selected_class == "orbit":
			progress["quest_orbit_spider_kills"] = int(progress.get("quest_orbit_spider_kills",0)) + 1
	var xp_value: int = 1
	match kind:
		"spider","slime","skeleton": xp_value = 1
		"stalker": xp_value = 2
		"brute","shaman","warder": xp_value = 3
		"minion": xp_value = 1
		"elite": xp_value = 18
	var allow_rare_xp: bool = not is_elite and kind != "minion"
	_spawn_xp(pos,xp_value,allow_rare_xp)
	if is_elite:
		elite_kills += 1
		if not tutorial_active:
			progress["quest_elites"] = int(progress.get("quest_elites",0)) + 1
			_spawn_chest(pos)
	var luck: float = float(player.endless_luck) if is_instance_valid(player) else 0.0
	var drop_roll: float = randf()
	var drop_chance: float = 0.018+luck*0.018
	if not tutorial_active and not is_elite and drop_roll < drop_chance:
		var type_roll: float = randf()
		if type_roll < 0.58: _spawn_pickup(pos,"heal")
		elif type_roll < 0.86: _spawn_pickup(pos,"magnet")
		else: _spawn_pickup(pos,"bomb")
	if not tutorial_active:
		_update_unlocks()

func _spawn_xp(pos: Vector2,value: int,allow_rare: bool = true) -> void:
	var rare_chance: float = 0.08
	if is_instance_valid(player):
		rare_chance += float(player.endless_rare_xp_chance_add)
		rare_chance += float(player.endless_luck)*0.01
	rare_chance = clampf(rare_chance,0.0,0.30)
	var rare: bool = allow_rare and randf() < rare_chance
	var final_value: int = _rare_xp_value() if rare else value
	var orb_soft_cap: int = 180
	if horde_performance_tier == 1:
		orb_soft_cap = 130
	elif horde_performance_tier == 2:
		orb_soft_cap = 90
	elif horde_performance_tier >= 3:
		orb_soft_cap = 72
	if cached_orb_count >= orb_soft_cap and is_instance_valid(xp_merge_target):
		xp_merge_target.add_value(final_value)
		return
	var orb = XpOrbScript.new()
	orb.configure(player,final_value,self,rare)
	orb.global_position = pos
	add_child(orb)
	var pop_dir: Vector2 = Vector2.RIGHT.rotated(randf_range(0.0, TAU))
	var pop_speed: float = randf_range(46.0, 82.0) * (1.15 if rare else 1.0)
	orb.launch(pop_dir * pop_speed, randf_range(0.05, 0.11), false)
	cached_orb_count += 1
	xp_merge_target = orb

func _rare_xp_value() -> int:
	# Golden XP is a clean reward spike: 15% of the CURRENT level bar.
	# It does not depend on the defeated enemy's base XP value.
	var target: int = int(round(float(xp_needed) * 0.15))
	return maxi(1, target)

func on_rare_xp_collected(value: int) -> void:
	_show_banner(_LF("banner.gold_orb",[value]),0.9)
	get_tree().call_group("screen_fx","pulse_magic")

func on_xp_orb_removed() -> void:
	cached_orb_count = maxi(0,cached_orb_count-1)

func _spawn_pickup(pos: Vector2,kind: String) -> void:
	var pickup = PickupScript.new()
	pickup.configure(player,kind)
	pickup.global_position = pos
	add_child(pickup)
	pickup.add_to_group("endless_drop")

func _spawn_chest(pos: Vector2,tier: String = "elite",life_time: float = -1.0) -> void:
	var chest = ChestScript.new()
	chest.configure(player,tier,life_time)
	chest.global_position = pos
	add_child(chest)


func _active_world_chests() -> int:
	var count: int = 0
	for chest in get_tree().get_nodes_in_group("world_chest"):
		if is_instance_valid(chest):
			count += 1
	return count

func _has_world_chest(tier: String) -> bool:
	for chest in get_tree().get_nodes_in_group("world_chest"):
		if is_instance_valid(chest) and chest.has_method("get_chest_tier"):
			if str(chest.get_chest_tier()) == tier:
				return true
	return false

func _find_world_chest_position() -> Vector2:
	for _i in range(24):
		var pos: Vector2 = _spawn_around_player(620.0,1450.0)
		var blocked: bool = false
		for chest in get_tree().get_nodes_in_group("world_chest"):
			if is_instance_valid(chest) and chest.global_position.distance_squared_to(pos) < 540.0*540.0:
				blocked = true
				break
		if not blocked:
			return pos
	return _spawn_around_player(760.0,1320.0)

func _update_world_chests(delta: float) -> void:
	if not run_active:
		return
	world_chest_timer -= delta
	silver_chest_timer -= delta
	gold_chest_timer -= delta
	if _active_world_chests() >= 2:
		return
	if silver_chest_timer <= 0.0:
		silver_chest_timer = randf_range(58.0,108.0)
		if randf() < 0.46 and _active_world_chests() < 2:
			_spawn_chest(_find_world_chest_position(),"silver",90.0)
	if gold_chest_timer <= 0.0:
		gold_chest_timer = randf_range(115.0,185.0)
		if not _has_world_chest("gold") and _active_world_chests() < 2 and randf() < 0.26:
			_spawn_chest(_find_world_chest_position(),"gold",105.0)

func _active_vases() -> int:
	var count: int = 0
	for vase in get_tree().get_nodes_in_group("xp_vase"):
		if is_instance_valid(vase) and vase.get("dead") != true:
			count += 1
	return count

func _update_vase_spawning(delta: float) -> void:
	vase_spawn_timer -= delta
	if vase_spawn_timer > 0.0:
		return
	vase_spawn_timer = randf_range(36.0,78.0)
	if _active_vases() >= 3:
		return
	# Pots are discoverable but still RNG-driven. Failed rolls avoid a predictable cadence.
	if randf() > 0.72:
		return
	var vase = XpVaseScript.new()
	vase.configure(player,self,randf_range(82.0,126.0))
	vase.global_position = _spawn_around_player(randf_range(330.0,430.0),randf_range(650.0,880.0))
	add_child(vase)

func on_xp_vase_broken(pos: Vector2) -> void:
	vases_broken_run += 1
	if not tutorial_active:
		progress["quest_vases"] = int(progress.get("quest_vases",0)) + 1

	# Vase reward: 5-10 XP stones TOTAL, with 1-3 of them golden.
	# They still burst outward first and then get smoothly vacuumed into the player.
	var total_count: int = randi_range(5, 10)
	var golden_count: int = randi_range(1, mini(3, total_count))
	var normal_count: int = total_count - golden_count
	var spawn_index: int = 0

	for i in range(normal_count):
		var a: float = TAU * float(spawn_index) / float(total_count) + randf_range(-0.16, 0.16)
		spawn_index += 1
		var launch_dir: Vector2 = Vector2(cos(a), sin(a))
		var orb = XpOrbScript.new()
		orb.configure(player, 1, self, false)
		orb.global_position = pos + launch_dir * randf_range(5.0, 11.0)
		orb.set_pickup_radius(9999.0)
		add_child(orb)
		orb.launch(launch_dir * randf_range(130.0, 205.0), randf_range(0.26, 0.42), true)
		cached_orb_count += 1
		xp_merge_target = orb

	for i in range(golden_count):
		var a: float = TAU * float(spawn_index) / float(total_count) + randf_range(-0.12, 0.12)
		spawn_index += 1
		var rare_dir: Vector2 = Vector2(cos(a), sin(a))
		var rare = XpOrbScript.new()
		rare.configure(player, _rare_xp_value(), self, true)
		rare.global_position = pos + rare_dir * randf_range(7.0, 13.0)
		rare.set_pickup_radius(9999.0)
		add_child(rare)
		rare.launch(rare_dir * randf_range(155.0, 225.0), randf_range(0.30, 0.44), true)
		cached_orb_count += 1
		xp_merge_target = rare

	_show_banner(_L("banner.vase"),0.85)
	if not tutorial_active:
		_update_unlocks()
		_save_progress()

func get_consumable_slots() -> Array:
	return consumable_slots.duplicate()

func get_consumable_name(item_id: String) -> String:
	match item_id:
		"heal_minor": return _L("item.heal_minor")
		"xp_magnet": return _L("item.xp_magnet")
		"xp_burst_small": return _L("item.xp_burst_small")
		"gold_cache": return _L("item.gold_cache")
		"flux_spark": return _L("item.flux_spark")
		"champion_impulse": return _L("item.champion_impulse")
		"runic_shock": return _L("item.runic_shock")
		"heal_major": return _L("item.heal_major")
		"xp_burst_major": return _L("item.xp_burst_major")
		"dragon_breath": return _L("item.dragon_breath")
		"skyfire_storm": return _L("item.skyfire_storm")
		"flux_reserve": return _L("item.flux_reserve")
		"arcane_guard": return _L("item.arcane_guard")
		_: return ""

func get_consumable_description(item_id: String) -> String:
	match item_id:
		"heal_minor": return _L("itemdesc.heal_minor")
		"xp_magnet": return _L("itemdesc.xp_magnet")
		"xp_burst_small": return _L("itemdesc.xp_burst_small")
		"gold_cache": return _L("itemdesc.gold_cache")
		"flux_spark": return _L("itemdesc.flux_spark")
		"champion_impulse": return _L("itemdesc.champion_impulse")
		"runic_shock": return _L("itemdesc.runic_shock")
		"heal_major": return _L("itemdesc.heal_major")
		"xp_burst_major": return _L("itemdesc.xp_burst_major")
		"dragon_breath": return _L("itemdesc.dragon_breath")
		"skyfire_storm": return _L("itemdesc.skyfire_storm")
		"flux_reserve": return _L("itemdesc.flux_reserve")
		"arcane_guard": return _L("itemdesc.arcane_guard")
		_: return ""

func get_consumable_key_label(slot_index: int) -> String:
	return "0" if slot_index == 9 else str(slot_index+1)

func are_consumable_details_visible() -> bool:
	return consumable_details_visible

func _toggle_consumable_details() -> void:
	consumable_details_visible = not consumable_details_visible
	get_tree().call_group("audio_bus","play_ui_panel_open")
	if is_instance_valid(hud_widget):
		hud_widget.queue_redraw()

func find_consumable_slot(item_id: String) -> int:
	for i in range(consumable_slots.size()):
		if consumable_slots[i] == item_id:
			return i
	return -1

func set_tutorial_consumables_locked(value: bool) -> void:
	tutorial_consumables_locked = value

func _grant_consumable(item_id: String, announce: bool = true) -> int:
	if item_id == "":
		return -1
	for i in range(consumable_slots.size()):
		if consumable_slots[i] == "":
			consumable_slots[i] = item_id
			if announce:
				_show_banner(_LF("item.stored",[get_consumable_name(item_id),get_consumable_key_label(i)]),1.45)
			get_tree().call_group("audio_bus","play_magic_reload_finish")
			if is_instance_valid(hud_widget):
				hud_widget.queue_redraw()
			return i
	if announce:
		_show_banner(_L("item.full"),1.25)
	return -1

func _use_consumable_slot(slot_index: int) -> bool:
	if slot_index < 0 or slot_index >= consumable_slots.size() or not run_active:
		return false
	if tutorial_consumables_locked:
		return false
	var item_id: String = consumable_slots[slot_index]
	if item_id == "":
		return false
	consumable_slots[slot_index] = ""
	last_consumable_used = item_id
	last_consumable_slot = slot_index
	consumable_use_count += 1
	_apply_consumable(item_id)
	_show_banner(_LF("item.used",[get_consumable_name(item_id)]),1.15)
	get_tree().call_group("audio_bus","play_magic_reload_finish")
	if is_instance_valid(hud_widget):
		hud_widget.queue_redraw()
	return true

func _apply_consumable(item_id: String) -> void:
	if not is_instance_valid(player):
		return
	match item_id:
		"heal_minor":
			player.heal(2)
		"xp_magnet":
			for orb in get_tree().get_nodes_in_group("xp_orb"):
				if is_instance_valid(orb):
					orb.force_collect()
		"xp_burst_small":
			_xp_burst(0.14)
		"gold_cache":
			_spawn_rare_xp_cache(4)
		"flux_spark":
			_grant_flux_cache(26.0)
		"champion_impulse":
			_grant_dash_surge()
		"runic_shock":
			_skyfire_storm(4,4)
		"heal_major":
			player.heal(3)
		"xp_burst_major":
			_xp_burst(0.28)
		"dragon_breath":
			_dragon_breath_blast()
		"skyfire_storm":
			_skyfire_storm(7,6)
		"flux_reserve":
			_grant_flux_cache(48.0)
		"arcane_guard":
			player.invulnerability = maxf(player.invulnerability,2.6)
			_grant_dash_surge()
			player.heal(1)
			get_tree().call_group("screen_fx","pulse_magic")

func _dragon_breath_blast() -> void:
	if not is_instance_valid(player):
		return
	get_tree().call_group("screen_fx","pulse_boss")
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var delta_pos: Vector2 = enemy.global_position-player.global_position
		var dist: float = delta_pos.length()
		if dist > 560.0 or dist <= 0.001:
			continue
		var align: float = 1.0
		if player.aim_direction.length_squared() > 0.001:
			align = player.aim_direction.normalized().dot(delta_pos.normalized())
		if align < -0.20:
			continue
		var dmg: int = 8 if dist < 260.0 else (6 if dist < 420.0 else 4)
		enemy.take_damage(dmg,delta_pos.normalized())

func _spawn_rare_xp_cache(count_value: int) -> void:
	if not is_instance_valid(player):
		return
	for i in range(count_value):
		var orb = XpOrbScript.new()
		orb.configure(player,_rare_xp_value(),self,true)
		var dir: Vector2 = Vector2.RIGHT.rotated(TAU * float(i) / float(count_value))
		orb.global_position = player.global_position + dir * (24.0 + float(i % 2) * 12.0)
		add_child(orb)
		orb.launch(dir * randf_range(72.0, 104.0), 0.16, true)
		cached_orb_count += 1

func _skyfire_storm(strikes: int,power: int = 5) -> void:
	if not is_instance_valid(player):
		return
	get_tree().call_group("screen_fx","pulse_magic")
	var enemies: Array = []
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if is_instance_valid(enemy) and enemy.has_method("take_damage"):
			enemies.append(enemy)
	if enemies.is_empty():
		return
	for i in range(strikes):
		var enemy = enemies[randi()%enemies.size()]
		if not is_instance_valid(enemy):
			continue
		if enemy.has_method("take_damage"):
			enemy.take_damage(power,(enemy.global_position-player.global_position).normalized())
			get_tree().call_group("audio_bus","play_lightning")

func _grant_flux_cache(amount_value: float) -> void:
	if not is_instance_valid(player):
		return
	player.add_flux(amount_value)
	if player.flux < 100.0 and amount_value >= 38.0:
		player.flux_idle_timer = maxf(player.flux_idle_timer,2.4)
	get_tree().call_group("screen_fx","pulse_magic")

func _grant_dash_surge() -> void:
	if not is_instance_valid(player):
		return
	player.dash_charges = player.max_dash_charges
	player.elite_victory_buff_timer = maxf(player.elite_victory_buff_timer,10.0)
	get_tree().call_group("screen_fx","pulse_dash")

func _xp_burst(percent: float) -> int:
	var amount_value: int = maxi(2,int(round(float(xp_needed)*percent)))
	gain_xp(amount_value)
	return amount_value

func open_world_chest(tier: String) -> void:
	if not run_active or not is_instance_valid(player):
		return
	var item_id: String = ""
	if tutorial_active:
		# The lesson is deterministic: silver demonstrates storage and gold always
		# gives Dragon Breath so the player can immediately learn the 1-9 belt.
		item_id = "dragon_breath" if tier == "gold" else "heal_minor"
	else:
		var roll: float = randf()
		match tier:
			"gold":
				if roll < 0.20: item_id = "heal_major"
				elif roll < 0.36: item_id = "xp_burst_major"
				elif roll < 0.53: item_id = "dragon_breath"
				elif roll < 0.68: item_id = "skyfire_storm"
				elif roll < 0.82: item_id = "flux_reserve"
				else: item_id = "arcane_guard"
			"silver":
				if roll < 0.24: item_id = "heal_minor"
				elif roll < 0.42: item_id = "xp_magnet"
				elif roll < 0.57: item_id = "xp_burst_small"
				elif roll < 0.71: item_id = "gold_cache"
				elif roll < 0.84: item_id = "flux_spark"
				elif roll < 0.93: item_id = "champion_impulse"
				else: item_id = "runic_shock"
	_grant_consumable(item_id,true)

func gain_xp(amount: int) -> void:

	if not run_active or not is_instance_valid(player):
		return
	var final_amount: int = maxi(1,int(round(float(amount)*float(player.endless_xp_gain_mul))))
	if tutorial_active and not tutorial_allow_levelup:
		# Tutorial examples can award real XP without accidentally opening the
		# Rune modal before the Sensei reaches that lesson.
		xp = mini(xp+final_amount,maxi(0,xp_needed-1))
		return
	xp += final_amount
	var leveled: bool = false
	while xp >= xp_needed:
		xp -= xp_needed
		level += 1
		xp_needed = _xp_for_next(level)
		pending_levelups += 1
		leveled = true
	if leveled:
		_show_banner(_LF("banner.level",[level]),0.9)
		call_deferred("_try_open_levelup")

func collect_pickup(kind: String) -> void:
	if not is_instance_valid(player): return
	match kind:
		"heal":
			player.heal(2)
			_show_banner(_L("banner.heal2"),1.2)
		"magnet":
			for orb in get_tree().get_nodes_in_group("xp_orb"):
				if is_instance_valid(orb): orb.force_collect()
			_show_banner(_L("banner.magnet"),1.2)
		"bomb":
			for enemy in get_tree().get_nodes_in_group("enemy"):
				if is_instance_valid(enemy) and enemy.has_method("take_damage"):
					var direction: Vector2 = (enemy.global_position-player.global_position).normalized()
					enemy.take_damage(999,direction)
			_show_banner(_L("banner.annihilation"),1.2)
	get_tree().call_group("audio_bus","play_magic_reload_finish")

func open_elite_chest() -> void:
	if not run_active:
		return
	_grant_consumable("arcane_guard",true)

func _try_open_levelup() -> void:
	if levelup_open or dead_open or pause_open or not run_active:
		return
	if pending_levelups <= 0:
		return
	pending_levelups -= 1
	_open_levelup(false)

func _open_levelup(rare: bool) -> void:
	levelup_open = true
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	level_layer = CanvasLayer.new()
	level_layer.layer = 230
	level_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(level_layer)
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.04,0.05,0.045,0.76)
	level_layer.add_child(dim)
	var title: Label = Label.new()
	title.position = Vector2(0,54)
	title.size = Vector2(960,42)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = _L("levelup.rare") if rare else _LF("banner.level",[level])
	title.add_theme_font_size_override("font_size",26)
	level_layer.add_child(title)
	var sub: Label = Label.new()
	sub.position = Vector2(200,96)
	sub.size = Vector2(560,30)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.text = _L("levelup.rare_choose") if rare else _L("levelup.choose")
	sub.add_theme_font_size_override("font_size",10)
	sub.add_theme_color_override("font_color",Color(1,1,1,0.52))
	level_layer.add_child(sub)
	var choices: Array = _roll_upgrade_choices(rare)
	if choices.is_empty():
		levelup_open = false
		if is_instance_valid(level_layer): level_layer.queue_free()
		get_tree().paused = false
		Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
		if is_instance_valid(player): player.heal(1)
		call_deferred("_try_open_levelup")
		return
	for i in range(choices.size()):
		var id: String = str(choices[i])
		var card = TraitCardScript.new()
		card.position = Vector2(76+float(i)*278.0,142)
		card.size = Vector2(252,306)
		card.configure(id,EndlessCatalog.get_trait_name(id),EndlessCatalog.get_description(id,selected_class),selected_class,rare,[])
		card.mouse_entered.connect(_menu_hover_sfx)
		card.pressed.connect(_menu_click_sfx)
		card.pressed.connect(_choose_level_upgrade.bind(id))
		level_layer.add_child(card)

func _roll_upgrade_choices(_rare: bool) -> Array:
	var pool: Array = EndlessCatalog.offerable_ids(acquired_traits,selected_class)
	if pool.is_empty():
		return []
	# Every level-up has a readable shape instead of three cards from the same pile:
	# 1) something for your class, 2) a foundation Rune, 3) a wildcard/mechanic.
	# Each bucket avoids recent cards on its own, so a busy wildcard pool can never
	# accidentally remove the guaranteed Samurai/Orbital/etc. choice.
	var class_all: Array = []
	var foundation_all: Array = []
	var wildcard_all: Array = []
	for value in pool:
		var id: String = str(value)
		if EndlessCatalog.is_class_specific(id,selected_class):
			class_all.append(id)
		elif EndlessCatalog.is_foundation_rune(id):
			foundation_all.append(id)
		else:
			wildcard_all.append(id)
	var signature_all: Array = []
	for value in class_all:
		var class_id: String = str(value)
		if EndlessCatalog.is_signature_rune(class_id,selected_class):
			signature_all.append(class_id)
	var class_pool: Array = _without_recent_offers(signature_all)
	if class_pool.is_empty(): class_pool = _without_recent_offers(class_all)
	var foundation_pool: Array = _without_recent_offers(foundation_all)
	var wildcard_pool: Array = _without_recent_offers(wildcard_all)
	if class_pool.is_empty(): class_pool = signature_all.duplicate() if not signature_all.is_empty() else class_all.duplicate()
	if foundation_pool.is_empty(): foundation_pool = foundation_all.duplicate()
	if wildcard_pool.is_empty(): wildcard_pool = wildcard_all.duplicate()
	class_pool.shuffle()
	foundation_pool.shuffle()
	wildcard_pool.shuffle()
	var result: Array = []
	_append_random_unique(result,class_pool)
	_append_random_unique(result,foundation_pool)
	_append_random_unique(result,wildcard_pool)
	# Very late in a run one of the roles can genuinely be exhausted. Fill only then.
	var fill_pool: Array = _without_recent_offers(pool)
	if fill_pool.is_empty(): fill_pool = pool.duplicate()
	fill_pool.shuffle()
	for value in fill_pool:
		if result.size() >= 3:
			break
		var fill_id: String = str(value)
		if not result.has(fill_id):
			result.append(fill_id)
	for offered in result:
		var offered_id: String = str(offered)
		recent_rune_offer_ids.append(offered_id)
		recent_rune_offer_keys.append(EndlessCatalog.get_offer_key(offered_id))
	while recent_rune_offer_ids.size() > 12:
		recent_rune_offer_ids.pop_front()
	while recent_rune_offer_keys.size() > 12:
		recent_rune_offer_keys.pop_front()
	return result

func _without_recent_offers(source: Array) -> Array:
	var result: Array = []
	for value in source:
		var id: String = str(value)
		if recent_rune_offer_ids.has(id):
			continue
		if recent_rune_offer_keys.has(EndlessCatalog.get_offer_key(id)):
			continue
		result.append(id)
	return result

func _append_random_unique(target: Array,source: Array) -> void:
	for value in source:
		var id: String = str(value)
		if not target.has(id):
			target.append(id)
			return

func _choose_level_upgrade(id: String) -> void:
	if not levelup_open or not is_instance_valid(player): return
	if player.apply_endless_upgrade(id):
		acquired_traits.append(id)
	levelup_open = false
	if is_instance_valid(level_layer): level_layer.queue_free()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	_show_banner(EndlessCatalog.get_trait_name(id).to_upper(),1.3)
	call_deferred("_try_open_levelup")

func _class_unlocked(kind: String) -> bool:
	match kind:
		"storm": return bool(progress.get("storm_unlocked",false))
		"rift": return false
		"samurai": return bool(progress.get("samurai_unlocked",false))
		_: return true

func _class_quest_text(kind: String) -> String:
	match kind:
		"storm":
			return _LF("quest.storm",[mini(80,int(progress.get("quest_orbit_spider_kills",0)))])
		"rift":
			return _L("classes.temporarily_removed")
		"samurai":
			return _LF("quest.samurai",[mini(4,int(progress.get("quest_vases",0))),mini(100,int(progress.get("quest_total_kills",0)))])
		_: return _L("classes.released")

func _update_unlocks() -> void:
	if tutorial_active:
		return
	var changed: bool = false
	if not bool(progress.get("storm_unlocked",false)) and int(progress.get("quest_orbit_spider_kills",0)) >= 80:
		progress["storm_unlocked"] = true
		changed = true
		_show_banner(_L("banner.unlock_storm"),3.0)
	if not bool(progress.get("samurai_unlocked",false)) and int(progress.get("quest_vases",0)) >= 4 and int(progress.get("quest_total_kills",0)) >= 100:
		progress["samurai_unlocked"] = true
		changed = true
		_show_banner(_L("banner.unlock_samurai"),3.0)
	if changed:
		_save_progress()

func _record_profile_run(reason: String) -> void:
	progress["profile_total_time"] = float(progress.get("profile_total_time",0.0))+elapsed
	progress["profile_total_run_kills"] = int(progress.get("profile_total_run_kills",0))+kill_count
	progress["profile_total_run_elites"] = int(progress.get("profile_total_run_elites",0))+elite_kills
	progress["profile_total_levels"] = int(progress.get("profile_total_levels",0))+maxi(0,level-1)
	progress["profile_best_level"] = maxi(int(progress.get("profile_best_level",1)),level)
	if reason == "death":
		progress["profile_deaths"] = int(progress.get("profile_deaths",0))+1
	else:
		progress["profile_abandons"] = int(progress.get("profile_abandons",0))+1
	best_time = maxf(best_time,elapsed)
	best_kills = maxi(best_kills,kill_count)
	progress["best_time"] = best_time
	progress["best_kills"] = best_kills

func _on_player_died() -> void:
	if dead_open:
		return
	if tutorial_active:
		if is_instance_valid(tutorial_controller) and tutorial_controller.has_method("_finish"):
			tutorial_controller._finish(false)
		else:
			_finish_tutorial(false)
		return
	run_active = false
	dead_open = true
	_record_profile_run("death")
	_save_progress()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_create_death_screen()

func _create_death_screen() -> void:
	death_layer = CanvasLayer.new()
	death_layer.layer = 240
	death_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(death_layer)
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.04,0.04,0.04,0.80)
	death_layer.add_child(dim)
	var title: Label = Label.new()
	title.position = Vector2(0,110)
	title.size = Vector2(960,56)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = _L("death.title")
	title.add_theme_font_size_override("font_size",30)
	death_layer.add_child(title)
	var stats: Label = Label.new()
	stats.position = Vector2(280,180)
	stats.size = Vector2(400,110)
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.text = _LF("death.stats",[_format_time(elapsed),level,kill_count,elite_kills,acquired_traits.size()])
	stats.add_theme_font_size_override("font_size",13)
	death_layer.add_child(stats)
	var retry: Button = Button.new()
	retry.position = Vector2(285,330)
	retry.size = Vector2(180,46)
	retry.text = _L("death.retry")
	retry.pressed.connect(_restart_run)
	death_layer.add_child(retry)
	var menu: Button = Button.new()
	menu.position = Vector2(495,330)
	menu.size = Vector2(180,46)
	menu.text = _L("menu.main")
	menu.pressed.connect(_return_to_menu)
	death_layer.add_child(menu)

func _restart_run() -> void:
	var kind: String = selected_class
	get_tree().paused = false
	if is_instance_valid(death_layer): death_layer.queue_free()
	dead_open = false
	_start_run(kind)

func _return_to_menu() -> void:
	get_tree().paused = false
	if is_instance_valid(death_layer): death_layer.queue_free()
	if is_instance_valid(hud_layer): hud_layer.queue_free()
	dead_open = false
	_clear_run_nodes()
	_rebuild_menu_layers()
	if is_instance_valid(audio_manager): audio_manager.play_menu_music()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _rebuild_menu_layers() -> void:
	if is_instance_valid(menu_layer): menu_layer.queue_free()
	if is_instance_valid(class_layer): class_layer.queue_free()
	_create_menu()
	_create_class_select()
	class_layer.visible = false
	menu_layer.visible = true

func _try_world_interaction() -> bool:
	if not is_instance_valid(player):
		return false
	var best_node = null
	var best_distance_sq: float = INF
	for node in get_tree().get_nodes_in_group("world_interactable"):
		if not is_instance_valid(node) or not node.has_method("can_interact") or not node.has_method("interact"):
			continue
		if not bool(node.can_interact(player)):
			continue
		var d: float = player.global_position.distance_squared_to(node.global_position)
		if d < best_distance_sq:
			best_distance_sq = d
			best_node = node
	if is_instance_valid(best_node):
		return bool(best_node.interact(player))
	return false

func _key_to_consumable_slot(keycode: int) -> int:
	match keycode:
		KEY_1: return 0
		KEY_2: return 1
		KEY_3: return 2
		KEY_4: return 3
		KEY_5: return 4
		KEY_6: return 5
		KEY_7: return 6
		KEY_8: return 7
		KEY_9: return 8
		KEY_0: return 9
		_: return -1

func _unhandled_input(event: InputEvent) -> void:
	if not run_active or dead_open:
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_TAB:
		if not levelup_open and not pause_open:
			if stats_visible:
				_hide_stats()
			else:
				_show_stats()
		get_viewport().set_input_as_handled()
		return
	if tutorial_active and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		return
	if stats_visible:
		# TAB is its own full pause/read mode. ESC simply closes it instead of
		# stacking the normal pause menu on top.
		if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
			_hide_stats()
			get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_E and not levelup_open and not pause_open:
			if _try_world_interaction():
				get_viewport().set_input_as_handled()
				return
		if event.keycode == KEY_I and not levelup_open and not pause_open:
			_toggle_consumable_details()
			get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_R and not levelup_open and not pause_open:
			_toggle_attack_target_mode()
			get_viewport().set_input_as_handled()
			return
		var consumable_slot: int = _key_to_consumable_slot(event.keycode)
		if consumable_slot >= 0:
			if not levelup_open and not pause_open:
				_use_consumable_slot(consumable_slot)
			get_viewport().set_input_as_handled()
			return
	if levelup_open:
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		if pause_open: _resume_run()
		else: _pause_run()
		get_viewport().set_input_as_handled()

func _show_stats() -> void:
	if levelup_open or dead_open or pause_open or not is_instance_valid(stats_layer):
		return
	stats_visible = true
	if is_instance_valid(death_decal_batch):
		if death_decal_batch.has_method("trim_for_pause"):
			death_decal_batch.trim_for_pause()
		death_decal_batch.visible = false
	get_tree().paused = true
	stats_layer.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if is_instance_valid(stats_panel) and stats_panel.has_method("open_panel"):
		stats_panel.open_panel()

func _hide_stats() -> void:
	stats_visible = false
	if is_instance_valid(stats_layer):
		stats_layer.visible = false
	if is_instance_valid(death_decal_batch):
		death_decal_batch.visible = true
	if not levelup_open and not dead_open and not pause_open:
		get_tree().paused = false
		if run_active:
			Input.mouse_mode = Input.MOUSE_MODE_HIDDEN

func _pause_run() -> void:
	_hide_stats()
	pause_open = true
	if is_instance_valid(death_decal_batch):
		if death_decal_batch.has_method("trim_for_pause"):
			death_decal_batch.trim_for_pause()
		death_decal_batch.visible = false
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	pause_layer = CanvasLayer.new()
	pause_layer.layer = 235
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pause_layer)
	var dim: ColorRect = ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.035,0.038,0.036,0.84)
	pause_layer.add_child(dim)
	var panel: ColorRect = ColorRect.new()
	panel.position = Vector2(70,66)
	panel.size = Vector2(820,410)
	panel.color = Color(0.065,0.072,0.068,0.97)
	pause_layer.add_child(panel)
	var title: Label = Label.new()
	title.position = Vector2(96,88)
	title.size = Vector2(300,42)
	title.text = _L("pause.title")
	title.add_theme_font_size_override("font_size",26)
	pause_layer.add_child(title)
	var sub: Label = Label.new()
	sub.position = Vector2(98,126)
	sub.size = Vector2(300,24)
	sub.text = _L("pause.stats_hint")
	sub.add_theme_font_size_override("font_size",9)
	sub.add_theme_color_override("font_color",Color(1,1,1,0.42))
	pause_layer.add_child(sub)
	var resume: Button = Button.new()
	resume.position = Vector2(98,190)
	resume.size = Vector2(220,46)
	resume.text = _L("pause.resume")
	resume.pressed.connect(_resume_run)
	pause_layer.add_child(resume)
	var menu: Button = Button.new()
	menu.position = Vector2(98,252)
	menu.size = Vector2(220,46)
	menu.text = _L("menu.back")
	menu.pressed.connect(_pause_to_menu)
	pause_layer.add_child(menu)
	var tab_hint: Label = Label.new()
	tab_hint.position = Vector2(98,326)
	tab_hint.size = Vector2(220,64)
	tab_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tab_hint.text = _L("pause.tab_hint")
	tab_hint.add_theme_font_size_override("font_size",9)
	tab_hint.add_theme_color_override("font_color",Color(1,1,1,0.42))
	pause_layer.add_child(tab_hint)
	_add_pause_run_stats()

func _add_pause_run_stats() -> void:
	if not is_instance_valid(pause_layer) or not is_instance_valid(player):
		return
	var x: float = 388.0
	var title: Label = Label.new()
	title.position = Vector2(x,104)
	title.size = Vector2(450,28)
	title.text = _L("pause.run_stats")
	title.add_theme_font_size_override("font_size",15)
	pause_layer.add_child(title)
	var rows: Array = [
		[_L("stats.label.class"),_class_name(selected_class)],
		[_L("stats.label.run_time"),_format_time(elapsed)],
		[_L("stats.label.health"),"%d / %d" % [int(player.health),int(player.max_health)]],
		[_L("stats.label.active_runes"),str(acquired_traits.size())],
		[_L("stats.label.kills___elite"),"%d / %d" % [kill_count,elite_kills]],
		[_L("stats.label.base_damage"),str(_pause_base_damage())],
		[_L("stats.label.attack_rate"),_pause_attack_rate()],
		[_L("stats.label.movement"),str(int(player.move_speed))],
		[_L("stats.label.dash"),"%d/%d" % [int(player.dash_charges),int(player.max_dash_charges)]],
		[_L("stats.label.xp"),"+%d%%" % int(round((float(player.endless_xp_gain_mul)-1.0)*100.0))]
	]
	for i in range(rows.size()):
		var row: Array = rows[i]
		var y: float = 148.0+float(i)*29.0
		var l: Label = Label.new()
		l.position = Vector2(x,y)
		l.size = Vector2(205,22)
		l.text = str(row[0])
		l.add_theme_font_size_override("font_size",9)
		l.add_theme_color_override("font_color",Color(1,1,1,0.43))
		pause_layer.add_child(l)
		var v: Label = Label.new()
		v.position = Vector2(x+210,y)
		v.size = Vector2(210,22)
		v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		v.text = str(row[1])
		v.add_theme_font_size_override("font_size",10)
		v.add_theme_color_override("font_color",Color(0.94,0.93,0.89,0.88))
		pause_layer.add_child(v)

func _pause_base_damage() -> int:
	match selected_class:
		"storm": return int(player.storm_damage)
		"rift": return int(player.rift_damage)
		"samurai": return int(player.samurai_damage)
		_: return int(player.orbit_damage)

func _pause_attack_rate() -> String:
	var rate: float = 0.0
	if selected_class == "storm":
		rate = 1.0/maxf(0.01,float(player.storm_charge_duration)+0.78*float(player.storm_recovery_multiplier))
	else:
		rate = 1.0/maxf(0.01,float(player.shot_cooldown))
	return "%.1f/s" % rate

func _resume_run() -> void:
	pause_open = false
	if is_instance_valid(death_decal_batch):
		death_decal_batch.visible = true
	get_tree().paused = false
	if is_instance_valid(pause_layer): pause_layer.queue_free()
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN

func _pause_to_menu() -> void:
	pause_open = false
	get_tree().paused = false
	if run_active:
		_record_profile_run("abandon")
	_save_progress()
	if is_instance_valid(pause_layer): pause_layer.queue_free()
	if is_instance_valid(hud_layer): hud_layer.queue_free()
	run_active = false
	_clear_run_nodes()
	_rebuild_menu_layers()
	if is_instance_valid(audio_manager): audio_manager.play_menu_music()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _clear_run_nodes() -> void:
	if is_instance_valid(stats_layer): stats_layer.queue_free()
	stats_layer = null
	stats_panel = null
	stats_visible = false
	registered_enemy_ids.clear()
	spatial_buckets.clear()
	spatial_enemy_cache.clear()
	cached_orb_count = 0
	for group_name in ["endless_spawn","enemy","enemy_projectile","boss_summon","rift_scar","run_decal","run_vfx"]:
		for node in get_tree().get_nodes_in_group(group_name):
			if is_instance_valid(node): node.queue_free()
	for node in get_tree().get_nodes_in_group("xp_orb"):
		if is_instance_valid(node): node.queue_free()
	for node in get_tree().get_nodes_in_group("endless_drop"):
		if is_instance_valid(node): node.queue_free()
	for node in get_tree().get_nodes_in_group("necro_minion"):
		if is_instance_valid(node): node.queue_free()
	if is_instance_valid(boss_instance):
		boss_instance.queue_free()
	boss_instance = null
	if is_instance_valid(boss_bar):
		boss_bar.queue_free()
	boss_bar = null
	if is_instance_valid(player):
		player.queue_free()
	player = null
	if is_instance_valid(aim_cursor):
		aim_cursor.queue_free()
	aim_cursor = null
	death_decal_batch = null

func _cleanup_far_enemies() -> void:
	if not is_instance_valid(player): return
	for node in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(node): continue
		if node.global_position.distance_squared_to(player.global_position) > 1120.0*1120.0:
			node.queue_free()

func _enemy_count() -> int:
	return registered_enemy_ids.size()

func notify_enemy_removed(instance_id: int) -> void:
	registered_enemy_ids.erase(instance_id)

func _physics_process(delta: float) -> void:
	# This controller runs in ALWAYS mode so menus can still receive input, but
	# horde bookkeeping must stop completely while gameplay is frozen. Rebuilding
	# the spatial hash behind TAB/ESC was wasting CPU on a motionless battlefield.
	if not run_active or pause_open or levelup_open or dead_open or stats_visible or get_tree().paused:
		return

	horde_budget_timer -= delta
	if horde_budget_timer <= 0.0:
		horde_budget_timer = 0.35
		var count: int = registered_enemy_ids.size()
		if count >= 180:
			horde_performance_tier = 3
		elif count >= 140:
			horde_performance_tier = 2
		elif count >= 85:
			horde_performance_tier = 1
		else:
			horde_performance_tier = 0

	feedback_budget_timer -= delta
	if feedback_budget_timer <= 0.0:
		feedback_budget_timer = 0.10
		if horde_performance_tier >= 3:
			hit_feedback_budget = 3
			death_feedback_budget = 2
		elif horde_performance_tier == 2:
			hit_feedback_budget = 5
			death_feedback_budget = 3
		elif horde_performance_tier == 1:
			hit_feedback_budget = 10
			death_feedback_budget = 7
		else:
			hit_feedback_budget = 18
			death_feedback_budget = 12

	spatial_rebuild_timer -= delta
	if spatial_rebuild_timer <= 0.0:
		spatial_rebuild_timer = 0.24 if horde_performance_tier >= 3 else (0.19 if horde_performance_tier == 2 else (0.14 if horde_performance_tier == 1 else 0.10))
		_rebuild_enemy_spatial_hash()

func _rebuild_enemy_spatial_hash() -> void:
	spatial_buckets.clear()
	spatial_enemy_cache.clear()
	var stale_ids: Array[int] = []
	for id_value in registered_enemy_ids.keys():
		var node = registered_enemy_ids[id_value]
		if not is_instance_valid(node):
			stale_ids.append(int(id_value))
			continue
		spatial_enemy_cache.append(node)
		var cell: Vector2i = Vector2i(
			int(floor(node.global_position.x / spatial_cell_size)),
			int(floor(node.global_position.y / spatial_cell_size))
		)
		if not spatial_buckets.has(cell):
			spatial_buckets[cell] = []
		var bucket: Array = spatial_buckets[cell]
		bucket.append(node)
	for stale_id in stale_ids:
		registered_enemy_ids.erase(stale_id)

func get_nearby_enemies(pos: Vector2,radius: float = 120.0) -> Array:
	# Spatial query used by AI, attacks and VFX. We return bucket candidates and let
	# the caller do its exact shape/range test; this avoids SceneTree-wide scans.
	var result: Array = []
	if spatial_buckets.is_empty():
		return get_tree().get_nodes_in_group("enemy")
	var center_cell: Vector2i = Vector2i(int(floor(pos.x/spatial_cell_size)),int(floor(pos.y/spatial_cell_size)))
	var cell_radius: int = maxi(1,int(ceil(radius/spatial_cell_size)))
	# Once a query spans many cells, iterating hundreds of dictionary keys costs more
	# than walking the already-cached enemy list. Local attacks still use buckets.
	if cell_radius > 5:
		return spatial_enemy_cache
	for yy in range(-cell_radius,cell_radius+1):
		for xx in range(-cell_radius,cell_radius+1):
			var key: Vector2i = center_cell+Vector2i(xx,yy)
			if not spatial_buckets.has(key):
				continue
			var bucket: Array = spatial_buckets[key]
			for node in bucket:
				if is_instance_valid(node):
					result.append(node)
	return result

func get_horde_performance_tier() -> int:
	return horde_performance_tier

func get_xp_performance_tier() -> int:
	# XP can become the bottleneck before enemy count does. This tier is used only
	# for cosmetic redraw/proximity cadence; XP values, visuals and movement stay intact.
	if cached_orb_count >= 145 or horde_performance_tier >= 3:
		return 3
	if cached_orb_count >= 100 or horde_performance_tier >= 2:
		return 2
	if cached_orb_count >= 60 or horde_performance_tier >= 1:
		return 1
	return 0

func allow_enemy_hit_feedback() -> bool:
	if hit_feedback_budget <= 0:
		return false
	hit_feedback_budget -= 1
	return true

func allow_enemy_death_feedback() -> bool:
	if death_feedback_budget <= 0:
		return false
	death_feedback_budget -= 1
	return true

func request_skeleton_shot() -> bool:
	if skeleton_shot_tokens < 1.0:
		return false
	var projectile_cap: int = 16
	if horde_performance_tier >= 3:
		projectile_cap = 10
	elif horde_performance_tier == 2:
		projectile_cap = 13
	if get_tree().get_nodes_in_group("enemy_projectile").size() >= projectile_cap:
		return false
	skeleton_shot_tokens -= 1.0
	return true

func allow_cosmetic_fx() -> bool:
	var count: int = registered_enemy_ids.size()
	if count < 58:
		return true
	if count < 100:
		return randf() < 0.42
	if count < 140:
		return randf() < 0.18
	if count < 180:
		return randf() < 0.09
	return randf() < 0.04

func _xp_for_next(current_level: int) -> int:
	return maxi(20,int(round(14.0+pow(float(current_level),1.45)*7.0)))

func _show_banner(text_value: String,duration: float) -> void:
	if not is_instance_valid(banner_label): return
	banner_label.text = text_value
	banner_label.modulate.a = 1.0
	banner_timer = duration

func _class_name(kind: String) -> String:
	match kind:
		"storm": return _L("class.storm")
		"rift": return _L("class.rift")
		"samurai": return _L("class.samurai")
		_: return _L("class.orbit")

func _wrap_words(text_value: String,max_chars: int) -> String:
	var words: PackedStringArray = text_value.split(" ")
	var lines: PackedStringArray = PackedStringArray()
	var current: String = ""
	for word_value in words:
		var word: String = str(word_value)
		if current == "":
			current = word
		elif current.length()+1+word.length() <= max_chars:
			current += " "+word
		else:
			lines.append(current)
			current = word
	if current != "": lines.append(current)
	return "\n".join(lines)

func _format_time(seconds_value: float) -> String:
	var total: int = maxi(0,int(seconds_value))
	return "%02d:%02d" % [int(float(total)/60.0),total%60]

func _load_progress() -> void:
	progress = {"storm_unlocked":false,"rift_unlocked":false,"samurai_unlocked":false,"quest_orbit_spider_kills":0,"quest_elites":0,"quest_vases":0,"quest_total_kills":0,"best_time":0.0,"best_kills":0,"profile_runs_started":0,"profile_deaths":0,"profile_abandons":0,"profile_total_time":0.0,"profile_total_run_kills":0,"profile_total_run_elites":0,"profile_total_levels":0,"profile_best_level":1,"profile_class_orbit":0,"profile_class_storm":0,"profile_class_rift":0,"profile_class_samurai":0,"attack_target_mode":"nearest","screen_shake":true,"post_fx":true,"resolution_w":960,"resolution_h":540,"display_mode":"windowed","tutorial_prompted":false,"tutorial_completed":false}
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load("user://endless_progress.cfg") == OK:
		progress["storm_unlocked"] = bool(cfg.get_value("unlock","storm",false))
		progress["rift_unlocked"] = bool(cfg.get_value("unlock","rift",false))
		progress["samurai_unlocked"] = bool(cfg.get_value("unlock","samurai",false))
		progress["quest_orbit_spider_kills"] = int(cfg.get_value("quests","orbit_spiders",0))
		progress["quest_elites"] = int(cfg.get_value("quests","elites",0))
		progress["quest_vases"] = int(cfg.get_value("quests","vases",0))
		progress["quest_total_kills"] = int(cfg.get_value("quests","total_kills",0))
		progress["best_time"] = float(cfg.get_value("record","time",0.0))
		progress["best_kills"] = int(cfg.get_value("record","kills",0))
		progress["profile_runs_started"] = int(cfg.get_value("profile","runs_started",0))
		progress["profile_deaths"] = int(cfg.get_value("profile","deaths",0))
		progress["profile_abandons"] = int(cfg.get_value("profile","abandons",0))
		progress["profile_total_time"] = float(cfg.get_value("profile","total_time",0.0))
		progress["profile_total_run_kills"] = int(cfg.get_value("profile","run_kills",0))
		progress["profile_total_run_elites"] = int(cfg.get_value("profile","run_elites",0))
		progress["profile_total_levels"] = int(cfg.get_value("profile","total_levels",0))
		progress["profile_best_level"] = int(cfg.get_value("profile","best_level",1))
		progress["profile_class_orbit"] = int(cfg.get_value("profile","class_orbit",0))
		progress["profile_class_storm"] = int(cfg.get_value("profile","class_storm",0))
		progress["profile_class_rift"] = int(cfg.get_value("profile","class_rift",0))
		progress["profile_class_samurai"] = int(cfg.get_value("profile","class_samurai",0))
		progress["attack_target_mode"] = str(cfg.get_value("config","attack_target_mode","nearest"))
		progress["screen_shake"] = bool(cfg.get_value("config","screen_shake",true))
		progress["post_fx"] = bool(cfg.get_value("config","post_fx",true))
		progress["resolution_w"] = int(cfg.get_value("config","resolution_w",960))
		progress["resolution_h"] = int(cfg.get_value("config","resolution_h",540))
		progress["display_mode"] = str(cfg.get_value("config","display_mode","windowed"))
		progress["tutorial_prompted"] = bool(cfg.get_value("tutorial","prompted",false))
		progress["tutorial_completed"] = bool(cfg.get_value("tutorial","completed",false))
	best_time = float(progress.get("best_time",0.0))
	best_kills = int(progress.get("best_kills",0))
	attack_target_mode = str(progress.get("attack_target_mode","nearest"))
	if attack_target_mode == "highest":
		attack_target_mode = "nearest"
	if attack_target_mode != "nearest" and attack_target_mode != "mouse":
		attack_target_mode = "nearest"
	progress["attack_target_mode"] = attack_target_mode

func _save_progress() -> void:
	var cfg: ConfigFile = ConfigFile.new()
	cfg.set_value("unlock","storm",bool(progress.get("storm_unlocked",false)))
	cfg.set_value("unlock","rift",bool(progress.get("rift_unlocked",false)))
	cfg.set_value("unlock","samurai",bool(progress.get("samurai_unlocked",false)))
	cfg.set_value("quests","orbit_spiders",int(progress.get("quest_orbit_spider_kills",0)))
	cfg.set_value("quests","elites",int(progress.get("quest_elites",0)))
	cfg.set_value("quests","vases",int(progress.get("quest_vases",0)))
	cfg.set_value("quests","total_kills",int(progress.get("quest_total_kills",0)))
	cfg.set_value("record","time",best_time)
	cfg.set_value("record","kills",best_kills)
	cfg.set_value("profile","runs_started",int(progress.get("profile_runs_started",0)))
	cfg.set_value("profile","deaths",int(progress.get("profile_deaths",0)))
	cfg.set_value("profile","abandons",int(progress.get("profile_abandons",0)))
	cfg.set_value("profile","total_time",float(progress.get("profile_total_time",0.0)))
	cfg.set_value("profile","run_kills",int(progress.get("profile_total_run_kills",0)))
	cfg.set_value("profile","run_elites",int(progress.get("profile_total_run_elites",0)))
	cfg.set_value("profile","total_levels",int(progress.get("profile_total_levels",0)))
	cfg.set_value("profile","best_level",int(progress.get("profile_best_level",1)))
	cfg.set_value("profile","class_orbit",int(progress.get("profile_class_orbit",0)))
	cfg.set_value("profile","class_storm",int(progress.get("profile_class_storm",0)))
	cfg.set_value("profile","class_rift",int(progress.get("profile_class_rift",0)))
	cfg.set_value("profile","class_samurai",int(progress.get("profile_class_samurai",0)))
	cfg.set_value("config","attack_target_mode",attack_target_mode)
	cfg.set_value("config","screen_shake",bool(progress.get("screen_shake",true)))
	cfg.set_value("config","post_fx",bool(progress.get("post_fx",true)))
	cfg.set_value("config","resolution_w",int(progress.get("resolution_w",DisplayServer.window_get_size().x)))
	cfg.set_value("config","resolution_h",int(progress.get("resolution_h",540)))
	cfg.set_value("config","display_mode",str(progress.get("display_mode","windowed")))
	cfg.set_value("tutorial","prompted",bool(progress.get("tutorial_prompted",false)))
	cfg.set_value("tutorial","completed",bool(progress.get("tutorial_completed",false)))
	cfg.save("user://endless_progress.cfg")

func _draw() -> void:
	# Denser endless biome pass: clearer composition, richer detail and stronger ambience.
	draw_rect(Rect2(Vector2.ZERO,WORLD_SIZE),Color("#b9b89a"),true)
	_draw_ground_patch(Vector2(950,820),Vector2(520,300),Color("#c7c6ab"),0.34,46)
	_draw_ground_patch(Vector2(1820,3120),Vector2(640,360),Color("#c2c0a2"),0.28,52)
	_draw_ground_patch(Vector2(3520,2230),Vector2(740,420),Color("#c9c6a4"),0.18,60)
	_draw_ground_patch(Vector2(5180,980),Vector2(620,320),Color("#c1bea0"),0.30,50)
	_draw_ground_patch(Vector2(5900,3010),Vector2(680,360),Color("#c3c1a5"),0.26,54)
	_draw_ground_patch(Vector2(2840,760),Vector2(420,220),Color("#d1cdb1"),0.16,44)
	_draw_ground_patch(Vector2(4220,3590),Vector2(500,260),Color("#d0cab2"),0.15,44)
	_draw_path(PackedVector2Array([Vector2(360,2300),Vector2(1450,1860),CENTER,Vector2(5100,2270),Vector2(6640,1710)]),162.0)
	_draw_path(PackedVector2Array([Vector2(1920,240),Vector2(2420,1040),CENTER,Vector2(4130,3290),Vector2(4550,4150)]),112.0)
	_draw_path(PackedVector2Array([Vector2(710,1080),Vector2(1580,1240),Vector2(2430,960),Vector2(3310,1260),Vector2(4630,920),Vector2(6150,1050)]),84.0)
	_draw_pond(Vector2(980,880),Vector2(360,225))
	_draw_pond(Vector2(5990,3120),Vector2(330,190))
	_draw_pond(Vector2(5100,1100),Vector2(240,150))
	_draw_ruin(Vector2(1790,1100),Vector2(205,78))
	_draw_ruin(Vector2(4700,1260),Vector2(180,74))
	_draw_ruin(Vector2(1440,3290),Vector2(150,68))
	_draw_ruin(Vector2(4300,3260),Vector2(200,72))
	_draw_ruin(Vector2(6160,2030),Vector2(160,60))
	_draw_stone_circle(CENTER,172.0)
	_draw_grove(Vector2(780,3400),15,260.0)
	_draw_grove(Vector2(6170,760),15,270.0)
	_draw_grove(Vector2(1220,1730),10,170.0)
	_draw_grove(Vector2(5280,2120),12,200.0)
	_draw_grove(Vector2(2720,640),9,155.0)
	_draw_ruin_tower(Vector2(2320,1460),54.0)
	_draw_ruin_tower(Vector2(5650,1860),50.0)
	_draw_ruin_tower(Vector2(3460,3300),46.0)
	_draw_canvas_tent(Vector2(2130,2570),1.0)
	_draw_canvas_tent(Vector2(2470,2510),0.9)
	_draw_canvas_tent(Vector2(5480,920),0.85)
	_draw_fence_segment(Vector2(1880,2460),Vector2(2280,2430),8)
	_draw_fence_segment(Vector2(2480,2410),Vector2(2820,2460),7)
	_draw_fence_segment(Vector2(5200,845),Vector2(5620,840),8)
	_draw_fallen_log(Vector2(2380,2870),150.0,-0.28)
	_draw_fallen_log(Vector2(5570,2470),128.0,0.22)
	_draw_flower_patch(Vector2(720,2140),8,Color("#828b67"))
	_draw_flower_patch(Vector2(3140,1380),10,Color("#7b8361"))
	_draw_flower_patch(Vector2(5770,1540),9,Color("#7f8762"))
	_draw_flower_patch(Vector2(2260,2540),8,Color("#91886e"))
	_draw_reed_patch(Vector2(720,980),10)
	_draw_reed_patch(Vector2(5310,1130),9)
	_draw_reed_patch(Vector2(6140,3210),10)
	_draw_fog_band(1220.0,0.08,0.17)
	_draw_fog_band(2870.0,0.06,0.11)
	_draw_fog_band(3810.0,0.05,0.08)
	for i in range(82):
		var a: float = float(i)*2.311
		var r: float = 520.0+fmod(float(i)*181.0,2450.0)
		var p: Vector2 = CENTER+Vector2(cos(a)*r,sin(a)*r*0.68)
		if p.x > 110 and p.x < WORLD_SIZE.x-110 and p.y > 110 and p.y < WORLD_SIZE.y-110:
			_draw_grass_clump(p,float(i))
	for i in range(46):
		var a2: float = float(i)*1.881
		var r2: float = 400.0+fmod(float(i)*213.0,2760.0)
		var rock_pos: Vector2 = CENTER+Vector2(cos(a2)*r2,sin(a2)*r2*0.64)
		if rock_pos.x > 120 and rock_pos.x < WORLD_SIZE.x-120 and rock_pos.y > 120 and rock_pos.y < WORLD_SIZE.y-120:
			_draw_rock_cluster(rock_pos,0.72+float(i%4)*0.08)
	for i in range(24):
		var x: float = 320.0+float(i%6)*1120.0+float((i*37)%160)
		var y: float = 320.0+(float(i)/6.0)*930.0+float((i*53)%180)
		_draw_shrub(Vector2(x,y),0.84+float(i%3)*0.08)

func _draw_path(points: PackedVector2Array,width: float) -> void:
	for i in range(points.size()-1):
		draw_line(points[i],points[i+1],Color("#d3c7a8"),width)
		draw_line(points[i],points[i+1],Color(0.18,0.16,0.12,0.10),width*0.72)
		draw_line(points[i],points[i+1],Color(0.20,0.18,0.13,0.16),2.2)
	for i in range(points.size()-1):
		var dir: Vector2 = (points[i+1]-points[i]).normalized()
		var normal: Vector2 = Vector2(-dir.y,dir.x)
		for j in range(7):
			var f: float = float(j)/6.0
			var pos: Vector2 = points[i].lerp(points[i+1],f)
			draw_line(pos+normal*(width*0.48+float((j%2)*6)),pos+normal*(width*0.60+18.0),Color(0.30,0.26,0.20,0.08),1.0)

func _draw_pond(center: Vector2,radii: Vector2) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(56):
		var a: float = TAU*float(i)/56.0
		var wobble: float = 1.0+sin(float(i)*1.7)*0.035+cos(float(i)*0.9)*0.02
		pts.append(center+Vector2(cos(a)*radii.x*wobble,sin(a)*radii.y*wobble))
	draw_colored_polygon(pts,Color("#8fa6a0"))
	var outline: PackedVector2Array = pts.duplicate()
	outline.append(pts[0])
	draw_polyline(outline,Color(0.08,0.12,0.11,0.32),2.2)
	for i in range(10):
		var y: float = center.y-radii.y*0.58+float(i)*radii.y*0.12
		draw_line(Vector2(center.x-radii.x*0.56,y),Vector2(center.x+radii.x*0.44,y+6),Color(1,1,1,0.07),1.2)
	_draw_reed_patch(center+Vector2(-radii.x*0.72,radii.y*0.18),7)
	_draw_reed_patch(center+Vector2(radii.x*0.52,-radii.y*0.10),6)

func _draw_ruin(center: Vector2,size: Vector2) -> void:
	var r: Rect2 = Rect2(center-size*0.5,size)
	draw_rect(r,Color("#8f897c"),true)
	draw_rect(r,Color("#201b15"),false,2.0)
	for i in range(5):
		var x: float = r.position.x+12.0+float(i)*(r.size.x-24.0)/4.0
		draw_line(Vector2(x,r.position.y+5),Vector2(x-10,r.end.y-5),Color(0.12,0.11,0.10,0.22),1.0)
	for i in range(3):
		var stone: Rect2 = Rect2(Vector2(r.position.x+18.0+float(i)*34.0,r.position.y-12.0+float(i%2)*4.0),Vector2(28.0,10.0))
		draw_rect(stone,Color("#9d9688"),true)
		draw_rect(stone,Color(0.10,0.09,0.08,0.28),false,1.0)

func _draw_stone_circle(center: Vector2,radius: float) -> void:
	for i in range(14):
		var a: float = TAU*float(i)/14.0
		var p: Vector2 = center+Vector2(cos(a),sin(a))*radius
		draw_circle(p,16.0,Color("#817e75"))
		draw_arc(p,16.0,0.0,TAU,18,Color(0.08,0.08,0.08,0.28),1.3)
		if i % 2 == 0:
			draw_circle(p+Vector2(0,-2),5.0,Color(1,1,1,0.05))
	draw_arc(center,radius*0.62,0.0,TAU,56,Color(0.18,0.16,0.12,0.12),2.0)

func _draw_grove(center: Vector2,count: int,radius: float) -> void:
	for i in range(count):
		var a: float = TAU*float(i)/float(count)+float(i%3)*0.13
		var r: float = radius*(0.45+0.50*absf(sin(float(i)*1.83)))
		var p: Vector2 = center+Vector2(cos(a)*r,sin(a)*r*0.65)
		_draw_tree(p,0.8+float(i%4)*0.08)

func _draw_tree(center: Vector2,scale_value: float) -> void:
	draw_circle(center+Vector2(5,10)*scale_value,26.0*scale_value,Color(0.05,0.06,0.04,0.10))
	draw_rect(Rect2(center+Vector2(-4,5)*scale_value,Vector2(8,30)*scale_value),Color("#6a5b42"),true)
	draw_circle(center+Vector2(-10,-8)*scale_value,21.0*scale_value,Color("#64785d"))
	draw_circle(center+Vector2(11,-12)*scale_value,23.0*scale_value,Color("#708566"))
	draw_circle(center+Vector2(0,-28)*scale_value,21.0*scale_value,Color("#687d61"))
	draw_circle(center+Vector2(-2,-17)*scale_value,8.0*scale_value,Color(1,1,1,0.05))

func _draw_ground_patch(center: Vector2,size: Vector2,color_value: Color,alpha: float,steps: int) -> void:
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(steps):
		var a: float = TAU*float(i)/float(steps)
		var sx: float = 1.0+sin(float(i)*1.7)*0.06+cos(float(i)*0.7)*0.03
		var sy: float = 1.0+cos(float(i)*1.2)*0.07
		pts.append(center+Vector2(cos(a)*size.x*sx,sin(a)*size.y*sy))
	var c: Color = color_value
	c.a = alpha
	draw_colored_polygon(pts,c)

func _draw_reed_patch(center: Vector2,count: int) -> void:
	for i in range(count):
		var off: Vector2 = Vector2((float(i)-float(count)*0.5)*4.0,sin(float(i))*2.0)
		var h: float = 18.0+float((i*7)%8)
		draw_line(center+off,center+off+Vector2(sin(float(i))*3.0,-h),Color(0.24,0.32,0.20,0.38),1.2)

func _draw_flower_patch(center: Vector2,count: int,tint: Color) -> void:
	for i in range(count):
		var p: Vector2 = center+Vector2(float((i*17)%70)-35.0,float((i*29)%28)-14.0)
		draw_circle(p,3.6,Color(tint.r,tint.g,tint.b,0.22))
		draw_circle(p+Vector2(0,-2),1.0,Color(1,1,1,0.14))

func _draw_rock_cluster(center: Vector2,scale_value: float) -> void:
	for i in range(3):
		var off: Vector2 = Vector2(float(i-1)*10.0,float((i*11)%8)-4.0)*scale_value
		draw_circle(center+off+Vector2(2,4),9.0*scale_value,Color(0.06,0.06,0.05,0.08))
		draw_circle(center+off,7.0*scale_value,Color("#7e7a72"))
		draw_arc(center+off,7.0*scale_value,0.0,TAU,16,Color(0.08,0.08,0.08,0.18),1.0)

func _draw_fallen_log(center: Vector2,length_value: float,angle: float) -> void:
	var dir: Vector2 = Vector2.RIGHT.rotated(angle)
	var normal: Vector2 = Vector2(-dir.y,dir.x)
	var a: Vector2 = center-dir*length_value*0.5
	var b: Vector2 = center+dir*length_value*0.5
	draw_line(a,b,Color("#725f44"),12.0)
	draw_line(a+normal*4.0,b+normal*4.0,Color(1,1,1,0.06),2.0)
	draw_circle(a,7.0,Color("#6a563c"))
	draw_circle(b,7.0,Color("#6a563c"))

func _draw_shrub(center: Vector2,scale_value: float) -> void:
	draw_circle(center+Vector2(-6,-2)*scale_value,11.0*scale_value,Color("#778561"))
	draw_circle(center+Vector2(5,-5)*scale_value,10.0*scale_value,Color("#6e7a58"))
	draw_circle(center+Vector2(0,-11)*scale_value,9.0*scale_value,Color("#84906d"))
	draw_circle(center+Vector2(0,6)*scale_value,14.0*scale_value,Color(0.05,0.05,0.04,0.08))

func _draw_ruin_tower(center: Vector2,height_value: float) -> void:
	var r: Rect2 = Rect2(center+Vector2(-18,-height_value),Vector2(36,height_value))
	draw_rect(r,Color("#8f887b"),true)
	draw_rect(r,Color(0.10,0.10,0.09,0.28),false,2.0)
	draw_rect(Rect2(center+Vector2(-24,-height_value-8),Vector2(48,10)),Color("#999183"),true)
	draw_rect(Rect2(center+Vector2(-5,-28),Vector2(10,14)),Color("#2f2a23"),true)
	for i in range(2):
		var flag_base: Vector2 = center+Vector2(10,-height_value+6+i*6)
		draw_line(flag_base,flag_base+Vector2(0,-16),Color("#5f5342"),1.5)
		var flag: PackedVector2Array = PackedVector2Array([flag_base+Vector2(0,-16),flag_base+Vector2(16,-14),flag_base+Vector2(6,-7)])
		draw_colored_polygon(flag,Color(0.10,0.10,0.10,0.18))

func _draw_canvas_tent(center: Vector2,scale_value: float) -> void:
	var shadow: Vector2 = center+Vector2(0,18)*scale_value
	draw_circle(shadow,22.0*scale_value,Color(0.05,0.05,0.05,0.06))
	var body: PackedVector2Array = PackedVector2Array([
		center+Vector2(-22,16)*scale_value, center+Vector2(0,-14)*scale_value,
		center+Vector2(24,16)*scale_value, center+Vector2(0,12)*scale_value
	])
	draw_colored_polygon(body,Color("#cbc2ac"))
	draw_polyline(PackedVector2Array([body[0],body[1],body[2],body[3],body[0]]),Color(0.12,0.10,0.08,0.26),1.4)
	draw_line(center+Vector2(0,-12)*scale_value,center+Vector2(0,18)*scale_value,Color(0.18,0.16,0.13,0.22),1.2)
	draw_line(center+Vector2(-22,16)*scale_value,center+Vector2(-31,24)*scale_value,Color(0.16,0.13,0.10,0.18),1.0)
	draw_line(center+Vector2(24,16)*scale_value,center+Vector2(34,24)*scale_value,Color(0.16,0.13,0.10,0.18),1.0)

func _draw_fence_segment(a: Vector2,b: Vector2,posts: int) -> void:
	draw_line(a,b,Color("#705c40"),4.0)
	for i in range(posts+1):
		var p: Vector2 = a.lerp(b,float(i)/float(posts))
		draw_line(p+Vector2(0,-8),p+Vector2(0,14),Color("#7d674a"),3.0)
		draw_line(p+Vector2(-4,0),p+Vector2(4,0),Color(1,1,1,0.05),1.0)
	draw_line(a+Vector2(0,-7),b+Vector2(0,-7),Color("#7b6648"),3.0)

func _draw_fog_band(y: float,alpha: float,wobble: float) -> void:
	var pts: PackedVector2Array = PackedVector2Array([Vector2(0,y)])
	for i in range(18):
		var x: float = WORLD_SIZE.x * float(i) / 17.0
		var off: float = sin(float(i)*1.23)*28.0 + cos(float(i)*0.82)*16.0
		pts.append(Vector2(x,y+off*wobble))
	pts.append(Vector2(WORLD_SIZE.x,y+120.0))
	pts.append(Vector2(0,y+120.0))
	draw_colored_polygon(pts,Color(1,1,1,alpha))

func _draw_grass_clump(center: Vector2,seed_value: float) -> void:
	for i in range(5):
		var off: float = float(i-2)*3.2
		var h: float = 8.0+fmod(seed_value*3.2+float(i)*2.4,7.2)
		draw_line(center+Vector2(off,4),center+Vector2(off+sin(seed_value+float(i))*3.4,-h),Color(0.20,0.29,0.17,0.34),1.1)
