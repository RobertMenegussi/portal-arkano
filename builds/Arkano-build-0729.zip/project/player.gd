extends CharacterBody2D

signal died

const ProjectileScript = preload("res://projectile.gd")
const AfterimageScript = preload("res://afterimage.gd")
const HitFxScript = preload("res://hit_fx.gd")
const LightningStrikeScript = preload("res://lightning_strike.gd")
const RiftBurstScript = preload("res://rift_burst.gd")
const RiftScarScript = preload("res://rift_scar.gd")
const ArcaneBurstScript = preload("res://arcane_burst.gd")
const UpgradeCatalog = preload("res://upgrade_catalog.gd")
const EndlessCatalog = preload("res://endless_catalog.gd")
const TomeArsenalScript = preload("res://tome_arsenal.gd")
const RuneRuntimeScript = preload("res://rune_runtime.gd")

@export var move_speed: float = 245.0
@export var shot_cooldown: float = 0.82
@export var dash_speed: float = 760.0
@export var dash_duration: float = 0.135
@export var dash_recharge: float = 3.0
@export var magic_reload_duration: float = 1.18

var mage_type: String = "orbit"
var accuracy_spread: float = 0.055
var accuracy_level: int = 0
var max_accuracy_level: int = 5

# Style-specific upgrades sold by the merchant.
var orbit_damage: int = 1
var orbit_projectile_speed: float = 660.0
var orbit_reload_upgrades: int = 0
var orbit_power_upgrades: int = 0
var orbit_speed_upgrades: int = 0
var orbit_echo_upgrades: int = 0
var orbit_echo_chance: float = 0.0
var storm_damage: int = 2
var storm_radius: float = 38.0
var storm_charge_duration: float = 0.30
var storm_charge: float = 0.0
var storm_charging: bool = false
var storm_target: Vector2 = Vector2.ZERO
var storm_radius_upgrades: int = 0
var storm_power_upgrades: int = 0
var storm_tempo_upgrades: int = 0
var storm_range: float = 380.0
var storm_range_upgrades: int = 0
var storm_accuracy_upgrades: int = 0
var rift_damage: int = 1
var rift_radius: float = 38.0
var rift_charge_time: float = 0.42
var rift_wave_speed: float = 470.0
var rift_wave_range: float = 300.0
var rift_radius_upgrades: int = 0
var rift_power_upgrades: int = 0
var rift_tempo_upgrades: int = 0
var rift_range_upgrades: int = 0
var rift_accuracy_upgrades: int = 0
var rift_reload_upgrades: int = 0
var rift_max_charges: int = 2
var rift_charges: int = 2
var rift_reload_duration: float = 2.40
var rift_reload_timer: float = 0.0
var rift_reloading: bool = false
var rift_scar_duration: float = 4.0
var rift_tick_interval: float = 0.90
var samurai_damage: int = 2
var samurai_dash_damage: int = 3
var samurai_range: float = 96.0
var samurai_arc: float = 1.78
var samurai_slash_flash: float = 0.0
var samurai_dash_flash: float = 0.0
var samurai_dash_phase: int = 0
var samurai_post_dash_stun: float = 0.0
var samurai_dash_hit_ids: Dictionary = {}
var samurai_focus_refresh_timer: float = 0.0
var samurai_cached_focus: Vector2 = Vector2.RIGHT

# Run-build systems. Traits change behavior; relics trade power for a drawback.
var arcane_traits: Dictionary = {}
var unstable_relics: Dictionary = {}
var flux: float = 0.0
var flux_active: bool = false
var flux_timer: float = 0.0
var flux_duration: float = 5.2
var flux_recharge_delay: float = 22.0
var flux_recharge_timer: float = 0.0
var flux_idle_timer: float = 0.0
var flux_activation_count: int = 0
var storm_double_strike_relic: bool = false
var orbit_contact_cooldowns: Dictionary = {}
var equipped_upgrades: Array = ["","",""]
var upgrade_traits: Dictionary = {}

# Endless run progression. These stack for the current run and are rebuilt into the class baseline.
var endless_mode: bool = false
var endless_upgrades: Array = []
var endless_auto_target_timer: float = 0.0
var endless_target_position: Vector2 = Vector2.ZERO
var endless_target_node = null
var endless_has_target: bool = false
var endless_damage_multiplier: float = 1.0
var endless_pickup_radius_mul: float = 1.0
var endless_xp_gain_mul: float = 1.0
var endless_luck: float = 0.0
var endless_rare_xp_chance_add: float = 0.0
var endless_elite_damage_bonus: float = 0.0
var elite_victory_buff_timer: float = 0.0
var endless_regen_per_second: float = 0.0
var endless_regen_accumulator: float = 0.0
var endless_guard_chance: float = 0.0
var endless_crit_chance: float = 0.0
var endless_kill_heal_chance: float = 0.0
var endless_low_health_damage_add: int = 0
var endless_extra_casts: int = 0
var endless_rift_speed_add: float = 0.0
var endless_fov_zoom_multiplier: float = 1.0
var flux_gain_multiplier: float = 1.0
var storm_recovery_multiplier: float = 1.0
var tome_arsenal
var rune_runtime
var cached_endless_controller = null

var active: bool = false
var spawning: bool = false
var spawn_t: float = 0.0
var cutscene_locked: bool = false

var max_health: int = 6
var health: int = 6
var invulnerability: float = 0.0
var hurt_flash: float = 0.0
var hurt_knockback: Vector2 = Vector2.ZERO

var aim_direction: Vector2 = Vector2.RIGHT
var visual_aim_direction: Vector2 = Vector2.RIGHT
var visual_move_direction: Vector2 = Vector2.ZERO
var moving: bool = false
var move_direction: Vector2 = Vector2.ZERO
var walk_phase: float = 0.0
var idle_phase: float = 0.0
var sketch_timer: float = 0.0
var sketch_frame: int = 0

# Magic stones: six charges orbit the mage. Each cast consumes the stone it fires from.
var max_magic_stones: int = 6
var magic_stones: int = 6
var magic_shot_index: int = 0
var magic_orbit_t: float = 0.0
var magic_reload_timer: float = 0.0
var magic_reloading: bool = false
var shot_cooldown_timer: float = 0.0
var cast_flash: float = 0.0
var attack_release_block: bool = false
var tutorial_attack_locked: bool = false
var tutorial_safe_mode: bool = false
var tutorial_flux_guard: bool = false

var max_dash_charges: int = 1
var dash_charges: int = 1
var dash_recharge_timer: float = 0.0
var dash_active: bool = false
var dash_left: float = 0.0
var dash_direction: Vector2 = Vector2.RIGHT
var dash_ghost_timer: float = 0.0
var orbit_dash_pose_blend: float = 0.0
var orbit_dash_start_flash: float = 0.0
var orbit_dash_end_flash: float = 0.0
var storm_dash_flash: float = 0.0
var storm_dash_morph: float = 0.0
var current_dash_duration: float = 0.0
var camera_look_offset: Vector2 = Vector2.ZERO
var camera_zoom_state: Vector2 = Vector2.ONE
var shift_was_down: bool = false

var shake: float = 0.0
var screen_shake_enabled: bool = true
var camera: Camera2D
var admin_god_mode: bool = false
var footstep_timer: float = 0.0
var next_left_step: bool = true
var footprints: Array = []
var dust_puffs: Array = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1
	z_index = 30
	visible = false

	var collider: CollisionShape2D = CollisionShape2D.new()
	var shape: CircleShape2D = CircleShape2D.new()
	shape.radius = 12.0
	collider.shape = shape
	collider.position = Vector2(0, 8)
	add_child(collider)

	camera = Camera2D.new()
	camera.position_smoothing_enabled = false
	camera.position_smoothing_speed = 0.0
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = 5800
	camera.limit_bottom = 1440
	camera.enabled = true
	add_child(camera)
	camera.position = Vector2.ZERO
	camera.zoom = Vector2.ONE
	camera_look_offset = Vector2.ZERO
	camera_zoom_state = Vector2.ONE
	visual_aim_direction = Vector2.RIGHT
	visual_move_direction = Vector2.ZERO
	camera.make_current()
	tome_arsenal = TomeArsenalScript.new()
	tome_arsenal.configure(self)
	add_child(tome_arsenal)
	rune_runtime = RuneRuntimeScript.new()
	rune_runtime.configure(self)
	add_child(rune_runtime)

func _exit_tree() -> void:
	get_tree().call_group("screen_fx","set_arcane_surge",false)

func begin_spawn() -> void:
	visible = true
	active = false
	spawning = true
	spawn_t = 0.0
	scale = Vector2(0.2, 0.05)
	modulate = Color(1, 1, 1, 0)

func set_mage_type(value: String) -> void:
	mage_type = value
	_rebuild_upgrade_effects()
	refill_magic()
	refill_dash()
	storm_charging = false
	storm_charge = 0.0
	visual_aim_direction = aim_direction
	visual_move_direction = move_direction
	queue_redraw()

func set_endless_mode(value: bool) -> void:
	endless_mode = value
	endless_has_target = false
	endless_target_node = null
	endless_auto_target_timer = 0.0

func clear_endless_upgrades() -> void:
	endless_upgrades.clear()
	_rebuild_upgrade_effects()

func has_endless_upgrade(upgrade_id: String) -> bool:
	return endless_upgrades.has(upgrade_id)

func apply_endless_upgrade(upgrade_id: String) -> bool:
	if upgrade_id == "" or has_endless_upgrade(upgrade_id):
		return false
	endless_upgrades.append(upgrade_id)
	var old_max: int = max_health
	_rebuild_upgrade_effects()
	if max_health > old_max:
		# Maximum-life Runes grant the new life immediately instead of only
		# increasing the cap invisibly.
		health = mini(max_health,health+(max_health-old_max))
	refill_magic()
	if is_instance_valid(rune_runtime) and rune_runtime.has_method("on_rune_acquired"):
		rune_runtime.on_rune_acquired(upgrade_id)
	get_tree().call_group("audio_bus","play_magic_reload_finish")
	get_tree().call_group("screen_fx","pulse_spawn")
	return true

func get_endless_upgrades() -> Array:
	return endless_upgrades.duplicate()

func get_equipped_upgrades() -> Array:
	return equipped_upgrades.duplicate()

func equip_upgrade(slot: int, upgrade_id: String) -> void:
	if slot < 0 or slot >= 3:
		return
	equipped_upgrades[slot] = upgrade_id
	_rebuild_upgrade_effects()
	refill_magic()
	get_tree().call_group("audio_bus","play_magic_reload_finish")
	get_tree().call_group("screen_fx","pulse_spawn")

func clear_upgrades() -> void:
	equipped_upgrades = ["","",""]
	_rebuild_upgrade_effects()

func _rebuild_upgrade_effects() -> void:
	# Sandbox baseline. Every inventory item is reapplied from a clean class state.
	move_speed = 245.0
	dash_speed = 760.0
	dash_recharge = 3.0
	max_health = 6
	match mage_type:
		"storm": accuracy_spread = 0.028
		"rift": accuracy_spread = 0.012
		"samurai": accuracy_spread = 0.0
		_: accuracy_spread = 0.018
	if mage_type == "orbit":
		shot_cooldown = 0.82
	elif mage_type == "rift":
		shot_cooldown = 0.55
	elif mage_type == "samurai":
		shot_cooldown = 0.68
	else:
		shot_cooldown = 0.52
	magic_reload_duration = 1.10
	max_magic_stones = 6
	orbit_damage = 1
	orbit_projectile_speed = 780.0
	orbit_echo_chance = 0.0
	storm_damage = 2
	storm_radius = 42.0
	storm_charge_duration = 0.32
	storm_range = 380.0
	storm_recovery_multiplier = 1.0
	rift_damage = 1
	rift_radius = 28.0
	rift_wave_speed = 470.0
	rift_wave_range = 340.0
	rift_reload_duration = 2.40
	rift_scar_duration = 4.0
	rift_tick_interval = 0.90
	rift_max_charges = 2
	samurai_damage = 2
	samurai_dash_damage = 3
	samurai_range = 96.0
	samurai_arc = 1.78
	if mage_type == "samurai":
		move_speed = 258.0
		dash_speed = 1120.0
		dash_recharge = 4.0
	flux_duration = 5.2
	flux_gain_multiplier = 1.0
	max_dash_charges = 1
	endless_damage_multiplier = 1.0
	endless_pickup_radius_mul = 1.0
	endless_xp_gain_mul = 1.0
	endless_luck = 0.0
	endless_rare_xp_chance_add = 0.0
	endless_elite_damage_bonus = 0.0
	endless_regen_per_second = 0.0
	endless_guard_chance = 0.0
	endless_crit_chance = 0.0
	endless_kill_heal_chance = 0.0
	endless_low_health_damage_add = 0
	endless_extra_casts = 0
	endless_rift_speed_add = 0.0
	endless_fov_zoom_multiplier = 1.0
	upgrade_traits.clear()
	for id_value in equipped_upgrades:
		var id: String = str(id_value)
		if id == "":
			continue
		_apply_upgrade_effect(UpgradeCatalog.get_effect(id,mage_type))
	for endless_value in endless_upgrades:
		var endless_id: String = str(endless_value)
		if endless_id == "":
			continue
		_apply_upgrade_effect(EndlessCatalog.get_effect(endless_id,mage_type))
	# Safety net for the Vitality ladder. The generic effect pass already applies
	# these points, but this guarantees that a later trait/mutation rebuild can
	# never erase the maximum-life bonus from acquired Vitality ranks.
	max_health = maxi(max_health, 6 + _vitality_rune_bonus())
	# Apply mutation number changes after all run upgrades are parsed.
	if upgrade_traits.has("storm_overcharge"):
		storm_charge_duration += 0.10
		storm_damage += 1
		storm_radius += 5.0
	if upgrade_traits.has("rift_longscar"):
		rift_wave_range += 52.0
	health = mini(health,max_health)
	magic_stones = mini(magic_stones,max_magic_stones)
	rift_charges = mini(rift_charges,rift_max_charges)

func _vitality_rune_bonus() -> int:
	var bonus: int = 0
	for value in endless_upgrades:
		var rune_id: String = str(value)
		if not rune_id.begins_with("vitality_"):
			continue
		var effect: Dictionary = EndlessCatalog.get_effect(rune_id,mage_type)
		bonus += int(effect.get("max_health_add",0))
	return bonus

func _apply_upgrade_effect(effect: Dictionary) -> void:
	if effect.has("accuracy_mul"):
		accuracy_spread = maxf(0.0015, accuracy_spread * float(effect["accuracy_mul"]))
	if effect.has("accuracy_add"):
		accuracy_spread = clampf(accuracy_spread + float(effect["accuracy_add"]),0.0015,0.12)
	if effect.has("move_speed_mul"):
		move_speed *= float(effect["move_speed_mul"])
	if effect.has("damage_mul"):
		endless_damage_multiplier *= float(effect["damage_mul"])
	if effect.has("max_health_mul"):
		var prev_max_mul: int = max_health
		max_health = maxi(1,int(ceil(float(max_health)*float(effect["max_health_mul"]))))
		health = mini(max_health,health+maxi(0,max_health-prev_max_mul))
	if effect.has("dash_speed_mul"):
		dash_speed *= float(effect["dash_speed_mul"])
	if effect.has("samurai_range_mul") and mage_type == "samurai":
		samurai_range *= float(effect["samurai_range_mul"])
	if effect.has("samurai_arc_add") and mage_type == "samurai":
		samurai_arc = minf(PI*0.92,samurai_arc+float(effect["samurai_arc_add"]))
	if effect.has("samurai_dash_damage_add") and mage_type == "samurai":
		samurai_dash_damage += int(effect["samurai_dash_damage_add"])
	if effect.has("damage_add"):
		var add: int = int(effect["damage_add"])
		match mage_type:
			"storm": storm_damage = maxi(1,storm_damage + add)
			"rift": rift_damage = maxi(1,rift_damage + add)
			"samurai": samurai_damage = maxi(1,samurai_damage + add)
			_: orbit_damage = maxi(1,orbit_damage + add)
	if effect.has("cooldown_mul"):
		var cooldown_floor: float = 0.42 if mage_type == "orbit" else (0.32 if mage_type == "samurai" else 0.20)
		shot_cooldown = maxf(cooldown_floor, shot_cooldown * float(effect["cooldown_mul"]))
	if effect.has("reload_mul"):
		if mage_type == "rift":
			rift_reload_duration = maxf(1.15,rift_reload_duration*float(effect["reload_mul"]))
		else:
			magic_reload_duration = maxf(0.55,magic_reload_duration*float(effect["reload_mul"]))
	if effect.has("charge_mul"):
		storm_charge_duration = maxf(0.16,storm_charge_duration*float(effect["charge_mul"]))
	if effect.has("storm_recovery_mul"):
		storm_recovery_multiplier *= float(effect["storm_recovery_mul"])
	if effect.has("projectile_speed_add"):
		orbit_projectile_speed += float(effect["projectile_speed_add"])
	if effect.has("range_add"):
		if mage_type == "storm":
			storm_range += float(effect["range_add"])
		elif mage_type == "rift":
			rift_wave_range += float(effect["range_add"])
	if effect.has("echo_add"):
		orbit_echo_chance = minf(0.45,orbit_echo_chance+float(effect["echo_add"]))
	if effect.has("radius_add"):
		if mage_type == "storm":
			storm_radius = maxf(18.0,storm_radius + float(effect["radius_add"]))
		elif mage_type == "rift":
			rift_radius = maxf(14.0,rift_radius + float(effect["radius_add"]))
	if effect.has("move_speed_add"):
		move_speed += float(effect["move_speed_add"])
	if effect.has("dash_recharge_mul"):
		dash_recharge = maxf(0.70,dash_recharge*float(effect["dash_recharge_mul"]))
	if effect.has("flux_gain_mul"):
		flux_gain_multiplier *= float(effect["flux_gain_mul"])
	if effect.has("flux_duration_add"):
		flux_duration += float(effect["flux_duration_add"])
	if effect.has("max_health_add"):
		var prev_max_add: int = max_health
		max_health += int(effect["max_health_add"])
		health = mini(max_health,health+maxi(0,max_health-prev_max_add))
	if effect.has("pickup_mul"):
		endless_pickup_radius_mul *= float(effect["pickup_mul"])
	if effect.has("xp_mul"):
		endless_xp_gain_mul *= float(effect["xp_mul"])
	if effect.has("regen_add"):
		endless_regen_per_second += float(effect["regen_add"])
	if effect.has("luck_add"):
		endless_luck += float(effect["luck_add"])
	if effect.has("rare_xp_chance_add"):
		endless_rare_xp_chance_add += float(effect["rare_xp_chance_add"])
	if effect.has("elite_damage_add"):
		endless_elite_damage_bonus = minf(0.60,endless_elite_damage_bonus+float(effect["elite_damage_add"]))
	if effect.has("orbit_stone_add") and mage_type == "orbit":
		max_magic_stones = maxi(1,max_magic_stones + int(effect["orbit_stone_add"]))
	if effect.has("rift_charge_add") and mage_type == "rift":
		rift_max_charges += int(effect["rift_charge_add"])
	if effect.has("dash_charge_add"):
		max_dash_charges += int(effect["dash_charge_add"])
	if effect.has("guard_add"):
		endless_guard_chance = minf(0.55,endless_guard_chance+float(effect["guard_add"]))
	if effect.has("crit_add"):
		endless_crit_chance = minf(0.65,endless_crit_chance+float(effect["crit_add"]))
	if effect.has("kill_heal_add"):
		endless_kill_heal_chance = minf(0.22,endless_kill_heal_chance+float(effect["kill_heal_add"]))
	if effect.has("low_health_damage_add"):
		endless_low_health_damage_add += int(effect["low_health_damage_add"])
	if effect.has("extra_cast_add"):
		endless_extra_casts = mini(4,endless_extra_casts+int(effect["extra_cast_add"]))
	if effect.has("rift_speed_add"):
		endless_rift_speed_add += float(effect["rift_speed_add"])
	if effect.has("rift_tick_mul"):
		rift_tick_interval = maxf(0.25,rift_tick_interval*float(effect["rift_tick_mul"]))
	if effect.has("rift_duration_add"):
		rift_scar_duration += float(effect["rift_duration_add"])
	if effect.has("fov_zoom_mul"):
		endless_fov_zoom_multiplier = maxf(0.78,endless_fov_zoom_multiplier*float(effect["fov_zoom_mul"]))
	if effect.has("traits"):
		var traits: Array = effect["traits"]
		for trait_value in traits:
			upgrade_traits[str(trait_value)] = true

func has_trait(trait_id: String) -> bool:
	return bool(arcane_traits.get(trait_id,false)) or bool(upgrade_traits.get(trait_id,false))

func apply_arcane_trait(trait_id: String) -> bool:
	if has_trait(trait_id):
		return false
	arcane_traits[trait_id] = true
	match trait_id:
		"orbit_contact":
			pass
		"storm_overcharge":
			storm_charge_duration += 0.12
			storm_damage += 1
			storm_radius += 6.0
		"rift_longscar":
			rift_wave_range += 48.0
		"generic_vitality":
			max_health += 1
			health = mini(max_health,health+1)
		"generic_flux":
			flux_duration += 1.15
		"generic_dash":
			dash_recharge = maxf(0.78,dash_recharge*0.82)
		_:
			pass
	get_tree().call_group("screen_fx","pulse_spawn")
	get_tree().call_group("audio_bus","play_magic_reload_finish")
	return true

func has_relic(relic_id: String) -> bool:
	return bool(unstable_relics.get(relic_id,false))

func can_buy_relic(relic_id: String) -> bool:
	return not has_relic(relic_id)

func apply_unstable_relic(relic_id: String) -> bool:
	if has_relic(relic_id):
		return false
	unstable_relics[relic_id] = true
	match relic_id:
		"relic_orbit_hungry":
			orbit_damage += 1
			max_magic_stones = maxi(4,max_magic_stones-1)
			magic_stones = mini(magic_stones,max_magic_stones)
			magic_reload_duration += 0.22
		"relic_storm_burned":
			storm_double_strike_relic = true
			storm_charge_duration += 0.10
			accuracy_spread = minf(0.085,accuracy_spread+0.020)
		"relic_rift_voracious":
			rift_damage += 1
			rift_radius += 8.0
			rift_wave_range += 42.0
			rift_reload_duration += 0.58
		_:
			return false
	return true

func add_flux(amount: float) -> void:
	if flux_active or flux_recharge_timer > 0.0 or amount <= 0.0:
		return
	flux = clampf(flux+amount*flux_gain_multiplier,0.0,100.0)
	flux_idle_timer = 2.60
	if flux >= 100.0:
		_activate_flux()

func _activate_flux() -> void:
	flux = 100.0
	get_tree().call_group("screen_fx","set_arcane_surge",true)
	get_tree().call_group("audio_bus","play_arcane_surge")
	flux_active = true
	flux_timer = flux_duration
	flux_activation_count += 1
	if mage_type == "orbit":
		magic_reloading = false
		magic_reload_timer = 0.0
		magic_stones = max_magic_stones
		magic_shot_index = 0
	elif mage_type == "rift":
		rift_reloading = false
		rift_reload_timer = 0.0
		rift_charges = rift_max_charges
	get_tree().call_group("screen_fx","pulse_boss")
	get_tree().call_group("endless_controller","_show_banner",Loc.t("player.surge_banner"),1.8)
	get_tree().call_group("audio_bus","play_magic_reload_finish")
	add_camera_shake(0.45)

func _update_flux(delta: float) -> void:
	if flux_active:
		flux_timer -= delta
		flux = clampf(100.0*(flux_timer/maxf(flux_duration,0.001)),0.0,100.0)
		if flux_timer <= 0.0:
			flux_active = false
			flux_timer = 0.0
			flux = 0.0
			flux_recharge_timer = flux_recharge_delay
			get_tree().call_group("screen_fx","set_arcane_surge",false)
			if mage_type == "orbit" and magic_stones <= 0:
				_start_magic_reload()
			elif mage_type == "rift" and rift_charges <= 0:
				_start_rift_reload()
		return
	if flux_recharge_timer > 0.0:
		flux_recharge_timer = maxf(0.0, flux_recharge_timer-delta)
		flux = 0.0
		return
	flux_idle_timer = maxf(0.0,flux_idle_timer-delta)
	if flux_idle_timer <= 0.0 and flux > 0.0:
		flux = maxf(0.0,flux-delta*4.2)

func on_enemy_killed(elite: bool = false) -> void:
	# Paper-horde pacing: kills should build Flow at a satisfying rate while chain-killing.
	add_flux(11.0 if elite else 1.25)
	if elite and has_trait("aux_champion_spoils"):
		elite_victory_buff_timer = 10.0
		dash_charges = mini(max_dash_charges,dash_charges+1)
		get_tree().call_group("screen_fx","pulse_dash")
	get_tree().call_group("tome_arsenal","on_enemy_killed",elite)
	get_tree().call_group("rune_runtime","on_enemy_killed",elite)
	if endless_mode and endless_kill_heal_chance > 0.0 and health < max_health and randf() < endless_kill_heal_chance:
		heal(1)

func on_perfect_dodge() -> void:
	add_flux(4.0)
	if mage_type == "storm" and has_trait("storm_dodge_prime"):
		shot_cooldown_timer = 0.0
	get_tree().call_group("screen_fx","pulse_dash")
	add_camera_shake(0.45)

func _update_orbit_contact(_delta: float) -> void:
	if mage_type != "orbit" or not has_trait("orbit_contact") or magic_reloading:
		orbit_contact_cooldowns.clear()
		return
	var now_ms: int = Time.get_ticks_msec()
	for enemy in _enemy_candidates(110.0):
		if not is_instance_valid(enemy) or not enemy.has_method("take_damage"):
			continue
		var id: int = enemy.get_instance_id()
		var last_ms: int = int(orbit_contact_cooldowns.get(id,0))
		if now_ms-last_ms < 520:
			continue
		for slot in range(magic_stones):
			var stone_world: Vector2 = global_position+_stone_local_position(slot)
			if stone_world.distance_to(enemy.global_position) <= 17.0:
				orbit_contact_cooldowns[id] = now_ms
				var dir: Vector2 = (enemy.global_position-global_position).normalized()
				enemy.take_damage(1,dir)
				break

func improve_accuracy() -> bool:
	if accuracy_level >= max_accuracy_level:
		return false
	accuracy_level += 1
	var levels: Array[float] = [0.055, 0.045, 0.036, 0.027, 0.018, 0.010]
	accuracy_spread = levels[accuracy_level]
	return true

func can_improve_accuracy() -> bool:
	return accuracy_level < max_accuracy_level

func can_buy_style_upgrade(kind: String) -> bool:
	match kind:
		"accuracy":
			return can_improve_accuracy()
		"orbit_reload":
			return orbit_reload_upgrades < 3
		"orbit_power":
			return orbit_power_upgrades < 2
		"orbit_speed":
			return orbit_speed_upgrades < 3
		"orbit_echo":
			return orbit_echo_upgrades < 3
		"storm_radius":
			return storm_radius_upgrades < 3
		"storm_power":
			return storm_power_upgrades < 2
		"storm_tempo":
			return storm_tempo_upgrades < 3
		"storm_range":
			return storm_range_upgrades < 3
		"storm_accuracy":
			return storm_accuracy_upgrades < 4
		"rift_radius":
			return rift_radius_upgrades < 3
		"rift_power":
			return rift_power_upgrades < 2
		"rift_tempo":
			return rift_tempo_upgrades < 3
		"rift_range":
			return rift_range_upgrades < 3
		"rift_accuracy":
			return rift_accuracy_upgrades < 4
		"rift_reload":
			return rift_reload_upgrades < 3
	return false

func apply_style_upgrade(kind: String) -> bool:
	if not can_buy_style_upgrade(kind):
		return false
	match kind:
		"accuracy":
			return improve_accuracy()
		"orbit_reload":
			orbit_reload_upgrades += 1
			magic_reload_duration = maxf(0.68, magic_reload_duration * 0.88)
		"orbit_power":
			orbit_power_upgrades += 1
			orbit_damage += 1
		"orbit_speed":
			orbit_speed_upgrades += 1
			orbit_projectile_speed = minf(920.0, orbit_projectile_speed + 70.0)
			shot_cooldown = maxf(0.50, shot_cooldown * 0.96)
		"orbit_echo":
			orbit_echo_upgrades += 1
			orbit_echo_chance = minf(0.28, orbit_echo_chance + 0.08)
		"storm_radius":
			storm_radius_upgrades += 1
			storm_radius = minf(58.0, storm_radius + 6.0)
		"storm_power":
			storm_power_upgrades += 1
			storm_damage += 1
		"storm_tempo":
			storm_tempo_upgrades += 1
			storm_charge_duration = maxf(0.20, storm_charge_duration * 0.90)
		"storm_range":
			storm_range_upgrades += 1
			storm_range = minf(520.0, storm_range + 42.0)
		"storm_accuracy":
			storm_accuracy_upgrades += 1
			accuracy_spread = maxf(0.010, accuracy_spread * 0.80)
		"rift_radius":
			rift_radius_upgrades += 1
			rift_radius = minf(56.0, rift_radius + 6.0)
		"rift_power":
			rift_power_upgrades += 1
			rift_damage += 1
		"rift_tempo":
			rift_tempo_upgrades += 1
			rift_wave_speed = minf(690.0, rift_wave_speed + 55.0)
		"rift_range":
			rift_range_upgrades += 1
			rift_wave_range = minf(430.0, rift_wave_range + 38.0)
		"rift_accuracy":
			rift_accuracy_upgrades += 1
			accuracy_spread = maxf(0.012, accuracy_spread * 0.82)
		"rift_reload":
			rift_reload_upgrades += 1
			rift_reload_duration = maxf(1.45, rift_reload_duration * 0.88)
	return true

func set_screen_shake_enabled(value: bool) -> void:
	screen_shake_enabled = value
	if not value and is_instance_valid(camera):
		shake = 0.0
		camera.offset = Vector2.ZERO

func set_cutscene_lock(value: bool) -> void:
	cutscene_locked = value
	active = not value and not spawning and health > 0
	if value:
		velocity = Vector2.ZERO
		dash_active = false
		invulnerability = maxf(invulnerability, 30.0)
	else:
		invulnerability = 0.28

func suppress_attack_until_release() -> void:
	attack_release_block = true

func set_tutorial_attack_locked(value: bool) -> void:
	tutorial_attack_locked = value
	# Keep the same click/space that closed a dialogue from becoming an attack
	# on the first gameplay frame after the objective appears.
	attack_release_block = true
	if value:
		storm_charging = false
		storm_charge = 0.0

func set_tutorial_safe_mode(value: bool) -> void:
	tutorial_safe_mode = value
	if value and health <= 0:
		health = 1

func set_tutorial_flux_guard(value: bool) -> void:
	tutorial_flux_guard = value

func _physics_process(delta: float) -> void:
	_update_camera(delta)
	_update_sketch(delta)
	_update_dash_recharge(delta)
	_update_magic(delta)
	_update_flux(delta)
	_update_orbit_contact(delta)
	_update_endless_passives(delta)
	_update_footstep_fx(delta)
	elite_victory_buff_timer = maxf(0.0,elite_victory_buff_timer-delta)

	invulnerability = maxf(0.0, invulnerability - delta)
	hurt_flash = move_toward(hurt_flash, 0.0, delta * 7.5)
	hurt_knockback = hurt_knockback.move_toward(Vector2.ZERO, delta * 760.0)
	cast_flash = move_toward(cast_flash, 0.0, delta * 5.6)
	if mage_type == "orbit" and dash_active:
		orbit_dash_pose_blend = move_toward(orbit_dash_pose_blend, 1.0, delta * 18.0)
	else:
		orbit_dash_pose_blend = move_toward(orbit_dash_pose_blend, 0.0, delta * 7.0)
	orbit_dash_start_flash = move_toward(orbit_dash_start_flash, 0.0, delta * 7.5)
	orbit_dash_end_flash = move_toward(orbit_dash_end_flash, 0.0, delta * 6.0)
	storm_dash_flash = move_toward(storm_dash_flash, 0.0, delta * 6.8)
	var storm_target_morph: float = 1.0 if mage_type == "storm" and dash_active else 0.0
	storm_dash_morph = move_toward(storm_dash_morph, storm_target_morph, delta * (18.0 if storm_target_morph > storm_dash_morph else 7.6))
	samurai_slash_flash = move_toward(samurai_slash_flash,0.0,delta*7.5)
	samurai_dash_flash = move_toward(samurai_dash_flash,0.0,delta*6.0)
	samurai_post_dash_stun = maxf(0.0, samurai_post_dash_stun - delta)
	shot_cooldown_timer = maxf(0.0, shot_cooldown_timer - delta)

	if attack_release_block:
		var attack_still_down: bool = Input.is_key_pressed(KEY_SPACE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
		if not attack_still_down:
			attack_release_block = false

	if spawning:
		_update_spawn(delta)
		queue_redraw()
		return

	if not active or cutscene_locked:
		moving = false
		velocity = Vector2.ZERO
		queue_redraw()
		return

	var input_vector: Vector2 = Vector2.ZERO if samurai_post_dash_stun > 0.0 else _get_move_input()
	moving = input_vector.length_squared() > 0.0
	if moving:
		move_direction = input_vector.normalized()
		# Slightly springy cadence shared by every class.
		walk_phase += delta * 10.8
	else:
		idle_phase += delta
		move_direction = move_direction.move_toward(Vector2.ZERO, delta * 5.0)

	if endless_mode:
		_update_endless_auto_target(delta)
		var endless_aim_mode: String = _get_attack_target_mode()
		if endless_aim_mode == "mouse":
			# Manual aim must be live every frame. Previously endless_has_target is false
			# in mouse mode, so Samurai kept the last automatic facing forever.
			var manual_delta: Vector2 = get_global_mouse_position() - global_position
			if manual_delta.length_squared() > 0.001:
				aim_direction = manual_delta.normalized()
		elif endless_has_target:
			var auto_delta: Vector2 = endless_target_position-global_position
			if auto_delta.length_squared() > 0.001:
				aim_direction = auto_delta.normalized()
	else:
		var mouse_delta: Vector2 = get_global_mouse_position() - global_position
		if mouse_delta.length_squared() > 0.001:
			aim_direction = mouse_delta.normalized()

	if mage_type == "samurai":
		var aim_mode: String = _get_attack_target_mode()
		if aim_mode == "mouse":
			# Manual melee aiming should honor the mouse and expose a proper cursor.
			# Keep the cached focus updated so visual smoothing still feels stable.
			if aim_direction.length_squared() > 0.001:
				samurai_cached_focus = aim_direction.normalized()
		else:
			# Full-time visual awareness, but the expensive nearest-enemy scan is cached.
			# This keeps the smooth eye/body tracking from 0708 without scanning the whole
			# horde every physics frame when 150-200 enemies are alive.
			samurai_focus_refresh_timer -= delta
			if samurai_focus_refresh_timer <= 0.0:
				var horde_tier: int = 0
				var controller = _get_endless_controller()
				if is_instance_valid(controller) and controller.has_method("get_horde_performance_tier"):
					horde_tier = int(controller.get_horde_performance_tier())
				samurai_focus_refresh_timer = 0.10 if horde_tier == 0 else (0.14 if horde_tier == 1 else (0.18 if horde_tier == 2 else 0.24))
				var refreshed_focus: Vector2 = Vector2.ZERO
				# Auto-target already maintains the nearest enemy. Reuse it instead of doing a
				# second full horde scan just for Samurai's visual facing.
				if is_instance_valid(endless_target_node):
					var focus_delta: Vector2 = endless_target_node.global_position-global_position
					if focus_delta.length_squared() > 0.001:
						refreshed_focus = focus_delta.normalized()
				if refreshed_focus.length_squared() <= 0.001:
					refreshed_focus = _get_nearest_enemy_direction(99999.0)
				if refreshed_focus.length_squared() > 0.001:
					samurai_cached_focus = refreshed_focus
			if samurai_cached_focus.length_squared() > 0.001:
				aim_direction = samurai_cached_focus

	var aim_target: Vector2 = aim_direction.normalized() if aim_direction.length_squared() > 0.001 else visual_aim_direction
	if visual_aim_direction.length_squared() <= 0.001:
		visual_aim_direction = aim_target
	else:
		visual_aim_direction = visual_aim_direction.lerp(aim_target, clampf(delta * 10.5, 0.0, 1.0)).normalized()
	var move_target: Vector2 = move_direction if move_direction.length_squared() > 0.001 else Vector2.ZERO
	visual_move_direction = visual_move_direction.lerp(move_target, clampf(delta * 8.0, 0.0, 1.0))
	if visual_move_direction.length() < 0.02:
		visual_move_direction = Vector2.ZERO

	var shift_now: bool = Input.is_key_pressed(KEY_SHIFT)
	if shift_now and not shift_was_down and not dash_active and samurai_post_dash_stun <= 0.0:
		_try_dash(input_vector)
	shift_was_down = shift_now

	if dash_active:
		_update_dash(delta)
	else:
		if samurai_post_dash_stun > 0.0:
			velocity = hurt_knockback
		else:
			var effective_move_speed: float = move_speed * (1.15 if elite_victory_buff_timer > 0.0 else 1.0)
			velocity = move_direction * effective_move_speed if moving else Vector2.ZERO
			velocity += hurt_knockback
		move_and_slide()

	_update_footsteps(delta)

	var attack_down: bool = false
	if not tutorial_attack_locked and samurai_post_dash_stun <= 0.0:
		var endless_auto_attack: bool = false
		if endless_mode:
			var mode: String = _get_attack_target_mode()
			endless_auto_attack = endless_has_target or mode == "mouse"
		attack_down = endless_auto_attack or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or Input.is_key_pressed(KEY_SPACE)
	if mage_type == "storm":
		_update_storm_cast(delta, attack_down and not dash_active and not attack_release_block)
	elif not dash_active and not attack_release_block and attack_down and _can_cast():
		_shoot_current_magic()

	queue_redraw()

func _get_endless_controller():
	if is_instance_valid(cached_endless_controller):
		return cached_endless_controller
	cached_endless_controller = get_tree().get_first_node_in_group("endless_controller")
	return cached_endless_controller

func _get_nearest_enemy_direction(radius: float) -> Vector2:
	var best_dir: Vector2 = Vector2.ZERO
	var best_d2: float = radius * radius
	for enemy in _enemy_candidates(radius):
		if not is_instance_valid(enemy):
			continue
		var delta_pos: Vector2 = enemy.global_position - global_position
		var d2: float = delta_pos.length_squared()
		if d2 <= 0.001 or d2 > best_d2:
			continue
		best_d2 = d2
		best_dir = delta_pos.normalized()
	return best_dir

func _enemy_candidates(radius: float) -> Array:
	var controller = _get_endless_controller()
	if is_instance_valid(controller) and controller.has_method("get_nearby_enemies"):
		return controller.get_nearby_enemies(global_position,radius)
	return get_tree().get_nodes_in_group("enemy")

func _get_attack_target_mode() -> String:
	var controller = _get_endless_controller()
	if is_instance_valid(controller) and controller.has_method("_get_attack_target_mode"):
		return str(controller._get_attack_target_mode())
	return "nearest"

func _is_endless_target_on_screen(node) -> bool:
	if not is_instance_valid(node):
		return false
	var viewport = get_viewport()
	if viewport == null:
		return false
	var screen_position: Vector2 = viewport.get_canvas_transform() * node.global_position
	# Small inward margin prevents auto-fire from locking things barely outside
	# the visible image at the exact viewport edge.
	var screen_rect: Rect2 = viewport.get_visible_rect().grow(-14.0)
	return screen_rect.has_point(screen_position)

func _update_endless_auto_target(delta: float) -> void:
	var mode: String = _get_attack_target_mode()
	if mode == "mouse":
		endless_has_target = false
		endless_target_node = null
		endless_target_position = get_global_mouse_position()
		return

	if is_instance_valid(endless_target_node) and endless_target_node.get("dead") != true and _is_endless_target_on_screen(endless_target_node):
		var current_distance_sq: float = global_position.distance_squared_to(endless_target_node.global_position)
		var class_limit: float = samurai_range*samurai_range if mage_type == "samurai" else INF
		if current_distance_sq <= class_limit:
			endless_target_position = endless_target_node.global_position
		else:
			endless_target_node = null
			endless_has_target = false
	else:
		endless_target_node = null
		endless_has_target = false

	endless_auto_target_timer -= delta
	# When no target was visible, the old condition retried the full enemy scan every
	# frame. Respect the timer in both states; acquiring a new target can wait a few
	# milliseconds and saves a large amount of work in 150-200 enemy hordes.
	if endless_auto_target_timer > 0.0:
		return
	var target_horde_tier: int = 0
	var target_controller = _get_endless_controller()
	if is_instance_valid(target_controller) and target_controller.has_method("get_horde_performance_tier"):
		target_horde_tier = int(target_controller.get_horde_performance_tier())
	endless_auto_target_timer = 0.10 if target_horde_tier == 0 else (0.12 if target_horde_tier == 1 else (0.15 if target_horde_tier == 2 else 0.18))

	# Runic vases are world interactions now. Basic auto-attacks ignore them;
	# the player deliberately breaks them with [E] at close range.

	var best_distance: float = INF
	var best_health: float = INF
	var best_max_health: float = -INF
	var best_node
	var samurai_limit_sq: float = samurai_range*samurai_range
	for node in _enemy_candidates(900.0):
		if not is_instance_valid(node) or node == self:
			continue
		if node.get("dead") == true:
			continue
		if not _is_endless_target_on_screen(node):
			continue
		var d: float = global_position.distance_squared_to(node.global_position)
		if mage_type == "samurai" and d > samurai_limit_sq:
			continue
		var hp: float = float(node.get("health"))
		match mode:
			"lowest":
				if hp < best_health or (is_equal_approx(hp, best_health) and d < best_distance):
					best_health = hp
					best_distance = d
					best_node = node
			"max_health":
				var target_max_hp: float = float(node.get("max_health"))
				if target_max_hp > best_max_health or (is_equal_approx(target_max_hp, best_max_health) and d < best_distance):
					best_max_health = target_max_hp
					best_distance = d
					best_node = node
			_:
				if d < best_distance:
					best_distance = d
					best_node = node

	if mode == "nearest" and is_instance_valid(endless_target_node) and is_instance_valid(best_node):
		var current_d: float = global_position.distance_squared_to(endless_target_node.global_position)
		if current_d <= best_distance * 1.18:
			best_node = endless_target_node

	endless_target_node = best_node
	endless_has_target = is_instance_valid(best_node)
	if endless_has_target:
		endless_target_position = best_node.global_position

func _update_endless_passives(delta: float) -> void:
	if not endless_mode:
		return
	if endless_regen_per_second > 0.0 and health > 0 and health < max_health:
		endless_regen_accumulator += delta*endless_regen_per_second
		while endless_regen_accumulator >= 1.0:
			endless_regen_accumulator -= 1.0
			heal(1)

func _roll_endless_damage(base_damage: int) -> int:
	var result: int = maxi(1,int(round(float(base_damage)*endless_damage_multiplier)))
	if endless_mode and health <= maxi(1,int(ceil(float(max_health)*0.35))):
		result += endless_low_health_damage_add
	if endless_mode and endless_crit_chance > 0.0 and randf() < endless_crit_chance:
		result *= 2
	return maxi(1,result)

func _get_move_input() -> Vector2:
	var v: Vector2 = Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		v.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		v.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		v.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		v.y += 1.0
	return v

func _update_spawn(delta: float) -> void:
	spawn_t = minf(1.0, spawn_t + delta / 0.78)
	var e: float = 1.0 - pow(1.0 - spawn_t, 3.0)
	scale = Vector2(lerpf(0.20, 1.0, e), lerpf(0.05, 1.0, e))
	modulate.a = clampf(spawn_t * 1.8, 0.0, 1.0)
	if spawn_t >= 1.0:
		spawning = false
		active = not cutscene_locked
		scale = Vector2.ONE
		modulate = Color.WHITE
		add_camera_shake(0.70)

func _update_magic(delta: float) -> void:
	magic_orbit_t += delta * (1.25 if not magic_reloading else 3.2)
	if mage_type != "storm":
		storm_charging = false
		storm_charge = 0.0

	if mage_type == "rift":
		if rift_reloading:
			rift_reload_timer -= delta
			if rift_reload_timer <= 0.0:
				rift_reload_timer = 0.0
				rift_reloading = false
				rift_charges = rift_max_charges
				cast_flash = 1.0
				get_tree().call_group("audio_bus", "play_magic_reload_finish")
				get_tree().call_group("screen_fx", "pulse_rift")
	else:
		rift_reloading = false
		rift_reload_timer = 0.0
		rift_charges = rift_max_charges

	if mage_type != "orbit":
		magic_reloading = false
		magic_reload_timer = 0.0
		return
	if not magic_reloading:
		return
	magic_reload_timer -= delta
	if magic_reload_timer <= 0.0:
		magic_reload_timer = 0.0
		magic_reloading = false
		magic_stones = max_magic_stones
		magic_shot_index = 0
		cast_flash = 1.0
		if has_trait("orbit_reload_burst"):
			_spawn_arcane_burst(76.0,1,0.0)
		get_tree().call_group("audio_bus", "play_magic_reload_finish")
		get_tree().call_group("screen_fx", "pulse_magic")

func _can_cast() -> bool:
	if shot_cooldown_timer > 0.0:
		return false
	if mage_type == "orbit":
		return not magic_reloading and magic_stones > 0
	if mage_type == "storm":
		return false
	if mage_type == "rift":
		return not rift_reloading and rift_charges > 0
	if mage_type == "samurai":
		return true
	return true

func _shoot_current_magic() -> void:
	match mage_type:
		"storm":
			_cast_lightning()
		"rift":
			_cast_rift()
		"samurai":
			_cast_samurai_slash()
		_:
			_shoot_magic_stone()
	get_tree().call_group("rune_runtime","on_basic_attack")

func _cast_samurai_slash() -> void:
	if not _can_cast():
		return
	var facing: Vector2 = aim_direction.normalized()
	if endless_mode and _get_attack_target_mode() == "mouse":
		# Resolve the cut from the cursor at the exact attack frame. This prevents
		# any stale auto-target direction from surviving the R-mode switch.
		var live_mouse_delta: Vector2 = get_global_mouse_position() - global_position
		if live_mouse_delta.length_squared() > 0.001:
			facing = live_mouse_delta.normalized()
			aim_direction = facing
			samurai_cached_focus = facing
	if facing.length_squared() < 0.001:
		facing = Vector2.RIGHT
	var cos_limit: float = cos(samurai_arc*0.5)
	var targets: Array = _enemy_candidates(samurai_range+48.0)
	targets.append_array(get_tree().get_nodes_in_group("basic_target"))
	for target in targets:
		if not is_instance_valid(target) or not target.has_method("take_damage"):
			continue
		var delta_pos: Vector2 = target.global_position-global_position
		var dist: float = delta_pos.length()
		if dist > samurai_range or dist <= 0.001:
			continue
		if facing.dot(delta_pos/dist) < cos_limit:
			continue
		target.take_damage(_roll_endless_damage(samurai_damage),delta_pos.normalized())
	samurai_slash_flash = 1.0
	cast_flash = 1.0
	shot_cooldown_timer = maxf(0.42,shot_cooldown*0.78) if flux_active else shot_cooldown
	get_tree().call_group("audio_bus","play_samurai_slash")
	get_tree().call_group("screen_fx","pulse_hit")

func _samurai_dash_damage_tick() -> void:
	if mage_type != "samurai":
		return
	var targets: Array = _enemy_candidates(72.0)
	targets.append_array(get_tree().get_nodes_in_group("basic_target"))
	for target in targets:
		if not is_instance_valid(target) or not target.has_method("take_damage"):
			continue
		var target_id: int = target.get_instance_id()
		if samurai_dash_hit_ids.has(target_id):
			continue
		var delta_pos: Vector2 = target.global_position-global_position
		if delta_pos.length_squared() > 56.0*56.0:
			continue
		samurai_dash_hit_ids[target_id] = true
		target.take_damage(_roll_endless_damage(samurai_dash_damage),dash_direction)
		get_tree().call_group("audio_bus","play_samurai_dash_hit")

func _shoot_magic_stone() -> void:
	if not _can_cast():
		return

	var stone_slot: int = magic_shot_index % max_magic_stones
	var stone_local: Vector2 = _stone_local_position(stone_slot)
	var projectile = ProjectileScript.new()
	# Converge every orbiting stone on the actual cursor from its own firing point.
	# This removes the old parallel-shot error that made Orbital feel imprecise up close.
	var muzzle_world: Vector2 = global_position + stone_local
	var target_world: Vector2 = endless_target_position if endless_mode and endless_has_target else get_global_mouse_position()
	var shot_dir: Vector2 = (target_world-muzzle_world).normalized()
	if shot_dir.length_squared() < 0.001:
		shot_dir = aim_direction
	shot_dir = shot_dir.rotated(randf_range(-accuracy_spread, accuracy_spread))
	projectile.direction = shot_dir
	projectile.damage = _roll_endless_damage(orbit_damage)
	projectile.speed = orbit_projectile_speed
	projectile.split_on_hit = has_trait("orbit_split")
	projectile.ricochet_count = 1 if has_trait("orbit_ricochet") else 0
	projectile.explode_on_hit = has_trait("orbit_explosive_core") or (has_trait("orbit_last_burst") and magic_stones == 1)
	projectile.global_position = global_position + stone_local
	get_tree().current_scene.add_child(projectile)
	if endless_extra_casts > 0:
		for extra_i in range(endless_extra_casts):
			var extra_projectile = ProjectileScript.new()
			var sign_value: float = -1.0 if extra_i % 2 == 0 else 1.0
			var spread_index: float = float(int(float(extra_i) / 2.0) + 1)
			extra_projectile.direction = shot_dir.rotated(sign_value*0.095*spread_index)
			extra_projectile.damage = maxi(1,_roll_endless_damage(orbit_damage)-1)
			extra_projectile.speed = orbit_projectile_speed*0.96
			extra_projectile.global_position = global_position+stone_local
			get_tree().current_scene.add_child(extra_projectile)
	if orbit_echo_chance > 0.0 and randf() < orbit_echo_chance:
		var echo = ProjectileScript.new()
		echo.direction = shot_dir.rotated(randf_range(-0.035,0.035))
		echo.damage = 1
		echo.speed = orbit_projectile_speed * 0.92
		echo.global_position = global_position + stone_local - shot_dir * 5.0
		get_tree().current_scene.add_child(echo)

	if not flux_active:
		magic_stones -= 1
		magic_shot_index += 1
	else:
		magic_shot_index = (magic_shot_index + 1) % maxi(1,max_magic_stones)
	shot_cooldown_timer = maxf(0.52, shot_cooldown * 0.72) if flux_active else shot_cooldown
	cast_flash = 1.0
	get_tree().call_group("screen_fx", "pulse_magic")
	get_tree().call_group("audio_bus", "play_player_shot")

	if magic_stones <= 0 and not flux_active:
		_start_magic_reload()

func _update_storm_cast(delta: float, attack_held: bool) -> void:
	if shot_cooldown_timer > 0.0:
		storm_charging = false
		storm_charge = 0.0
		return
	if not attack_held:
		storm_charging = false
		storm_charge = 0.0
		return
	storm_charging = true
	storm_target = _target_point(storm_range)
	storm_charge = minf(storm_charge_duration, storm_charge + delta)
	if storm_charge >= storm_charge_duration:
		_cast_lightning()
		storm_charging = false
		storm_charge = 0.0

func _cast_lightning() -> void:
	var target: Vector2 = storm_target
	var error_radius: float = accuracy_spread * 115.0
	target += Vector2(randf_range(-error_radius,error_radius), randf_range(-error_radius,error_radius))
	var strike = LightningStrikeScript.new()
	strike.configure(true)
	strike.radius = storm_radius
	strike.damage = _roll_endless_damage(storm_damage)
	strike.delay = 0.30
	strike.chain_count = 1 if has_trait("storm_chain") else 0
	strike.aftershock = has_trait("storm_aftershock") or flux_active
	strike.owner_player = self
	strike.global_position = target
	get_tree().current_scene.add_child(strike)
	if endless_extra_casts > 0:
		for extra_i in range(endless_extra_casts):
			var extra_strike = LightningStrikeScript.new()
			extra_strike.configure(true)
			extra_strike.radius = maxf(22.0,storm_radius*0.72)
			extra_strike.damage = maxi(1,_roll_endless_damage(storm_damage)-1)
			extra_strike.delay = 0.34+float(extra_i)*0.06
			extra_strike.owner_player = self
			var a_extra: float = TAU*float(extra_i)/maxf(1.0,float(endless_extra_casts))+magic_orbit_t
			extra_strike.global_position = target+Vector2(cos(a_extra),sin(a_extra))*48.0
			get_tree().current_scene.add_child(extra_strike)
	if has_trait("storm_twin"):
		var side_dir: Vector2 = Vector2(-aim_direction.y,aim_direction.x)
		var twin = LightningStrikeScript.new()
		twin.configure(true)
		twin.radius = maxf(24.0,storm_radius*0.66)
		twin.damage = maxi(1,storm_damage-1)
		twin.delay = 0.38
		twin.chain_count = 0
		twin.aftershock = false
		twin.owner_player = self
		twin.global_position = target+side_dir*52.0
		get_tree().current_scene.add_child(twin)
	if storm_double_strike_relic:
		var second = LightningStrikeScript.new()
		second.configure(true)
		second.radius = maxf(26.0,storm_radius*0.72)
		second.damage = maxi(1,storm_damage-1)
		second.delay = 0.52
		second.chain_count = 0
		second.aftershock = false
		second.owner_player = self
		var scatter: float = accuracy_spread*210.0+16.0
		second.global_position = target+Vector2(randf_range(-scatter,scatter),randf_range(-scatter,scatter))
		get_tree().current_scene.add_child(second)
	shot_cooldown_timer = 0.52 if flux_active else 0.78*storm_recovery_multiplier
	cast_flash = 1.0
	get_tree().call_group("screen_fx", "pulse_storm_charge")

func _cast_rift() -> void:
	if rift_reloading or rift_charges <= 0:
		return
	var direction_value: Vector2 = aim_direction.rotated(randf_range(-accuracy_spread * 0.55, accuracy_spread * 0.55))
	if direction_value.length_squared() < 0.001:
		direction_value = Vector2.RIGHT
	var scar = RiftScarScript.new()
	scar.direction = direction_value.normalized()
	scar.length = rift_wave_range
	scar.width = rift_radius
	scar.damage = _roll_endless_damage(rift_damage)
	scar.duration = rift_scar_duration
	scar.tick_interval = rift_tick_interval
	scar.pull_strength = 185.0 if has_trait("rift_gravity") else 0.0
	scar.end_burst = has_trait("rift_endburst")
	scar.owner_player = self
	scar.global_position = global_position + direction_value.normalized() * 22.0
	get_tree().current_scene.add_child(scar)
	if has_trait("rift_cross"):
		var cross = RiftScarScript.new()
		var cross_dir: Vector2 = direction_value.rotated(PI*0.5).normalized()
		cross.direction = cross_dir
		cross.length = rift_wave_range*0.72
		cross.width = maxf(14.0,rift_radius*0.76)
		cross.damage = maxi(1,_roll_endless_damage(rift_damage)-1)
		cross.duration = rift_scar_duration*0.88
		cross.tick_interval = rift_tick_interval
		cross.pull_strength = 140.0 if has_trait("rift_gravity") else 0.0
		cross.end_burst = false
		cross.owner_player = self
		cross.global_position = global_position+direction_value*(rift_wave_range*0.46)-cross_dir*(cross.length*0.5)
		get_tree().current_scene.add_child(cross)
	if has_trait("rift_twin_scar"):
		var twin = RiftScarScript.new()
		var side_sign: float = -1.0 if magic_shot_index % 2 == 0 else 1.0
		var twin_direction: Vector2 = direction_value.rotated(0.13*side_sign).normalized()
		twin.direction = twin_direction
		twin.length = rift_wave_range*0.94
		twin.width = maxf(14.0,rift_radius*0.66)
		twin.damage = maxi(1,_roll_endless_damage(rift_damage)-1)
		twin.duration = rift_scar_duration*0.90
		twin.tick_interval = rift_tick_interval
		twin.owner_player = self
		twin.global_position = global_position + twin_direction*22.0
		get_tree().current_scene.add_child(twin)
	if not flux_active:
		rift_charges -= 1
	shot_cooldown_timer = 0.34 if flux_active else shot_cooldown
	cast_flash = 1.0
	get_tree().call_group("screen_fx", "pulse_rift_cast")
	if rift_charges <= 0 and not flux_active:
		_start_rift_reload()

func _start_rift_reload() -> void:
	rift_reloading = true
	rift_reload_timer = rift_reload_duration
	if has_trait("rift_reload_guard"):
		_spawn_arcane_burst(58.0,1,0.0)
	get_tree().call_group("audio_bus", "play_magic_reload")

func get_rift_reload_ratio() -> float:
	if not rift_reloading:
		return 1.0
	return 1.0 - clampf(rift_reload_timer / rift_reload_duration, 0.0, 1.0)

func _target_point(max_range: float) -> Vector2:
	var desired: Vector2 = endless_target_position if endless_mode and endless_has_target else get_global_mouse_position()
	var delta_pos: Vector2 = desired - global_position
	if delta_pos.length() > max_range:
		return global_position + delta_pos.normalized() * max_range
	return desired

func _start_magic_reload() -> void:
	magic_reloading = true
	magic_reload_timer = magic_reload_duration
	get_tree().call_group("audio_bus", "play_magic_reload")

func _stone_angle(slot: int) -> float:
	# A slow orbit keeps the six firing points readable without looking static.
	return -PI * 0.08 + TAU * float(slot) / float(max_magic_stones) + magic_orbit_t * 0.22

func _stone_local_position(slot: int) -> Vector2:
	var angle: float = _stone_angle(slot)
	var radius: float = 58.0 + sin(magic_orbit_t * 1.8 + float(slot)) * 3.8
	return Vector2(cos(angle) * radius, sin(angle) * radius * 0.78 - 5.0)

func get_magic_reload_ratio() -> float:
	if not magic_reloading:
		return 1.0
	return 1.0 - clampf(magic_reload_timer / magic_reload_duration, 0.0, 1.0)


func _spawn_arcane_burst(radius_value: float, damage_value: int, pull_value: float = 0.0) -> void:
	var burst = ArcaneBurstScript.new()
	burst.radius = radius_value
	burst.damage = damage_value
	burst.pull_strength = pull_value
	burst.global_position = global_position
	get_tree().current_scene.add_child(burst)

func _orbit_dash_finish() -> void:
	orbit_dash_end_flash = 1.0
	cast_flash = maxf(cast_flash, 0.92)
	_spawn_arcane_burst(48.0, 1, 0.0)
	get_tree().call_group("screen_fx", "pulse_dash")

func _storm_dash_finish() -> void:
	storm_dash_flash = 1.0
	storm_dash_morph = maxf(storm_dash_morph, 0.68)
	cast_flash = maxf(cast_flash, 0.52)
	get_tree().call_group("screen_fx", "pulse_dash")

func _samurai_dash_finish() -> void:
	samurai_dash_phase = 0
	samurai_post_dash_stun = 0.4
	samurai_dash_flash = 1.0
	samurai_slash_flash = maxf(samurai_slash_flash, 0.82)
	cast_flash = maxf(cast_flash, 0.58)
	get_tree().call_group("screen_fx", "pulse_dash")


func _try_dash(input_vector: Vector2) -> void:
	if dash_charges <= 0:
		return

	var chosen: Vector2 = input_vector.normalized()
	if chosen.length_squared() < 0.01:
		chosen = aim_direction

	dash_charges -= 1
	if mage_type == "samurai":
		samurai_dash_phase = 0
		samurai_post_dash_stun = 0.0
		samurai_dash_hit_ids.clear()
		samurai_dash_flash = 1.0
	if mage_type == "storm":
		storm_dash_flash = 1.0
		storm_dash_morph = maxf(storm_dash_morph, 0.16)
		cast_flash = maxf(cast_flash, 0.40)
	if mage_type == "orbit":
		orbit_dash_pose_blend = 1.0
		orbit_dash_start_flash = 1.0
		cast_flash = maxf(cast_flash, 0.55)
	if has_trait("dash_echo"):
		_spawn_arcane_burst(54.0,1,0.0)
	dash_direction = chosen
	get_tree().call_group("tome_arsenal","on_dash_started",global_position,dash_direction)
	get_tree().call_group("rune_runtime","on_dash_started")
	dash_active = true
	current_dash_duration = dash_duration * (1.28 if mage_type == "storm" else (0.82 if mage_type == "samurai" else 1.0))
	dash_left = current_dash_duration
	dash_ghost_timer = 0.0
	invulnerability = maxf(invulnerability, current_dash_duration + 0.10)

	if dash_charges < max_dash_charges and dash_recharge_timer <= 0.0:
		dash_recharge_timer = dash_recharge

	get_tree().call_group("screen_fx", "pulse_dash")
	get_tree().call_group("audio_bus", "play_dash")
	add_camera_shake(0.65)

func _update_dash(delta: float) -> void:
	dash_left -= delta
	dash_ghost_timer -= delta
	velocity = dash_direction * dash_speed
	move_and_slide()
	_samurai_dash_damage_tick()

	if dash_ghost_timer <= 0.0:
		dash_ghost_timer = 0.032
		var ghost = AfterimageScript.new()
		ghost.global_position = global_position
		ghost.sketch_frame = sketch_frame
		get_tree().current_scene.add_child(ghost)

	if dash_left <= 0.0:
		dash_active = false
		if mage_type == "orbit":
			_orbit_dash_finish()
		elif mage_type == "storm":
			_storm_dash_finish()
		elif mage_type == "samurai":
			_samurai_dash_finish()

func _update_dash_recharge(delta: float) -> void:
	if dash_charges >= max_dash_charges:
		dash_recharge_timer = 0.0
		return

	if dash_recharge_timer <= 0.0:
		dash_recharge_timer = dash_recharge

	dash_recharge_timer -= delta
	if dash_recharge_timer <= 0.0:
		if mage_type == "samurai":
			dash_charges = max_dash_charges
			dash_recharge_timer = 0.0
		else:
			dash_charges += 1
			if dash_charges < max_dash_charges:
				dash_recharge_timer = dash_recharge
			else:
				dash_recharge_timer = 0.0

func take_damage(amount: int, source_direction: Vector2) -> void:
	if admin_god_mode:
		return
	if not active or cutscene_locked or dash_active or invulnerability > 0.0:
		return
	if endless_mode and is_instance_valid(tome_arsenal) and tome_arsenal.has_method("try_block_hit") and tome_arsenal.try_block_hit():
		invulnerability = 0.20
		return
	if endless_mode and endless_guard_chance > 0.0 and randf() < endless_guard_chance:
		invulnerability = 0.22
		get_tree().call_group("screen_fx","pulse_dash")
		get_tree().call_group("audio_bus","play_magic_reload_finish")
		return

	if tutorial_safe_mode:
		health = maxi(1,health-amount)
	else:
		health -= amount
	if not flux_active and not tutorial_flux_guard:
		flux = maxf(0.0,flux-14.0)
	invulnerability = 0.58
	hurt_flash = 1.0
	hurt_knockback = source_direction.normalized() * 170.0
	add_camera_shake(2.0)
	get_tree().call_group("screen_fx", "pulse_damage")
	get_tree().call_group("audio_bus", "play_player_hurt")
	get_tree().call_group("tome_arsenal","on_player_damaged")
	get_tree().call_group("rune_runtime","on_player_damaged")

	var fx = HitFxScript.new()
	fx.global_position = global_position
	fx.tint = Color("#111111")
	fx.direction = source_direction
	get_tree().current_scene.add_child(fx)

	if health <= 0:
		active = false
		collision_layer = 0
		died.emit()

func heal(amount: int) -> void:
	health = mini(max_health, health + amount)

func boost_fire_rate(multiplier: float) -> void:
	shot_cooldown = maxf(0.42 if mage_type == "orbit" else (0.32 if mage_type == "samurai" else 0.18), shot_cooldown * multiplier)

func boost_dash_recharge(multiplier: float) -> void:
	dash_recharge = maxf(0.55, dash_recharge * multiplier)

func refill_dash() -> void:
	dash_charges = max_dash_charges
	dash_recharge_timer = 0.0

func get_dash_recharge_ratio() -> float:
	if dash_charges >= max_dash_charges:
		return 1.0
	if dash_recharge <= 0.001:
		return 1.0
	return clampf(1.0-(dash_recharge_timer/dash_recharge),0.0,1.0)

func refill_magic() -> void:
	magic_reloading = false
	magic_reload_timer = 0.0
	magic_stones = max_magic_stones
	magic_shot_index = 0
	rift_charges = rift_max_charges
	rift_reload_timer = 0.0
	rift_reloading = false

func on_enemy_hit(strength: float = 1.0) -> void:
	# Flow should reward staying aggressive even before enemies die.
	# Still scaled by target strength so elites/bosses give slightly more per hit.
	add_flux(0.30 * strength)
	get_tree().call_group("screen_fx", "pulse_hit")

func add_camera_shake(amount: float) -> void:
	if not screen_shake_enabled:
		return
	shake = maxf(shake, amount * 0.42)

func _update_camera(delta: float) -> void:
	if not is_instance_valid(camera):
		return
	if not cutscene_locked:
		var desired_look: Vector2 = Vector2.ZERO
		if endless_mode:
			if moving:
				desired_look = move_direction * 11.0
		else:
			desired_look = aim_direction * 24.0
			if moving:
				desired_look += move_direction * 10.0
		var look_speed: float = 4.0 if endless_mode else 3.1
		camera_look_offset = camera_look_offset.lerp(desired_look, clampf(delta * look_speed, 0.0, 1.0))
		if camera_look_offset.distance_to(desired_look) < 0.02:
			camera_look_offset = desired_look
		camera.position = camera_look_offset
		var target_zoom: float = 0.872 if endless_mode and moving else (0.860 if endless_mode else (0.985 if moving else 1.0))
		if dash_active:
			target_zoom = 0.835 if endless_mode else 0.948
		elif flux_active:
			target_zoom = 0.855 if endless_mode else 0.972
		if endless_mode:
			target_zoom = maxf(0.70, target_zoom * endless_fov_zoom_multiplier)
		var zoom_target_v: Vector2 = Vector2(target_zoom, target_zoom)
		camera_zoom_state = camera_zoom_state.lerp(zoom_target_v, clampf(delta * 4.6, 0.0, 1.0))
		camera.zoom = camera_zoom_state
	if not screen_shake_enabled:
		shake = 0.0
		camera.offset = camera.offset.lerp(Vector2.ZERO, clampf(delta * 10.0, 0.0, 1.0))
		return
	shake = move_toward(shake, 0.0, delta * 22.0)
	var shake_target: Vector2 = Vector2.ZERO
	if shake > 0.05:
		var now: float = float(Time.get_ticks_msec()) * 0.001
		shake_target = Vector2(sin(now * 36.0), cos(now * 31.0)) * shake
	camera.offset = camera.offset.lerp(shake_target, clampf(delta * 16.0, 0.0, 1.0))

func _update_sketch(delta: float) -> void:
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.065
		sketch_frame += 1

func sketch_jitter(index: int, amount: float) -> float:
	var jitter_scale: float = 0.10 if endless_mode else 0.45
	return sin(float(sketch_frame) * 2.17 + float(index) * 4.31) * amount * jitter_scale



func _update_footstep_fx(delta: float) -> void:
	var kept_feet: Array = []
	for item_value in footprints:
		var item: Dictionary = item_value
		item["ttl"] = float(item.get("ttl", 0.0)) - delta
		if float(item["ttl"]) > 0.0:
			kept_feet.append(item)
	footprints = kept_feet
	var kept_dust: Array = []
	for item_value in dust_puffs:
		var item: Dictionary = item_value
		item["ttl"] = float(item.get("ttl", 0.0)) - delta
		if float(item["ttl"]) > 0.0:
			kept_dust.append(item)
	dust_puffs = kept_dust

func _update_footsteps(delta: float) -> void:
	if not moving or dash_active or velocity.length() < 55.0:
		footstep_timer = minf(footstep_timer, 0.08)
		return
	var rate: float = clampf(velocity.length() / move_speed, 0.65, 1.35)
	footstep_timer -= delta * rate
	if footstep_timer > 0.0:
		return
	footstep_timer = 0.18
	_spawn_footstep(next_left_step)
	next_left_step = not next_left_step

func _spawn_footstep(is_left: bool) -> void:
	var forward: Vector2 = move_direction.normalized()
	if forward.length_squared() < 0.001:
		forward = Vector2.DOWN
	var lateral: Vector2 = Vector2(-forward.y, forward.x)
	var side_mult: float = -1.0 if is_left else 1.0
	var base_pos: Vector2 = global_position - forward * 4.0 + lateral * side_mult * 6.0 + Vector2(0, 18)
	footprints.append({"pos": base_pos, "ttl": 0.58, "side": side_mult})
	for i in range(2):
		var dust_pos: Vector2 = base_pos + Vector2(randf_range(-2.0, 2.0), randf_range(-1.0, 1.0))
		dust_puffs.append({"pos": dust_pos, "ttl": 0.24 + float(i) * 0.04})
	get_tree().call_group("audio_bus", "play_footstep")

func _draw_ground_marks() -> void:
	for item_value in footprints:
		var item: Dictionary = item_value
		var foot_world: Vector2 = item.get("pos", global_position)
		var local_pos: Vector2 = foot_world - global_position
		var ttl: float = float(item.get("ttl", 0.0))
		var alpha: float = clampf(ttl / 0.58, 0.0, 1.0)
		var side_mult: float = float(item.get("side", 1.0))
		_draw_oval(local_pos, Vector2(4.2, 2.1), Color(0.08,0.08,0.08,0.055 * alpha))
		_sketch_line(local_pos + Vector2(-2.3 * side_mult, 0), local_pos + Vector2(2.3 * side_mult, 0), Color(0.08,0.08,0.08,0.09 * alpha), 1.0, 1, 210)
	for item_value in dust_puffs:
		var item: Dictionary = item_value
		var foot_world: Vector2 = item.get("pos", global_position)
		var local_pos: Vector2 = foot_world - global_position
		var ttl: float = float(item.get("ttl", 0.0))
		var alpha: float = clampf(ttl / 0.28, 0.0, 1.0)
		draw_circle(local_pos + Vector2(0, -ttl * 10.0), 1.5 + (1.0 - alpha) * 2.0, Color(0.08,0.08,0.08,0.04 * alpha))

func _draw() -> void:
	var hop: float = absf(sin(walk_phase)) if moving else 0.0
	var bob: float = (-hop * 3.5 + sin(walk_phase * 2.0) * 0.34) if moving else sin(idle_phase * 2.0) * 0.32
	var step: float = sin(walk_phase) * 4.8 if moving else 0.0
	var ink: Color = Color("#111111").lerp(Color("#858585"), hurt_flash * 0.68)
	var paper: Color = Color("#faf7ef")
	var accent: Color = Color("#ece5d8")
	match mage_type:
		"storm": accent = Color(0.84, 0.93, 1.0, 0.92)
		"rift": accent = Color(0.86, 0.96, 1.0, 0.88)
		"samurai": accent = Color(1.0, 0.90, 0.90, 0.88)
		_:
			accent = Color(0.98, 0.96, 0.90, 0.90)
	_draw_ground_marks()
	var shadow_scale: float = 1.0 - hop * 0.16
	var shadow_alpha: float = 0.08 - hop * 0.016
	_draw_oval(Vector2(0, 23), Vector2(23.0 * shadow_scale, 5.4 * shadow_scale), Color(0.08, 0.08, 0.08, shadow_alpha))
	draw_arc(Vector2(0, 16), 18.0 + sin(idle_phase * 2.0) * 1.4, 0.0, TAU, 26, Color(accent.r, accent.g, accent.b, 0.08), 1.0)
	match mage_type:
		"storm":
			if dash_active:
				if storm_dash_morph < 0.58:
					_draw_storm_mage(bob, step, ink, paper)
				_draw_storm_dash_form(bob, ink, accent, storm_dash_morph)
			elif storm_dash_morph > 0.08:
				_draw_storm_mage(bob, step, ink, paper)
				_draw_storm_dash_form(bob, ink, accent, storm_dash_morph)
			else:
				_draw_storm_mage(bob, step, ink, paper)
		"rift": _draw_rift_mage(bob, step, ink, paper)
		"samurai":
			if dash_active:
				_draw_samurai_dash_pose(bob, ink, paper, accent)
			elif samurai_post_dash_stun > 0.01:
				_draw_samurai_recovery_pose(bob, ink, paper, accent)
			else:
				_draw_samurai_mage(bob, step, ink, paper)
		_: _draw_orbit_mage(bob, step, ink, paper)
	if mage_type == "orbit" and (dash_active or orbit_dash_start_flash > 0.01 or orbit_dash_end_flash > 0.01):
		_draw_orbit_dash_fx(bob, accent)
	elif mage_type == "storm" and (dash_active or storm_dash_flash > 0.01):
		_draw_storm_dash_fx(bob, accent)
	if mage_type == "storm" and storm_charging:
		var local_target: Vector2 = storm_target - global_position
		var charge_ratio: float = clampf(storm_charge / maxf(0.001, storm_charge_duration), 0.0, 1.0)
		draw_arc(local_target, 20.0 + charge_ratio * 14.0, 0.0, TAU, 28, Color(accent.r, accent.g, accent.b, 0.18 + charge_ratio * 0.18), 1.7)
		draw_line(local_target + Vector2(-10, 0), local_target + Vector2(10, 0), Color(0.08, 0.08, 0.08, 0.28), 1.2)
		draw_line(local_target + Vector2(0, -10), local_target + Vector2(0, 10), Color(0.08, 0.08, 0.08, 0.28), 1.2)
	match mage_type:
		"storm": _draw_storm_magic(bob)
		"rift": _draw_rift_magic(bob)
		"samurai": _draw_samurai_slash_fx(bob)
		_: _draw_magic_stones(bob)
	if flux_active:
		_draw_flux_aura()
	_draw_world_dash_icons(accent)
	if elite_victory_buff_timer > 0.0:
		var buff_ratio: float = clampf(elite_victory_buff_timer / 10.0, 0.0, 1.0)
		draw_arc(Vector2.ZERO, 31.0 + sin(magic_orbit_t * 5.0) * 2.0, 0.0, TAU, 28, Color(0.08, 0.08, 0.08, 0.12 + buff_ratio * 0.12), 1.6)
		for i in range(3):
			var a: float = magic_orbit_t * 1.8 + TAU * float(i) / 3.0
			var p: Vector2 = Vector2(cos(a) * 27.0, sin(a) * 18.0)
			draw_circle(p, 1.8, Color(accent.r, accent.g, accent.b, 0.16 + buff_ratio * 0.16))

func _draw_world_dash_icons(accent: Color) -> void:
	if max_dash_charges <= 0:
		return
	var count: int = maxi(1, int(max_dash_charges))
	var spacing: float = 18.0
	if count >= 4:
		spacing = 16.0
	if count >= 6:
		spacing = 14.0
	var total_width: float = float(count - 1) * spacing
	var base_y: float = -48.0
	if mage_type == "samurai":
		base_y = -44.0
	elif mage_type == "rift":
		base_y = -40.0
	var base: Vector2 = Vector2(0.0, base_y)
	var available: int = int(dash_charges)
	var progress_ratio: float = 0.0
	if dash_charges < max_dash_charges:
		progress_ratio = get_dash_recharge_ratio()
	for i in range(count):
		var icon_center: Vector2 = base + Vector2(float(i) * spacing - total_width * 0.5, 0.0)
		var fill_ratio: float = 0.0
		if i < available:
			fill_ratio = 1.0
		elif i == available:
			fill_ratio = progress_ratio
		_draw_dash_runner_icon(icon_center, fill_ratio, accent, i)

func _draw_dash_runner_icon(center: Vector2, fill_ratio: float, accent: Color, icon_index: int) -> void:
	var ink: Color = Color(0.08, 0.08, 0.08, 0.96)
	var ring_alpha: float = 0.16 + 0.24 * fill_ratio
	var pulse: float = maxf(0.0, sin(magic_orbit_t * 8.0 + float(icon_index) * 0.8)) if fill_ratio >= 0.999 else 0.0
	draw_circle(center, 9.4 + pulse * 0.35, Color(1.0, 1.0, 1.0, 0.04 + pulse * 0.05))
	draw_arc(center, 8.2, -PI * 0.5, -PI * 0.5 + TAU * fill_ratio, 22, Color(accent.r, accent.g, accent.b, ring_alpha + pulse * 0.10), 1.8)
	draw_arc(center, 8.2, 0.0, TAU, 22, Color(0.08, 0.08, 0.08, 0.10), 1.0)
	# tiny running-person dash emoji with motion trails
	var icon_col: Color = ink if fill_ratio > 0.94 else Color(0.08, 0.08, 0.08, 0.36 + fill_ratio * 0.32)
	var trail_col: Color = Color(accent.r, accent.g, accent.b, 0.12 + fill_ratio * 0.18)
	# trailing wind streaks
	draw_line(center + Vector2(-7.6, -2.2), center + Vector2(-4.5, -2.2), trail_col, 1.1)
	draw_line(center + Vector2(-8.4, 0.7), center + Vector2(-3.7, 0.7), trail_col, 1.0)
	draw_line(center + Vector2(-7.0, 3.4), center + Vector2(-4.0, 3.4), trail_col, 0.9)
	# runner body
	draw_circle(center + Vector2(2.0, -4.0), 1.5, icon_col)
	draw_line(center + Vector2(1.2, -2.3), center + Vector2(-0.2, 0.2), icon_col, 1.35)
	draw_line(center + Vector2(-0.2, 0.2), center + Vector2(3.3, 1.2), icon_col, 1.25)
	draw_line(center + Vector2(-0.2, 0.2), center + Vector2(-3.0, 1.6), icon_col, 1.15)
	draw_line(center + Vector2(0.0, 0.2), center + Vector2(3.8, 4.4), icon_col, 1.35)
	draw_line(center + Vector2(0.0, 0.2), center + Vector2(-2.8, 4.5), icon_col, 1.15)
	if fill_ratio >= 0.999:
		draw_arc(center + Vector2(1.3, -0.3), 5.6 + pulse * 0.3, -0.32, 0.52, 10, Color(accent.r, accent.g, accent.b, 0.20 + pulse * 0.10), 1.0)

func _draw_orbit_mage(bob: float, step: float, ink: Color, paper: Color) -> void:
	var motion: Vector2 = dash_direction if dash_active else move_direction
	if motion.length_squared() > 0.001:
		motion = motion.normalized()
	var dash_blend: float = orbit_dash_pose_blend
	var cast_blend: float = clampf(cast_flash, 0.0, 1.0)
	var sway: float = sin(magic_orbit_t * 2.8) * 0.85
	var lean_x: float = motion.x * (1.8 + dash_blend * 3.1) + aim_direction.x * cast_blend * 1.2
	var shoulder_y: float = -9.0 + bob - dash_blend * 0.55
	var waist_y: float = 3.6 + bob
	var hem_y: float = 21.5 + bob
	var rear_flutter: float = sin(magic_orbit_t * 3.2 + motion.x * 1.7) * 0.9
	var torso_shift: Vector2 = Vector2(lean_x * 0.08, 0.0)
	var head_shift: Vector2 = Vector2(lean_x * 0.24, -dash_blend * 0.4)
	_draw_legs(bob, step * (0.86 + dash_blend * 0.08), ink)
	var rear_drape: PackedVector2Array = PackedVector2Array([
		Vector2(-12.0, shoulder_y - 0.5),
		Vector2(12.0, shoulder_y - 0.5),
		Vector2(16.0, 3.0 + bob + rear_flutter * 0.35),
		Vector2(14.0, 17.0 + bob),
		Vector2(7.0, 24.0 + bob),
		Vector2(0.0, 26.2 + bob),
		Vector2(-7.0, 24.0 + bob),
		Vector2(-14.0, 17.0 + bob),
		Vector2(-16.0, 3.0 + bob - rear_flutter * 0.35)
	])
	for i in range(rear_drape.size()):
		rear_drape[i] += torso_shift
	draw_colored_polygon(rear_drape, Color(0.05, 0.05, 0.05, 0.42))
	var robe: PackedVector2Array = PackedVector2Array([
		Vector2(-11.2, shoulder_y),
		Vector2(11.2, shoulder_y),
		Vector2(10.2, waist_y),
		Vector2(16.0, hem_y - 1.8 + sway * 0.12),
		Vector2(8.0, hem_y),
		Vector2(0.0, hem_y + 2.8),
		Vector2(-8.0, hem_y),
		Vector2(-16.0, hem_y - 1.8 - sway * 0.12),
		Vector2(-10.2, waist_y)
	])
	for i in range(robe.size()):
		robe[i] += torso_shift
	draw_colored_polygon(robe, ink)
	var inner_panel: PackedVector2Array = PackedVector2Array([
		Vector2(-4.1, -5.0 + bob),
		Vector2(4.3, -5.0 + bob),
		Vector2(5.0, 16.0 + bob),
		Vector2(0.0, 22.0 + bob),
		Vector2(-5.0, 16.0 + bob)
	])
	for i in range(inner_panel.size()):
		inner_panel[i] += torso_shift
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var mantle: PackedVector2Array = PackedVector2Array([
		Vector2(-13.0, shoulder_y - 1.2),
		Vector2(13.0, shoulder_y - 1.2),
		Vector2(10.0, -1.2 + bob - dash_blend * 0.25),
		Vector2(4.0, 1.3 + bob),
		Vector2(0.0, 2.2 + bob),
		Vector2(-4.0, 1.3 + bob),
		Vector2(-10.0, -1.2 + bob - dash_blend * 0.25)
	])
	for i in range(mantle.size()):
		mantle[i] += torso_shift
	draw_colored_polygon(mantle, Color(0.06, 0.06, 0.06, 0.94))
	var collar_left: PackedVector2Array = PackedVector2Array([
		Vector2(-7.0, shoulder_y - 0.4), Vector2(-1.2, shoulder_y - 0.6), Vector2(-2.0, -1.0 + bob), Vector2(-8.4, -2.2 + bob)
	])
	var collar_right: PackedVector2Array = PackedVector2Array([
		Vector2(7.0, shoulder_y - 0.4), Vector2(1.2, shoulder_y - 0.6), Vector2(2.0, -1.0 + bob), Vector2(8.4, -2.2 + bob)
	])
	for poly in [collar_left, collar_right]:
		for i in range(poly.size()):
			poly[i] += torso_shift
		draw_colored_polygon(poly, Color(1.0, 1.0, 1.0, 0.07))
	var shoulder_left: PackedVector2Array = PackedVector2Array([
		Vector2(-13.2, shoulder_y + 0.6), Vector2(-8.2, shoulder_y - 0.1), Vector2(-9.2, -1.3 + bob), Vector2(-14.8, 1.7 + bob)
	])
	var shoulder_right: PackedVector2Array = PackedVector2Array([
		Vector2(13.2, shoulder_y + 0.6), Vector2(8.2, shoulder_y - 0.1), Vector2(9.2, -1.3 + bob), Vector2(14.8, 1.7 + bob)
	])
	for poly in [shoulder_left, shoulder_right]:
		for i in range(poly.size()):
			poly[i] += torso_shift
		draw_colored_polygon(poly, Color(1.0, 1.0, 1.0, 0.045))
	var belt_y: float = 7.5 + bob
	draw_line(Vector2(-10.0, belt_y) + torso_shift, Vector2(10.0, belt_y) + torso_shift, Color(1.0, 1.0, 1.0, 0.11), 2.0)
	draw_line(Vector2(-10.0, belt_y + 2.0) + torso_shift, Vector2(10.0, belt_y + 2.0) + torso_shift, Color(0.08, 0.08, 0.08, 0.20), 1.1)
	_draw_diamond(Vector2(0.0, belt_y + 1.0) + torso_shift, 2.2 + cast_blend * 0.15, Color(1.0, 1.0, 1.0, 0.85))
	draw_line(Vector2(0.0, shoulder_y + 2.0) + torso_shift, Vector2(0.0, hem_y - 1.5) + torso_shift, Color(1.0, 1.0, 1.0, 0.14), 1.1)
	draw_line(Vector2(-5.6, 6.2 + bob) + torso_shift, Vector2(5.6, 6.2 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.06), 1.0)
	draw_line(Vector2(-7.4, 14.2 + bob) + torso_shift, Vector2(-1.0, 17.0 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.05), 1.0)
	draw_line(Vector2(7.4, 14.2 + bob) + torso_shift, Vector2(1.0, 17.0 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.05), 1.0)
	for side in [-1.0, 1.0]:
		var rope_top: Vector2 = Vector2(side * 6.8, belt_y + 0.4) + torso_shift
		var rope_mid: Vector2 = rope_top + Vector2(side * 1.8, 5.0)
		var rope_end: Vector2 = rope_mid + Vector2(side * 0.5, 4.2)
		draw_line(rope_top, rope_mid, Color(1.0, 1.0, 1.0, 0.08), 1.0)
		draw_line(rope_mid, rope_end, Color(0.08, 0.08, 0.08, 0.20), 1.0)
		draw_circle(rope_end, 1.1, Color(1.0, 1.0, 1.0, 0.18))
		draw_circle(rope_end + Vector2(0.0, 2.0), 0.8, Color(0.08, 0.08, 0.08, 0.18))
	_draw_diamond(Vector2(0.0, 6.8 + bob) + torso_shift, 2.8 + sin(magic_orbit_t * 4.2) * 0.18 + cast_blend * 0.12, paper)
	_draw_oval(Vector2(0.0, -15.0 + bob) + head_shift, Vector2(8.7, 10.1), ink)
	var head_center: Vector2 = Vector2(0.0, -15.0 + bob) + head_shift
	var hat_brim: PackedVector2Array = PackedVector2Array([
		Vector2(-19.0, -21.0 + bob), Vector2(19.0, -21.0 + bob), Vector2(12.2, -15.8 + bob), Vector2(-12.2, -15.8 + bob)
	])
	for i in range(hat_brim.size()):
		hat_brim[i] += head_shift
	draw_colored_polygon(hat_brim, ink)
	var under_brim: PackedVector2Array = PackedVector2Array([
		Vector2(-10.5, -18.0 + bob), Vector2(10.5, -18.0 + bob), Vector2(7.0, -15.4 + bob), Vector2(-7.0, -15.4 + bob)
	])
	for i in range(under_brim.size()):
		under_brim[i] += head_shift
	draw_colored_polygon(under_brim, Color(1.0, 1.0, 1.0, 0.04))
	var hat_body: PackedVector2Array = PackedVector2Array([
		Vector2(-9.6, -20.4 + bob), Vector2(9.1, -20.4 + bob), Vector2(8.0, -31.2 + bob), Vector2(3.0, -43.5 + bob + sway),
		Vector2(-1.6, -39.0 + bob + sway * 0.55), Vector2(-8.4, -31.2 + bob)
	])
	for i in range(hat_body.size()):
		hat_body[i] += head_shift + Vector2(-motion.x * dash_blend * 0.5, 0.0)
	draw_colored_polygon(hat_body, ink)
	draw_line(Vector2(-7.0, -24.1 + bob) + head_shift, Vector2(6.6, -24.1 + bob) + head_shift, paper, 1.2)
	draw_line(Vector2(-5.0, -33.0 + bob) + head_shift, Vector2(2.4, -38.0 + bob + sway * 0.45) + head_shift, Color(1.0, 1.0, 1.0, 0.08), 1.0)
	_draw_diamond(Vector2(4.6, -28.5 + bob) + head_shift, 1.8, Color(1.0, 1.0, 1.0, 0.42))
	draw_line(Vector2(8.6, -26.0 + bob) + head_shift, Vector2(11.8, -16.8 + bob) + head_shift, Color(1.0, 1.0, 1.0, 0.06), 1.0)
	draw_circle(Vector2(12.0, -15.9 + bob) + head_shift, 1.0, Color(1.0, 1.0, 1.0, 0.14))
	_draw_eyes(head_center, paper)
	draw_line(head_center + Vector2(-4.2, 4.0), head_center + Vector2(4.2, 4.0), Color(1.0, 1.0, 1.0, 0.05), 1.0)
	_draw_orbit_arms(bob, ink)

func _draw_orbit_arms(bob: float, ink: Color) -> void:
	var motion: Vector2 = dash_direction if dash_active else move_direction
	if motion.length_squared() > 0.001:
		motion = motion.normalized()
	var cast_blend: float = clampf(cast_flash, 0.0, 1.0)
	var dash_blend: float = orbit_dash_pose_blend
	var arm_swing: float = sin(walk_phase) * 1.5 if moving else 0.0
	var left_anchor: Vector2 = Vector2(-7.4, -1.5 + bob)
	var right_anchor: Vector2 = Vector2(7.4, -2.5 + bob)
	var left_hand: Vector2 = Vector2(-15.0, 5.4 + bob + arm_swing) - motion * (0.8 + dash_blend * 1.4)
	var right_hand: Vector2 = Vector2(13.0, 2.4 + bob - arm_swing) + aim_direction * (2.8 + cast_blend * 5.6 + dash_blend * 2.2) + motion * 0.9
	draw_line(left_anchor, left_hand, ink, 2.8)
	draw_line(right_anchor, right_hand, ink, 2.8)
	var left_cuff: PackedVector2Array = PackedVector2Array([
		left_hand + Vector2(-2.8, -0.8), left_hand + Vector2(0.3, -1.4), left_hand + Vector2(1.6, 1.3), left_hand + Vector2(-1.5, 1.9)
	])
	var right_cuff: PackedVector2Array = PackedVector2Array([
		right_hand + Vector2(-1.0, -1.7), right_hand + Vector2(2.2, -0.8), right_hand + Vector2(1.2, 1.8), right_hand + Vector2(-1.8, 1.0)
	])
	draw_colored_polygon(left_cuff, Color(1.0, 1.0, 1.0, 0.05))
	draw_colored_polygon(right_cuff, Color(1.0, 1.0, 1.0, 0.05))
	_draw_oval(left_hand + Vector2(-0.6, 0.8), Vector2(2.9, 2.0), ink)
	_draw_oval(right_hand + Vector2(0.8, 0.4), Vector2(2.9, 2.0), ink)
	var focus: Vector2 = right_hand + aim_direction * (5.6 + cast_blend * 4.2) + Vector2(sin(magic_orbit_t * 3.5) * 1.5, -5.0 + cos(magic_orbit_t * 4.0) * 1.5)
	draw_line(right_hand, focus, Color(0.08, 0.08, 0.08, 0.38 + cast_blend * 0.10), 1.2)
	draw_circle(focus, 1.5 + cast_blend * 0.35, Color(1, 1, 1, 0.26 + cast_blend * 0.12))
	_draw_diamond(focus, 2.0 + sin(magic_orbit_t * 5.0) * 0.25 + cast_blend * 0.22, Color(1, 1, 1, 0.42 + cast_blend * 0.08))

func _draw_orbit_dash_fx(bob: float, accent: Color) -> void:
	var dir: Vector2 = dash_direction if dash_direction.length_squared() > 0.001 else aim_direction
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	dir = dir.normalized()
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var dash_alpha: float = 0.12 + orbit_dash_pose_blend * 0.18 + orbit_dash_start_flash * 0.08
	var center: Vector2 = Vector2.ZERO + Vector2(0.0, bob * 0.15)
	for i in range(4):
		var t_line: float = float(i)
		var start: Vector2 = center - dir * (12.0 + t_line * 11.0) + side * sin(magic_orbit_t * 7.0 + t_line) * 2.4
		var finish: Vector2 = start - dir * (18.0 + t_line * 7.0) - side * sin(magic_orbit_t * 5.0 + t_line) * 1.6
		draw_line(start, finish, Color(0.08, 0.08, 0.08, dash_alpha * (1.0 - t_line * 0.16)), 2.4 - t_line * 0.32)
		draw_circle(start, 4.4 - t_line * 0.55, Color(accent.r, accent.g, accent.b, 0.05 + orbit_dash_pose_blend * 0.03))
	var front: Vector2 = center + dir * (24.0 + orbit_dash_pose_blend * 12.0)
	draw_arc(front, 16.0 + orbit_dash_pose_blend * 10.0, dir.angle() - 1.02, dir.angle() + 1.02, 22, Color(accent.r, accent.g, accent.b, 0.16 + orbit_dash_start_flash * 0.10), 3.2)
	draw_arc(front, 16.0 + orbit_dash_pose_blend * 10.0, dir.angle() - 1.02, dir.angle() + 1.02, 22, Color(0.08, 0.08, 0.08, 0.22 + orbit_dash_pose_blend * 0.12), 1.4)
	draw_arc(center, 18.0 + orbit_dash_start_flash * 18.0, 0.0, TAU, 26, Color(accent.r, accent.g, accent.b, 0.06 + orbit_dash_start_flash * 0.10), 1.4)
	if orbit_dash_end_flash > 0.01:
		var landing_t: float = 1.0 - orbit_dash_end_flash
		var landing_radius: float = lerpf(18.0, 68.0, landing_t)
		draw_arc(center, landing_radius, 0.0, TAU, 28, Color(0.08, 0.08, 0.08, orbit_dash_end_flash * 0.24), 1.8)
		draw_arc(center, maxf(8.0, landing_radius - 8.0), 0.0, TAU, 24, Color(accent.r, accent.g, accent.b, orbit_dash_end_flash * 0.12), 1.2)
		for i in range(6):
			var a: float = TAU * float(i) / 6.0 + magic_orbit_t * 0.8
			var p: Vector2 = center + Vector2(cos(a), sin(a)) * (10.0 + landing_radius * 0.52)
			draw_line(center + Vector2(cos(a), sin(a)) * 8.0, p, Color(0.08, 0.08, 0.08, orbit_dash_end_flash * 0.18), 1.0)

func _draw_storm_mage(bob: float, step: float, ink: Color, paper: Color) -> void:
	var motion: Vector2 = visual_move_direction if visual_move_direction.length_squared() > 0.001 else move_direction
	if motion.length_squared() > 0.001:
		motion = motion.normalized()
	var look: Vector2 = visual_aim_direction if visual_aim_direction.length_squared() > 0.001 else aim_direction
	if look.length_squared() > 0.001:
		look = look.normalized()
	var hand_sway: float = sin(walk_phase) * 1.35 if moving else sin(idle_phase * 2.0) * 0.22
	var gust: float = sin(magic_orbit_t * 2.6) * 0.8
	var lean_x: float = motion.x * 1.9 + look.x * 1.05
	var shoulder_y: float = -8.4 + bob
	var waist_y: float = 4.4 + bob
	var hem_y: float = 23.5 + bob
	var torso_shift: Vector2 = Vector2(lean_x * 0.18, 0.0)
	var head_shift: Vector2 = Vector2(lean_x * 0.36, look.y * 0.65)
	var side: Vector2 = Vector2(-look.y, look.x)
	var storm_dark: Color = Color(0.06, 0.07, 0.09, 0.98)
	var storm_mid: Color = ink
	var storm_glow: Color = Color(0.74, 0.90, 1.0, 0.22)
	_draw_legs(bob, step * 0.94, ink)
	var rear_cloak: PackedVector2Array = PackedVector2Array([
		Vector2(-16.2, shoulder_y), Vector2(16.2, shoulder_y), Vector2(22.0, 3.5 + bob + gust * 0.35),
		Vector2(18.5, 18.0 + bob), Vector2(8.5, 25.8 + bob), Vector2(0.0, 22.3 + bob),
		Vector2(-8.5, 25.8 + bob), Vector2(-18.5, 18.0 + bob), Vector2(-22.0, 3.5 + bob - gust * 0.35)
	])
	for i in range(rear_cloak.size()):
		rear_cloak[i] += torso_shift
	draw_colored_polygon(rear_cloak, Color(0.05, 0.05, 0.05, 0.44))
	var coat: PackedVector2Array = PackedVector2Array([
		Vector2(-13.4, shoulder_y), Vector2(13.4, shoulder_y), Vector2(12.2, waist_y),
		Vector2(18.5, 19.8 + bob), Vector2(8.5, 18.4 + bob), Vector2(0.0, hem_y),
		Vector2(-8.5, 18.4 + bob), Vector2(-18.5, 19.8 + bob), Vector2(-12.2, waist_y)
	])
	for i in range(coat.size()):
		coat[i] += torso_shift
	draw_colored_polygon(coat, storm_mid)
	var inner_panel: PackedVector2Array = PackedVector2Array([
		Vector2(-4.4, -3.4 + bob), Vector2(4.4, -3.4 + bob), Vector2(5.4, 16.4 + bob),
		Vector2(0.0, 22.0 + bob), Vector2(-5.4, 16.4 + bob)
	])
	for i in range(inner_panel.size()):
		inner_panel[i] += torso_shift
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var mantle: PackedVector2Array = PackedVector2Array([
		Vector2(-17.4, shoulder_y - 0.8), Vector2(17.4, shoulder_y - 0.8), Vector2(11.4, -1.3 + bob),
		Vector2(4.2, 1.7 + bob), Vector2(0.0, 2.6 + bob), Vector2(-4.2, 1.7 + bob), Vector2(-11.4, -1.3 + bob)
	])
	for i in range(mantle.size()):
		mantle[i] += torso_shift
	draw_colored_polygon(mantle, storm_dark)
	var collar_left: PackedVector2Array = PackedVector2Array([
		Vector2(-17.6, shoulder_y - 1.2), Vector2(-7.0, shoulder_y - 1.6), Vector2(-9.6, 1.1 + bob), Vector2(-20.8, 2.2 + bob)
	])
	var collar_right: PackedVector2Array = PackedVector2Array([
		Vector2(17.6, shoulder_y - 1.2), Vector2(7.0, shoulder_y - 1.6), Vector2(9.6, 1.1 + bob), Vector2(20.8, 2.2 + bob)
	])
	for poly in [collar_left, collar_right]:
		for i in range(poly.size()):
			poly[i] += torso_shift
		draw_colored_polygon(poly, Color(1.0, 1.0, 1.0, 0.05))
	draw_line(Vector2(0.0, -1.4 + bob) + torso_shift, Vector2(0.0, 22.0 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.14), 1.0)
	draw_polyline(PackedVector2Array([
		Vector2(-6.5, 3.0 + bob) + torso_shift, Vector2(1.8, 8.6 + bob) + torso_shift, Vector2(-2.5, 13.8 + bob) + torso_shift, Vector2(7.0, 18.2 + bob) + torso_shift
	]), paper, 1.45)
	draw_line(Vector2(-10.0, 7.3 + bob) + torso_shift, Vector2(10.0, 7.3 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.07), 1.1)
	_draw_diamond(Vector2(0.0, 8.1 + bob) + torso_shift, 2.4 + sin(magic_orbit_t * 4.2) * 0.15, Color(1.0, 1.0, 1.0, 0.86))
	for side_sign in [-1.0, 1.0]:
		var tassel_top: Vector2 = Vector2(side_sign * 7.4, 8.7 + bob) + torso_shift
		draw_line(tassel_top, tassel_top + Vector2(side_sign * 2.0, 5.0), Color(1.0, 1.0, 1.0, 0.08), 1.0)
		draw_circle(tassel_top + Vector2(side_sign * 2.5, 6.5), 1.0, Color(1.0, 1.0, 1.0, 0.16))
	var head_center: Vector2 = Vector2(0.0, -15.0 + bob) + head_shift
	_draw_oval(head_center, Vector2(8.9, 10.3), ink)
	var hood: PackedVector2Array = PackedVector2Array([
		Vector2(-13.0, -21.0 + bob), Vector2(13.0, -21.0 + bob), Vector2(11.2, -33.0 + bob),
		Vector2(4.0, -42.0 + bob + gust), Vector2(-1.0, -39.0 + bob + gust * 0.5), Vector2(-10.8, -31.0 + bob)
	])
	for i in range(hood.size()):
		hood[i] += head_shift + Vector2(-motion.x * 0.4, 0.0)
	draw_colored_polygon(hood, ink)
	var crown: PackedVector2Array = PackedVector2Array([
		Vector2(-17.0, -20.0 + bob), Vector2(-11.2, -36.0 + bob), Vector2(-4.8, -31.0 + bob),
		Vector2(-1.0, -44.0 + bob), Vector2(3.4, -35.0 + bob), Vector2(8.4, -41.0 + bob),
		Vector2(15.8, -20.0 + bob)
	])
	for i in range(crown.size()):
		crown[i] += head_shift + Vector2(look.x * 0.45, 0.0)
	draw_colored_polygon(crown, ink)
	draw_line(Vector2(-9.0, -24.5 + bob) + head_shift, Vector2(9.0, -24.5 + bob) + head_shift, paper, 1.1)
	draw_line(Vector2(-5.5, -31.8 + bob) + head_shift, Vector2(2.0, -38.0 + bob + gust * 0.4) + head_shift, Color(1.0, 1.0, 1.0, 0.07), 1.0)
	draw_circle(Vector2(0.5, -31.0 + bob) + head_shift, 1.0, Color(1.0, 1.0, 1.0, 0.22))
	_draw_eyes(head_center, paper)
	draw_line(head_center + Vector2(-4.0, 4.0), head_center + Vector2(4.0, 4.0), Color(1.0, 1.0, 1.0, 0.05), 1.0)
	var left_anchor: Vector2 = Vector2(-8.0, -2.0 + bob) + torso_shift
	var right_anchor: Vector2 = Vector2(8.0, -2.0 + bob) + torso_shift
	var left_hand: Vector2 = Vector2(-17.4, 5.0 + bob + hand_sway) + torso_shift - motion * 0.8
	var right_hand: Vector2 = Vector2(13.4, 4.2 + bob - hand_sway) + torso_shift + look * 3.8 + motion * 0.55
	draw_line(left_anchor, left_hand, ink, 2.8)
	draw_line(right_anchor, right_hand, ink, 2.8)
	var left_cuff: PackedVector2Array = PackedVector2Array([
		left_hand + Vector2(-2.7, -0.8), left_hand + Vector2(0.0, -1.4), left_hand + Vector2(1.7, 1.2), left_hand + Vector2(-1.6, 1.8)
	])
	var right_cuff: PackedVector2Array = PackedVector2Array([
		right_hand + Vector2(-1.5, -1.6), right_hand + Vector2(2.1, -0.9), right_hand + Vector2(1.2, 1.7), right_hand + Vector2(-1.9, 1.0)
	])
	draw_colored_polygon(left_cuff, Color(1.0, 1.0, 1.0, 0.05))
	draw_colored_polygon(right_cuff, Color(1.0, 1.0, 1.0, 0.05))
	_draw_oval(left_hand, Vector2(3.0, 2.1), ink)
	_draw_oval(right_hand, Vector2(3.0, 2.1), ink)
	# storm focus rod / wand so the class has the same hand-crafted feel as Orbit.
	var rod_start: Vector2 = right_hand + look * 1.8 - side * 0.8
	var rod_tip: Vector2 = rod_start + look * 15.5 + side * (sin(magic_orbit_t * 3.7) * 1.6)
	draw_line(rod_start, rod_tip, Color(0.08, 0.08, 0.08, 0.98), 2.3)
	draw_line(rod_start + side * 0.5, rod_tip + side * 0.5, Color(1.0, 1.0, 1.0, 0.20), 0.9)
	draw_line(rod_start - look * 2.2, rod_start + look * 2.2, Color(0.82, 0.92, 1.0, 0.42), 1.0)
	for j in range(3):
		var spark_from: Vector2 = rod_tip + side * (-2.0 + float(j) * 2.1)
		var spark_mid: Vector2 = spark_from + look * (2.5 + float(j) * 1.8) + side * (2.4 if j % 2 == 0 else -2.2)
		var spark_tip: Vector2 = spark_mid + look * (2.6 + float(j)) + side * (-1.9 if j % 2 == 0 else 1.6)
		draw_polyline(PackedVector2Array([spark_from, spark_mid, spark_tip]), Color(0.82, 0.92, 1.0, 0.28), 1.6)
		draw_polyline(PackedVector2Array([spark_from, spark_mid, spark_tip]), Color(0.08, 0.08, 0.08, 0.18), 0.8)
	var halo: Vector2 = rod_tip + look * 1.8
	draw_arc(halo, 5.2, -1.0, 1.2, 14, storm_glow, 1.5)
	draw_circle(halo, 1.35, Color(1.0, 1.0, 1.0, 0.20))
	for side_sign in [-1.0, 1.0]:
		var hand: Vector2 = left_hand if side_sign < 0.0 else right_hand
		var hand_halo: Vector2 = hand + Vector2(side_sign * 6.8, -2.0 + sin(magic_orbit_t * 5.0 + side_sign) * 1.4)
		draw_arc(hand_halo, 4.8, -1.4, 1.4, 12, Color(0.82, 0.92, 1.0, 0.10), 1.3)
		draw_arc(hand_halo, 4.8, -1.4, 1.4, 12, Color(0.08, 0.08, 0.08, 0.18), 1.0)

func _draw_storm_dash_form(bob: float, ink: Color, accent: Color, morph: float) -> void:
	var dir: Vector2 = dash_direction.normalized()
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var dash_ratio: float = clampf(dash_left / maxf(0.001, current_dash_duration), 0.0, 1.0)
	var phase_alpha: float = clampf(0.18 + morph * 0.82, 0.0, 1.0)
	var head_pos: Vector2 = dir * (4.0 + morph * 4.0) + Vector2(0.0, -10.0 + bob * 0.10)
	var bolt: PackedVector2Array = PackedVector2Array([
		Vector2(-8.0, -18.0 + bob * 0.08), Vector2(0.0, -18.0 + bob * 0.08), Vector2(-5.0, -5.0 + bob * 0.08),
		Vector2(6.5, -5.0 + bob * 0.08), Vector2(-1.0, 16.0 + bob * 0.08), Vector2(1.0, 2.0 + bob * 0.08), Vector2(-8.0, 2.0 + bob * 0.08)
	])
	for i in range(bolt.size()):
		var local: Vector2 = bolt[i]
		bolt[i] = head_pos + dir * local.y * 0.38 + side * local.x
	draw_colored_polygon(bolt, Color(0.08, 0.08, 0.08, 0.92 * phase_alpha))
	draw_polyline(bolt, Color(1.0, 1.0, 1.0, (0.30 + storm_dash_flash * 0.06) * phase_alpha), 1.6 + morph * 0.5)
	draw_line(head_pos - side * 2.2, head_pos + side * 2.2, Color(1.0, 1.0, 1.0, 0.48 * phase_alpha), 1.2)
	draw_circle(head_pos + dir * 2.0, 1.6 + morph * 0.45, Color(accent.r, accent.g, accent.b, 0.90 * phase_alpha))
	draw_circle(head_pos - dir * 1.0, 1.0 + morph * 0.2, Color(1.0, 1.0, 1.0, 0.34 * phase_alpha))
	for i in range(3):
		var echo_alpha: float = (0.14 + float(2 - i) * 0.05) * dash_ratio * phase_alpha
		var echo_shift: Vector2 = -dir * (10.0 + float(i) * 12.0)
		draw_line(head_pos + echo_shift + side * 8.0, head_pos + echo_shift - side * 8.0, Color(0.08, 0.08, 0.08, echo_alpha), 1.2)
		draw_line(head_pos + echo_shift + side * 4.0, head_pos + echo_shift - dir * 10.0, Color(accent.r, accent.g, accent.b, echo_alpha * 0.95), 2.2)
	for branch in range(4):
		var off: float = -18.0 + float(branch) * 11.0
		var base: Vector2 = head_pos - dir * (6.0 + float(branch) * 3.0) + side * off * 0.35
		var tip: Vector2 = base + side * signf(off) * (5.0 + float(branch)) + dir * (2.0 - float(branch) * 0.6)
		draw_line(base, tip, Color(0.82, 0.92, 1.0, 0.16 * phase_alpha), 1.1)
		draw_line(base, tip, Color(0.08, 0.08, 0.08, 0.18 * phase_alpha), 0.8)

func _draw_storm_dash_fx(bob: float, accent: Color) -> void:
	var dir: Vector2 = dash_direction.normalized()
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var dash_ratio: float = clampf(dash_left / maxf(0.001, current_dash_duration), 0.0, 1.0) if dash_active else 0.0
	var tail_alpha: float = 0.14 + dash_ratio * 0.18 + storm_dash_flash * 0.08
	var front: Vector2 = dir * (14.0 + dash_ratio * 12.0) + Vector2(0.0, bob * 0.10)
	for i in range(4):
		var trail: Vector2 = -dir * (12.0 + float(i) * 13.0) + Vector2(0.0, bob * 0.08)
		var spread: float = 10.0 - float(i) * 1.6
		draw_line(trail + side * spread, trail - side * spread, Color(0.08, 0.08, 0.08, tail_alpha * (1.0 - float(i) * 0.18)), 1.4)
		draw_line(trail + side * (spread * 0.5), trail - dir * 15.0, Color(accent.r, accent.g, accent.b, tail_alpha * 0.92), 2.4)
	for i in range(3):
		var bolt_origin: Vector2 = front - dir * float(i) * 8.0
		var mid: Vector2 = bolt_origin + side * (4.0 if i % 2 == 0 else -4.0) + dir * 5.0
		var bolt_tip: Vector2 = mid + side * (-3.0 if i % 2 == 0 else 3.0) + dir * 6.0
		draw_polyline(PackedVector2Array([bolt_origin, mid, bolt_tip]), Color(0.82, 0.92, 1.0, 0.22 + storm_dash_flash * 0.08), 2.2)
		draw_polyline(PackedVector2Array([bolt_origin, mid, bolt_tip]), Color(0.08, 0.08, 0.08, 0.20), 1.0)
	draw_arc(front, 18.0 + storm_dash_flash * 8.0, dir.angle() - 0.9, dir.angle() + 0.9, 22, Color(accent.r, accent.g, accent.b, 0.18 + storm_dash_flash * 0.10), 3.2)
	draw_arc(front, 18.0 + storm_dash_flash * 8.0, dir.angle() - 0.9, dir.angle() + 0.9, 22, Color(0.08, 0.08, 0.08, 0.20 + storm_dash_flash * 0.08), 1.4)
	draw_circle(front, 2.1 + storm_dash_flash * 0.4, Color(1.0, 1.0, 1.0, 0.26 + storm_dash_flash * 0.08))

func _draw_rift_mage(bob: float, step: float, ink: Color, paper: Color) -> void:
	# Narrow asymmetric silhouette with a clean split cloak and broken mask.
	_draw_legs(bob,step,ink)
	var left: PackedVector2Array = PackedVector2Array([Vector2(-15,-7+bob),Vector2(-1,-8+bob),Vector2(-2,19+bob),Vector2(-12,25+bob),Vector2(-20,16+bob)])
	var right: PackedVector2Array = PackedVector2Array([Vector2(1,-8+bob),Vector2(12,-6+bob),Vector2(17,15+bob),Vector2(6,18+bob),Vector2(2,22+bob)])
	draw_colored_polygon(left,ink)
	draw_colored_polygon(right,Color(0.08,0.08,0.08,0.76))
	draw_line(Vector2(0,-7+bob),Vector2(-2,20+bob),paper,1.4)
	_draw_oval(Vector2(0,-14+bob),Vector2(10,11),ink)
	var hood: PackedVector2Array = PackedVector2Array([Vector2(-15,-19+bob),Vector2(15,-19+bob),Vector2(10,-34+bob),Vector2(2,-39+bob),Vector2(-8,-35+bob),Vector2(-13,-27+bob)])
	draw_colored_polygon(hood,ink)
	draw_line(Vector2(1,-34+bob),Vector2(-1,-18+bob),paper,1.2)
	# one eye pair is intentionally offset around the split mask
	_draw_eyes(Vector2(0,-14+bob),paper)
	_draw_arms(bob,ink,-2.0)

func _draw_samurai_mage(bob: float, step: float, ink: Color, paper: Color) -> void:
	var cloth_dark: Color = Color(0.06, 0.06, 0.07, 0.97)
	var cloth_mid: Color = Color(0.10, 0.10, 0.12, 0.96)
	var crimson: Color = Color(0.62, 0.19, 0.22, 0.82)
	var gold: Color = Color(0.83, 0.69, 0.40, 0.66)
	var look: Vector2 = visual_aim_direction if visual_aim_direction.length_squared() > 0.001 else aim_direction
	if look.length_squared() > 0.001:
		look = look.normalized()
	var motion: Vector2 = visual_move_direction if visual_move_direction.length_squared() > 0.001 else move_direction
	if motion.length_squared() > 0.001:
		motion = motion.normalized()
	var gait: float = sin(walk_phase) if moving else 0.0
	var stride: float = gait * 3.6
	var left_lift: float = maxf(0.0, sin(walk_phase)) * 3.7 if moving else 0.0
	var right_lift: float = maxf(0.0, -sin(walk_phase)) * 3.7 if moving else 0.0
	var torso_lean: float = motion.x * 1.2 + look.x * 0.95
	var torso_shift: Vector2 = Vector2(torso_lean * 0.18, 0.0)
	var head_shift: Vector2 = Vector2(torso_lean * 0.40, look.y * 0.50)
	var hip_y: float = 11.8 + bob
	# deliberate stalking walk with a more alive body rhythm.
	draw_line(Vector2(-5.0, hip_y) + torso_shift, Vector2(-7.4 + stride * 0.66, 20.0 - left_lift), ink, 3.0)
	draw_line(Vector2(5.0, hip_y) + torso_shift, Vector2(7.4 - stride * 0.66, 20.0 - right_lift), ink, 3.0)
	draw_line(Vector2(-11.2 + stride * 0.66, 20.0 - left_lift), Vector2(-3.4 + stride * 0.66, 20.0 - left_lift), ink, 2.2)
	draw_line(Vector2(3.4 - stride * 0.66, 20.0 - right_lift), Vector2(11.2 - stride * 0.66, 20.0 - right_lift), ink, 2.2)
	var rear_cloak: PackedVector2Array = PackedVector2Array([
		Vector2(-16.0, -7.0 + bob), Vector2(16.0, -7.0 + bob), Vector2(19.5, 2.5 + bob), Vector2(16.0, 15.5 + bob),
		Vector2(8.0, 24.5 + bob), Vector2(0.0, 21.0 + bob), Vector2(-8.0, 24.5 + bob), Vector2(-16.0, 15.5 + bob), Vector2(-19.5, 2.5 + bob)
	])
	for i in range(rear_cloak.size()):
		rear_cloak[i] += torso_shift
	draw_colored_polygon(rear_cloak, Color(0.04, 0.04, 0.04, 0.34))
	var hakama: PackedVector2Array = PackedVector2Array([
		Vector2(-15.0, 2.5 + bob), Vector2(-6.2, -0.8 + bob), Vector2(0.0, 18.8 + bob), Vector2(6.2, -0.8 + bob),
		Vector2(15.0, 2.5 + bob), Vector2(12.4, 18.4 + bob), Vector2(5.4, 16.8 + bob), Vector2(0.0, 22.5 + bob), Vector2(-5.4, 16.8 + bob), Vector2(-12.4, 18.4 + bob)
	])
	for i in range(hakama.size()):
		hakama[i] += torso_shift
	draw_colored_polygon(hakama, cloth_dark)
	var torso: PackedVector2Array = PackedVector2Array([
		Vector2(-14.0, -10.6 + bob), Vector2(14.0, -10.6 + bob), Vector2(11.8, 5.8 + bob), Vector2(2.0, 10.6 + bob), Vector2(-12.2, 6.2 + bob)
	])
	for i in range(torso.size()):
		torso[i] += torso_shift
	draw_colored_polygon(torso, cloth_mid)
	var shoulder_left: PackedVector2Array = PackedVector2Array([Vector2(-15.2, -8.8 + bob), Vector2(-7.2, -10.6 + bob), Vector2(-5.6, -0.2 + bob), Vector2(-13.8, 1.0 + bob)])
	var shoulder_right: PackedVector2Array = PackedVector2Array([Vector2(15.2, -8.8 + bob), Vector2(7.2, -10.6 + bob), Vector2(5.6, -0.2 + bob), Vector2(13.8, 1.0 + bob)])
	for poly in [shoulder_left, shoulder_right]:
		for i in range(poly.size()):
			poly[i] += torso_shift
		draw_colored_polygon(poly, Color(0.03, 0.03, 0.03, 0.52))
	var inner_panel: PackedVector2Array = PackedVector2Array([Vector2(-4.6, -5.2 + bob), Vector2(3.9, -5.2 + bob), Vector2(4.5, 13.4 + bob), Vector2(0.0, 18.5 + bob), Vector2(-4.7, 13.4 + bob)])
	for i in range(inner_panel.size()):
		inner_panel[i] += torso_shift
	draw_colored_polygon(inner_panel, Color(1.0, 1.0, 1.0, 0.055))
	var sash: PackedVector2Array = PackedVector2Array([Vector2(-11.5, 4.5 + bob), Vector2(11.5, 4.5 + bob), Vector2(9.8, 8.8 + bob), Vector2(-9.8, 8.8 + bob)])
	for i in range(sash.size()):
		sash[i] += torso_shift
	draw_colored_polygon(sash, crimson)
	draw_line(Vector2(-8.8, -4.4 + bob) + torso_shift, Vector2(7.2, 4.8 + bob) + torso_shift, paper, 1.2)
	draw_line(Vector2(-6.0, 5.8 + bob) + torso_shift, Vector2(6.0, 5.8 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.08), 0.9)
	for fold in range(4):
		var xx: float = -5.8 + float(fold) * 3.8
		draw_line(Vector2(xx, 6.0 + bob) + torso_shift, Vector2(xx * 0.55, 19.8 + bob) + torso_shift, Color(1.0, 1.0, 1.0, 0.055), 0.8)
	_draw_diamond(Vector2(0.0, 6.8 + bob) + torso_shift, 1.8, gold)
	var head_center: Vector2 = Vector2(0.0, -17.2 + bob) + head_shift
	_draw_oval(head_center, Vector2(10.7, 10.9), ink)
	draw_line(head_center + Vector2(-10.4, -1.2), head_center + Vector2(10.4, -1.2), paper, 1.55)
	draw_circle(head_center + Vector2(8.8, -1.1), 1.2, cloth_dark)
	var tail_swing: float = sin(walk_phase * 1.55) * 1.8 if moving else sin(idle_phase * 2.0) * 0.6
	draw_line(head_center + Vector2(8.2, -2.2), head_center + Vector2(16.2 + tail_swing, -8.3 + look.y * 1.1), ink, 1.75)
	draw_line(head_center + Vector2(8.2, -1.0), head_center + Vector2(17.2 + tail_swing * 1.08, 0.8 - look.y * 0.6), ink, 1.45)
	draw_line(head_center + Vector2(-5.0, -4.4), head_center + Vector2(5.0, -4.4), Color(1.0, 1.0, 1.0, 0.05), 0.9)
	_draw_eyes(head_center, paper)
	# visible sheath on the hip
	var sheath_dir: Vector2 = Vector2(0.96, 0.24).normalized()
	var sheath_center: Vector2 = Vector2(-8.6, 8.0 + bob) + torso_shift
	draw_line(sheath_center - sheath_dir * 7.0, sheath_center + sheath_dir * 25.6, Color(0.07, 0.07, 0.07, 0.98), 3.5)
	draw_line(sheath_center + sheath_dir * 4.0, sheath_center + sheath_dir * 16.5, Color(crimson.r, crimson.g, crimson.b, 0.62), 1.0)
	draw_line(sheath_center + sheath_dir * 17.8, sheath_center + sheath_dir * 22.8, gold, 1.0)
	draw_circle(sheath_center - sheath_dir * 0.4, 1.05, gold)
	var front_hand: Vector2 = Vector2(11.6, 1.2 + bob) + torso_shift + look * 4.4 + Vector2(gait * 0.7, -absf(gait) * 0.42)
	var rear_hand: Vector2 = Vector2(-10.1, 2.2 + bob) + torso_shift + Vector2(-gait * 0.55, absf(gait) * 0.45)
	# rear hand braces near the sheath while the front hand presents the blade.
	draw_line(Vector2(6.2, -2.4 + bob) + torso_shift, front_hand, ink, 2.9)
	draw_line(Vector2(-7.2, -2.1 + bob) + torso_shift, rear_hand, ink, 2.85)
	_draw_oval(front_hand, Vector2(3.0, 2.1), ink)
	_draw_oval(rear_hand, Vector2(3.0, 2.1), ink)
	draw_line(front_hand + Vector2(-1.5, -0.5), front_hand + Vector2(1.8, 1.0), Color(1.0, 1.0, 1.0, 0.05), 1.0)
	draw_line(rear_hand + Vector2(-1.8, -0.5), rear_hand + Vector2(1.4, 1.0), Color(1.0, 1.0, 1.0, 0.05), 1.0)
	# active sword hold / blade pose to match the care put into Orbit's wand hand.
	var blade_dir: Vector2 = (look * 0.94 + Vector2(0.18, -0.08)).normalized()
	var blade_side: Vector2 = Vector2(-blade_dir.y, blade_dir.x)
	var hilt_start: Vector2 = front_hand - blade_dir * 2.8
	var blade_base: Vector2 = front_hand + blade_dir * 2.1
	var blade_tip: Vector2 = blade_base + blade_dir * 23.0 + blade_side * 2.2
	draw_line(hilt_start, blade_base, Color(0.08, 0.08, 0.08, 0.98), 3.0)
	draw_line(front_hand - blade_side * 2.2, front_hand + blade_side * 2.2, gold, 1.1)
	draw_circle(front_hand, 1.05, gold)
	draw_line(blade_base, blade_tip, Color(0.08, 0.08, 0.08, 0.98), 2.0)
	draw_line(blade_base + blade_side * 0.55, blade_tip + blade_side * 0.55, Color(1.0, 1.0, 1.0, 0.30), 0.9)
	draw_arc(blade_tip - blade_dir * 1.0, 8.5, blade_dir.angle() - 0.65, blade_dir.angle() + 0.15, 16, Color(1.0, 1.0, 1.0, 0.07), 1.0)

func _draw_samurai_dash_pose(bob: float, ink: Color, paper: Color, accent: Color) -> void:
	var dir: Vector2 = dash_direction.normalized()
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var dash_ratio: float = clampf(dash_left / maxf(0.001, current_dash_duration), 0.0, 1.0)
	var rush: float = 1.0 - dash_ratio
	var phase_sign: float = -1.0
	var lean: Vector2 = dir * (10.0 + rush * 8.0) + side * phase_sign * (2.4 + rush * 1.8)
	var head_center: Vector2 = Vector2(0.0, -16.2 + bob) + lean * 0.20
	var cloth_dark: Color = Color(0.06, 0.06, 0.07, 0.98)
	var cloth_mid: Color = Color(0.10, 0.10, 0.12, 0.97)
	var crimson: Color = Color(0.62, 0.19, 0.22, 0.82)
	var gold: Color = Color(0.83, 0.69, 0.40, 0.66)
	# trailing ghost body streaks and sash flutter
	for i in range(4):
		var trail_offset: Vector2 = -dir * (12.0 + float(i) * 8.0) - side * (2.0 + float(i) * 1.4)
		draw_line(head_center + trail_offset + side * 7.0, head_center + trail_offset - side * 7.0, Color(0.06,0.06,0.06,0.14 - float(i) * 0.022), 1.2)
		draw_line(head_center + trail_offset - dir * 4.0, head_center + trail_offset + dir * 10.0, Color(accent.r, accent.g, accent.b,0.10 - float(i) * 0.018), 1.8)
	# compressed pose leaning into the cut
	draw_line(Vector2(-4.2, 10.0 + bob) - dir * 5.2, Vector2(-9.4, 19.0 + bob) - dir * 2.2 + side * 1.8, ink, 2.9)
	draw_line(Vector2(4.0, 11.8 + bob) - dir * 6.0, Vector2(11.0, 18.3 + bob) + dir * 2.4 - side * 2.2, ink, 2.9)
	var rear_cloak: PackedVector2Array = PackedVector2Array([
		Vector2(-15.0, -8.8 + bob), Vector2(13.6, -10.8 + bob), Vector2(16.2, 0.8 + bob), Vector2(12.8, 14.0 + bob),
		Vector2(4.8, 22.2 + bob), Vector2(-2.0, 18.8 + bob), Vector2(-10.4, 23.5 + bob), Vector2(-16.8, 13.4 + bob), Vector2(-18.5, 2.0 + bob)
	])
	draw_colored_polygon(rear_cloak, Color(0.04,0.04,0.04,0.32))
	var torso: PackedVector2Array = PackedVector2Array([
		Vector2(-12.6, -10.4 + bob), Vector2(14.0, -11.6 + bob), Vector2(10.8, 3.8 + bob), Vector2(2.8, 9.8 + bob), Vector2(-10.2, 6.0 + bob)
	])
	draw_colored_polygon(torso, cloth_mid)
	var shoulder_left: PackedVector2Array = PackedVector2Array([Vector2(-13.8,-8.4 + bob), Vector2(-6.8,-10.0 + bob), Vector2(-5.2,-0.4 + bob), Vector2(-12.2,1.0 + bob)])
	var shoulder_right: PackedVector2Array = PackedVector2Array([Vector2(14.8,-9.2 + bob), Vector2(8.4,-10.6 + bob), Vector2(7.0,-0.6 + bob), Vector2(13.6,1.0 + bob)])
	draw_colored_polygon(shoulder_left, Color(0.03,0.03,0.03,0.48))
	draw_colored_polygon(shoulder_right, Color(0.03,0.03,0.03,0.52))
	var hakama: PackedVector2Array = PackedVector2Array([
		Vector2(-13.4, 2.4 + bob), Vector2(-5.8, -0.5 + bob), Vector2(0.0, 17.2 + bob), Vector2(5.8, -0.5 + bob),
		Vector2(13.6, 2.6 + bob), Vector2(11.0, 17.4 + bob), Vector2(4.9, 15.6 + bob), Vector2(0.0, 21.4 + bob), Vector2(-4.9, 15.6 + bob), Vector2(-11.0, 17.4 + bob)
	])
	draw_colored_polygon(hakama, cloth_dark)
	var sash: PackedVector2Array = PackedVector2Array([Vector2(-10.8, 4.0 + bob), Vector2(10.8, 4.0 + bob), Vector2(9.0, 8.0 + bob), Vector2(-9.0, 8.0 + bob)])
	draw_colored_polygon(sash, crimson)
	draw_line(Vector2(-7.8, -4.8 + bob), Vector2(6.8, 4.1 + bob), paper, 1.2)
	draw_line(Vector2(-5.6, 4.6 + bob), Vector2(5.7, 4.6 + bob), Color(1.0,1.0,1.0,0.06), 0.9)
	_draw_diamond(Vector2(0.0, 6.0 + bob), 1.6, gold)
	_draw_oval(head_center, Vector2(10.4, 10.6), ink)
	draw_line(head_center + Vector2(-10.0, -1.3), head_center + Vector2(10.0, -1.3), paper, 1.45)
	draw_circle(head_center + Vector2(8.8, -1.1), 1.1, cloth_dark)
	draw_line(head_center + Vector2(8.2, -2.2), head_center + Vector2(17.0, -7.6), ink, 1.7)
	draw_line(head_center + Vector2(8.2, -0.8), head_center + Vector2(18.0, 1.0), ink, 1.45)
	_draw_eyes(head_center, paper)
	var rear_hand: Vector2 = Vector2(-7.0, 0.9 + bob) - dir * 1.0
	var front_hand: Vector2 = Vector2(6.4, -1.2 + bob) + dir * 11.0 + side * 5.8
	draw_line(Vector2(-6.2, -1.8 + bob), rear_hand, ink, 2.7)
	draw_line(Vector2(4.8, -3.0 + bob), front_hand, ink, 2.8)
	_draw_oval(rear_hand, Vector2(2.8, 2.0), ink)
	_draw_oval(front_hand, Vector2(2.8, 2.0), ink)
	var blade_start: Vector2 = front_hand + dir * 2.0
	var blade_mid: Vector2 = blade_start + dir * 16.0 + side * 6.0
	var blade_tip: Vector2 = blade_start + dir * 29.0 + side * 17.0
	draw_line(blade_start - dir * 3.0, blade_start + dir * 3.0, gold, 1.1)
	draw_polyline(PackedVector2Array([blade_start, blade_mid, blade_tip]), Color(0.08,0.08,0.08,0.98), 2.2)
	draw_polyline(PackedVector2Array([blade_start + side * 0.5, blade_mid + side * 0.5, blade_tip + side * 0.5]), Color(1.0,1.0,1.0,0.32), 0.9)
	draw_arc(blade_tip, 7.5, dir.angle() - 0.9, dir.angle() + 0.3, 14, Color(1.0,1.0,1.0,0.08 + rush * 0.08), 1.1)
	# scarf/headband flourish
	draw_line(head_center + Vector2(8.6,-2.2), head_center + Vector2(18.0 - rush * 2.0, -8.6 - rush * 0.8), Color(0.08,0.08,0.08,0.95), 1.4)
	draw_line(head_center + Vector2(8.8,-1.0), head_center + Vector2(19.5 - rush * 2.0, 1.4 + rush * 0.6), Color(crimson.r, crimson.g, crimson.b,0.55), 1.1)

func _draw_samurai_recovery_pose(bob: float, ink: Color, paper: Color, accent: Color) -> void:
	var recover_ratio: float = clampf(samurai_post_dash_stun / 0.4, 0.0, 1.0)
	var dir: Vector2 = aim_direction.normalized()
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var head_center: Vector2 = Vector2(-1.5, -16.8 + bob)
	var cloth_dark: Color = Color(0.06, 0.06, 0.07, 0.98)
	var cloth_mid: Color = Color(0.10, 0.10, 0.12, 0.97)
	var crimson: Color = Color(0.62, 0.19, 0.22, 0.82)
	var gold: Color = Color(0.83, 0.69, 0.40, 0.66)
	# planted finishing stance
	draw_line(Vector2(-5.0,11.5 + bob), Vector2(-10.5,19.0 + bob), ink, 3.0)
	draw_line(Vector2(4.0,11.5 + bob), Vector2(9.0,19.8 + bob), ink, 3.0)
	var cloak: PackedVector2Array = PackedVector2Array([Vector2(-15.0,-8.8+bob),Vector2(14.5,-10.0+bob),Vector2(15.5,1.0+bob),Vector2(12.5,14.0+bob),Vector2(4.8,22.2+bob),Vector2(-1.8,19.0+bob),Vector2(-9.6,23.0+bob),Vector2(-15.6,13.0+bob),Vector2(-17.0,1.0+bob)])
	draw_colored_polygon(cloak, Color(0.04,0.04,0.04,0.28 + recover_ratio * 0.06))
	var torso: PackedVector2Array = PackedVector2Array([Vector2(-12.0,-10.4+bob),Vector2(13.0,-10.8+bob),Vector2(10.6,4.0+bob),Vector2(2.8,10.0+bob),Vector2(-10.0,6.0+bob)])
	draw_colored_polygon(torso, cloth_mid)
	var hakama: PackedVector2Array = PackedVector2Array([Vector2(-13.2,2.4+bob),Vector2(-5.8,-0.5+bob),Vector2(0.0,17.0+bob),Vector2(5.8,-0.5+bob),Vector2(13.4,2.5+bob),Vector2(11.0,17.6+bob),Vector2(4.8,15.4+bob),Vector2(0.0,21.6+bob),Vector2(-4.8,15.4+bob),Vector2(-11.0,17.6+bob)])
	draw_colored_polygon(hakama, cloth_dark)
	var sash: PackedVector2Array = PackedVector2Array([Vector2(-10.4,4.2+bob),Vector2(10.4,4.2+bob),Vector2(8.8,8.0+bob),Vector2(-8.8,8.0+bob)])
	draw_colored_polygon(sash, crimson)
	_draw_diamond(Vector2(0.0,6.0+bob), 1.6, gold)
	_draw_oval(head_center, Vector2(10.2,10.4), ink)
	draw_line(head_center + Vector2(-10.0,-1.2), head_center + Vector2(10.0,-1.2), paper, 1.45)
	draw_circle(head_center + Vector2(8.8,-1.1), 1.1, cloth_dark)
	draw_line(head_center + Vector2(8.0,-2.0), head_center + Vector2(18.0, -8.0), Color(0.08,0.08,0.08,0.90), 1.35)
	draw_line(head_center + Vector2(8.2,-0.8), head_center + Vector2(19.0, 1.0), Color(crimson.r, crimson.g, crimson.b,0.48), 1.0)
	_draw_eyes(head_center, paper)
	var rear_hand: Vector2 = Vector2(-7.2, 0.8 + bob)
	var front_hand: Vector2 = Vector2(4.6, -3.2 + bob)
	draw_line(Vector2(-6.0,-1.6+bob), rear_hand, ink, 2.7)
	draw_line(Vector2(5.0,-2.8+bob), front_hand, ink, 2.7)
	_draw_oval(rear_hand, Vector2(2.8,2.0), ink)
	_draw_oval(front_hand, Vector2(2.8,2.0), ink)
	var sword_start: Vector2 = front_hand + dir * 1.0
	var sword_tip: Vector2 = sword_start + dir * 24.0 + side * 3.0
	draw_line(sword_start - dir * 2.6, sword_start + dir * 2.6, gold, 1.0)
	draw_line(sword_start, sword_tip, Color(0.08,0.08,0.08,0.98), 2.0)
	draw_line(sword_start + side * 0.5, sword_tip + side * 0.5, Color(1.0,1.0,1.0,0.30), 0.9)
	# lingering finishing gleam
	draw_arc(sword_tip - dir * 2.0, 12.0 + recover_ratio * 4.0, dir.angle() - 0.6, dir.angle() + 0.2, 18, Color(accent.r, accent.g, accent.b,0.10 + recover_ratio * 0.08), 1.8)
	draw_arc(Vector2.ZERO, 28.0 + recover_ratio * 6.0, dir.angle() - 0.22, dir.angle() + 0.32, 18, Color(0.05,0.05,0.05,0.10 + recover_ratio * 0.08), 1.0)

func _draw_samurai_slash_fx(bob: float) -> void:
	var accent: Color = Color(0.96, 0.84, 0.88, 0.62)
	var accent_soft: Color = Color(1.0, 0.93, 0.95, 0.40)
	var stun_ratio: float = clampf(samurai_post_dash_stun / 0.4, 0.0, 1.0)
	var slash_alpha: float = samurai_slash_flash * 0.42 + stun_ratio * 0.12
	var dash_ratio: float = clampf(dash_left / maxf(0.001, current_dash_duration), 0.0, 1.0) if dash_active else 0.0
	var dash_alpha: float = maxf(samurai_dash_flash * 0.46, dash_ratio * 0.62) + stun_ratio * 0.09
	if slash_alpha <= 0.01 and dash_alpha <= 0.01:
		return
	var dir: Vector2 = (dash_direction if dash_active else aim_direction).normalized()
	if dir.length_squared() < 0.001:
		dir = Vector2.RIGHT
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var angle: float = dir.angle()
	var center := Vector2(0, bob * 0.2)
	if dash_alpha > 0.01:
		var cut_center: Vector2 = center + dir * 31.0 + side * 3.0
		for i in range(6):
			var trail_origin: Vector2 = center - dir * (12.0 + float(i) * 10.0) - side * (2.0 + float(i) * 0.9)
			var trail_tip: Vector2 = trail_origin + dir * (24.0 + float(i) * 3.2) + side * (8.0 + float(i) * 0.9)
			draw_line(trail_origin, trail_tip, Color(0.06, 0.06, 0.06, dash_alpha * (0.76 - float(i) * 0.10)), 1.7)
			draw_line(trail_origin, trail_tip, Color(1.0, 0.95, 0.97, dash_alpha * (0.34 - float(i) * 0.045)), 2.5)
		# main cutting arcs and cross-cut accent arcs for a more premium read
		draw_arc(cut_center, 54.0, angle - 0.72, angle + 0.12, 28, Color(1.0, 0.97, 0.98, dash_alpha * 0.34), 6.4)
		draw_arc(cut_center, 54.0, angle - 0.72, angle + 0.12, 28, Color(0.05, 0.05, 0.05, dash_alpha * 0.84), 2.9)
		draw_arc(cut_center + side * 3.6, 46.0, angle - 0.56, angle + 0.20, 24, Color(accent.r, accent.g, accent.b, dash_alpha * 0.16), 2.4)
		draw_arc(cut_center - side * 4.0, 62.0, angle - 0.88, angle - 0.10, 24, Color(1.0, 1.0, 1.0, dash_alpha * 0.12), 1.5)
		draw_arc(cut_center + dir * 5.0, 38.0, angle - 0.22, angle + 0.48, 20, Color(accent.r, accent.g, accent.b, dash_alpha * 0.10), 1.3)
		draw_line(center - dir * 6.0, center + dir * 40.0 + side * 11.0, Color(1.0, 0.98, 0.99, dash_alpha * 0.30), 2.4)
		draw_line(center - dir * 8.0, center + dir * 29.0 + side * 4.0, Color(0.05, 0.05, 0.05, dash_alpha * 0.24), 1.0)
		for spark in range(7):
			var d: float = 10.0 + float(spark) * 8.5
			var origin: Vector2 = center + dir * d + side * (-10.0 + float(spark) * 3.6)
			var tip: Vector2 = origin + side * (4.2 if spark % 2 == 0 else -4.2) + dir * (7.5 + float(spark) * 0.8)
			draw_line(origin, tip, Color(0.08, 0.08, 0.08, dash_alpha * 0.42), 1.0)
			draw_line(origin, tip, Color(1.0, 0.92, 0.94, dash_alpha * 0.18), 0.8)
			_draw_diamond(tip, 1.15 + float(spark % 3) * 0.28, Color(1.0, 1.0, 1.0, dash_alpha * 0.16))
		# ring bursts so the dash slash really pops
		draw_arc(center + dir * 10.0, 18.0 + dash_alpha * 16.0, angle - 1.0, angle + 1.0, 26, Color(0.05, 0.05, 0.05, dash_alpha * 0.20), 1.3)
		draw_arc(center + dir * 10.0, 12.0 + dash_alpha * 10.0, angle - 0.76, angle + 0.76, 22, Color(accent.r, accent.g, accent.b, dash_alpha * 0.10), 1.1)
	if slash_alpha > 0.01:
		var start_angle: float = angle - samurai_arc * 0.56
		var end_angle: float = angle + samurai_arc * 0.56
		# layered slash crescents for the normal attack
		draw_arc(center, samurai_range * 0.62, start_angle - 0.03, end_angle + 0.03, 30, Color(1.0, 0.94, 0.95, slash_alpha * 0.18), 6.0)
		draw_arc(center, samurai_range * 0.74, start_angle, end_angle, 30, Color(0.05, 0.05, 0.05, slash_alpha), 3.4)
		draw_arc(center, samurai_range * 0.86, start_angle + 0.06, end_angle - 0.06, 28, Color(1.0, 1.0, 1.0, slash_alpha * 0.54), 1.4)
		draw_arc(center, samurai_range * 0.96, start_angle + 0.14, end_angle - 0.14, 24, Color(accent.r, accent.g, accent.b, slash_alpha * 0.14), 1.4)
		draw_arc(center + dir * 7.0, samurai_range * 0.78, start_angle + 0.28, end_angle - 0.36, 24, Color(accent_soft.r, accent_soft.g, accent_soft.b, slash_alpha * 0.08), 3.0)
		# central cut streak
		var streak_start: Vector2 = center + dir * 12.0
		var streak_mid: Vector2 = center + dir * (samurai_range * 0.48) + side * 8.0
		var streak_end: Vector2 = center + dir * (samurai_range * 0.80) + side * 20.0
		draw_polyline(PackedVector2Array([streak_start, streak_mid, streak_end]), Color(1.0, 0.98, 0.99, slash_alpha * 0.22), 2.0)
		draw_polyline(PackedVector2Array([streak_start, streak_mid, streak_end]), Color(0.05, 0.05, 0.05, slash_alpha * 0.22), 0.9)
		for i in range(8):
			var a: float = lerpf(start_angle, end_angle, float(i) / 7.0)
			var p: Vector2 = Vector2(cos(a), sin(a)) * samurai_range * (0.68 + float(i % 2) * 0.05)
			draw_line(p - dir * 9.0, p + dir * 8.0, Color(0.06, 0.06, 0.06, slash_alpha * 0.60), 1.0)
			draw_circle(p, 1.25, Color(1.0, 1.0, 1.0, slash_alpha * 0.24))
			if i < 7:
				_draw_diamond(p + side * 2.6, 1.15, Color(1.0, 0.98, 0.98, slash_alpha * 0.14))
		# small floating blade petals / shards to sell impact
		for shard in range(6):
			var shard_t: float = float(shard) / 5.0
			var shard_angle: float = lerpf(start_angle + 0.08, end_angle - 0.08, shard_t)
			var shard_pos: Vector2 = Vector2(cos(shard_angle), sin(shard_angle)) * samurai_range * 0.92 + dir * 6.0
			var shard_dir: Vector2 = Vector2(cos(shard_angle + 0.42), sin(shard_angle + 0.42))
			draw_line(shard_pos - shard_dir * 4.0, shard_pos + shard_dir * 4.5, Color(0.05, 0.05, 0.05, slash_alpha * 0.34), 1.0)
			draw_line(shard_pos - shard_dir * 3.0, shard_pos + shard_dir * 3.5, Color(accent.r, accent.g, accent.b, slash_alpha * 0.12), 1.3)

func _draw_legs(bob: float, step: float, ink: Color) -> void:



	var left_step: float = step
	var right_step: float = -step
	var left_lift: float = maxf(0.0,sin(walk_phase))*3.2 if moving else 0.0
	var right_lift: float = maxf(0.0,-sin(walk_phase))*3.2 if moving else 0.0
	var left_foot_y: float = 20.0-left_lift
	var right_foot_y: float = 20.0-right_lift
	draw_line(Vector2(-6,13+bob),Vector2(-7+left_step*0.55,left_foot_y),ink,3.0)
	draw_line(Vector2(6,13+bob),Vector2(7+right_step*0.55,right_foot_y),ink,3.0)
	draw_line(Vector2(-11+left_step*0.55,left_foot_y),Vector2(-3+left_step*0.55,left_foot_y),ink,2.3)
	draw_line(Vector2(3+right_step*0.55,right_foot_y),Vector2(11+right_step*0.55,right_foot_y),ink,2.3)

func _draw_arms(bob: float, ink: Color, spread: float) -> void:
	var arm_swing: float = sin(walk_phase)*1.8 if moving else 0.0
	var left_hand: Vector2 = Vector2(-14-spread,7+bob+arm_swing)
	var right_hand: Vector2 = Vector2(14+spread,7+bob-arm_swing)
	draw_line(Vector2(-9,-1+bob),left_hand,ink,3.0)
	draw_line(Vector2(9,-1+bob),right_hand,ink,3.0)
	_draw_oval(left_hand+Vector2(0,1),Vector2(3.2,2.3),ink)
	_draw_oval(right_hand+Vector2(0,1),Vector2(3.2,2.3),ink)

func _draw_eyes(center: Vector2, paper: Color) -> void:
	var base_dir: Vector2 = visual_aim_direction if visual_aim_direction.length_squared() > 0.001 else aim_direction
	if base_dir.length_squared() > 0.001:
		base_dir = base_dir.normalized()
	var look: Vector2 = base_dir * 1.6
	draw_circle(center + Vector2(-4, 0) + look, 2.3, paper)
	draw_circle(center + Vector2(4, 0) + look, 2.3, paper)
	draw_circle(center + Vector2(-4, 0) + look + base_dir * 0.45, 0.65, Color("#111111"))
	draw_circle(center + Vector2(4, 0) + look + base_dir * 0.45, 0.65, Color("#111111"))

func _draw_flux_aura() -> void:
	var phase: float = magic_orbit_t * 2.8
	for i in range(5):
		var radius: float = 30.0 + float(i) * 10.0 + sin(phase * 1.3 + float(i)) * 4.0
		var alpha: float = 0.28 - float(i) * 0.035
		draw_arc(Vector2(0, -4), radius, phase + float(i) * 0.86, phase + float(i) * 0.86 + PI * 1.36, 34, Color(0.06, 0.06, 0.06, alpha), 1.6 if i < 2 else 1.0)
		draw_arc(Vector2(0, -4), radius + 3.0, phase + float(i) * 0.62, phase + float(i) * 0.62 + PI * 0.74, 24, Color(0.82, 0.92, 1.0, alpha * 0.18), 1.0)
	for i in range(14):
		var a: float = -phase * 1.6 + float(i) * TAU / 14.0
		var rr: float = 42.0 + float(i % 4) * 6.0 + sin(phase * 2.4 + float(i)) * 3.0
		var p: Vector2 = Vector2(cos(a) * rr, sin(a) * rr * 0.68 - 4.0)
		_draw_diamond(p, 2.0 + sin(phase * 3.4 + float(i)) * 0.65, Color(0.05, 0.05, 0.05, 0.34))
	for i in range(4):
		var a2: float = phase * 0.7 + float(i) * TAU / 4.0
		var p1: Vector2 = Vector2(cos(a2) * 24.0, sin(a2) * 18.0 - 4.0)
		var p2: Vector2 = Vector2(cos(a2 + 0.25) * 58.0, sin(a2 + 0.25) * 38.0 - 4.0)
		var mid: Vector2 = (p1 + p2) * 0.5 + Vector2(sin(phase * 4.0 + float(i)) * 5.0, cos(phase * 3.0 + float(i)) * 4.0)
		draw_polyline(PackedVector2Array([p1, mid, p2]), Color(0.04, 0.04, 0.04, 0.24), 1.2)
	var linked: int = 0
	for enemy in _enemy_candidates(270.0):
		if linked >= 5 or not is_instance_valid(enemy):
			continue
		var local: Vector2 = enemy.global_position - global_position
		if local.length() < 250.0:
			draw_line(Vector2.ZERO, local, Color(0.05, 0.05, 0.05, 0.035 + 0.025 * absf(sin(phase + float(linked)))), 1.0)
			linked += 1

func _draw_magic_stones(bob: float) -> void:
	var paper: Color = Color("#fffdf7")
	var accent: Color = Color(0.84, 0.93, 1.0, 0.62)
	var core_center: Vector2 = Vector2(0.0, -5.0 + bob * 0.20)
	var ready_points: Array[Vector2] = []
	var dash_blend: float = orbit_dash_pose_blend
	var dash_dir: Vector2 = dash_direction if dash_direction.length_squared() > 0.001 else aim_direction
	if dash_dir.length_squared() < 0.001:
		dash_dir = Vector2.RIGHT
	dash_dir = dash_dir.normalized()
	var dash_side: Vector2 = Vector2(-dash_dir.y, dash_dir.x)
	for slot in range(max_magic_stones):
		var progress: float = float(slot) / float(maxi(1, max_magic_stones))
		var present: bool = true if flux_active else (slot >= magic_shot_index and slot < magic_shot_index + magic_stones)
		var ghost_only: bool = false
		if magic_reloading and not flux_active:
			var reload_ratio: float = get_magic_reload_ratio()
			present = float(slot + 1) / float(max_magic_stones) <= reload_ratio + 0.02
			ghost_only = not present and progress <= minf(1.0, reload_ratio + 0.20)
		var p: Vector2 = _stone_local_position(slot) + Vector2(0.0, bob * 0.22)
		if dash_blend > 0.01:
			var row: float = floor(float(slot) / 2.0)
			var lane: float = -1.0 if slot % 2 == 0 else 1.0
			var dash_pos: Vector2 = Vector2(0.0, -3.0 + bob * 0.15) - dash_dir * (10.0 + row * 11.0 + float(slot) * 3.2) + dash_side * lane * (6.0 + row * 1.5)
			dash_pos += dash_dir * sin(magic_orbit_t * 8.0 + float(slot)) * 1.2
			p = p.lerp(dash_pos, dash_blend * 0.92)
		var orbit_dir: Vector2 = (p - core_center).normalized() if p.distance_squared_to(core_center) > 0.001 else Vector2.UP
		var tangent: Vector2 = Vector2(-orbit_dir.y, orbit_dir.x)
		var orbit_alpha: float = 0.045 + (0.025 if present else 0.0) + (0.012 if flux_active else 0.0)
		draw_arc(core_center, p.distance_to(core_center), _stone_angle(slot) - 0.26, _stone_angle(slot) + 0.26, 12, Color(0.08, 0.08, 0.08, orbit_alpha * (1.0 - dash_blend * 0.75)), 1.0)
		if not present and not ghost_only:
			continue
		if present:
			ready_points.append(p)
		for trail_i in range(2, -1, -1):
			var trail_offset: float = float(trail_i + 1) * (5.2 + dash_blend * 2.0)
			var trail_alpha: float = (0.16 - float(trail_i) * 0.04) * (0.80 if present else 0.40)
			var trail_pos: Vector2 = p - tangent * trail_offset - dash_dir * dash_blend * float(trail_i + 1) * 3.0
			draw_circle(trail_pos, 6.8 - float(trail_i) * 1.0, Color(accent.r, accent.g, accent.b, trail_alpha * (0.26 + dash_blend * 0.12)))
		var pulse: float = 5.4 + sin(magic_orbit_t * 5.0 + float(slot) * 0.82) * 0.9 + dash_blend * 0.35
		var crystal_alpha: float = 1.0 if present else 0.34
		draw_circle(p, 10.5 + cast_flash * 1.2 + dash_blend * 1.4, Color(accent.r, accent.g, accent.b, (0.12 if present else 0.05) + cast_flash * 0.05 + dash_blend * 0.04))
		draw_circle(p, 7.2 + dash_blend * 0.45, Color(1, 1, 1, 0.06 if present else 0.02))
		_draw_diamond(p, pulse, Color(paper.r, paper.g, paper.b, 0.98 * crystal_alpha))
		draw_polyline(PackedVector2Array([
			p + Vector2(0.0, -pulse), p + Vector2(pulse * 0.74, 0.0), p + Vector2(0.0, pulse), p + Vector2(-pulse * 0.74, 0.0), p + Vector2(0.0, -pulse)
		]), Color(0.08, 0.08, 0.08, 0.46 * crystal_alpha), 1.0)
		draw_line(p + Vector2(-pulse * 0.18, -pulse * 0.58), p + Vector2(pulse * 0.25, pulse * 0.54), Color(0.08, 0.08, 0.08, 0.24 * crystal_alpha), 1.0)
		draw_line(core_center + orbit_dir * 16.0, p - orbit_dir * 8.0, Color(0.08, 0.08, 0.08, 0.10 * crystal_alpha), 1.0)
	if ready_points.size() >= 2:
		for i in range(ready_points.size()):
			var a: Vector2 = ready_points[i]
			var b: Vector2 = ready_points[(i + 1) % ready_points.size()]
			if a.distance_to(b) <= 52.0 or dash_blend > 0.30:
				draw_line(a, b, Color(0.08, 0.08, 0.08, 0.05 + dash_blend * 0.04), 1.0)
	if magic_reloading:
		var ratio: float = get_magic_reload_ratio()
		var radius: float = lerpf(76.0, 50.0, ratio)
		draw_arc(Vector2(0, -4 + bob * 0.2), radius, -PI * 0.5, -PI * 0.5 + TAU * ratio, 32, Color(0.08, 0.08, 0.08, 0.24), 1.5)
		for i in range(5):
			var a: float = magic_orbit_t * 2.0 + float(i) * TAU / 5.0
			var rp: Vector2 = Vector2(cos(a), sin(a) * 0.8) * lerpf(42.0, 24.0, ratio) + Vector2(0, -4)
			draw_circle(rp, 1.5, Color(0.08, 0.08, 0.08, 0.14))

func _draw_storm_magic(bob: float) -> void:
	var ink: Color = Color("#111111")
	var dash_bonus: float = (0.14 if dash_active else 0.0) + storm_dash_flash * 0.06 + storm_dash_morph * 0.08
	for i in range(5):
		var a: float = magic_orbit_t * 1.85 + float(i) * TAU / 5.0
		var p: Vector2 = Vector2(cos(a) * 24.0, sin(a) * 17.0 - 4.0 + bob * 0.2)
		var p2: Vector2 = p + Vector2(sin(a * 2.2) * 5.0, -6.5 + cos(a) * 4.2)
		draw_circle(p, 8.0 + dash_bonus * 18.0, Color(0.82, 0.92, 1.0, 0.03 + dash_bonus * 0.20))
		draw_line(p, p2, Color(0.82, 0.92, 1.0, 0.18 + dash_bonus * 0.34), 3.1 + dash_bonus * 2.0)
		draw_line(p, p2, Color(0.08, 0.08, 0.08, 0.24 + dash_bonus * 0.10), 1.15)
		draw_circle(p2, 1.6 + dash_bonus * 0.8, ink)
		if i < 4:
			var chain_next: float = magic_orbit_t * 1.85 + float(i + 1) * TAU / 5.0
			var p_next: Vector2 = Vector2(cos(chain_next) * 24.0, sin(chain_next) * 17.0 - 4.0 + bob * 0.2)
			draw_line(p, p_next, Color(0.08, 0.08, 0.08, 0.08), 1.0)

func _draw_rift_magic(bob: float) -> void:
	var ink: Color = Color("#111111")
	var paper: Color = Color("#fffdf7")
	for i in range(rift_max_charges):
		var side: float = -1.0 if i == 0 else 1.0
		var c: Vector2 = Vector2(side * 25.0, -5.0 + bob * 0.2)
		var available: bool = i < rift_charges and not rift_reloading
		var alpha: float = 0.36 if available else 0.08
		draw_arc(c, 8.0 + sin(magic_orbit_t * 3.0 + float(i)) * 1.0, -1.2, 1.2, 14, Color(0.80, 0.92, 1.0, alpha * 0.30), 3.0)
		draw_arc(c, 8.0 + sin(magic_orbit_t * 3.0 + float(i)) * 1.0, -1.2, 1.2, 14, Color(0.08, 0.08, 0.08, alpha), 1.4)
		if available:
			draw_circle(c + Vector2(side * 2.0, 0), 1.7, ink)
			draw_circle(c, 11.0, Color(0.08, 0.08, 0.08, 0.035))
	if rift_reloading:
		var ratio: float = get_rift_reload_ratio()
		var center: Vector2 = Vector2(0, -5 + bob * 0.2)
		draw_arc(center, 34.0, -PI * 0.5, -PI * 0.5 + TAU * ratio, 28, Color(0.08, 0.08, 0.08, 0.28), 1.7)
		for i in range(5):
			var a: float = magic_orbit_t * 2.6 + float(i) * TAU / 5.0
			var p: Vector2 = center + Vector2(cos(a) * lerpf(38.0, 20.0, ratio), sin(a) * lerpf(24.0, 13.0, ratio))
			draw_circle(p, 1.5, paper)
			draw_arc(p, 2.8, 0.0, TAU, 10, Color(0.08, 0.08, 0.08, 0.25), 1.0)


func _sketch_line(a: Vector2, b: Vector2, color: Color, width: float, passes: int, seed_value: int) -> void:
	for i in range(passes):
		var off_a: Vector2 = Vector2(sketch_jitter(seed_value + i * 2, 1.0), sketch_jitter(seed_value + i * 2 + 1, 1.0))
		var off_b: Vector2 = Vector2(sketch_jitter(seed_value + 20 + i * 2, 1.0), sketch_jitter(seed_value + 21 + i * 2, 1.0))
		draw_line(a + off_a, b + off_b, color, width)

func _draw_oval(center: Vector2, radii: Vector2, color: Color) -> void:
	var points: PackedVector2Array = PackedVector2Array()
	for i in range(24):
		var a: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(points, color)

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([
		center + Vector2(0, -radius),
		center + Vector2(radius * 0.75, 0),
		center + Vector2(0, radius),
		center + Vector2(-radius * 0.75, 0)
	])
	draw_colored_polygon(poly, color)
