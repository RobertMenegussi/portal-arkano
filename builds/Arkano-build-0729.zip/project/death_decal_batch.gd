extends Node2D

const ChunkScript = preload("res://death_decal_chunk.gd")
const MAX_CHUNKS: int = 4
var chunks: Array = []
var prune_timer: float = 1.5

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	z_index = 10
	add_to_group("death_decal_batch")
	add_to_group("run_decal")
	_ensure_chunk()

func _process(delta: float) -> void:
	prune_timer -= delta
	if prune_timer > 0.0:
		return
	prune_timer = 1.5
	for i in range(chunks.size()-1,-1,-1):
		if not is_instance_valid(chunks[i]):
			chunks.remove_at(i)

func _ensure_chunk():
	if not chunks.is_empty():
		var last = chunks[chunks.size()-1]
		if is_instance_valid(last) and not last.is_full():
			return last
	while chunks.size() >= MAX_CHUNKS:
		var oldest = chunks.pop_front()
		if is_instance_valid(oldest):
			oldest.queue_free()
	var chunk = ChunkScript.new()
	chunk.z_index = 0
	add_child(chunk)
	chunks.append(chunk)
	return chunk

func add_slime(world_pos: Vector2) -> void:
	_ensure_chunk().add_slime(world_pos)

func add_skeleton(world_pos: Vector2,pieces: Array) -> void:
	_ensure_chunk().add_skeleton(world_pos,pieces)

func trim_for_pause() -> void:
	# Frozen build/pause screens still render the world underneath. Keep only the
	# newest corpse chunk so old remains cannot make a long run expensive to display.
	for i in range(chunks.size()-2,-1,-1):
		var old_chunk = chunks[i]
		chunks.remove_at(i)
		if is_instance_valid(old_chunk):
			old_chunk.queue_free()
