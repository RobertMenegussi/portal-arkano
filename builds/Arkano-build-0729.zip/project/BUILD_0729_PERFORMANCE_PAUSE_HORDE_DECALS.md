ARKANO 0.5.1 PRE-ALPHA BUILD 0729 — PERFORMANCE / PAUSE / HORDE PASS

Primary fixes
- TAB/ESC pause no longer keeps rebuilding enemy spatial data in the background.
- TAB build screen is now event-driven instead of redrawing itself 24 times per second while frozen.
- HUD/XP/threat/boss overlay redraw work stops while the SceneTree is paused.
- Debug telemetry uses a cheap paused sample path instead of scanning projectile groups while paused.

High-horde optimization
- Added Horde Performance Tier 3 at 180+ registered enemies.
- True enemy render LOD now replaces distant idle enemies with lightweight silhouettes under Tier 2/3; close enemies and active attacks retain full art.
- Distant enemies switch to cheap direct steering sooner under heavy load, reducing CharacterBody collision cost.
- AI decision cadence, redraw cadence and crowd separation budgets scale harder at 140+/180+ enemies.
- Tier 3 caps cosmetic hit/death feedback more aggressively while keeping gameplay unchanged.
- Skeleton projectile cap scales down under Tier 2/3.
- Necromancer minion global cap now scales with horde tier so summons cannot secretly push the real actor count far above the visible enemy target.
- Auto-target scanning now respects its timer even when no target is found; previously it could rescan the whole horde every frame.
- Samurai reuses the existing auto-target for visual facing instead of doing a second full nearest-enemy scan.
- Enemy ceiling is clamped to 202, preserving the ~200-enemy target without director pressure pushing it above 210.

XP load
- Added XP performance Tier 3.
- At 180+ enemies, loose XP soft cap drops to 72; excess XP merges into an existing orb without losing XP value.
- Tier 3 XP proximity checks and decorative redraws run less often, while movement/suction remain per-frame.

Corpse / map remains
- Death decals now live about 8–12 seconds and fade during the final 2 seconds.
- Corpse decals are capped to 4 chunks × 24 decals (96 maximum retained remains).
- Oldest decal chunks are discarded when the cap is reached.
- Entering TAB/ESC keeps only the newest decal chunk and hides corpse decals while paused, reducing frozen-scene render load.

Build
- Endless build: 0729
- Legacy/main build number: 0235
