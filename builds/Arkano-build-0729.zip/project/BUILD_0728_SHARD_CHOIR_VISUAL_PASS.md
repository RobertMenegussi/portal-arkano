ARKANO 0.5.1 PRE-ALPHA BUILD 0728 — SHARD CHOIR VISUAL PASS

What changed
- Reworked the rune "Coro de Estilhaços" / "Shard Choir" to have a much stronger bespoke VFX.
- Added a dedicated effect path for rune id style_all_15 instead of using the generic line pattern only.
- The proc now renders a layered "choir" of parallel shard lanes, animated crystal shards, impact fans, front-end burst accents and scratch arcs.
- Extended the effect duration slightly so the visual reads better during gameplay.

Technical notes
- rune_runtime.gd now passes rune_id and count_value into rune_effect.gd.
- rune_effect.gd now supports a special-case renderer for style_all_15.
- Build number updated from 0727 to 0728.
