extends Node2D

const MAX_DECALS: int = 24
const DECAL_MIN_LIFETIME: float = 8.0
const DECAL_MAX_LIFETIME: float = 12.0
const CLEANUP_INTERVAL: float = 0.50

var decals: Array = []
var cleanup_timer: float = CLEANUP_INTERVAL

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE

func is_full() -> bool:
	return decals.size() >= MAX_DECALS

func is_empty() -> bool:
	return decals.is_empty()

func add_slime(world_pos: Vector2) -> void:
	decals.append({
		"kind":"slime",
		"pos":to_local(world_pos),
		"age":0.0,
		"ttl":randf_range(DECAL_MIN_LIFETIME,DECAL_MAX_LIFETIME)
	})
	queue_redraw()

func add_skeleton(world_pos: Vector2,pieces: Array) -> void:
	var origin: Vector2 = to_local(world_pos)
	var stored: Array = []
	for piece_value in pieces:
		var piece: Dictionary = piece_value
		var piece_pos: Vector2 = piece.get("pos",Vector2.ZERO)
		stored.append({
			"kind":str(piece.get("kind","bone")),
			"pos":origin+piece_pos,
			"rot":float(piece.get("rot",0.0))
		})
	decals.append({
		"kind":"skeleton",
		"pieces":stored,
		"age":0.0,
		"ttl":randf_range(DECAL_MIN_LIFETIME,DECAL_MAX_LIFETIME)
	})
	queue_redraw()

func _process(delta: float) -> void:
	cleanup_timer -= delta
	if cleanup_timer > 0.0:
		return
	cleanup_timer = CLEANUP_INTERVAL
	var removed: bool = false
	var fading: bool = false
	for i in range(decals.size()-1,-1,-1):
		var decal: Dictionary = decals[i]
		var age: float = float(decal.get("age",0.0)) + CLEANUP_INTERVAL
		decal["age"] = age
		decals[i] = decal
		var ttl: float = float(decal.get("ttl",10.0))
		if age >= ttl:
			decals.remove_at(i)
			removed = true
		elif age >= ttl-2.0:
			fading = true
	if removed or fading:
		queue_redraw()

func _draw() -> void:
	for decal_value in decals:
		var decal: Dictionary = decal_value
		var ttl: float = maxf(0.1,float(decal.get("ttl",10.0)))
		var age: float = float(decal.get("age",0.0))
		var fade_start: float = ttl-2.0
		var alpha_mul: float = 1.0
		if age > fade_start:
			alpha_mul = clampf((ttl-age)/2.0,0.0,1.0)
		if str(decal.get("kind","")) == "slime":
			var slime_pos: Vector2 = decal.get("pos",Vector2.ZERO)
			_draw_slime(slime_pos,alpha_mul)
		else:
			var piece_list: Array = decal.get("pieces",[])
			_draw_skeleton(piece_list,alpha_mul)

func _draw_slime(center: Vector2,alpha_mul: float) -> void:
	var points := PackedVector2Array()
	for i in range(18):
		var a: float = TAU*float(i)/18.0
		points.append(center+Vector2(cos(a)*30.0,sin(a)*2.8)+Vector2(0,14.0))
	draw_colored_polygon(points,Color(0.05,0.05,0.05,0.26*alpha_mul))

func _draw_skeleton(pieces: Array,alpha_mul: float) -> void:
	for piece_value in pieces:
		var piece: Dictionary = piece_value
		var pos: Vector2 = piece.get("pos",Vector2.ZERO)
		var rot: float = float(piece.get("rot",0.0))
		if str(piece.get("kind","bone")) == "skull":
			draw_circle(pos,7.0,Color(0.965,0.945,0.89,0.88*alpha_mul))
			draw_arc(pos,7.0,0.0,TAU,14,Color(0.09,0.09,0.09,0.90*alpha_mul),1.2)
			draw_circle(pos+Vector2(-2.6,-0.8).rotated(rot),1.4,Color(0.09,0.09,0.09,0.86*alpha_mul))
			draw_circle(pos+Vector2(2.6,-0.8).rotated(rot),1.4,Color(0.09,0.09,0.09,0.86*alpha_mul))
		else:
			var dir := Vector2(8.0,0).rotated(rot)
			draw_line(pos-dir,pos+dir,Color(0.09,0.09,0.09,0.72*alpha_mul),2.1)
