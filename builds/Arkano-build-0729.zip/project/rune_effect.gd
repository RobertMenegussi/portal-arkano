extends Node2D

var rune_id: String = ""
var pattern: String = "nova"
var radius: float = 120.0
var direction: Vector2 = Vector2.RIGHT
var points: Array = []
var accent: int = 0
var count_value: int = 1
var t: float = 0.0
var duration: float = 0.62
var visual_timer: float = 0.0

func configure(new_rune_id: String,effect_pattern: String,origin: Vector2,radius_value: float,dir: Vector2,target_points: Array,accent_index: int = 0,new_count_value: int = 1) -> void:
	rune_id = new_rune_id
	pattern = effect_pattern
	global_position = origin
	radius = radius_value
	direction = dir.normalized() if dir.length_squared() > 0.001 else Vector2.RIGHT
	points = target_points.duplicate()
	accent = accent_index
	count_value = maxi(1,new_count_value)
	if rune_id == "style_all_15":
		duration = 0.82

func _ready() -> void:
	z_index = 40
	process_mode = Node.PROCESS_MODE_PAUSABLE
	add_to_group("run_vfx")

func _process(delta: float) -> void:
	t += delta
	if t >= duration:
		queue_free()
		return
	visual_timer -= delta
	if visual_timer <= 0.0:
		visual_timer = 1.0/30.0
		queue_redraw()

func _palette() -> Color:
	match accent % 4:
		1: return Color("#ffca74")
		2: return Color("#64d8ff")
		3: return Color("#ff7ea6")
		_: return Color("#f6f1df")

func _glow() -> Color:
	var c: Color = _palette()
	return Color(minf(1.0,c.r+0.10),minf(1.0,c.g+0.10),minf(1.0,c.b+0.10),1.0)

func _ink(alpha: float) -> Color:
	return Color(0.03,0.03,0.04,alpha)

func _draw() -> void:
	var p: float = clampf(t/duration,0.0,1.0)
	var fade: float = 1.0-p
	var c: Color = _palette()
	var glow: Color = _glow()
	c.a = 0.60*fade
	glow.a = 0.28*fade
	var ink: Color = _ink(0.34*fade)
	_draw_activation_sigil(p,fade,c,ink)
	if rune_id == "style_all_15":
		_draw_shard_choir(p,fade,c,glow,ink)
		return
	match pattern:
		"nova":
			var rr: float = radius*(0.16+0.84*p)
			draw_circle(Vector2.ZERO,rr*0.78,Color(c.r,c.g,c.b,0.03*fade))
			draw_arc(Vector2.ZERO,rr,0.0,TAU,56,glow,5.0)
			draw_arc(Vector2.ZERO,rr,0.0,TAU,56,c,2.4)
			draw_arc(Vector2.ZERO,rr*0.80,0.0,TAU,48,ink,1.2)
			_draw_scratch_ring(rr*0.62,8,fade,c,ink)
			for i in range(12):
				var a: float = TAU*float(i)/12.0+t*0.9
				var q0: Vector2 = Vector2(cos(a),sin(a))*rr*0.58
				var q1: Vector2 = Vector2(cos(a),sin(a))*rr*1.04
				draw_line(q0,q1,Color(c.r,c.g,c.b,0.34*fade),1.2)
				_draw_diamond(q1,2.4+2.8*fade,Color(glow.r,glow.g,glow.b,0.54*fade))
		"bolt":
			for point_value in points:
				var point: Vector2 = point_value
				_draw_lightning(Vector2.ZERO,point,c,ink,p)
				draw_circle(point,7.0+12.0*fade,Color(c.r,c.g,c.b,0.10*fade))
				_draw_starburst(point,10.0+16.0*fade,6,Color(c.r,c.g,c.b,0.28*fade))
		"rain":
			for point_value in points:
				var point: Vector2 = point_value
				draw_line(point+Vector2(0,-58)*(1.0-p),point,Color(glow.r,glow.g,glow.b,0.56*fade),2.6)
				draw_line(point+Vector2(-5,-36)*(1.0-p),point+Vector2(5,-4),ink,1.0)
				draw_circle(point,10.0+20.0*p,Color(c.r,c.g,c.b,0.10*fade))
				draw_arc(point,12.0+18.0*p,0.0,TAU,24,c,1.6)
				_draw_starburst(point,9.0+12.0*p,7,Color(c.r,c.g,c.b,0.22*fade))
		"cone":
			var angle: float = direction.angle()
			var outer: float = radius*(0.56+0.32*p)
			var inner: float = outer*0.64
			var poly := PackedVector2Array([Vector2.ZERO,Vector2(cos(angle-0.74),sin(angle-0.74))*outer,Vector2(cos(angle),sin(angle))*radius*(0.84+0.12*p),Vector2(cos(angle+0.74),sin(angle+0.74))*outer])
			draw_colored_polygon(poly,Color(c.r,c.g,c.b,0.05*fade))
			draw_arc(Vector2.ZERO,outer,angle-0.74,angle+0.74,32,glow,4.6)
			draw_arc(Vector2.ZERO,outer,angle-0.74,angle+0.74,32,c,2.2)
			draw_arc(Vector2.ZERO,inner,angle-0.56,angle+0.56,28,ink,1.1)
			_draw_starburst(direction*outer*0.72,10.0+8.0*fade,6,Color(c.r,c.g,c.b,0.26*fade))
		"line":
			var end: Vector2 = direction*radius
			_draw_lightning(Vector2.ZERO,end,c,ink,p)
			draw_arc(end,12.0+10.0*fade,0.0,TAU,20,Color(c.r,c.g,c.b,0.42*fade),1.8)
			_draw_starburst(end,11.0+8.0*fade,8,Color(c.r,c.g,c.b,0.24*fade))
		"orbit":
			var rr2: float = radius*0.72
			draw_circle(Vector2.ZERO,rr2*0.88,Color(c.r,c.g,c.b,0.03*fade))
			draw_arc(Vector2.ZERO,rr2,0.0,TAU,56,glow,4.2)
			draw_arc(Vector2.ZERO,rr2,0.0,TAU,56,Color(c.r,c.g,c.b,0.32*fade),2.0)
			draw_arc(Vector2.ZERO,rr2*0.70,0.0,TAU,44,ink,1.0)
			for i in range(8):
				var a2: float = t*7.8+TAU*float(i)/8.0
				var q: Vector2 = Vector2(cos(a2)*rr2,sin(a2)*rr2*0.72)
				_draw_diamond(q,4.4+2.2*fade,Color(glow.r,glow.g,glow.b,0.74*fade))
				if i % 2 == 0:
					draw_line(q,q.normalized()*rr2*0.36,Color(c.r,c.g,c.b,0.24*fade),0.9)
		"burst":
			for i in range(14):
				var a3: float = TAU*float(i)/14.0+0.18+t*0.2
				var a0: Vector2 = Vector2(cos(a3),sin(a3))*radius*0.10
				var a1: Vector2 = Vector2(cos(a3),sin(a3))*radius*(0.32+0.74*p)
				draw_line(a0,a1,Color(glow.r,glow.g,glow.b,0.52*fade),2.3)
				draw_line(a0,a1,ink,0.9)
				_draw_diamond(a1,2.0+1.8*fade,Color(c.r,c.g,c.b,0.38*fade))
		"aura":
			var rr3: float = radius*(0.88+sin(t*20.0)*0.05)
			draw_circle(Vector2.ZERO,rr3,Color(c.r,c.g,c.b,0.045*fade))
			draw_circle(Vector2.ZERO,rr3*0.78,Color(c.r,c.g,c.b,0.018*fade))
			draw_arc(Vector2.ZERO,rr3,0.0,TAU,48,glow,4.2)
			draw_arc(Vector2.ZERO,rr3,0.0,TAU,48,c,1.8)
			for i in range(6):
				var a4: float = t*2.2+TAU*float(i)/6.0
				var pt: Vector2 = Vector2(cos(a4),sin(a4))*rr3
				draw_circle(pt,2.6+1.0*fade,Color(glow.r,glow.g,glow.b,0.90*fade))
				if i % 2 == 0:
					_draw_diamond(pt,2.4+1.0*fade,Color(c.r,c.g,c.b,0.40*fade))
		"mark":
			for point_value in points:
				var point: Vector2 = point_value
				draw_arc(point,18.0+12.0*p,0.0,TAU,28,glow,4.0)
				draw_arc(point,18.0+12.0*p,0.0,TAU,28,c,2.0)
				draw_line(point+Vector2(-14,0),point+Vector2(14,0),ink,1.2)
				draw_line(point+Vector2(0,-14),point+Vector2(0,14),ink,1.2)
				_draw_starburst(point,12.0+8.0*fade,4,Color(c.r,c.g,c.b,0.24*fade))
		"spiral":
			for i in range(26):
				var f: float = float(i)/25.0
				var a5: float = f*TAU*2.8+t*8.2
				var q2: Vector2 = Vector2(cos(a5),sin(a5))*radius*f*0.78
				draw_circle(q2,1.8+1.8*fade,Color(glow.r,glow.g,glow.b,0.72*fade))
				if i % 5 == 0:
					_draw_diamond(q2,2.0+1.6*fade,Color(c.r,c.g,c.b,0.34*fade))

func _draw_shard_choir(progress: float,fade: float,c: Color,glow: Color,ink: Color) -> void:
	var end: Vector2 = direction * radius * (0.88 + 0.18 * progress)
	var normal: Vector2 = Vector2(-direction.y,direction.x)
	var total_lines: int = maxi(5,count_value + 3)
	var choir_width: float = 44.0
	var trail_fill := PackedVector2Array([
		Vector2.ZERO + normal * (-choir_width * 0.55),
		Vector2.ZERO + normal * (choir_width * 0.55),
		end + normal * (choir_width * 0.30),
		end + normal * (-choir_width * 0.30)
	])
	draw_colored_polygon(trail_fill,Color(c.r,c.g,c.b,0.045*fade))
	for i in range(total_lines):
		var f: float = 0.0 if total_lines <= 1 else float(i) / float(total_lines - 1)
		var lane_offset: float = lerpf(-choir_width, choir_width, f)
		var lane_start: Vector2 = normal * lane_offset * 0.32
		var lane_end: Vector2 = end + normal * lane_offset * 0.58
		var lane_mid: Vector2 = lane_start.lerp(lane_end,0.52) + normal * sin(t*11.0 + f*9.0) * 5.0
		var lane_pts: PackedVector2Array = PackedVector2Array([lane_start,lane_mid,lane_end])
		draw_polyline(lane_pts,Color(ink.r,ink.g,ink.b,0.28*fade),4.8)
		draw_polyline(lane_pts,Color(glow.r,glow.g,glow.b,0.26*fade),7.2)
		draw_polyline(lane_pts,Color(c.r,c.g,c.b,0.84*fade),2.2)
		var shard_pos: Vector2 = lane_start.lerp(lane_end,0.35 + 0.45 * progress)
		var shard_angle: float = direction.angle() + 0.35 * sin(t * 12.0 + f * 4.0)
		_draw_shard(shard_pos,shard_angle,9.0 + 5.0 * fade,Color(glow.r,glow.g,glow.b,0.72*fade),Color(ink.r,ink.g,ink.b,0.16*fade))
		if i % 2 == 0:
			var echo_pos: Vector2 = lane_start.lerp(lane_end,0.72)
			_draw_shard(echo_pos,shard_angle + 0.58,5.2 + 3.0 * fade,Color(c.r,c.g,c.b,0.38*fade),Color(ink.r,ink.g,ink.b,0.12*fade))
	var front: Vector2 = end
	var tip_size: float = 18.0 + 10.0 * fade
	for k in range(3):
		var spread: float = float(k - 1) * 0.23
		var tip_dir: Vector2 = direction.rotated(spread).normalized()
		_draw_shard(front + normal * spread * 14.0, tip_dir.angle(), tip_size - absf(spread) * 4.0, Color(glow.r,glow.g,glow.b,0.90*fade), Color(ink.r,ink.g,ink.b,0.22*fade))
	_draw_starburst(front,18.0 + 16.0 * fade,10,Color(c.r,c.g,c.b,0.24*fade))
	draw_arc(front,15.0 + 11.0 * fade,0.0,TAU,28,Color(c.r,c.g,c.b,0.42*fade),1.8)
	for r in range(3):
		var rr: float = 20.0 + 14.0 * float(r) + 18.0 * progress
		draw_arc(front,rr,direction.angle()-0.95,direction.angle()+0.95,28,Color(glow.r,glow.g,glow.b,(0.22 - float(r) * 0.05) * fade),2.4 - float(r) * 0.4)
		_draw_scratch_arc(front,rr*0.88,direction.angle()-0.84,direction.angle()+0.84,7,fade,c,ink)
	for m in range(12):
		var mf: float = float(m) / 11.0
		var arc_offset: float = lerpf(-0.82,0.82,mf)
		var choir_pos: Vector2 = front + direction.rotated(arc_offset) * (26.0 + 12.0 * progress)
		_draw_diamond(choir_pos,2.0 + 2.0 * fade,Color(glow.r,glow.g,glow.b,0.48*fade))

func _draw_activation_sigil(progress: float,fade: float,c: Color,ink: Color) -> void:
	var core_r: float = 12.0+18.0*progress
	var glow: Color = _glow()
	glow.a = 0.20*fade
	draw_circle(Vector2.ZERO,core_r*0.58,Color(c.r,c.g,c.b,0.05*fade))
	draw_arc(Vector2.ZERO,core_r,t*1.8,t*1.8+PI*1.35,26,glow,3.5)
	draw_arc(Vector2.ZERO,core_r,t*1.8,t*1.8+PI*1.35,26,Color(c.r,c.g,c.b,0.26*fade),1.2)
	draw_arc(Vector2.ZERO,core_r*0.62,-t*2.1,-t*2.1+PI*1.15,20,Color(ink.r,ink.g,ink.b,0.22*fade),0.9)
	for i in range(4):
		var a: float = TAU*float(i)/4.0+t*0.8
		var q: Vector2 = Vector2(cos(a),sin(a))*core_r
		_draw_diamond(q,2.2+1.8*fade,Color(c.r,c.g,c.b,0.34*fade))
	for i in range(5):
		var a2: float = -1.0+float(i)*0.50+t*0.16
		var d: Vector2 = Vector2(cos(a2),sin(a2))
		draw_line(d*6.0,d*(17.0+float(i)*2.2),Color(ink.r,ink.g,ink.b,0.14*fade),0.9)

func _draw_lightning(a: Vector2,b: Vector2,c: Color,ink: Color,progress: float) -> void:
	var pts: PackedVector2Array = PackedVector2Array([a])
	for i in range(1,8):
		var f: float = float(i)/8.0
		var base: Vector2 = a.lerp(b,f)
		var normal: Vector2 = Vector2(-(b-a).y,(b-a).x).normalized()
		var jitter: float = sin(float(i)*7.31+t*35.0)*8.5*(1.0-f*0.35)
		pts.append(base+normal*jitter)
	pts.append(b*clampf(0.25+progress*0.9,0.0,1.0))
	draw_polyline(pts,Color(ink.r,ink.g,ink.b,0.44),4.2)
	draw_polyline(pts,Color(c.r,c.g,c.b,0.82),2.0)
	draw_polyline(pts,Color(_glow().r,_glow().g,_glow().b,0.24),6.2)

func _draw_scratch_ring(rr: float,segments: int,fade: float,c: Color,ink: Color) -> void:
	for i in range(segments):
		var a0: float = TAU*float(i)/float(segments)+t*0.42
		var a1: float = a0+0.18+0.08*sin(t*3.0+float(i))
		draw_arc(Vector2.ZERO,rr,a0,a1,8,Color(c.r,c.g,c.b,0.18*fade),1.0)
		draw_arc(Vector2.ZERO,rr*0.92,a0+0.03,a1-0.02,8,Color(ink.r,ink.g,ink.b,0.10*fade),0.7)

func _draw_scratch_arc(center: Vector2,rr: float,start_angle: float,end_angle: float,segments: int,fade: float,c: Color,ink: Color) -> void:
	for i in range(segments):
		var f0: float = float(i) / float(segments)
		var f1: float = float(i + 1) / float(segments)
		var a0: float = lerpf(start_angle,end_angle,f0) + 0.02*sin(t*5.0+float(i))
		var a1: float = lerpf(start_angle,end_angle,f1) - 0.02*cos(t*4.0+float(i))
		draw_arc(center,rr,a0,a1,6,Color(c.r,c.g,c.b,0.14*fade),0.9)
		if i % 2 == 0:
			draw_arc(center,rr*0.96,a0+0.02,a1-0.02,6,Color(ink.r,ink.g,ink.b,0.08*fade),0.6)

func _draw_starburst(center: Vector2,rr: float,spikes: int,color: Color) -> void:
	for i in range(spikes):
		var a: float = TAU*float(i)/float(spikes)+t*0.5
		var q0: Vector2 = center+Vector2(cos(a),sin(a))*rr*0.36
		var q1: Vector2 = center+Vector2(cos(a),sin(a))*rr
		draw_line(q0,q1,color,1.0)

func _draw_diamond(center: Vector2,r: float,color: Color) -> void:
	var poly := PackedVector2Array([center+Vector2(0,-r),center+Vector2(r*0.72,0),center+Vector2(0,r),center+Vector2(-r*0.72,0)])
	draw_colored_polygon(poly,color)

func _draw_shard(center: Vector2,angle: float,size: float,fill: Color,shadow: Color) -> void:
	var dir: Vector2 = Vector2(cos(angle),sin(angle))
	var normal: Vector2 = Vector2(-dir.y,dir.x)
	var tip: Vector2 = center + dir * size
	var tail: Vector2 = center - dir * size * 0.78
	var poly := PackedVector2Array([
		tip,
		center + normal * size * 0.42,
		tail,
		center - normal * size * 0.42
	])
	draw_colored_polygon(poly,shadow)
	draw_colored_polygon(poly,fill)
	draw_line(tail,tip,Color(0.98,0.98,1.0,fill.a*0.58),1.2)
	var cross_a: Vector2 = center + normal * size * 0.26
	var cross_b: Vector2 = center - normal * size * 0.26
	draw_line(cross_a,cross_b,Color(0.98,0.98,1.0,fill.a*0.36),0.9)
