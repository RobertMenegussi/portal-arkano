# BUILD 0723 — XP performance + vase reward pass

## XP performance
- Kept the current XP art, trails, sparks, glow and collection movement.
- Staggered orb redraw timing so large XP clouds do not all redraw on the same frame.
- Added adaptive cosmetic redraw cadence: 24 Hz normally, 18 Hz under medium XP/horde load, 14 Hz under heavy load.
- Orb world movement remains per-frame, so suction/burst motion stays smooth.
- Reduced proximity-check cadence only under load.
- Replaced SceneTree group dispatch on every orb collection with direct controller calls when available.
- Added an XP performance tier that reacts to both live XP count and horde load.

## XP vase
- Now drops 5-10 XP stones total.
- Of those, 1-3 are golden XP stones every vase.
- Keeps the outward explosion + delayed smooth suction animation.
