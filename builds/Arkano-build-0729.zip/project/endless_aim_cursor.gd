extends Node2D

var controller
var t: float = 0.0
var sketch_frame: int = 0
var sketch_timer: float = 0.0
var is_samurai_cursor: bool = false
var player_anchor_global: Vector2 = Vector2.ZERO
var melee_range: float = 96.0
var melee_arc: float = 1.78
var aim_dir: Vector2 = Vector2.RIGHT

func configure(owner_controller) -> void:
	controller = owner_controller

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	z_index = 4000

func _process(delta: float) -> void:
	t += delta
	sketch_timer -= delta
	if sketch_timer <= 0.0:
		sketch_timer = 0.06
		sketch_frame += 1
	if controller == null or not is_instance_valid(controller):
		visible = false
		return
	var show_cursor: bool = bool(controller.run_active) and not bool(controller.pause_open) and not bool(controller.levelup_open) and not bool(controller.dead_open) and not bool(controller.stats_visible) and str(controller.attack_target_mode) == "mouse"
	visible = show_cursor
	if not visible:
		return
	var player = controller.player if controller.get("player") != null else null
	var mouse_pos: Vector2 = get_global_mouse_position()
	is_samurai_cursor = false
	player_anchor_global = Vector2.ZERO
	melee_range = 96.0
	melee_arc = 1.78
	aim_dir = Vector2.RIGHT
	if is_instance_valid(player):
		player_anchor_global = player.global_position
		if player.get("mage_type") == "samurai":
			is_samurai_cursor = true
			melee_range = float(player.get("samurai_range"))
			melee_arc = float(player.get("samurai_arc"))
			var delta_pos: Vector2 = mouse_pos - player.global_position
			if delta_pos.length_squared() > 0.001:
				aim_dir = delta_pos.normalized()
			var dist: float = clampf(delta_pos.length(), 26.0, melee_range)
			global_position = player.global_position + aim_dir * dist
		else:
			global_position = mouse_pos
	else:
		global_position = mouse_pos
	queue_redraw()

func _jitter(index: int, amount: float) -> float:
	return sin(float(sketch_frame) * 2.6 + float(index) * 3.8) * amount

func _draw() -> void:
	if is_samurai_cursor:
		_draw_samurai_cursor()
	else:
		_draw_default_cursor()

func _draw_default_cursor() -> void:
	var ink: Color = Color(0.07, 0.07, 0.07, 0.96)
	var soft: Color = Color(1.0, 1.0, 1.0, 0.07)
	var accent: Color = Color(0.96, 0.95, 0.90, 0.22)
	var pulse: float = 0.92 + sin(t * 6.0) * 0.08
	var ring_r: float = 13.0 + sin(t * 4.2) * 0.5
	for i in range(2):
		var c: Vector2 = Vector2(_jitter(i * 2, 0.55), _jitter(i * 2 + 1, 0.55))
		draw_arc(c, ring_r + float(i) * 4.1, 0.0, TAU, 28, Color(0.08, 0.08, 0.08, 0.16 - float(i) * 0.05), 1.1)
	var diamond: PackedVector2Array = PackedVector2Array([Vector2(0, -5.2), Vector2(5.2, 0), Vector2(0, 5.2), Vector2(-5.2, 0)])
	draw_colored_polygon(diamond, Color(1.0, 1.0, 1.0, 0.04))
	draw_line(Vector2(-18, 0), Vector2(-8, 0), ink, 1.45)
	draw_line(Vector2(18, 0), Vector2(8, 0), ink, 1.45)
	draw_line(Vector2(0, -18), Vector2(0, -8), ink, 1.45)
	draw_line(Vector2(0, 18), Vector2(0, 8), ink, 1.45)
	draw_arc(Vector2.ZERO, 8.7, -0.95, 0.95, 16, ink, 1.1)
	draw_arc(Vector2.ZERO, 8.7, PI - 0.95, PI + 0.95, 16, ink, 1.1)
	draw_circle(Vector2.ZERO, 1.9 + pulse * 0.2, ink)
	draw_circle(Vector2.ZERO, 1.0, Color(1.0, 1.0, 1.0, 0.28))
	for i in range(4):
		var a: float = t * 0.8 + TAU * float(i) / 4.0
		var p: Vector2 = Vector2(cos(a), sin(a)) * (6.8 + pulse)
		draw_circle(p, 0.85, accent)
	for sx in [-1.0, 1.0]:
		for sy in [-1.0, 1.0]:
			var base: Vector2 = Vector2(sx * 13.2, sy * 13.2)
			draw_line(base, base - Vector2(sx * 4.8, 0), soft, 1.0)
			draw_line(base, base - Vector2(0, sy * 4.8), soft, 1.0)

func _draw_samurai_cursor() -> void:
	var ink: Color = Color(0.07, 0.07, 0.07, 0.96)
	var accent: Color = Color(0.86, 0.72, 0.46, 0.28)
	var soft: Color = Color(1.0, 1.0, 1.0, 0.08)
	var pulse: float = 0.95 + sin(t * 7.8) * 0.08
	var local_player: Vector2 = to_local(player_anchor_global)
	var dir: Vector2 = aim_dir.normalized()
	var side: Vector2 = Vector2(-dir.y, dir.x)
	var slash_radius: float = clampf(melee_range * 0.84, 52.0, 96.0)
	var slash_half_arc: float = clampf(melee_arc * 0.46, 0.44, 0.95)
	var slash_fill_alpha: float = 0.060 + sin(t * 6.4) * 0.012
	# slash area preview from the samurai to the edge of the melee cut
	var sector: PackedVector2Array = PackedVector2Array([local_player])
	var sector_steps: int = 14
	for i in range(sector_steps + 1):
		var a: float = dir.angle() - slash_half_arc + (slash_half_arc * 2.0) * (float(i) / float(sector_steps))
		sector.append(local_player + Vector2(cos(a), sin(a)) * slash_radius)
	draw_colored_polygon(sector, Color(accent.r, accent.g, accent.b, slash_fill_alpha))
	draw_arc(local_player, slash_radius, dir.angle() - slash_half_arc, dir.angle() + slash_half_arc, 30, Color(0.08, 0.08, 0.08, 0.11), 1.1)
	draw_arc(local_player, slash_radius - 6.0, dir.angle() - slash_half_arc * 0.88, dir.angle() + slash_half_arc * 0.88, 24, Color(accent.r, accent.g, accent.b, 0.16), 1.0)
	var edge_a: Vector2 = local_player + Vector2(cos(dir.angle() - slash_half_arc), sin(dir.angle() - slash_half_arc)) * slash_radius
	var edge_b: Vector2 = local_player + Vector2(cos(dir.angle() + slash_half_arc), sin(dir.angle() + slash_half_arc)) * slash_radius
	draw_line(local_player, edge_a, Color(accent.r, accent.g, accent.b, 0.10), 1.0)
	draw_line(local_player, edge_b, Color(accent.r, accent.g, accent.b, 0.10), 1.0)
	# tether so the player reads the melee direction instantly
	draw_line(local_player, Vector2.ZERO, Color(0.07, 0.07, 0.07, 0.10), 1.0)
	draw_line(local_player.lerp(Vector2.ZERO, 0.18), Vector2.ZERO, Color(accent.r, accent.g, accent.b, 0.18), 1.2)
	# slash halo / melee endpoint
	var arc_r: float = 15.5 + pulse * 1.1
	draw_arc(Vector2.ZERO, arc_r, dir.angle() - 1.10, dir.angle() + 1.10, 26, Color(0.08, 0.08, 0.08, 0.16), 1.2)
	draw_arc(Vector2.ZERO, arc_r - 3.1, dir.angle() - 0.78, dir.angle() + 0.78, 20, Color(accent.r, accent.g, accent.b, 0.22), 1.6)
	# blade marker
	var tip: Vector2 = dir * (9.0 + pulse * 0.6)
	var blade: PackedVector2Array = PackedVector2Array([
		tip + side * 1.0,
		dir * 17.5,
		tip - side * 1.0,
		dir * 3.5 - side * 1.4
	])
	draw_colored_polygon(blade, Color(1.0, 1.0, 1.0, 0.12))
	draw_polyline(PackedVector2Array([blade[0], blade[1], blade[2], blade[3], blade[0]]), ink, 1.0)
	# cross guard / handle cue
	draw_line(-side * 4.8, side * 4.8, Color(accent.r, accent.g, accent.b, 0.26), 1.2)
	draw_line(-dir * 4.2, dir * 3.4, ink, 1.2)
	# twin slash marks so it reads as melee and unique
	for i in range(2):
		var offset: float = 6.5 + float(i) * 4.0
		var start: Vector2 = -dir * 3.0 + side * (-4.0 + float(i) * 8.0)
		var end: Vector2 = dir * (offset + pulse * 1.5) + side * (2.5 + float(i) * 1.6)
		draw_line(start, end, Color(1.0, 1.0, 1.0, 0.10 - float(i) * 0.02), 1.0)
	# edge brackets
	var edge: float = 18.5
	draw_line(dir * edge + side * 6.0, dir * (edge + 6.0) + side * 10.0, soft, 1.0)
	draw_line(dir * edge - side * 6.0, dir * (edge + 6.0) - side * 10.0, soft, 1.0)
	draw_circle(Vector2.ZERO, 1.3, ink)
	draw_circle(Vector2.ZERO, 0.6, Color(1.0, 1.0, 1.0, 0.28))
