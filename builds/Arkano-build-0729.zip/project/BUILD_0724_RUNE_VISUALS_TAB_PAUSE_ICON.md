# BUILD 0724 — Rune visuals, TAB pause/read mode, icon pass

## Game icon
- Added the approved black/white sketch icon as `arkano_icon.png`.
- Added a multi-size Windows `arkano_icon.ico` (16/24/32/48/64/128/256).
- `project.godot` now points to both the project icon and Windows native icon.

## Rune fixes / clarity
- Added a safety pass so acquired Vitality ranks can never lose their maximum-health bonus during upgrade rebuilds.
- Maximum-health increases still heal the newly added health immediately.
- Rewrote Style Rune trigger descriptions so they state the trigger and cooldown directly instead of saying “when the Rune is ready”.

## Rune visuals
- Every acquired Rune now produces an acquisition burst.
- Every acquired Rune contributes a subtle category glyph to the player’s ambient Rune field.
- Foundation Runes have their own low-cost persistent visual signatures.
- Style Runes show compact cooldown/proc glyph feedback around the player.
- Style Rune proc VFX gained an additional activation sigil, ink scratches and extra layered details.

## TAB build panel
- TAB is now a toggle instead of hold-to-view.
- Opening TAB pauses the SceneTree and freezes run time/gameplay.
- Mouse becomes visible for reading/interacting with the build panel.
- Click any Rune to open a large full-description view.
- Mouse wheel scrolls the Rune list when there are many Runes.
- TAB or ESC closes the build panel and resumes the run.
- Tutorial text/logic updated for the new TAB behavior in EN / PT-BR / JA / ES.
