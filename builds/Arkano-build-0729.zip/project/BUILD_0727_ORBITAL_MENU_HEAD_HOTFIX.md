# BUILD 0727 — Orbital menu head hotfix

- Fixed the Orbital mascot/menu mage head floating above its body.
- Moved the head down into the correct silhouette.
- Added a small neck/collar bridge so the head and mantle read as one character.
- Updated mouse eye-tracking origin to match the corrected head position.
- No rune/gameplay balance changes from 0726.
