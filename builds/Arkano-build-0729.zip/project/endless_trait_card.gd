extends Button

const EndlessCatalog = preload("res://endless_catalog.gd")

var trait_id: String = ""
var title_text: String = ""
var description_text: String = ""
var mage_type: String = "orbit"
var rare: bool = false
var hover_t: float = 0.0
var pressed_t: float = 0.0
var hovered: bool = false
var down: bool = false
var t: float = 0.0
var stat_lines: Array = []

func configure(id_value: String, title_value: String, description_value: String, class_value: String, is_rare: bool, stats_value: Array = []) -> void:
	trait_id = id_value
	title_text = title_value
	description_text = description_value
	mage_type = class_value
	rare = is_rare
	stat_lines = stats_value.duplicate(true)
	queue_redraw()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	focus_mode = Control.FOCUS_NONE
	mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	text = ""
	flat = true
	mouse_entered.connect(func(): hovered = true)
	mouse_exited.connect(func(): hovered = false; down = false)
	button_down.connect(func(): down = true)
	button_up.connect(func(): down = false)
	var clear: StyleBoxFlat = StyleBoxFlat.new()
	clear.bg_color = Color(0, 0, 0, 0)
	for state in ["normal", "hover", "pressed", "focus", "disabled"]:
		add_theme_stylebox_override(state, clear)

func _process(delta: float) -> void:
	t += delta
	hover_t = move_toward(hover_t, 1.0 if hovered else 0.0, delta * 8.5)
	pressed_t = move_toward(pressed_t, 1.0 if down else 0.0, delta * 18.0)
	queue_redraw()

func _draw() -> void:
	var lift: float = -7.0 * hover_t + 2.0 * pressed_t
	var rect: Rect2 = Rect2(Vector2(2, 10 + lift), size - Vector2(4, 16))
	var outline: Color = Color("#111513")
	var panel_bg: Color = Color(0.96, 0.95, 0.91, 0.98) if not rare else Color(0.98, 0.93, 0.83, 0.98)
	var rune_color: Color = _category_color()
	var accent: Color = Color(rune_color.r,rune_color.g,rune_color.b,0.10 if not rare else 0.18)
	draw_rect(Rect2(rect.position + Vector2(0, 8), rect.size), Color(0, 0, 0, 0.18 + hover_t * 0.06), true)
	draw_rect(rect, panel_bg, true)
	for i in range(3):
		draw_rect(rect.grow(-float(i) * 1.6), Color(0.06, 0.07, 0.06, 0.16 if i < 2 else 0.52), false, 1.0)
	var seam_alpha: float = 0.16 if not rare else 0.28
	draw_rect(Rect2(rect.position + Vector2(10, 10), Vector2(rect.size.x - 20, 28)), accent, true)
	draw_line(rect.position + Vector2(12, 44), Vector2(rect.end.x - 12, rect.position.y + 44), Color(0.12, 0.10, 0.07, seam_alpha), 1.0)
	var icon_center := Vector2(rect.position.x + 36, rect.position.y + 27)
	draw_circle(icon_center, 21.0, Color(rune_color.r,rune_color.g,rune_color.b,0.18 if rare else 0.13))
	draw_circle(icon_center, 16.5, Color(1, 1, 1, 0.16 if rare else 0.10))
	var icon_ink: Color = outline.lerp(rune_color,0.36)
	_draw_icon(icon_center, 18.0, icon_ink)
	var font = ThemeDB.fallback_font
	if font == null:
		return
	var title_x: float = rect.position.x + 66.0
	var title_w: float = rect.size.x - 84.0
	var title_size: int = _fit_font(font, title_text, 15, title_w, 10)
	draw_string(font, Vector2(title_x, rect.position.y + 30), title_text, HORIZONTAL_ALIGNMENT_LEFT, title_w, title_size, outline)
	var rarity_text: String = Loc.t("rune.rare") if rare else Loc.t("rune.arcane")
	draw_string(font, Vector2(title_x, rect.position.y + 41), rarity_text, HORIZONTAL_ALIGNMENT_LEFT, title_w, 8, Color(0.08, 0.09, 0.08, 0.46))
	var rank_level: int = EndlessCatalog.get_rank_level(trait_id)
	var rank_max: int = EndlessCatalog.get_rank_max(trait_id)
	if rank_level > 0 and rank_max > 0:
		var pip_start_x: float = rect.end.x - 12.0 - float(rank_max) * 9.0
		for rank_i in range(rank_max):
			var rank_rect := Rect2(Vector2(pip_start_x + float(rank_i) * 9.0, rect.position.y + 34), Vector2(6, 6))
			draw_rect(rank_rect, Color(0.08, 0.09, 0.08, 0.66 if rank_i < rank_level else 0.12), true)
	var desc_height: float = 108.0 if stat_lines.size() > 0 else rect.size.y - 88.0
	_draw_wrapped(font, description_text, Rect2(rect.position + Vector2(18, 62), Vector2(rect.size.x - 36, desc_height)), 11, Color(0.08, 0.09, 0.08, 0.70))
	if stat_lines.size() > 0:
		_draw_stat_lines(font, Rect2(rect.position + Vector2(18, 178), Vector2(rect.size.x - 36, 80)))
	var y: float = rect.end.y - 20.0
	draw_line(Vector2(rect.position.x + 18, y), Vector2(lerpf(rect.position.x + 52, rect.end.x - 18, hover_t), y), Color(0.08, 0.09, 0.08, 0.20 + hover_t * 0.25), 1.3)
	if hover_t > 0.15:
		draw_string(font, Vector2(rect.position.x + 18, rect.end.y - 7), Loc.t("rune.choose"), HORIZONTAL_ALIGNMENT_LEFT, rect.size.x - 36, 9, Color(0.08, 0.09, 0.08, 0.48 * hover_t))

func _draw_stat_lines(font, rect: Rect2) -> void:
	var y: float = rect.position.y + 10.0
	var green: Color = Color("#2f9657")
	var red: Color = Color("#b44343")
	var neutral: Color = Color(0.08, 0.09, 0.08, 0.54)
	for line_value in stat_lines:
		if y > rect.end.y - 4.0:
			break
		var line: Dictionary = line_value
		var label: String = str(line.get("label", ""))
		var current: String = str(line.get("current", ""))
		var delta: String = str(line.get("delta", ""))
		var pct: String = str(line.get("pct", ""))
		var sign_value: int = int(line.get("sign", 0))
		var accent: Color = green if sign_value > 0 else (red if sign_value < 0 else neutral)
		draw_string(font, Vector2(rect.position.x, y), label, HORIZONTAL_ALIGNMENT_LEFT, 82, 9, neutral)
		if current != "":
			draw_string(font, Vector2(rect.position.x + 84, y), current, HORIZONTAL_ALIGNMENT_LEFT, 48, 9, Color(0.08, 0.09, 0.08, 0.70))
		var delta_x: float = rect.position.x + 134.0 if current != "" else rect.position.x + 84.0
		draw_string(font, Vector2(delta_x, y), delta, HORIZONTAL_ALIGNMENT_LEFT, maxf(40.0, rect.end.x - delta_x), 9, accent)
		if pct != "":
			draw_string(font, Vector2(rect.end.x - 58.0, y), pct, HORIZONTAL_ALIGNMENT_RIGHT, 58, 8, accent)
		y += 18.0

func _category_color() -> Color:
	var category: String = EndlessCatalog.get_category(trait_id)
	match category:
		"DAMAGE": return Color("#db866f")
		"WEAPON": return Color("#d5bd76")
		"MOVEMENT": return Color("#78b6d5")
		"SURVIVAL": return Color("#7fb786")
		"UTILITY": return Color("#79c5c3")
		"CONTROL": return Color("#9d83d4")
		_: return Color("#d6d0bf")

func _draw_icon(center: Vector2, radius: float, ink: Color) -> void:
	var idx: int = 0
	if trait_id.begins_with("endless_"):
		idx = int(trait_id.substr(8))
	else:
		for char_i in range(trait_id.length()):
			idx += trait_id.unicode_at(char_i) * (char_i + 1)
	var family: int = absi(idx) % 30
	draw_arc(center, radius, 0.0, TAU, 24, Color(0.08, 0.09, 0.08, 0.30), 1.2)
	draw_circle(center, radius * 0.78, Color(1, 1, 1, 0.26 if rare else 0.20))
	match family % 10:
		0:
			draw_line(center + Vector2(-8, 0), center + Vector2(8, 0), ink, 2.0)
			draw_circle(center + Vector2(5, 0), 3.0, ink)
		1:
			_draw_diamond(center, 8.0, ink)
		2:
			for i in range(3):
				draw_arc(center, 5.0 + float(i) * 3.0, -1.0, 1.0, 12, ink, 1.2)
		3:
			draw_arc(center, 9.0, -PI * 0.5, PI * 1.25, 20, ink, 1.8)
			draw_line(center + Vector2(-7, -5), center + Vector2(-11, -1), ink, 1.5)
		4:
			draw_line(center + Vector2(-9, 7), center + Vector2(9, -7), ink, 2.0)
			draw_line(center + Vector2(2, -8), center + Vector2(9, -7), ink, 1.4)
		5:
			for i in range(3):
				var a: float = t * 0.8 + float(i) * TAU / 3.0
				draw_circle(center + Vector2(cos(a), sin(a)) * 8.0, 2.4, ink)
		6:
			draw_circle(center, 4.0, ink)
			draw_arc(center, 10.0, 0.0, TAU, 20, ink, 1.2)
		7:
			draw_polyline(PackedVector2Array([center + Vector2(-8, 6), center + Vector2(-2, -1), center + Vector2(1, 4), center + Vector2(8, -7)]), ink, 2.0)
		8:
			draw_arc(center, 9.0, 0.0, TAU, 20, ink, 1.4)
			draw_circle(center, 2.6, ink)
		9:
			draw_line(center + Vector2(-7, 7), center + Vector2(0, -8), ink, 2.0)
			draw_line(center + Vector2(0, -8), center + Vector2(7, 7), ink, 2.0)
	if mage_type == "storm":
		draw_line(center + Vector2(11, -10), center + Vector2(8, -3), Color(0.08, 0.09, 0.08, 0.42), 1.0)
	elif mage_type == "rift":
		draw_line(center + Vector2(11, -9), center + Vector2(7, 2), Color(0.08, 0.09, 0.08, 0.42), 1.0)
	else:
		draw_circle(center + Vector2(11, -9), 1.8, Color(0.08, 0.09, 0.08, 0.42))

func _draw_diamond(center: Vector2, radius: float, color: Color) -> void:
	var poly: PackedVector2Array = PackedVector2Array([center + Vector2(0, -radius), center + Vector2(radius, 0), center + Vector2(0, radius), center + Vector2(-radius, 0)])
	draw_colored_polygon(poly, color)

func _fit_font(font, value: String, requested: int, max_width: float, minimum: int) -> int:
	var result: int = requested
	while result > minimum and font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, result).x > max_width:
		result -= 1
	return result

func _draw_wrapped(font, text_value: String, rect: Rect2, font_size: int, color: Color) -> void:
	var line: String = ""
	var y: float = rect.position.y + float(font_size)
	if not text_value.contains(" "):
		for i in range(text_value.length()):
			var char_value: String = text_value.substr(i, 1)
			var candidate: String = line + char_value
			if font.get_string_size(candidate, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x > rect.size.x and line != "":
				draw_string(font, Vector2(rect.position.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x, font_size, color)
				y += float(font_size) + 5.0
				line = char_value
				if y > rect.end.y - float(font_size):
					return
			else:
				line = candidate
	else:
		var words: PackedStringArray = text_value.split(" ")
		for word_value in words:
			var word: String = str(word_value)
			var candidate: String = word if line == "" else line + " " + word
			if font.get_string_size(candidate, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x <= rect.size.x:
				line = candidate
			else:
				draw_string(font, Vector2(rect.position.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x, font_size, color)
				y += float(font_size) + 5.0
				line = word
				if y > rect.end.y - float(font_size):
					return
	if line != "" and y <= rect.end.y:
		draw_string(font, Vector2(rect.position.x, y), line, HORIZONTAL_ALIGNMENT_LEFT, rect.size.x, font_size, color)
